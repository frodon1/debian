#ifndef __Viscoelastic_terms__
#define __Viscoelastic_terms__

#include <Pointer.h> 
#include <Material_piece.h> 
#include <Behavior.h> 

Z_START_NAMESPACE;

ZCLASS VE_SHEAR : public MATERIAL_PIECE {
 public : 
   TENSOR2_VAUX   v_dev;
   COEFF     tau, omega;
   COEFF     gamma;
   VE_SHEAR(ASCII_FILE& file,
         MATERIAL_PIECE* boss,
         int name_index, 
         bool classic_names=0);
     RTTI_INFO;
};

ZCLASS VE_VOLUMIC : public MATERIAL_PIECE {
 public : 
   SCALAR_VAUX    v_vol;
   COEFF          tau, omega;
   COEFF     gamma;
   VE_VOLUMIC(ASCII_FILE& file, 
           MATERIAL_PIECE* boss,
           int name_index, 
           bool classic_names=0);
     RTTI_INFO;
};

ZCLASS VE_VOLUMIC_SIMO : public MATERIAL_PIECE {
 public : 
   TENSOR2_VAUX   v_vol;
   COEFF          tau, omega;
   VE_VOLUMIC_SIMO(ASCII_FILE& file, 
           MATERIAL_PIECE* boss,
           int name_index, 
           bool classic_names=0);
     RTTI_INFO;
};

ZCLASS VE_SHIFT_FUNCTION : public MATERIAL_PIECE {
 public :
   VE_SHIFT_FUNCTION(); 
   virtual ~VE_SHIFT_FUNCTION(); 
   virtual void initialize(ASCII_FILE& file, MATERIAL_PIECE* boss);

   virtual double compute(); 
   virtual double compute(double temp_in, double& dshift_dtemp); 
     RTTI_INFO;
};


// 
// Here's a module for adding standard prony series viscoelastic 
// relaxations to a model. The code was 1st done up in gen_evp but 
// I'm trying here to make it re-usable within different frameworks 
// 
// The model however reads a little different notation, with gamma 
// and tau being as defined in Simo and Hughes 
// 
ZCLASS VE_STANDARD_COMPONENT : public MATERIAL_PIECE { 
   public: 
     STRING star_level;  // default "**" meaning break on next **
     PLIST<VE_SHEAR>   shear;
     PLIST<VE_VOLUMIC> volumic;


     // 
     // Default model. 
     // 
     SMATRIX Cel;
     MATRIX stor_v;
     TENSOR2 unity;
     TENSOR2 vtmp;
     MATRIX        Va, Ua; 
     SCALAR_VAUX   ev;
     COEFF   gamma_inf;
     double  dtst;
     double  edtst;
     double  factor;
     TENSOR2 dalpha;

     VECTOR  s_gamma;
     VECTOR  v_gamma;
     double  s_gamma_sum;
     double  v_gamma_sum;


     int mode_modulus_inf;

     PTR<VE_SHIFT_FUNCTION> shift;

     VE_STANDARD_COMPONENT(); 
     virtual ~VE_STANDARD_COMPONENT(); 
     virtual void initialize(ASCII_FILE& file, MATERIAL_PIECE* boss); 
     virtual bool base_read(STRING& str, ASCII_FILE& file); 
     static  VE_STANDARD_COMPONENT* read(ASCII_FILE& file, MATERIAL_PIECE* b);

     virtual bool calc_coef();

     virtual void add_classical_viscoelasticity(double use_dt,
                                                TENSOR2& sig,
                                                TENSOR2& sig_ini,
                                                MATRIX& tangent, int flags);

     virtual void compute_modified_tangent(MATRIX& new_el, MATRIX& el);
     RTTI_INFO;

}; 

Z_END_NAMESPACE;
#endif

