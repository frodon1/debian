#ifndef __PHASEFIELD_REMESH_H__
#define __PHASEFIELD_REMESH_H__

#include<Quad_to_lin.h>
#include<Lin_to_quad.h>
#include <Transfer_standard.h>  //zTransfer
#include <Utility_z8_results.h>
#include <Yams.h>  //Mother class zTransfer

Z_START_NAMESPACE;

class PHASEFIELD_REMESH : public YAMS_GHS3D    
{
 private:
  double dispersion;
  double max_density;

  bool diffusion_remeshing_criterion;
  bool phase_field_remeshing_criterion;
  bool mechanical_remeshing_criterion;
  bool quad;


  enum PROG {LINEAR,  QUADRATIC};

  STRING inp_file_name;
  VECTOR Phi_at_nodes;
  UTILITY_MESH* initial_mesh;
 
  void nodal_interpolation(ARRAY<UTILITY_NODE*> &nodes,VECTOR& values,VECTOR& point_value);
  void verify();

 protected:


 public :
  PHASEFIELD_REMESH();
  virtual ~PHASEFIELD_REMESH() {};

  bool GetResponse(STRING key, ASCII_FILE &inp);
  void apply(UTILITY_MESH& mesh);
  virtual bool provide_surfacic_density(){return(TRUE);}
  virtual void surfacic_density(ARRAY<UTILITY_NODE*> &nodes, VECTOR &densities, bool);
};

Z_END_NAMESPACE;

#endif //__PHASEFIELD_REMESH_H__
