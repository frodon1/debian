#ifndef __CB_SHELL_H__
#define __CB_SHELL_H__

#include <GMesh.h>
#include <P_element.h>
#include <Layer_geom_info.h>
#include <Space.h>
#include <Space_with_section.h>
#include <Graphics_data_dialog.h>
#include <Graphics_command.h>
#include <Utility_shell_elements.h>

Z_START_NAMESPACE;

/*

FF, march 3rd, 2009

A Continuum-Based (aka "CB") shell.

See for instance:

Non linear finite elements for continua and structures
Ted Belytschko, Wing Kam Liu and Brian Moran
Wiley 2000

*/

class CB_SHELL_GI : public LAYER_GEOM_INFO
{
  protected :
    UTILITY_MESH *its_mesh;
    GRAPHICS_DATA_DIALOG *its_dialog;
    UTILITY_ELSET *current_elset;
    STRING current_elset_name;
    MESH_INFO_READER *current_mr;

  public :
    double thickness,alpha;
    int gauss;
    bool use_local_frame,locking_control;

    CB_SHELL_GI();
    virtual ~CB_SHELL_GI() { }

    virtual bool GetResponse(ASCII_FILE&,const STRING&);
    virtual void post_initialize();

    virtual void read(Zifstream &f) { f>>thickness; LAYER_GEOM_INFO::read(f); }
    virtual void write(Zofstream &f) { f<<"cb_shell "<<thickness<<"\n"; LAYER_GEOM_INFO::write(f); }
    virtual void mesh_loaded(UTILITY_MESH*);

    virtual void click(MESH_INFO_READER &mir, STRING &eset_name, UTILITY_ELSET *eset);
    virtual bool do_command(STRING cmd);
    void set_state(int s);

    RTTI_INFO;
};


class CB_SHELL_D_ELEMENT_CALLBACK;
class CB_SHELL_ELEMENT_CALLBACK;

class CB_SHELL : public P_ELEMENT
{
  protected :
    P_ELEMENT *inside;
    GEOMETRY  *inside_geometry;
    MATRIX inside_coord,elem_coord;
    CB_SHELL_D_ELEMENT_CALLBACK *my_callback;
    CB_SHELL_ELEMENT_CALLBACK *my_element_callback;
    CB_SHELL_GI *cb_gi;
    VECTOR inside_d_dof_tot , inside_d_dof_incr;
    ARRAY<GNODE*> inside_nodes;
    ARRAY<TENSOR2> shell_rotations;
    MATRIX T,t; SMATRIX local_frame;
    STRING inside_elem_type;
    bool make_node,first_time,always_change_geom;
    int dim;

    void compute_inside_coord();

  public :
    CB_SHELL() : P_ELEMENT() { inside=NULL; inside_geometry=NULL; my_callback=NULL; cb_gi=NULL; my_element_callback=NULL; }
    virtual ~CB_SHELL() { }

    virtual void setup_dofs(const char* key);
    virtual bool verification();
    virtual void initialize_element(const ARRAY<GNODE*>& element_nodes,
                              GMESH* the_mesh_it_belongs_to,
                              GEOMETRY* element_geometry,
                              char *the_im,
                              int element_id,
                              const char* ele_type);
    virtual void check_for_section(GEOMETRY* geo,
                                     GMESH* m,
                                     BUFF_LIST<UTILITY_ELSET*>& esets);
    virtual void set_material(ARRAY<BEHAVIOR*>&,PLIST<MATERIAL_DATA_INIT>&,ARRAY<LOCAL_FRAME*>&);

    virtual void get_position_of_integration_point(ARRAY<VECTOR>& gp_positions,bool use_coord=FALSE)const;
    virtual void get_position_of_integration_point(VECTOR& gp_position,bool use_coord=FALSE)const;
    virtual ARRAY<LOCAL_FRAME*>& get_rotation();
    virtual int nb_gp_tot()const;

    virtual INTEGRATION_RESULT* internal_reaction(bool,VECTOR&,SMATRIX&, bool get_only_tg_matrix=FALSE);



    virtual void start(const MATRIX &ec) { D_ELEMENT::start(ec); }
    virtual void start() const { D_ELEMENT::start(); }

    virtual void next(const MATRIX &ec) { D_ELEMENT::next(ec); }
    virtual void next()const { D_ELEMENT::next(); }
    virtual void reset() { inside->reset(); }
//    virtual int  ok() const { return(inside->ok()); }

    void  fail();


    virtual void size_mat_data(int nb_mat_data);
    virtual MAT_DATA& pub_mat_data() { return inside->pub_mat_data(); }
    virtual MAT_DATA& pub_mat_data(int i) { return inside->pub_mat_data(i); }
    virtual const MAT_DATA& pub_mat_data()const { return inside->pub_mat_data(); }

    void get_elem_d_dof_tot_cb (VECTOR& elem_d_dof_tot) const;
    void get_elem_d_dof_incr_cb (VECTOR& elem_d_dof_incr) const;

    void get_elem_coord_cb (MATRIX& elem_coord,bool use_coord) const ;
    void get_elem_coord_cb (VECTOR& elem_coord,int icoord,bool use_coord) const ;

    virtual void cal_val_at_node_from_integration(const STRING& var_name,VECTOR& val_node)const;
    virtual void cal_val_at_node_from_integration(int ivar , ARRAY<BEHAVIOR*>& behavior_index , ARRAY< BUFF_LIST<int> >& key_indices, VECTOR& val_node)const;
    virtual bool cal_val_at_integration(int ivar , ARRAY<BEHAVIOR*>& behavior_index , ARRAY< BUFF_LIST<int> >& key_indices, VECTOR& val)const;
    virtual bool cal_val_at_integration(const STRING& var_name,VECTOR& val_gp) const;

    virtual void cal_val_at_node_from_integration(VECTOR &val_gp,VECTOR& val_node)const;
    virtual void cal_val_at_integration_from_node(VECTOR &val_gp,VECTOR& val_node)const;

    virtual void cal_contour_outputs(const STRING& var_name,VECTOR& val_node);

    virtual void  cal_contour_outputs(int ivar , ARRAY<BEHAVIOR*>& behavior_index , ARRAY< BUFF_LIST<int> >& key_indices ,VECTOR& val_node);

    virtual int  nb_contour_nodal_outputs();

    virtual void write_restart(RST_FSTREAM& file) const ;
    virtual void read_restart(RST_FSTREAM& file);

    virtual void init() { P_ELEMENT::init(); inside->init(); }
    virtual void init_iterations() { P_ELEMENT::init_iterations(); inside->init_iterations(); }
    virtual void set_main_sequence(void *v) { P_ELEMENT::set_main_sequence(v); inside->set_main_sequence(v); }

    virtual void init_external_parameter( const ARRAY<EXTERNAL_PARAM*> &p );

    virtual void compute_mass_matrix(MATRIX&);
    virtual void compute_param_value() { 
      P_ELEMENT::compute_param_value(); 
      inside->compute_param_value(); 
    }
    virtual void reinit() { inside->reinit(); }

    virtual VECTOR compute_reac_centrifugal_node(double dist_axe,int dir,bool if_actualized);
    virtual VECTOR compute_reac_gravity_node(); 
    virtual VECTOR compute_reac_gravity_dof(const VECTOR& g); 

    P_ELEMENT* get_inside() { return inside; }

    RTTI_INFO;
};




class CB_SHELL_D_ELEMENT_CALLBACK : public D_ELEMENT::D_ELEMENT_CALLBACK
{
  public :
    CB_SHELL *boss;

    CB_SHELL_D_ELEMENT_CALLBACK() { boss=NULL; }
    virtual ~CB_SHELL_D_ELEMENT_CALLBACK() { }

    virtual void get_elem_d_dof_tot (VECTOR& elem_d_dof_tot) const { boss->get_elem_d_dof_tot_cb(elem_d_dof_tot); }
    virtual void get_elem_d_dof_incr (VECTOR& elem_d_dof_incr) const { boss->get_elem_d_dof_incr_cb(elem_d_dof_incr); }
};

class CB_SHELL_ELEMENT_CALLBACK : public ELEMENT::ELEMENT_CALLBACK
{
  public :
    CB_SHELL *boss;

    CB_SHELL_ELEMENT_CALLBACK() { boss=NULL; }
    virtual ~CB_SHELL_ELEMENT_CALLBACK() { }

    virtual void get_elem_coord (MATRIX& elem_coord,bool use_coord=FALSE) const {
      boss->get_elem_coord_cb(elem_coord,use_coord);
    }
    virtual void get_elem_coord (VECTOR& elem_coord,int icoord,bool use_coord=FALSE) const {
      boss->get_elem_coord_cb(elem_coord,icoord,use_coord);
    }
};

Z_END_NAMESPACE;

#endif
