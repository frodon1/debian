#ifndef __Utility_relations__
#define __Utility_relations__

// ---------------------------------------------------------------------------- 
// Assorted classes/functions for mesh entity relationships   RF June 05 2004 
// 
// These are meant as a means to implement the relationship changes from 8.4 
// without needing to keep all that connection stuff in tow for every problem. 
//
// I think having the connectivity is better along the side because 
//  1) save mem when not using this. 
//  2) we generate the info when we need it... not costly, and there 
//     were a lot of mesh.reestablish_connectivity calls all over the place 
//     to be safe. 
//  3) we're in control of what we want at a particular time. 
//  4) simple translations of the 8.3/8.4 code. 
//
// UTILITY_REL_MESH rel_mesh(mesh); 
// UTILITY_NODE* nd = mesh->find_node(id); 
// UTILITY_REL_NODE& rel_node = rel_mesh.nodes[nd->give_rank()]; 
// for (i=0;i<rel_node.attached_elements.size();i++) {
//      ... 
// }
// ---------------------------------------------------------------------------- 

#include <Buffered_list.h> 
#include <Utility_elements.h>
#include <Gauge.h>

Z_START_NAMESPACE;

class UTILITY_NODE;
class UTILITY_ELEMENT;
class UTILITY_MESH;

class UTILITY_REL_NODE;
class UTILITY_REL_ELEMENT;
class UTILITY_REL_EDGE;
class UTILITY_REL_FACE;

ZCLASS UTILITY_REL_ENTITY : public Z_OBJECT
{
  protected :
    char     _type[12];
    int      _id,_rank;

  public :
    const int &id,&rank;
    int color; // the 'color' refers here to an int marker, and not a real color, of course
    STRING   type;

    BUFF_LIST<UTILITY_REL_ELEMENT*> &attached_elements;

    BUFF_LIST<UTILITY_REL_NODE*>     nodes;
    BUFF_LIST<UTILITY_REL_ELEMENT*>  elements;
    BUFF_LIST<UTILITY_REL_FACE*>     faces;
    BUFF_LIST<UTILITY_REL_EDGE*>     edges;

    UTILITY_REL_ENTITY();
   ~UTILITY_REL_ENTITY();

    inline void set_rank(int i) { _rank=i; }
    inline void set_id(int i) { _id=i; }

    inline int give_rank() { return(rank); }
    inline int give_id() { return(id); }

    UTILITY_REL_ENTITY& operator=(const UTILITY_REL_ENTITY&);

    RTTI_INFO;
};

ZCLASS UTILITY_REL_NODE  : public UTILITY_REL_ENTITY
{ 
  public: 
    UTILITY_NODE *real_node;

    UTILITY_REL_NODE(UTILITY_NODE*); 
    UTILITY_REL_NODE(); 

    const UTILITY_NODE& real() { return(*real_node); }
}; 

WIN_THINGIE unsigned int HASH_FUNCTION_UTILITY_REL_NODE(UTILITY_REL_NODE* const &);

ZCLASS UTILITY_REL_ELEMENT : public UTILITY_REL_ENTITY
{
  public: 
    UTILITY_ELEMENT *real_element;

    UTILITY_REL_ELEMENT(UTILITY_ELEMENT*); 
    UTILITY_REL_ELEMENT(); 

    virtual void initialize(const STRING& the_type);

    const UTILITY_ELEMENT& real() { return(*real_element); }

    static UTILITY_REL_ELEMENT* make(const STRING& the_type);
    static UTILITY_REL_ELEMENT* make(const STRING& the_type, int nb);

    virtual void build_faces(BUFF_LIST<UTILITY_REL_FACE*>&); // return faces for this element
    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE*>&); // return edges for this element WHICH ARE NOT attached to a face

    virtual void to_quadratic();
  
    RTTI_INFO;
};

WIN_THINGIE unsigned int HASH_FUNCTION_UTILITY_REL_ELEMENT(UTILITY_REL_ELEMENT* const &);

ZCLASS UTILITY_REL_FACE : public UTILITY_REL_ENTITY
{
  public :
    UTILITY_REL_FACE();

    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE*>&)=0;

    bool operator==(const UTILITY_REL_FACE&)const;
    bool operator!=(const UTILITY_REL_FACE& in) const { return (*this==in) ? FALSE : TRUE; }
    bool same(const UTILITY_REL_FACE&)const;

    virtual void to_quadratic();

    RTTI_INFO;
};

WIN_THINGIE unsigned int HASH_FUNCTION_UTILITY_REL_FACE(UTILITY_REL_FACE* const &);

ZCLASS UTILITY_REL_EDGE : public UTILITY_REL_ENTITY
{
  public :
    UTILITY_REL_EDGE();

    bool operator==(const UTILITY_REL_EDGE&)const;
    bool operator!=(const UTILITY_REL_EDGE& in) const { return (*this==in) ? FALSE : TRUE; }
    bool same(const UTILITY_REL_EDGE&)const;

    virtual void to_quadratic(BUFF_LIST<UTILITY_NODE*>&,BUFF_LIST<UTILITY_REL_NODE*>&);

    RTTI_INFO;
};

WIN_THINGIE unsigned int HASH_FUNCTION_UTILITY_REL_EDGE(UTILITY_REL_EDGE* const &);


ZCLASS UTILITY_REL_MESH 
{ 
   protected: 
     UTILITY_MESH* its_boss; 
     LIST<UTILITY_REL_ELEMENT*> element_blocks;
     LIST<UTILITY_REL_NODE*>    node_blocks;

     void build_nodes_elements();

   public: 
     GAUGE *gauge;

     BUFF_LIST<UTILITY_REL_NODE*>      nodes; 
     BUFF_LIST<UTILITY_REL_ELEMENT*>   elements; 
     HASHED_LIST<UTILITY_REL_EDGE*>    edges;
     HASHED_LIST<UTILITY_REL_FACE*>    faces;

     ~UTILITY_REL_MESH();
     UTILITY_REL_MESH();
     UTILITY_REL_MESH(UTILITY_MESH*);

     void build_faces(HASHED_LIST<UTILITY_REL_FACE*>& faces, ARRAY<UTILITY_REL_ELEMENT*>& elem_in, bool whole=FALSE);
     void build_edges(HASHED_LIST<UTILITY_REL_EDGE*>& edges, HASHED_LIST<UTILITY_REL_FACE*>& faces, bool whole=FALSE);

     void reset(UTILITY_MESH *boss);
     void reset(UTILITY_MESH *boss, ARRAY<UTILITY_ELEMENT*>&);
     void reestablish_connectivity(UTILITY_MESH *boss); 
     void reestablish_connectivity(); 
     void reestablish_full_connectivity(bool handle_edges=FALSE);

     void clear(); 
};
Z_END_NAMESPACE;

#endif
