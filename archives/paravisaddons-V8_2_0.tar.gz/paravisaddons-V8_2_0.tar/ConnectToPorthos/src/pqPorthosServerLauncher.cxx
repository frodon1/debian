/*=========================================================================
 Developed for EDF by Kitware SAS.
 Copyright (c) Kitware SAS 2015
 All rights reserved.
 More information http://www.kitware.fr
=========================================================================*/
#include "pqPorthosServerLauncher.h"
#include "ui_pqPorthosServerLauncher.h"
#include "pqPorthosConfig.h"

// Server/Manager Includes.
#include "vtkPVXMLElement.h"

// Qt Includes.
#include <QDir>
#include <QDebug>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QLabel>
#include <QLineEdit>
#include <QProcess>
#include <QProgressBar>
#include <QPushButton>
#include <QSpinBox>
#include <QProcessEnvironment>

// ParaView Includes.
#include "pqApplicationCore.h"
#include "pqCoreUtilities.h"
#include "pqEventDispatcher.h"
#include "pqServer.h"
#include "pqServerConfiguration.h"
#include "pqServerLauncher.h"
#include "pqServerResource.h"
#include "pqSettings.h"

const char pqPorthosServerLauncher::PARAVISADDONS_ROOT_DIR[]="PARAVISADDONS_ROOT_DIR";
const char pqPorthosServerLauncher::ASK_PATH_EXE[]="PorthosAskPass";

static const QString ENABLED_PROGRESS_BAR_STYLE = "QProgressBar { border: 2px solid grey; border-radius: 5px; background-color: red; text-align: center } QProgressBar::chunk { background-color: green;  width: 1px;    }";
//-----------------------------------------------------------------------------
class pqPorthosServerLauncher::pqInternals
{
public:
  Ui::pqPorthosServerLauncher* SlurmWidget;
  QPushButton* okButton;
  QPushButton* cancelButton;
  QSpinBox* nbNodesSpinBox;
  QWidget* slurmTimeWidget;
};


//-----------------------------------------------------------------------------
pqPorthosServerLauncher::pqPorthosServerLauncher(const pqServerConfiguration& config, QObject* parentObject)
  : Superclass(pqPorthosServerLauncher::clean(config), parentObject),
  Internals(new pqPorthosServerLauncher::pqInternals())
{
  this->Internals->SlurmWidget = new Ui::pqPorthosServerLauncher();
  this->Internals->nbNodesSpinBox = NULL;
  this->Internals->slurmTimeWidget = NULL;

  QString serverType;
  vtkPVXMLElement* tmpXML = config.hintsXML();
  if( tmpXML != NULL )
    {
    tmpXML = tmpXML->FindNestedElementByName("ServerType");
    if( tmpXML != NULL )
      {
      serverType = tmpXML->GetAttribute("value");
      }
    }
  this->ConfigIsSlurm = (serverType == "slurm");
}

//-----------------------------------------------------------------------------
pqPorthosServerLauncher::~pqPorthosServerLauncher()
{
  delete this->Internals->SlurmWidget;
  this->Internals->SlurmWidget = NULL;
}

//-----------------------------------------------------------------------------
pqServerConfiguration pqPorthosServerLauncher::clean(const pqServerConfiguration& config)
{
  pqServerConfiguration slurmConfig = config.clone();
  pqServerResource resource = slurmConfig.resource();
  QString host = resource.host();
  QString slurmHost = "slurm-";
  if (host.left(slurmHost.size()) == slurmHost)
    {
    resource.setHost(host.right(host.size() - slurmHost.size()));
    slurmConfig.setResource(resource);
    }
  return slurmConfig;
}

//-----------------------------------------------------------------------------
void pqPorthosServerLauncher::prepareDialogForPromptOptions(QDialog& dialog)
{
  this->Superclass::prepareDialogForPromptOptions(dialog);
  if (!this->ConfigIsSlurm) { return; }

  // Set Slurm Server Host, without the slurm prefix
  this->options().insert("SLURM_SERVER_HOST", this->options().value("PV_SERVER_HOST"));

  // Set SSH ASKPASS
  QProcessEnvironment environment(QProcessEnvironment::systemEnvironment());
  QString PARAVISADDONS_ROOT_DIRValue(environment.value(PARAVISADDONS_ROOT_DIR));
  QString locToPorthosAskPass;
  if(!PARAVISADDONS_ROOT_DIRValue.isEmpty())
    {
      
      QString s(QDir::toNativeSeparators(QString("%1/bin/%2").arg(PARAVISADDONS_ROOT_DIRValue).arg(ASK_PATH_EXE)));
      QFileInfo fis(s);
      if(fis.exists())
        locToPorthosAskPass=s;
      else
        locToPorthosAskPass=QString("Regarding var \"%1\" with value \"%2\", file \"%3\" is supposed to exist ! BUT It does not exist !").arg(PARAVISADDONS_ROOT_DIR).arg(PARAVISADDONS_ROOT_DIRValue).arg(s);
    }
  else
    {
      locToPorthosAskPass=QString("Var %1 is not defined ! Invalid env !").arg(PARAVISADDONS_ROOT_DIR);
    }
  this->options().insert("SSH_ASKPASS",locToPorthosAskPass);

  // Recover pqSettings
  pqSettings* settings = pqApplicationCore::instance()->settings();
  settings->beginGroup("SlurmPlugin");

  // setup the dialog using the configuration's XML.
  dialog.setWindowTitle("Slurm Control");

  // Adding Widget to layout
  QFormLayout* connectionLayout = qobject_cast<QFormLayout*>(dialog.layout());

  // Setup Slurm Ui
  connectionLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);

  // Set vertical stretch for all widget from formLayout
  int count = connectionLayout->count();
  for (int i = 0; i<count; i++)
    {
      QWidget* wdg = connectionLayout->itemAt(i)->widget();
      if (wdg != NULL)
        {
        QSizePolicy pol = wdg->sizePolicy();
        pol.setVerticalStretch(1);
        wdg->setSizePolicy(pol);
        }
    }

  //Switch layouts
  QWidget tmp;
  tmp.setLayout(connectionLayout);
  this->Internals->SlurmWidget->setupUi(&dialog);
  this->Internals->SlurmWidget->ConnectionOptions->setLayout(connectionLayout);

  // Available Nodes widgets
  this->Internals->SlurmWidget->availableNodesButton->setIcon(QApplication::style()->standardIcon(QStyle::SP_BrowserReload));
  this->connect(this->Internals->SlurmWidget->availableNodesButton, SIGNAL(clicked()), this, SLOT(updateAvailableNodes()));

  // Finding Info widget if any
  count = connectionLayout->count();
  QString clusterInfoName = "INFO";
  QLineEdit* clusterInfo;
  for (int i = 0; i<count; i++)
    {
    if (connectionLayout->itemAt(i)->widget()->objectName() == clusterInfoName)
      {
      clusterInfo = qobject_cast<QLineEdit*>(connectionLayout->itemAt(i)->widget());
      break;
      }
    }
  if (clusterInfo != NULL)
    {
    QLabel* clusterInfoLabel = qobject_cast<QLabel*>(connectionLayout->labelForField(clusterInfo));
    clusterInfo->setParent(&dialog);
    clusterInfoLabel->setParent(&dialog);
    clusterInfo->hide();
    clusterInfoLabel->hide();

    // Host Labels
    this->Internals->SlurmWidget->clusterLabel->setText(this->Internals->SlurmWidget->clusterLabel->text() + "<a href=\"" + clusterInfo->text() + "\">" + this->options().value("SLURM_SERVER_HOST") + "</a>");
    this->Internals->SlurmWidget->clusterLabel->setTextFormat(Qt::RichText);
    this->Internals->SlurmWidget->clusterLabel->setTextInteractionFlags(Qt::TextBrowserInteraction);
    this->Internals->SlurmWidget->clusterLabel->setOpenExternalLinks(true);
    this->Internals->SlurmWidget->clusterLabel->setToolTip(clusterInfoLabel->text());
    }
  else
    {
    this->Internals->SlurmWidget->clusterLabel->setText(this->Internals->SlurmWidget->clusterLabel->text() + this->options().value("SLURM_SERVER_HOST"));
    }

  // Finding nb nodes spinbox if any
  count = connectionLayout->count();
  QString slurmNodeWidgetName = "SLURM_NODES";
  for (int i = 0; i<count; i++)
    {
    if (connectionLayout->itemAt(i)->widget()->objectName() == slurmNodeWidgetName)
      {
      this->Internals->nbNodesSpinBox = qobject_cast<QSpinBox*>(connectionLayout->itemAt(i)->widget());
      break;
      }
    }
  if (this->Internals->nbNodesSpinBox != NULL)
    {
    QWidget* nbNodesLabel = connectionLayout->labelForField(this->Internals->nbNodesSpinBox);
    this->Internals->nbNodesSpinBox->setEnabled(false);

    // Moving nb nodes spinbox to slurm layout
    this->Internals->SlurmWidget->clusterLayout->addWidget(nbNodesLabel, 2, 0);
    this->Internals->SlurmWidget->clusterLayout->addWidget(this->Internals->nbNodesSpinBox, 2, 1, 1, 2);
    }

  // Finding time edit spinbox if any
  count = connectionLayout->count();
  QString slurmTimeWidgetName = "SLURM_TIME";
  for (int i = 0; i<count; i++)
    {
    if (connectionLayout->itemAt(i)->widget()->objectName() == slurmTimeWidgetName)
      {
      this->Internals->slurmTimeWidget = connectionLayout->itemAt(i)->widget();
      break;
      }
    }
  if (this->Internals->slurmTimeWidget != NULL)
    {
    QWidget* slurmTimeLabel = connectionLayout->labelForField(this->Internals->slurmTimeWidget);
    this->Internals->slurmTimeWidget->setEnabled(false);

    // Moving slurm time spinbox to slurm layout
    this->Internals->SlurmWidget->clusterLayout->addWidget(slurmTimeLabel, 3, 0);
    this->Internals->SlurmWidget->clusterLayout->addWidget(this->Internals->slurmTimeWidget, 3, 1, 1, 2);
    }

  // Disable OK button and move buttons
  QDialogButtonBox* buttons = qobject_cast<QDialogButtonBox*>(connectionLayout->itemAt(connectionLayout->rowCount() - 1, QFormLayout::SpanningRole)->widget());
  this->Internals->okButton = buttons->button(QDialogButtonBox::Ok);
  this->Internals->cancelButton = buttons->button(QDialogButtonBox::Cancel);
  this->Internals->okButton->setEnabled(false);
  this->Internals->okButton->setText("Launch And Connect");
  this->Internals->SlurmWidget->dialogLayout->addWidget(buttons, this->Internals->SlurmWidget->dialogLayout->rowCount(), 0, 1, this->Internals->SlurmWidget->dialogLayout->columnCount());
  settings->endGroup();
}

//-----------------------------------------------------------------------------
void pqPorthosServerLauncher::updateAvailableNodes()
{
  // Update options first
  this->updateOptionsUsingUserSelections();

  // Generate sinfo command
  QString command = this->sshCommandString();
  command.append(" \"sinfo -N\"");

  this->CaptureProcessStreams = true;
  // Execute command
  if (this->processCommand(command, 2, -1))
    {
    this->waitForOutputString(5000);
    // Recover nodes
    int availableNodes, totalNodes;
    if (this->parseUpdateString(this->LastStdOut, availableNodes, totalNodes))
      {
      if (totalNodes > 0)
        {
        this->Internals->SlurmWidget->availableNodesBar->setMaximum(totalNodes);
        this->Internals->SlurmWidget->availableNodesBar->setValue(availableNodes);

        // Enable available nodes
        this->Internals->SlurmWidget->availableNodesBar->setStyleSheet(ENABLED_PROGRESS_BAR_STYLE);
        this->Internals->SlurmWidget->availableNodesBar->setFormat(QString::number(availableNodes) + " avail / " + QString::number(totalNodes) + " total");

        // If there is availabled nodes
        if (availableNodes > 0)
          {

          // Enable widgets
          this->Internals->slurmTimeWidget->setEnabled(true);
          this->Internals->nbNodesSpinBox->setEnabled(true);
          this->Internals->okButton->setEnabled(true);

          //Set nbNode spinbox max
          if (this->Internals->nbNodesSpinBox != NULL)
              this->Internals->nbNodesSpinBox->setMaximum(availableNodes);
          }
        }
      }
    }
  this->CaptureProcessStreams = false;
}

//-----------------------------------------------------------------------------
bool pqPorthosServerLauncher::connectToPrelaunchedServer()
{
  bool ret = this->Superclass::connectToPrelaunchedServer();
  if (ret && this->ConfigIsSlurm)
    {
    // We set again the slurm server host with slum prefix,
    // so it is displayed in the gui and the recent connection works.
    pqServer* server = pqApplicationCore::instance()->getActiveServer();
    pqServerResource resource = server->getResource();
    resource.setHost(this->options().value("SLURM_SERVER_HOST"));
    server->setResource(resource);
    }
  return ret;
}

//-----------------------------------------------------------------------------
bool pqPorthosServerLauncher::launchServer(bool show_status_dialog)
{
  if (!this->ConfigIsSlurm)
    {
    return this->Superclass::launchServer(show_status_dialog);
    }

  this->CaptureProcessStreams = true;
  this->clearProcessOutputs();

  if (!this->Superclass::launchServer(show_status_dialog))
    {
    this->CaptureProcessStreams = false;
    return false;
    }

  this->waitForOutputString(5000);

  QString computeNodeHost;
  if (!this->parseSrunCommandOutput(this->LastStdErr, computeNodeHost))
    {
    qCritical() << "No compute node host or ip, aborting connection." << endl
      << "You may need to cancel the slurm job manually if it successfully launched" << endl;
    }
  pqServerConfiguration &config = this->configuration();
  pqServerResource resource = config.resource();
  resource.setHost(computeNodeHost);
  config.setResource(resource);
  this->CaptureProcessStreams = false;
  return true;
}

//-----------------------------------------------------------------------------
bool pqPorthosServerLauncher::processCommand(QString command, double timeout, double delay)
{
  // Create QProcess and connects signals
  this->clearProcessOutputs();

  QProcessEnvironment env =  QProcessEnvironment::systemEnvironment();
  return this->Superclass::processCommand(command, timeout, delay, &this->options());
}

//-----------------------------------------------------------------------------
void pqPorthosServerLauncher::handleProcessStandardOutput(const QByteArray& data)
{
  // Nodes list: names and states
  if (this->CaptureProcessStreams)
    {
    this->LastStdOut += data.data();
    }

  this->Superclass::handleProcessStandardOutput(data);
}

//-----------------------------------------------------------------------------
void pqPorthosServerLauncher::handleProcessErrorOutput(const QByteArray& data)
{
  if (this->CaptureProcessStreams)
    {
    this->LastStdErr += data.data();
    }

  this->Superclass::handleProcessErrorOutput(data);
}

//-----------------------------------------------------------------------------
void pqPorthosServerLauncher::clearProcessOutputs()
{
  this->LastStdErr.clear();
  this->LastStdOut.clear();
}

//-----------------------------------------------------------------------------
bool pqPorthosServerLauncher::parseUpdateString(QString updateString, int& availableNodes, int& totalNodes)
{
  // Parse the provided string, execting to be formatted in a very strict way
  availableNodes = 0;
  totalNodes = 0;

  // Cut lines by lines
  QStringList stringList = updateString.split(QRegExp("[\r\n]"), QString::SkipEmptyParts);

  // Check First line is as expected
  if (stringList.size() > 0)
    {
    QString firstLine(stringList[0].trimmed());
    QStringList columnsLegend(firstLine.split(QRegExp("[\\s]+")));
    if (columnsLegend.size() != 4 || columnsLegend[0] != "NODELIST" ||
        columnsLegend[1] != "NODES" || columnsLegend[2] != "PARTITION" ||
        columnsLegend[3] != "STATE")
      {
      qCritical() << "Unexpected Update String:" << updateString;
      return false;
      }
    }
  else
    {
      qCritical() << "Unexpected Empty Update String";
      return false;
    }

  // Remove first line
  stringList.removeAt(0);

  // For each line
  foreach (QString string, stringList)
    {
    // Cut by space
    QStringList lineList = string.split(" ", QString::SkipEmptyParts);
    if (lineList.size() != 4)
      {
      qCritical() << "Unexpected Update String:"<< updateString;
      return false;
      }

    // Consider only cg nodes
    if (lineList[2].contains("cg"))
      {
      // Check if node is idle
      if (lineList[3] == "idle")
        {
        availableNodes += lineList[1].toInt();
        }
      totalNodes += lineList[1].toInt();
      }
    }
  return true;
}

//-----------------------------------------------------------------------------
bool pqPorthosServerLauncher::parseEDFSlurmOutput(QString edfSlurmOutput, QString& computeNodeHost)
{
  std::cerr << computeNodeHost.toStdString() << " ***** " << edfSlurmOutput.toStdString() << std::endl;
  // Search for ipaddress in provided string
  QStringList stringList = edfSlurmOutput.split(QRegExp("[\r\n]"), QString::SkipEmptyParts);
  foreach (QString string, stringList)
    {
    if (string.contains("ipaddress"))
      {
      int firstChar = string.indexOf(">") + 1;
      int nChar =  string.lastIndexOf("<") - firstChar;
      computeNodeHost = string.mid(firstChar, nChar);
      return true;
      }
    }
  qCritical() << "Cannot find ip adress in EDF Slurm Output String:" << edfSlurmOutput;
  return false;
}

//-----------------------------------------------------------------------------
bool pqPorthosServerLauncher::parseSrunCommandOutput(QString srunCommandOutput, QString& computeNodeHost)
{
  // Search for ipaddress in provided string
  //std::cerr << computeNodeHost.toStdString() << " ***** " << srunCommandOutput.toStdString() << std::endl;
  QStringList stringList = srunCommandOutput.split(QRegExp("[\r\n]"), QString::SkipEmptyParts);
  foreach (QString string, stringList)
    {
    if (string.contains("srun: launching"))
      {
      if (string.endsWith("0"))
        {
	QString trigger1 = "host";
        int firstChar = string.indexOf(trigger1) + trigger1.length() + 1;
        int nChar =  string.lastIndexOf(",") - firstChar + 1;
        computeNodeHost = string.mid(firstChar, nChar);
        // Convert node name into IP based on first pocg001 ip 10.114.116.201
        computeNodeHost = "10.114.116." + QString::number(200 + string.mid(firstChar+4, 3).toLong());
        return true;
	}
      }
    }
    qCritical() << "Cannot find node name in srun Command Output String:" << srunCommandOutput;
    return false;
}


//-----------------------------------------------------------------------------
bool pqPorthosServerLauncher::waitForOutputString(int msTime)
{
  int timeCount = 0;
  int timeStep = 100;
  while (this->LastStdOut.isEmpty() && timeCount < msTime)
    {
    pqEventDispatcher::processEventsAndWait(static_cast<int>(timeStep));
    timeCount += timeStep;
    }
}

//-----------------------------------------------------------------------------
QString pqPorthosServerLauncher::sshCommandString()
{
  QString command("setsid ssh -Y ");
  QString user = this->options().value("SLURM_USER");
  if (!user.isEmpty())
    {
    command.append(user);
    command.append("@");
    }
  command.append(this->options().value("SLURM_SERVER_HOST"));
  return command;
}
