#ifndef __Math_object__
#define __Math_object__

// ============================================================================ 
//  MATH_OBJECT Base class for Z-set math objects, handling basic flags, etc 
//
//  o status is essentially a mutable member. 
//  o RF 02/26/2002  I put the implementations back inline in the class def 
// ============================================================================ 

#include <Defines.h> 

Z_START_NAMESPACE;

#define K ((MATH_OBJECT*)this)

ZCLASS MATH_OBJECT {
  public :
    enum { bad=1, 
           is_sub=2, 
           has_sub=4,
           temporary=8, 
           diagonal=16, 
           STATIC=32 ,
           read_only=64,
           math_obj_flag1=128,
           math_obj_flag2=256,
           math_obj_flag3=512,
           math_obj_flag4=1024
    } ;

    int status;

    inline MATH_OBJECT(int ist=0) : status(ist) {}

    inline void reset_status()const             { K->status  = 0; }
    inline void unset_temporary()const          { K->status &= ~temporary; }

    inline void set_is_sub()const               { K->status |= is_sub; }
    inline void set_has_sub()const              { K->status |= has_sub; }
    inline void set_temporary()const { 
         if (status && status!=temporary)  { }
         else {
              K->status = temporary;
         }
    }

    inline void set_bad()const                  { K->status |= bad; }
    inline void set_diagonal()const             { K->status |= diagonal; }
    inline void set_read_only()const            { K->status |= read_only; }

    inline int if_ok_to_swap()const             { return (status && status!=temporary) ? 0 : 1; }

    inline int if_is_sub()const                 { return status&is_sub; }
    inline int if_has_sub()const                { return status&has_sub; }

    inline int if_temporary()const              { return status&temporary; }
    inline int if_bad()const                    { return status&bad; }
    inline int if_diagonal()const               { return status&diagonal; }
    inline int if_static()const                 { return status&STATIC; }

    inline int confirm_status_is_ok()const      { return (status>=0 && status<=64) ? 1 : 0; }
    inline int check_status_eq_zero()const      { return status==0; } 
};
#undef K
Z_END_NAMESPACE;

#endif
