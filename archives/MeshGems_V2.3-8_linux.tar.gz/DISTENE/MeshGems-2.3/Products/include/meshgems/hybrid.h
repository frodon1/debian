#ifndef __MESHGEMS_HYBRID_H__
#define __MESHGEMS_HYBRID_H__

#include "meshgems/meshgems.h"
#include "meshgems/hybrid_short_names.h"

/**

 \page sessions Sessions

 \htmlonly <hr width=50%> \endhtmlonly

 \section session_hexa Hexa Session

 An hexa session object (of type hexa_session) is an object describing an Hexa run.
 It makes the link between the input mesh and parameters, the meshing process and the resulting mesh recovery.

 */

/*
 * \defgroup hexa Hybrid Session
 *@{*/

struct meshgems_hybrid_session_t_;

/**
 * Opaque type to store session data.
 */
typedef struct meshgems_hybrid_session_t_ meshgems_hybrid_session_t;

/**
 * Get the meshgems hybrid major version number.
 * @return the major version number of the called library
 */
MESHGEMS_METHOD meshgems_integer meshgems_hybrid_get_version_major(void);

/**
 * Get the meshgems hybrid minor version number.
 * @return the minor version number of the called library
 */
MESHGEMS_METHOD meshgems_integer meshgems_hybrid_get_version_minor(void);

/**
 * Get the meshgems hybrid patch version number.
 * @return the patch version number of the called library
 */
MESHGEMS_METHOD meshgems_integer meshgems_hybrid_get_version_patch(void);

/**
 * Get the meshgems hybrid version string.
 * @return the version string of the called library
 */
MESHGEMS_METHOD const char *meshgems_hybrid_hybrid_version_string(void);

/**
 * \weakgroup hybrid Module hybrid
 *@{*/

/**
 * \defgroup hybrid_init_del hybrid Session Constructor and Destructor
 * \ingroup hybrid
 *@{*/

/**
 * Simple constructor.
 *
 * @param[in]	ctx	: the context this session is attached to.
 *
 * @retval "a new hybrid_session_t" on success;
 *
 * @retval NULL on failure.
 */
MESHGEMS_METHOD meshgems_hybrid_session_t *meshgems_hybrid_session_new(
		meshgems_context_t *ctx);

/**
 * Destructor.
 *
 * @param[in]	hxs	: the hybrid session (is freed and \b unusable afterwards).
 */
MESHGEMS_METHOD void meshgems_hybrid_session_delete(
		meshgems_hybrid_session_t *hxs);

/*@}*/

/**
 * \defgroup hybrid_callbacks hybrid Session Callbacks
 * \ingroup hybrid
 *@{*/

/**
 * Sets the message callback function.
 *
 * This is where the user should detect and print phase changes,
 * timings, intersections, ...
 *
 * @param[in]	hxs	: the hybrid session.
 * @param[in]	cb	: the message callback (or NULL to remove any previous callback and use the callback from the context)
 * @param[in]	user_data	: the user pointer which will be given to cb as a parameter
 *
 *  @retval STATUS_OK or another STATUS_* in case of error
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_message_callback(
		meshgems_hybrid_session_t *hxs, meshgems_message_callback_t cb,
		void *user_data);

/**
 * Sets the interrupt callback function.
 *
 * This is where the user indicates if he wants the process to
 * end the ongoing session call.
 *
 * @param[in]	hxs	: the hybrid session.
 * @param[in]	cb	: the interrupt callback (or NULL to remove any previous callback and use the callback from the context)
 * @param[in]	user_data	: the user pointer which will be given to cb as a parameter
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_interrupt_callback(
		meshgems_hybrid_session_t *hxs, meshgems_interrupt_callback_t cb,
		void *user_data);

/*@}*/

/**
 * \defgroup hybrid_input_mesh hybrid Session Input Parameters
 * \ingroup hybrid
 *@{*/

/**
 * Sets required surface mesh and entities.
 *
 * Defines the skins (external and internal) of mesh (vertices and
 * elements) as well as all the required entities, "floating" or not
 * (vertices, edges or elements).
 *
 * @param[in]	hxs	: the hybrid session.
 * @param[in]	m	: the \ref mesh_t object holding the required vertices and elements.
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_surface_mesh(
		meshgems_hybrid_session_t *hxs, meshgems_mesh_t *m);


/**
 * Sets volume mesh and entities to be optimised.
 *
 * Defines the input volume mesh (vertices and
 * elements) as well as all the required entities, "floating" or not
 * (vertices, edges or elements).
 *
 * @param[in]	hxs	: the hybrid session.
 * @param[in]	m	: the \ref mesh_t object holding the required vertices and elements.
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD status_t meshgems_hybrid_set_volume_mesh(meshgems_hybrid_session_t *hys,
meshgems_mesh_t *m);

/**
 * Sets a sizemap.
 *
 * @param[in]	hxs	: the hybrid session;
 * @param[in]	s : the sizemap.
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_sizemap(
		meshgems_hybrid_session_t *hxs, meshgems_sizemap_t *s);

/**
 * Sets a parameter.
 *
 * This function allows setting:
 * @li verbose level;
 * @li octree's subdivision level;
 * @li element's size;
 * @li sub-domain mode generation;
 * @li sharp angle threshold;
 * @li geometric approximation threshold;
 * @li ...
 *
 * @param[in]	hxs : the hybrid session;
 * @param[in]	param_name : the option name whose value will be changed;
 * @param[in]	option_value : new option value.
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_param(
		meshgems_hybrid_session_t *hxs, const char *param_name,
		const char *option_value);

/**
 * Sets boundary layers local parameters.
 *
 * This function allows setting:
 * @li a reference defining a part of the surface where boundary layers are requested;
 * @li the height of the first layer on this part;
 *
 * @param[in]	hxs : the hybrid session;
 * @param[in]	blref : a reference defining a part of the surface where boundary layers are requested;
 * @param[in]	height : the height of the first layer;
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_initial_height_on_surface_tag(
		meshgems_hybrid_session_t *hxs, meshgems_integer blref,
		meshgems_real height);


/**
 * Sets boundary layer imprinting parameters.
 *
 * This function allows setting:
 * @li a list of references defining the parts of the surface where boundary layers have to be imprinted;
 *
 * @param[in]	hxs : the hybrid session;
 * @param[in]	iref : a reference defining a part of the surface where boundary layers are requested;
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_boundary_layer_imprinting_tag(
		meshgems_hybrid_session_t *hxs, meshgems_integer iref);

/**
 * Sets boundary layer snapping parameters.
 *
 * This function allows setting:
 * @li a list of references defining the parts of the surface where boundary layers have to be imprinted;
 *
 * @param[in]	hxs : the hybrid session;
 * @param[in]	iref : a reference defining a part of the surface where boundary layers are requested;
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_boundary_layer_snapping_tag(
		meshgems_hybrid_session_t *hxs, meshgems_integer iref);
/*@}*/

/**
 * \defgroup hybrid_gene_mesh hybrid Session Actions
 * \ingroup hybrid
 *@{*/

/**
 * Generate a mesh.
 *
 * @param[in]	hxs : the hybrid session. This session must have been
 *   given a surface mesh with hybrid_set_surface_mesh().
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_compute_mesh(
		meshgems_hybrid_session_t *hxs);


/**
 * optimize a mesh.
 *
 * @param[in]	hxs : the hybrid session. This session must have been
 *   given a volume mesh with hybrid_set_volume_mesh().
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_optimise_volume(meshgems_hybrid_session_t *hys);

/*@}*/

/**
 * \defgroup hybrid_output_mesh hybrid Session Mesh Access
 * \ingroup hybrid
 *@{*/

/**
 * Returns the mesh within current session.  Session cannot be
 * modified afterwards unless mesh is released.
 *
 * @param[in]	hxs : the hybrid session;
 * @param[out]	msh : the \ref mesh_t.
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_get_mesh(
		meshgems_hybrid_session_t *hxs, meshgems_mesh_t **msh);

/*@}*/

/*@}*/

/*@}*/

/*@}*/

/**
 * Gives the mesh control back to the current session.  Session and
 * object can be modified afterwards.
 *
 * @param[in]	hxs	: the hybrid session
 * @param[in]	msh	: the \ref mesh_t (is freed and \b unusable afterwards).
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_regain_mesh(
		meshgems_hybrid_session_t *hxs, meshgems_mesh_t *msh);

/* Private and undocumented methods */

/**
 * Sets boundary layers imprinting surface.
 *
 * This function allows setting:
 * @li a list of references defining the parts of the surface where boundary layers have to be imprinted;
 *
 * @param[in]	hxs : the hybrid session;
 * @param[in]	iref : a reference defining a part of the surface where boundary layers are requested;
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_boundary_layers_imprint_id(
		meshgems_hybrid_session_t *hxs, meshgems_integer iref);


/**
 * Sets boundary layer imprinting parameters.
 *
 * This function allows setting:
 * @li a list of references defining the parts of the surface where boundary layers have to be imprinted;
 *
 * @param[in]	hxs : the hybrid session;
 * @param[in]	iref : a reference defining a part of the surface where boundary layers are requested;
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_boundary_layers_imprint_tags(
		meshgems_hybrid_session_t *hxs, meshgems_integer iref);

/**
 * Sets boundary layers parameters.
 *
 * This function allows setting:
 * @li a list of references defining the parts of the surface where boundary layers are requested;
 * @li the direction of the boundary layers;
 * @li the number of layers;
 * @li the height of the first layer;
 *
 * @param[in]	hxs : the hybrid session;
 * @param[in]	blref : a reference defining a part of the surface where boundary layers are requested;
 * @param[in]	nbref : number of references
 * @param[in]	in_outward : the direction of the boundary layers;
 * @param[in]	height : the height of the first layer;
 * @param[in]	nblayer : the number of boundary layers ;
 * @param[in]	geometric_growth : the geometric progression between successive layers;
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_boundary_layers_parameter_onref(
		meshgems_hybrid_session_t *hxs, meshgems_integer blref,
		meshgems_integer in_outward, meshgems_real height,
		meshgems_integer nblayer, meshgems_real geometric_growth);

/**
 * Sets a boundary layers surface id.
 *
 * This function allows setting:
 * @li a references defining a part of the surface where boundary layers are requested;
 *
 * @param[in]	hxs : the hybrid session;
 * @param[in]	blref : a reference defining a part of the surface where boundary layers are requested;
 *
 * @retval STATUS_OK or another STATUS_* in case of error
 *
 */
MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_boundary_layers_surface_id(
		meshgems_hybrid_session_t *hxs, meshgems_integer iref);

typedef status_t (*meshgems_boundary_layer_height_t)(real hn, integer n, real *hn1, void * user_data);

MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_set_boundary_layers_height(
		meshgems_hybrid_session_t *hxs, meshgems_boundary_layer_height_t f, void * u);

/**
 * Get the meshgems hybrid ident string.
 * @return the version string of the called library
 */
MESHGEMS_METHOD const char *meshgems_hybrid_get_version_ident_string(void);

MESHGEMS_METHOD meshgems_status_t meshgems_hybrid_session_set_banner(
		meshgems_hybrid_session_t *hxs, meshgems_integer type);

#endif
