//
// Gosselet 2004, Generic iterative solvers (mostly used with generic_dd)
// see P. Gosselet thesis (2003), nice paper soon
//
// The general minimum residual method (see Saad)
// suited to general matrices, reputed to be robust
//
#ifndef __N_GMRES_SOLVER__
#define __N_GMRES_SOLVER__

#include <Krylov_iterative_solver.h>

Z_START_NAMESPACE;

class N_GMRES_SOLVER : public KRYLOV_ITERATIVE_SOLVER {
  protected :
    MATRIX hessem;
    SMATRIX hessem_store;
    VECTOR beta,givenscos,givenssin;
    int cols;
    void compute_solution(AUTO_PTR<VECTOR_LIKE>)const;

  public :
    N_GMRES_SOLVER() : KRYLOV_ITERATIVE_SOLVER() { }
    virtual ~N_GMRES_SOLVER() { }
    virtual void loop();

    virtual void set_parameter(SOLVER_PARAMETER *sp) {
      KRYLOV_ITERATIVE_SOLVER::set_parameter(sp);
//PI      parameters->ortho_type="mgskss";
      parameters->ortho_type="gskss";
    }
    
    virtual void give_hessem(SMATRIX &H){prn("HHH",hessem_store);H.reassign(niter,hessem_store,0,0);}
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
