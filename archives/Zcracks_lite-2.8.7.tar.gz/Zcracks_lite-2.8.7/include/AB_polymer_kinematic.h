#ifndef __AB_polymer_kinematic__ 
#define __AB_polymer_kinematic__

// ----------------------------------------------------------------------------  
//  AB_POLYMER_KINEMATIC class for storage of kinematic model.. the state variables 
//  are however kept and managed in the behavior itself. 
// ----------------------------------------------------------------------------  

#include <Bool.h>
#include <Hierarchy.h>
#include <List.h>
#include <ZMath.h>
#include <Zminmax.h>

#include <Coefficient.h>
#include <Int_variable_holder.h>
#include <Material_piece.h>
#include <Special_vector.h>

Z_START_NAMESPACE;

class AB_POLYMER_KINEMATIC : public MATERIAL_PIECE { 
  public : 
    double dtime; 

    AB_POLYMER_KINEMATIC();
    AB_POLYMER_KINEMATIC(const AB_POLYMER_KINEMATIC& iso,
                                       MATERIAL_PIECE* boss );
    virtual ~AB_POLYMER_KINEMATIC();

    virtual void initialize(ASCII_FILE&,MATERIAL_PIECE* boss);
    virtual MATERIAL_PIECE* copy_self(MATERIAL_PIECE*);

    static  AB_POLYMER_KINEMATIC* read(ASCII_FILE& file, MATERIAL_PIECE* b);

    virtual void pre_step(TENSOR2& Fb_t); 

    virtual TENSOR2 compute(const TENSOR2& F); 
    virtual TENSOR2 compute_recovery(TENSOR2& Bhat, double Deq);
    virtual MATRIX  dB_dFb(const TENSOR2& F);
    virtual SMATRIX drec_dB(); 

    virtual TENSOR2 drec_dDeq(); 

    virtual void deriv_wrt(TENSOR2& dX_dw, TENSOR2& drec_dw, const char* what); 
     RTTI_INFO;
}; 

Z_END_NAMESPACE;

#endif 
