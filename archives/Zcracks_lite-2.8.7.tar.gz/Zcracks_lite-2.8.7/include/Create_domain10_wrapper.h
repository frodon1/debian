#ifndef __CREATE_DOMAIN10_WRAPPER__
#define __CREATE_DOMAIN10_WRAPPER__

#include <List.h>
#include <Stringpp.h>
#include <Geometry_parts.h>
#include <Dao_create_domain10.h>

Z_START_NAMESPACE;

class CREATE_DOMAIN10_WRAPPER
{
  public :
    int read_plane_norm;
    VECTOR plane_norm;

    CREATE_DOMAIN10_WRAPPER();
    virtual ~CREATE_DOMAIN10_WRAPPER();

    void create_domain(STRING tag_name, STRING elset_name, DOMAIN10_CREATE_COMMAND::METHOD , 
      DOMAIN10_CREATE_COMMAND::KINEMATIC_ORDER ,
      DOMAIN10_CREATE_COMMAND::INTEGRATION_MODE , 
      DOMAIN10_CREATE_COMMAND::TYPE , LIST<DAO_EDGE*>& , STRING angle, STRING prop, STRING seam , STRING close);
     void set_local_name(STRING,STRING);
};
Z_END_NAMESPACE;

#endif
