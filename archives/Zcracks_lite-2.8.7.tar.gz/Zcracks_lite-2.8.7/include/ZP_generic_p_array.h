#ifndef __ZP_G_P_ARRAY__
#define __ZP_G_P_ARRAY__

#include <ZP_basic_type.h>
#include <ZP_generic_pointer.h>

Z_START_NAMESPACE;

template <class T>
ZCLASSt ZP_G_P_ARRAY : public ZP_BASIC_TYPE< ARRAY< T* > >
{
  protected :
    ZP_FATAL_ERROR* resize(ZP_STACK&,int);
    ZP_FATAL_ERROR* size(ZP_STACK&,int);
    ZP_FATAL_ERROR* bracket(ZP_STACK&,int);
    ZP_FATAL_ERROR* last(ZP_STACK&,int);

    virtual void type_init(char*) { this->type="GARRAY"; }

  public :
    BASIC_CONSTRUCTORS(ZP_G_P_ARRAY,ARRAY< T* >)

    METHOD_DECLARATION_START
      METHOD("[]",bracket,1)
      METHOD("size",size,0)
      METHOD("resize",resize,1)
      METHOD("!",size,0)
      METHOD("size",size,0)
      METHOD("last",last,0)
    METHOD_DECLARATION_ANCESTOR(ZP_BASIC_TYPE< ARRAY< T* > >)

    ZPO_RTTI_INFO(ARRAY< T* >)
};

template <class T> inline
ZP_FATAL_ERROR* ZP_G_P_ARRAY<T>::resize(ZP_STACK& stack,int)
{
  int c;

  if(stack.last()->type!="int") TYPE_MISMATCH_ERROR_1("[]");
  c=ZP_INT::cast(stack.last());
  if(c<0) c=0;
  stack.pop();
  this->get().resize(c);
  return(NULL);
}

template <class T> inline
ZP_FATAL_ERROR* ZP_G_P_ARRAY<T>::size(ZP_STACK& stack,int)
{
  AUTO_PTR< ZP_OBJECT > zpo;
  int i=this->get().size();

  zpo=new ZP_INT(i);
  stack.add(zpo);
  return(NULL);
}

Z_END_NAMESPACE;

#define IMPL_G_ARRAY(ty) \
Z_START_NAMESPACE; \
  template<> ZP_FATAL_ERROR* ZP_G_P_ARRAY< ty >::bracket(ZP_STACK& stack,int) { int c; AUTO_PTR<ZP_OBJECT> zpo; \
  if(stack.last()->type!="int") TYPE_MISMATCH_ERROR_1("[]"); \
  c=ZP_INT::cast(stack.last()); \
  if(c<0 || c>=!get()) ZP_ISSUE_FATAL_ERROR("index out of range in []"); \
  stack.pop(); ZP_GENERIC_POINTER<ty> *p=new ZP_GENERIC_POINTER<ty>; \
  zpo=p; p->get().ptr=& get()[c] ; p->get().object=new ZP_##ty (get()[c]); \
  stack.add(zpo); \
  return(NULL); } \
  template<> ZP_FATAL_ERROR* ZP_G_P_ARRAY< ty >::last(ZP_STACK& stack,int) { AUTO_PTR<ZP_OBJECT> zpo; \
  ZP_GENERIC_POINTER<ty> *p=new ZP_GENERIC_POINTER<ty>; \
  zpo=p; p->get().ptr=& get().last() ; p->get().object=new ZP_##ty (get().last()); \
  stack.add(zpo); \
  return(NULL); } \
  template<> const char* ZP_G_P_ARRAY< ty >::__type()const { static char ret[1024]=""; if(strcmp(ret,"")==0) sprintf(ret,"ZP_G_P_ARRAY<%s*>",#ty); return(ret); } \
  template<> const char* ZP_G_P_ARRAY< ty >::isA()const { return(__type()); } \
  template<> bool  ZP_G_P_ARRAY< ty >::__are_you_a(const char* str)const \
  { static char ret[1024]=""; if(strcmp(ret,"")==0) sprintf(ret,"ZP_G_P_ARRAY<%s*>",#ty); \
    if(strcmp(str,ret)==0) return TRUE; \
    else return ZP_BASIC_TYPE< ARRAY< ty * > >::__are_you_a(str); \
  } \
  template<> bool ZP_G_P_ARRAY< ty >::areYouA(const char* str)const \
  { return(__are_you_a(str)); } \
  template<> ARRAY< ty *> & ZP_G_P_ARRAY< ty >::cast(AUTO_PTR<ZP_OBJECT> &zpo) { \
    static char ret[1024]=""; if(strcmp(ret,"")==0) sprintf(ret,"ZP_G_P_ARRAY<%s*>",#ty); \
    if(!zpo->__are_you_a(ret)) ERROR("Internal error : Bas Cast"); \
    return(( (ZP_G_P_ARRAY< ty >*)(zpo()) )->get()); \
  } \
template<> bool  ZP_G_P_ARRAY< ty >::CheckType(const char* str) const \
{ \
static char ret[1024]=""; \
if(strcmp(ret,"")==0) sprintf(ret,"ARRAY<%s*>",#ty); \
if(strcmp(str,ret)==0) return TRUE; \
  else return FALSE; } \
Z_END_NAMESPACE;

#endif
