#ifndef __Post_mises__
#define __Post_mises__

#include <Utility.h>
#include <Local_post_computation.h>
#include <Post_simple.h>
#include <Mises_sqrt2.h>

Z_START_NAMESPACE;


ZCLASS2 POST_MISES :public POST_SIMPLE {
 protected :
  int   tsz;
  STRING out_name; 
 public :
  POST_MISES();
  virtual ~POST_MISES();
  virtual MODIFY_INFO_RECORD* get_modify_info_record();

  virtual void input_i_need(int,ARRAY<STRING>&);
  virtual void output_i_give(bool&,ARRAY<STRING>&);
  virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
};
Z_END_NAMESPACE;
  
#endif
