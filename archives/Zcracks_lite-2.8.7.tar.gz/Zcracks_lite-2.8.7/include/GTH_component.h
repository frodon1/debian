#ifndef __GTH_PROBLEM_COMPONENT__
#define __GTH_PROBLEM_COMPONENT__

#include <Base_restart_defines.h>
#include <Problem_component.h>
#include <Stringpp.h>
#include <File.h>
#include <Problem.h>
#include <Calcul_timer.h>
#include <Integration_result_ok_but_do_it_again.h>
#include <Set.h>
#include <Crack_FC.h>
#include <Crack_FE.h>
#include <Crack_FV.h>
#include <Crack_FG.h>
#include <Mesh.h>
#include <Ask.h>
#include <Clock.h>
#include <EigenNonSymmetric.h>
#include <Crack_INFO_xfem.h>
#include <GTH_propagation_behavior.h>
#include <DC_element.h>

Z_START_NAMESPACE;

class GTH_PROBLEM_COMPONENT : public PROBLEM_COMPONENT
{
  protected :
    CRACK_FC *_crack_front_curve;
    ARRAY <DC_ELEMENT*> dc_elems;
    double hmin;
    VECTOR CPT_times;
    VECTOR clength;
    int nb_pt_ffo,nb_filter;
    MARRAY<ARRAY <DOF*> > xdofs; // Enriched dofs
    ARRAY<DOF*> dof_table_replace; // Dof table replacement for correct enriched/std transition elements

    AUTO_PTR<GTH_PROPAGATION_BEHAVIOR> propag_behavior;

    bool if_plastic,enrich_tip,if_vectorial;
    double RDe,RDi;
    VECTOR D_ep_max,G_el_max,D_ep_comp,Epcum_max,Epcum; // Maximal plastic dissipation
    double T_cycle,DT_cycle;
    VECTOR Kmin,Kmax,Gmin,Gmax,Amin,Amax,Tmin,Tmax;
    VECTOR Kmin0,Kmax0,Gmin0,Gmax0,Tmin0,Tmax0; // For implicit propagation
   
    int elem_radius; 
    double autor_err,czm_extension;
    VECTOR list_radius;
    bool if_last,if_first,if_active;
    //static bool if_reduce,if_augment;
    bool if_xfem;
    bool if_gradient;
    VECTOR PG,tan_vect,Theta_tot;
    double step;
    double eps_implicit;
    CRACK_INFO_XFEM* crack_info_xfem;
    CRACK_RESULTS_XFEM* crack_results_xfem;
    Zofstream resu_file,list_file;
    int iteration_gth;
    double previous_time,autoh_factor;
    ARRAY<VECTOR> pos_front,previous_pos_front,normal_front;
    STRING crack_front_name,bb_tree_elset_name,speed_name,cut_name,autoh_name;
    bool autor;
    int cut_nb;
    B_UTILITY_SET *crack_front;
    double ra, rb, _Gc, h, r_max;

    // for lms interaction integral
    int nbr;
    double a_barsoum,a_max;
    bool if_int_lms;

    int init_type,nb_node,nb_point;
    bool check_normal;
    VECTOR p_dir,p_dir2,_N0,_N1;
    ARRAY<VECTOR> speed,front_position;
    CFV_VOLUME_INFOS* cfv_infos;
    double adv_noremesh;
    double angle_out;
    bool if_out_plane;
    double astep,amin,amax; 
    double normal_factor;
    MARRAY <VECTOR> front_normals;
    VECTOR init_point; 
    VECTOR front_angle, front_sign;

    INTEGRATION_RESULT *iobdia;
    MARRAY<VECTOR> Delta_A,Delta_A_save;

    bool if_implicit,if_plane,if_fatigue,if_compute_K,if_compute_Ki;
    //static double Delta_N;
    double C,m,R; 

    CRACK_FG_3D *crack_geom;
    MESH *mesh;
    STRING elset_name,nset_name;

    void base_internal_initialize();
    bool internal_initialize();
    void size_vectors(int);

    bool reset_xfem(APPLICATION_MESSAGE* msg);
    bool give_gtheta(APPLICATION_MESSAGE* msg);
    bool give_xfem(APPLICATION_MESSAGE* msg);
    bool give_results_xfem(APPLICATION_MESSAGE* msg);
    bool give_if_remesh(APPLICATION_MESSAGE* msg);
    bool give_speed(APPLICATION_MESSAGE* msg);
    bool give_position(APPLICATION_MESSAGE* msg);
    bool give_front_nset(APPLICATION_MESSAGE* msg);
    bool give_dtime(APPLICATION_MESSAGE* msg);
    bool give_cfv(APPLICATION_MESSAGE* msg);
    bool if_adv_vol;
    double radv,radv_diff;
    double fdiff,fh;
    VECTOR Gc,G0,K0,Gm,Km,atheta;
    int nbnodes;
    STRING lipname;

    void find_h();
 
    void print_front(int);
    void print_G_info(VECTOR *G,VECTOR *KI,VECTOR *T,VECTOR *angle,MATRIX *K,int nb_node);

  public :
    // mandatory to avoid mem leaks: never allocate static objects in PROBLEM_COMPONENT contructors
    CRACK_FC& crack_front_curve() { return(*_crack_front_curve); }

    VECTOR Ptheta;
    double Delta_N,h_factor;
    double N_cycles;
    bool if_must_remesh,if_exclude_be;

    double compute_displacement(const VECTOR &M, VECTOR &, VECTOR *v=NULL);
    double compute_displacement(const VECTOR &M, VECTOR &, VECTOR *v, double &angle );
    double max_norm_theta;

    void init_from(const GTH_PROBLEM_COMPONENT& component);
    void set_xfem(CRACK_INFO_XFEM* _crack_info_xfem) { crack_info_xfem=_crack_info_xfem; }
    double give_gtheta_h_param(){return h;}

    DATA_D2 data_d2;
    GTH_PROBLEM_COMPONENT(); 
    virtual ~GTH_PROBLEM_COMPONENT();

    virtual void start_increment() { mesh = its_boss->get_mesh(); } 

    virtual bool GetResponse(STRING&,ASCII_FILE&);
    virtual void end_increment(INTEGRATION_RESULT*&);
    virtual void load(ASCII_FILE&, PROBLEM *);
    virtual bool initialize();

    virtual bool is_first_round() { return TRUE; } // Required to be called before solver step
    virtual void after_mesh_setup();

    virtual void read_restart(RST_FSTREAM& obin);
    virtual void write_restart(RST_FSTREAM& rep);

    void set_crack_front_name(STRING& nm) { crack_front_name = nm; }

    RTTI_INFO;
    DECLARE_ASK;
};

Z_END_NAMESPACE;

#endif
