#ifndef __Sort_Array_legacy__
#define __Sort_Array_legacy__

#include <Array.h>

Z_START_NAMESPACE;

template <class T> void qsort_array(int beg, int end, ARRAY <T>& array, ARRAY<int>& pos)
{ T pivot;        // pivot value for unpartitioned array
  int ubeg,uend;  // indices at end of unpartitioned array
  int ieq;        // least index of array entry with value equal to pivot
  T tmp;          // tempory index used for swapping
  int ptmp;

  if(beg >= end) return;

  pivot = array[(beg+end)/2];

  ieq = ubeg = beg;
  uend = end;

  while(ubeg <= uend) {
     if(array[uend] > pivot) {
        // here we can reduce the size of the upartitioned array
        uend--;
     }
     else {
        // here sort[uend] <= pivot so swap entries at indices uend and ubeg
        tmp = array[ubeg];
        array[ubeg] = array[uend];
        array[uend] = tmp;
        ptmp = pos[ubeg];
        pos[ubeg] = pos[uend];
        pos[uend] = ptmp;
        // after the swap sort[ubeg] <= pivot
        if(array[ubeg] < pivot) {
           // swap entries at indices ieq and ubeg
           tmp = array[ieq];
           array[ieq]  = array[ubeg];
           array[ubeg] = tmp;
           ptmp = pos[ieq];
           pos[ieq]  = pos[ubeg];
           pos[ubeg] = ptmp;
           // after the swap sort[ieq] < pivot so we need to change ieq
           ieq++;
        }
        // size of the unpartitioned array can be reduced
        ubeg++;
     }
  }
  // now all entries from beg to ieq-1 are < pivot
  // and all entries from uend to end+1 are > pivot
  // these 2 regions can be sorted recursively
  qsort_array(beg,ieq-1,array,pos);
  qsort_array(uend+1,end,array,pos);
}

template <class T> void sort_array(ARRAY <T>& array, ARRAY<int>& pos)
{
  pos.resize(!array);
  for(int i=0;i<!pos;i++) pos[i] = i;
  qsort_array(0,!array-1,array,pos);
}

Z_END_NAMESPACE;

#endif
