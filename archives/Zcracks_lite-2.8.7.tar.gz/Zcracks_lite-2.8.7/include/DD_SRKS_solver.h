//
// Gosselet 2004, Generic iterative solvers (mostly used with generic_dd)
// see P. Gosselet thesis (2003), nice paper soon
//
// The selective reuse of Krylov subspaces methods to accelerate resolution in multiresolution context
//
#ifndef __DD_SRKS_SOLVER__
#define __DD_SRKS_SOLVER__

#include <DD_accelerated_krylov_solver.h>

Z_START_NAMESPACE;

class DD_SRKS_SOLVER : public DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER{
  protected :    
   void sort(ARRAY<VECTOR> &,ARRAY<double> &,ARRAY<VECTOR> &,ARRAY<double> &);
   void sort(ARRAY<VECTOR> &,ARRAY<double> &,ARRAY<VECTOR> &,ARRAY<double> &,int, int);
   double compute_distance(ARRAY<double> &,int);
   double compute_theoretical_distance(ARRAY<double> &,int);
   double compute_distance_to_interval(ARRAY<double> &,int,int,int,int,int); 
  public: 
    virtual void loop();
    DD_SRKS_SOLVER():DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER(){}
    virtual ~DD_SRKS_SOLVER(){}
//    virtual AUTO_PTR<MATRIX_LIKE> provide_augmentation(){
//     if(Caugm.Null()) {Caugm = provider->give_matrix();Caugm->import_matrix(inout);}
//     return(Caugm);
//    }
    RTTI_INFO;
};

class DD_TRKS_SOLVER : public DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER{
  public:
    virtual void loop();
    DD_TRKS_SOLVER():DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER(){}
    virtual ~DD_TRKS_SOLVER(){}
//    virtual AUTO_PTR<MATRIX_LIKE> provide_augmentation(){
//     if(Caugm.Null()) {Caugm = provider->give_matrix();Caugm->import_matrix(inout);}
//     return(Caugm);
//    }
    RTTI_INFO;
};


Z_END_NAMESPACE;
#endif

