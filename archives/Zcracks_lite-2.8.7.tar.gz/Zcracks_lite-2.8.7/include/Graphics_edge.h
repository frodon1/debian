#ifndef __Graphics_edge__ 
#define __Graphics_edge__ 

#include <Buffered_list.h>
#include <Allocator_template.h>

#include <Graphics_object.h>
#include <limits.h>

Z_START_NAMESPACE;

ZCLASS GRAPHICS_EDGE { 
  public : 
    bool closed;
    GRAPHICS_EDGE();
    virtual ~GRAPHICS_EDGE() { }
    BUFF_LIST<GRAPHICS_POINT*> points; 

    void setup(ARRAY<GRAPHICS_POINT>& pts); 
    void setup(ARRAY<GRAPHICS_POINT*>& pts); 
    void reverse_order(); 

    virtual void paint(GRAPHICS_AREA&);
}; 
Z_END_NAMESPACE;

#endif 
