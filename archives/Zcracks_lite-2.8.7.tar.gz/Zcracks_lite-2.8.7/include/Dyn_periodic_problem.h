#ifndef __DYN_PERIODIC_PROBLEM__
#define __DYN_PERIODIC_PROBLEM__

#include <Material_black_box.h>
#include <Dyn_extern_problem.h>
#include <Localisation.h>
#include <List.h>
#include <Homogeneisation.h>
#include <MPC_periodic.h>
#include <Problem_mechanical.h>

Z_START_NAMESPACE;

ZCLASS2 DYN_PERIODIC_PROBLEM  : public MAT_BLACK_BOX, public DYN_EXTERN_PROBLEM
{
  private :
    double ratio;
    STRING cvgce_type;
    STRING _reinit;
    int max_iter;
    SEQUENCE *main_seq;
    int loc_read, hom_read, pb_read;
    int _name_assigned;
    int _last_niter;

    void read_periodicity(ASCII_FILE&);

  public :
    bool active;
    const int &name_assigned;
    const int &last_niter;
    VECTOR flux,grad,dgrad,dflux;
    LOCALISATION *loc;
    HOMOGENEISATION *hom;
    double start_time, end_time;

    DYN_PERIODIC_PROBLEM();
    DYN_PERIODIC_PROBLEM(ASCII_FILE&);
    virtual ~DYN_PERIODIC_PROBLEM();
    
    virtual void set_name(const STRING&);
    void set_restart_outputs() { int i; for(i=0;i<!output;i++) output[i]->restart_mode=RESTARTER::READ_WRITE_RESTART;  }

    virtual void get_internal_values(VECTOR&);
    virtual void get_internal_names_and_size(LIST<STRING>&,LIST<int>&);
    virtual void initialize(ASCII_FILE &f) { initialize(f,""); }
    virtual void initialize(ASCII_FILE&, const STRING&, bool restart=FALSE);

    virtual void set_grad(const VECTOR&,double,double);
    virtual void get_flux(VECTOR&);
    virtual void apply_external_load(double,double);
    virtual int end_of_step(double,double);

    virtual void start_iterations();
    virtual void end_iterations();
    virtual void set_main_sequence(void*);

    virtual bool Execute();

    void build_ini_files();
    void build_next_sequence(double,double);

    void check_rules(int,int);
    void add_macro_param(EXTERNAL_PARAM*);

    void restarted_output();
};
Z_END_NAMESPACE;

#endif
