#ifndef __Sub_problem__  
#define __Sub_problem__  

// ============================================================================
//  SUB_PROBLEM holds a problem, or a something to do during a coupled 
//  calculation... it's not really necessary, but it holds together 
//  the problem names, and the transfer operators..
// ============================================================================

#include <Clock.h> 
#include <Bool.h> 
#include <Object_factory.h>
#include <Coupled_data_transfer.h>

Z_START_NAMESPACE;

class ASCII_FILE;
class PROBLEM;
class COUPLED_DATA_TRANSFER;
class WEAK_COUPLING;

ZCLASS2 SUB_PROBLEM {
  protected :
   STRING         its_name;
   int            ipc;
   WEAK_COUPLING *its_boss; 

  public :
   PLIST<COUPLED_DATA_TRANSFER> transfer;

   SUB_PROBLEM();
   virtual void enable_parallel_computation();
   virtual void initialize(ASCII_FILE&); // takes name..
   virtual ~SUB_PROBLEM();
   static SUB_PROBLEM* read(ASCII_FILE&,int ipc=0);

   virtual bool base_read(STRING&, ASCII_FILE&);

   virtual void Initialize() { if (get_fem_problem()) get_fem_problem()->Initialize(); }
   virtual void init_problem();
   virtual void init_transfers();
   virtual void output(bool forced=FALSE);

   virtual bool set_auto_restart();
   virtual void write_restart(RST_FSTREAM&);
   virtual void read_restart(RST_FSTREAM&);
   virtual bool verification(); 
   virtual PROBLEM* get_fem_problem() { return NULL; }

   virtual bool run_increment(double time)=0;

           void set_boss(WEAK_COUPLING *w) { its_boss=w; }

   virtual STRING get_name() { return( its_name ); }

};

#define SUB_PROBLEM_READER(a,b) DECLARE_OBJECT(SUB_PROBLEM,a,b)
Z_END_NAMESPACE;

#endif
