#ifndef __MP_GLOBAL_HANDLER__
#define __MP_GLOBAL_HANDLER__

#include <Array.h>
#include <Bool.h>
#include <Handler_mp.h>
#include <Server.h>
#include <Out_message.h>

Z_START_NAMESPACE;

#define Z_GLOBAL_SUM_INT 1
#define Z_GLOBAL_SUM_DOUBLE 2

ZCLASS MP_GLOBAL_HANDLER : public HANDLER_MP
{
  protected :
    void make_global_sum_int();
    void make_global_sum_double();
 
    ARRAY< ARRAY<int> > *tab_i_s;
    ARRAY< ARRAY<double> > *tab_d_s;
    int n_i_s;
    int n_d_s;

  public :
    MP_GLOBAL_HANDLER() : HANDLER_MP() { tab_d_s=NULL; tab_i_s=NULL; }
   ~MP_GLOBAL_HANDLER(void) { }

    DECLARE_HANDLER;
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
