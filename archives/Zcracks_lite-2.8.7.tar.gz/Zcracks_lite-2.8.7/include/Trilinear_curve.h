#ifndef __TRILINEAR_CURVE__
#define __TRILINEAR_CURVE__

#include <Implicit_curve.h>

Z_START_NAMESPACE;

class TRILINEAR_CURVE : public IMPLICIT_CURVE
{
  protected :
    TRICUBIC_INTERPOLATION t1,t2;

  public :
    TRILINEAR_CURVE() : IMPLICIT_CURVE(t1,t2) { }
    virtual ~TRILINEAR_CURVE() { }

    void initialize(const double _x0, const double _y0, const double _z0,
                    const double _dx, const double _dy, const double _dz,
                    const double _values[64], const double _values2[64]) {

      t1.initialize(_x0,_y0,_z0,_dx,_dy,_dz,_values);
      t2.initialize(_x0,_y0,_z0,_dx,_dy,_dz,_values2);
    }
};
Z_END_NAMESPACE;

#endif
