#ifndef  __Zener_hyperviscoelastic__
#define  __Zener_hyperviscoelastic__

#include <Isotropic_hyperelastic.h>
#include <Behavior.h>
#include <Viscoelastic_terms.h>

Z_START_NAMESPACE;

ZCLASS ZENER_HYPER_VISCO_ELASTIC : public BEHAVIOR {
      protected :
        PTR<ISOTROPIC_HYPERELASTIC_LAW> hyper_law_e; 
        PTR<ISOTROPIC_HYPERELASTIC_LAW> hyper_law; 
        TENSOR2_VAUX Cvn;
        TENSOR2_VAUX dWedCvn;
        TENSOR2 sig;
        TENSOR2 one;
        TENSOR4 ONE;
        TENSOR4 UNIT;
        TENSOR4 Idev;
        SMATRIX m_tgmat;
        COEFF eta;


        virtual void verif_read();

      public :

        ZENER_HYPER_VISCO_ELASTIC();
        virtual ~ZENER_HYPER_VISCO_ELASTIC(); 
        
        virtual void initialize(ASCII_FILE& file, int dim, LOCAL_INTEGRATION*);
        int base_read(const STRING& strin,ASCII_FILE& file);


        INTEGRATION_RESULT* integrate( MAT_DATA&, 
                                       const VECTOR&, 
                                       MATRIX*&, int);

        virtual STRESS_MEASURE get_stress_measure()const { 
             return hyper_law->get_stress_measure(); 
        }

};
Z_END_NAMESPACE;

#endif
