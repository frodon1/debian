#ifndef __Bubble_rgp__
#define __Bubble_rgp__

#include <Interpolation.h>
#include <Ref_Gauss_point.h>

Z_START_NAMESPACE;

ZCLASS RGP_2_G3_N3_M : public REF_GAUSS_POINT {
    public :
       RGP_2_G3_N3_M(int gp_id);
       virtual ~RGP_2_G3_N3_M();
       static void init();
       static ARRAY<REF_GAUSS_POINT*> rgp;
};

ZCLASS RGP_3_G4_N4_M : public REF_GAUSS_POINT {
    public :
       RGP_3_G4_N4_M(int gp_id);
       virtual ~RGP_3_G4_N4_M();
       static void init();
       static ARRAY<REF_GAUSS_POINT*> rgp;
};

Z_END_NAMESPACE;
#endif

