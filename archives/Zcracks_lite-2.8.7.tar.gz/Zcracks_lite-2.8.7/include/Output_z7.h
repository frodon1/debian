#ifndef __Output_z7__ 
#define __Output_z7__ 

// ============================================================================  
//  Classic Zebulon multi-file output 
// 
// ============================================================================  

#include <Output.h>

Z_START_NAMESPACE;

ZCLASS2 OUTPUT_Z7 : public OUTPUT {
  protected :
     LIST<ZSTREAMPOS> ut_state,node_state,ele_state,integ_state,contour_state,contour_mat_state,contour_ele_state;
     LIST<int> tag_state;

     bool first_time;

     int  nd_length; 
     bool default_node; 
     bool default_integ; 
     bool save_in_local; 
     bool default_ele; 

     // 
     // Special stuff for the indexed output which speeds up 
     // storage for huge numbers of state vars. 
     // 
     int                     use_indexed_output; 
     ARRAY< LIST<MATERIAL_PIECE_VARIABLE_KEY*> > output_keys;
     ARRAY< BUFF_LIST<int> >         output_integ_index; 
     ARRAY< BEHAVIOR* > behavior_index;

     BUFF_LIST<STRING>       output_integ_variables,
                             output_integ_def_variables,
                             output_node_variable, 
                             output_ele_variable;

     BUFF_LIST<DOF_TYPE*>     output_nodefault_node_variable;


     BUFF_LIST<STRING>       parsed_ut;
     BUFF_LIST<DOF_TYPE*>    dof_type_at_node;
     BUFF_LIST<STRING>       dump_mat_data;
     LIST< LIST< STRING > >  dump_mdat_vars;
     LIST<STRING>            local_names;
     LIST<STRING>            dump_dofs;
     LIST<VECTOR>            tmp_val;
     Zofstream uto;

     // 
     // To append results when using a ***initialize_from_results
     // 
     int append_files; 
     STRING append_prefix; 
     double time_offset; 
     int    map_offset; 

     STRING  use_mesh_name; 

     bool if_store_global_matrix;
     //     bool save_kinematic; // JDG (2007/03/29) this already exists as (location_flags & KINEMATIC) in Output.h
     bool save_material_rotations;

     int nb_U;
     LIST<double> at_time;
     LIST<STRING> global_matrix_name;LIST<STRING> global_matrix_file_name;
     Zfstream node,ele,integ,contour,contour_mat,contour_ele;
     ZSTREAMPOS recl_node, recl_integ, recl_contour, recl_contour_mat,
               recl_contour_ele, recl_ele; // record lengths

     void read_test(ASCII_FILE&,const MESH&);
     void compute_recl(const MESH&);
     void set_file_position();

     virtual void write_ut_header(MESH&);
     virtual void write_ut(MESH&);
     virtual void write_node(MESH&);
     virtual void dump_mdat(MESH&);
     virtual void dump_do(MESH&);
     virtual void write_integ(MESH&);
     virtual void write_contour(MESH&);
     virtual void write_contour_mat(MESH&,const ARRAY<BEHAVIOR*>&);
     virtual void write_contour_ele(MESH&);
     virtual void write_ele(MESH&);
     virtual void write_global_matrix(MESH&);

     virtual void put_node_record(ARRAY<float> &f, int ivar);
     virtual void flush_node();

     virtual void put_integ_record(ARRAY<float> &f, int ielem, int ivar);
     virtual void flush_integ();

 public :

     OUTPUT_Z7(); 
     virtual bool base_read(STRING cctl1, ASCII_FILE& inp);
     virtual void initialize(PROBLEM* pb, ASCII_FILE* inp); 

     virtual ~OUTPUT_Z7();

     virtual void open_files(MODE m=OPEN);
     virtual void write_output(MESH& mesh,ARRAY<BEHAVIOR*>& behavior);
     virtual void setup(ARRAY<BEHAVIOR*>&,MESH& mesh,RESTARTER::MODE lrestart_mode,int io, bool rescan=FALSE);
     void close_files();

     virtual void save_state(int);
     virtual void restore_state(int);
     virtual void remove_state(int);

     RTTI_INFO;
};

Z_END_NAMESPACE;

#endif   
