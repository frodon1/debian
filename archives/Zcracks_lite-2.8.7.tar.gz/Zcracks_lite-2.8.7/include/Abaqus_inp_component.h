#ifndef __ABAQUS_INP_COMP__
#define __ABAQUS_INP_COMP__

#include <Abaqus_zebulon.h>
#include<Sorted_list.h>

Z_START_NAMESPACE;

class ABAQUS_READER;

class LOCAL_SYSTEM {
  public:
  VECTOR T;
  SMATRIX R;
  public:
  LOCAL_SYSTEM(){ T.resize(3); R.resize(3); }
  ~LOCAL_SYSTEM(){}
  void to_global(VECTOR &in){ in=T + R*in; }
};

class ABAQUS_INP_COMP {
   public :
      // name is on of the parameter (NAME=), it is not availabale in all derived
      // classes, but is defined here to call it without a cast to derived class 
      STRING name;
      // a local system is activated when *SYSTEM is encountered, this is needed 
      // in part, assembly and instance, defined here to avoid cast to derived class
      LOCAL_SYSTEM* local_system;

      UTILITY_MESH* mesh;
      // the ABAQUS_READER that hold the file being read
      ABAQUS_READER* reader;
      // the class that hold this one in it's subs list
      ABAQUS_INP_COMP* parent;
      // all sub components of this component
      BUFF_LIST<ABAQUS_INP_COMP*> subs;
      // unhandled statements goes here
      BUFF_LIST<STRING> unhandled;

      SORTED_LIST<STRING> preserved;

   public :
      ABAQUS_INP_COMP();
      virtual ~ABAQUS_INP_COMP();
      void initialize(ABAQUS_READER* _reader, ABAQUS_INP_COMP* _parent=NULL);
      // read all components until end_lvl ( of type *END ASSEMBLY for eg )
      void get_sub_components(const char* end_lvl);
      // get a component from subs list by derived type
      ABAQUS_INP_COMP* get_sub(STRING type, STRING name, bool fail=true);
      // get the number of current component in the parent's sub 
      // take into account only similar type components
      int my_number();

      /********** redefine thoses functions for derived classes **********/
      // return the type of current class (the one used for DECLARE_OBJECT)
      virtual STRING type();
      // this function parse the input file
      virtual void parse();
      virtual void write(STRING& last);

      void add_to_bset(UTILITY_ELEMENT* elem, int faceid, B_UTILITY_SET* bset);
};

Z_END_NAMESPACE;


#endif
