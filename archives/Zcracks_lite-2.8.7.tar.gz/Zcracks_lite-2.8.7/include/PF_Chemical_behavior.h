#ifndef __Phasefield_phic_behavior__
#define __Phasefield_phic_behavior__

#include <PF_Chemical_energy.h>


Z_START_NAMESPACE;

class MAT_DATA; class ASCII_FILE;
class PHASEFIELD_PHIC_ENERGY;

ZCLASS2 PHASEFIELD_PHIC_BEHAVIOR : public BEHAVIOR {
  protected:
      VECTOR_FLUX xi;
      VECTOR_FLUX J;
      VECTOR_GRAD C_grad;
      VECTOR_GRAD Phi_grad;
     // VECTOR_GRAD mu_grad;
      SCALAR_VAUX mu;
      SCALAR_VAUX Phi;
      SCALAR_VAUX C;
      SCALAR_VAUX pi, pi_c;


      COEFF alpha,beta;
      COEFF onsag2,onsag1;
      COEFF function;

      double h, dh,d2h;
      
      PHASEFIELD_PHIC_ENERGY *energy;

  public:
      PHASEFIELD_PHIC_BEHAVIOR();
      virtual ~PHASEFIELD_PHIC_BEHAVIOR();
      virtual void initialize(ASCII_FILE&,int,LOCAL_INTEGRATION*);

      virtual INTEGRATION_RESULT* integrate(MATERIAL_INTEGRATION_INFO&);
};

Z_END_NAMESPACE;

#endif
