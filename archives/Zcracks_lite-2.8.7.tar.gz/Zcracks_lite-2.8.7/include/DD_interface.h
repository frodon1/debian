#ifndef __DD_INTERFACE__
#define __DD_INTERFACE__

#include <Buffered_list.h>
#include <DD_dof.h>
#include <DD_node.h>

Z_START_NAMESPACE;

ZCLASS2 DD_INTERFACE {
  friend class DD_SUB_DOMAIN;
  protected :
   BUFF_LIST<DD_DOF*>  dofs;
   BUFF_LIST<DD_NODE*> nodes;
   ARRAY<int> saved_fixed_status;
   ARRAY<double> saved_fixed_values;
   int _sd_rank,_rank,_tag;  // rank : rank of this interface in the domain interfaces list
   DD_INTERFACE *_companion;

  public :

    const int &sd_rank;
    const int &rank;
    const int &tag;

//  interface dofs due to MPCs across sub-domains :
//  should be added/removed from the interface dofs everytime MPCs are applied
    BUFF_LIST<DD_DOF*>  mpc_dofs;

    DD_INTERFACE(int w): _sd_rank(w) , _companion(NULL) , sd_rank(_sd_rank) , rank(_rank) , tag(_tag) { 
      _tag=-1; dofs.resize(0);nodes.resize(0); 
    }
    virtual ~DD_INTERFACE() { }
    void add_dof(DD_DOF *f) { dofs.add(f); }
    void add_mpc_dof(DD_DOF *f) { dofs.add(f); mpc_dofs.add(f); }
    void remove_dof(DD_DOF *f) { dofs.suppress_item(f); }
    void add_node(DD_NODE *n) { nodes.add(n); }
    void remove_node(DD_NODE *n) { nodes.suppress_item(n); }
    void set_companion(DD_INTERFACE *i) { _companion=i; }
    void set_rank(int r) { _rank=r; }
    void set_tag(int t) { _tag=t; }
    void clean_mpc_dofs() {
      if(!mpc_dofs) {
        for(int i=0;i<!mpc_dofs;i++) dofs.suppress(); 
        mpc_dofs.resize(0);
      }
    }
    void clean_color(int c) {
      for (int i=dofs.size()-1;i>=0;i--) if (dofs[i]->color==c) { dofs.suppress(i); }
      for (int i=nodes.size()-1;i>=0;i--) if (nodes[i]->color==c) { nodes.suppress(i); }
    }
    void fix_interface_dofs(double* v) {
      saved_fixed_status.resize(!dofs); saved_fixed_values.resize(!dofs);
      for(int idof=0;idof<!dofs;idof++) {
        saved_fixed_status[idof]=dofs[idof]->dof->if_fixed;
        saved_fixed_values[idof]=dofs[idof]->dof->fixed;
        dofs[idof]->dof->if_fixed=1;
        if(v) dofs[idof]->dof->fixed=v[idof]; 
        else dofs[idof]->dof->fixed=0.0;
      }
    }
    void restore_interface_dofs_bcs() {
      for(int idof=0;idof<!dofs;idof++) {
        dofs[idof]->dof->if_fixed=saved_fixed_status[idof];
        dofs[idof]->dof->fixed=saved_fixed_values[idof];
      }
    }

    DD_INTERFACE* companion() { return(_companion); }
    DD_DOF* dd_dof(int i) { return(dofs[i]); }
    DD_NODE* dd_node(int i) { return(nodes[i]); }
    int nb_dofs() { return(!dofs); }
    int nb_nodes() { return(!nodes); }
    void sort_nodes() {
      DD_NODE *tmp=NULL;
      for(int i=0;i<!nodes-1;++i) 
        for(int j=i+1;j<!nodes;++j) 
          if(nodes[i]->global_rank > nodes[j]->global_rank){tmp=nodes[i];nodes[i]=nodes[j];nodes[j]=tmp;}
    }

    void sort_dofs() {
      DD_DOF *tmp=NULL;
      for(int i=0;i<!dofs-1;++i) 
        for(int j=i+1;j<!dofs;++j) 
          if(dofs[i]->global_rank > dofs[j]->global_rank){tmp=dofs[i];dofs[i]=dofs[j];dofs[j]=tmp;}
    }

    virtual void before_send(VECTOR&) { } // see classes P_MPC and  P_MPC_INTERFACE
    virtual void after_receive(VECTOR&) { }
    virtual void before_send(MATRIX&) { } // see classes P_MPC and  P_MPC_INTERFACE
    virtual void after_receive(MATRIX&) { }
    virtual void rhs_contribution(VECTOR &v) { v.resize(dofs.size()); v=0.; }

// quick count of dofs according to their type
    int n_primal,n_dual,n_mixed,n_unknown,n_recondensed;
    void update_count(){n_primal=n_dual=n_mixed=n_unknown=n_recondensed=0; 
      for (int i=0;i<dofs.size();++i) 
        if (dofs[i]->kind==DD_DOF::PRIMAL) ++n_primal;
        else if (dofs[i]->kind==DD_DOF::DUAL) ++n_dual;
        else if (dofs[i]->kind==DD_DOF::MIXED) ++n_mixed;
        else if (dofs[i]->kind==DD_DOF::PRIMAL_R) ++n_recondensed;
        else if (dofs[i]->kind==DD_DOF::UNKNOWN) ++n_unknown;
      }
};
Z_END_NAMESPACE;

#endif
