#ifndef __GTH_PROPAGATION_BEHAVIOR__
#define __GTH_PROPAGATION_BEHAVIOR__

#include <Z_object.h>
#include <Vector.h>
#include <Base_restart_defines.h>

Z_START_NAMESPACE;

class GTH_PROBLEM_COMPONENT;

class GTH_PROPAGATION_BEHAVIOR : public Z_OBJECT
{ 
   public :
     GTH_PROPAGATION_BEHAVIOR();
     virtual ~GTH_PROPAGATION_BEHAVIOR();

     virtual void initialize(ASCII_FILE&,GTH_PROBLEM_COMPONENT*);
     virtual bool is_cyclic() { return(FALSE); }
     virtual bool is_linear() { return(FALSE); }
     virtual void read_restart(RST_FSTREAM& obin) {} 
     virtual void write_restart(RST_FSTREAM& rep) {}

     virtual GTH_PROPAGATION_BEHAVIOR* copy_self() const = 0; 
     // virtual bool update(const VECTOR& G)=0;
     // virtual bool update(const VECTOR& G,const VECTOR& T)=0;
     virtual bool update(const VECTOR& G,const VECTOR& T,const VECTOR &angle)=0;
     virtual VECTOR compute_propagation(double &Ncycle,VECTOR &angle)=0;

     // To add advances with different angles
     void add_with_angles(VECTOR &A,const VECTOR &da,VECTOR &angle,const VECTOR &dangle);

     RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
