gcc -I. -L. cadsurf_discrete_geometry.c -lmg-cadsurf -lmeshgems -lmeshgems_stubs -lmg-tetra -lm -lc  -o discrete_geometry.exe

