/*
 * Integration template into OpenCascade CAD engine.
 * This file describes how to import an OpenCascade TopoDS_Shape
 * into the meshgems cad_t structure. The function generate_mesh
 * defined in mg-cadsurf_template_common.cpp is then called to
 * build a surface mesh using MG-CADSurf.
 */

#define CREATE_DCAD 0
#define IMPORT_WIRE 0
#define IMPORT_3D_CURVE 0
#define CREATE_PERIODICITY 0

#include <string.h>
#include <iostream>
#include <sstream>
#include <time.h>
#include <stdlib.h>
#include <assert.h>

extern "C" {
#include <meshgems/meshgems.h>
}
#include <list>
#include <vector>
using namespace std;

#include <config.h>
#include <BRep_Tool.hxx>
#include <BRepTools.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <NCollection_Map.hxx>

#include <Geom_Surface.hxx>
#include <Handle_Geom_Surface.hxx>
#include <Geom2d_Curve.hxx>
#include <Handle_Geom2d_Curve.hxx>
#include <Geom_Curve.hxx>
#include <Handle_Geom_Curve.hxx>
#include <Handle_AIS_InteractiveObject.hxx>
#include <TopoDS_Vertex.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Wire.hxx>
#include <TopoDS_Face.hxx>
#include <GeomAPI_ProjectPointOnSurf.hxx>
#include <gp_Pnt2d.hxx>
#include <TopTools_IndexedMapOfShape.hxx>
#include <TopoDS_Shape.hxx>
#include <BRep_Builder.hxx>
#include <BRepTools.hxx>
#include <IGESControl_Reader.hxx>
#include <STEPControl_Reader.hxx>

status_t generate_mesh(context_t * ctx, cad_t * c, dcad_t * dc,
                       mesh_t * msh);

static status_t curv_function_occ(real t, real * uv, real * dt, real * dtt,
                                  void *user_data)
{
  const Geom2d_Curve *pargeo = (const Geom2d_Curve *) user_data;

  if (uv) {
    gp_Pnt2d P;
    P = pargeo->Value(t);
    uv[0] = P.X();
    uv[1] = P.Y();
  }

  if (dt) {
    gp_Vec2d V1;
    V1 = pargeo->DN(t, 1);
    dt[0] = V1.X();
    dt[1] = V1.Y();
  }

  if (dtt) {
    gp_Vec2d V2;
    V2 = pargeo->DN(t, 2);
    dtt[0] = V2.X();
    dtt[1] = V2.Y();
  }

  return STATUS_OK;
}

static status_t curv3d_function_occ(real t, real * xyz, void *user_data)
{
  const Geom_Curve *pargeo3d = (const Geom_Curve *) user_data;

  if (xyz) {
    gp_Pnt P;
    P = pargeo3d->Value(t);
    xyz[0] = P.X();
    xyz[1] = P.Y();
    xyz[2] = P.Z();
  }

  return STATUS_OK;
}

static status_t curv3d2_function_occ(real t, real * xyz, real * dt,
                                     real * dtt, void *user_data)
{
  const Geom_Curve *pargeo3d = (const Geom_Curve *) user_data;

  if (xyz) {
    gp_Pnt P;
    P = pargeo3d->Value(t);
    xyz[0] = P.X();
    xyz[1] = P.Y();
    xyz[2] = P.Z();
  }

  if (dt) {
    gp_Vec V1;
    V1 = pargeo3d->DN(t, 1);
    dt[0] = V1.X();
    dt[1] = V1.Y();
    dt[2] = V1.Z();
  }

  if (dtt) {
    gp_Vec V2;
    V2 = pargeo3d->DN(t, 2);
    dtt[0] = V2.X();
    dtt[1] = V2.Y();
    dtt[2] = V2.Z();
  }

  return STATUS_OK;
}

static status_t surf_function_occ(real * uv, real * xyz, real * du,
                                  real * dv, real * duu, real * duv,
                                  real * dvv, void *user_data)
{
  const Geom_Surface *geometry = (const Geom_Surface *) user_data;

  if (duu && duv && dvv) {
    gp_Pnt P;
    gp_Vec D1U, D1V;
    gp_Vec D2U, D2V, D2UV;

    geometry->D2(uv[0], uv[1], P, D1U, D1V, D2U, D2V, D2UV);
    duu[0] = D2U.X();
    duu[1] = D2U.Y();
    duu[2] = D2U.Z();

    duv[0] = D2UV.X();
    duv[1] = D2UV.Y();
    duv[2] = D2UV.Z();

    dvv[0] = D2V.X();
    dvv[1] = D2V.Y();
    dvv[2] = D2V.Z();
    if (du && dv) {
      du[0] = D1U.X();
      du[1] = D1U.Y();
      du[2] = D1U.Z();

      dv[0] = D1V.X();
      dv[1] = D1V.Y();
      dv[2] = D1V.Z();
    }
    if (xyz) {
      xyz[0] = P.X();
      xyz[1] = P.Y();
      xyz[2] = P.Z();
    }
  } else if (du && dv) {
    gp_Pnt P;
    gp_Vec D1U, D1V;

    geometry->D1(uv[0], uv[1], P, D1U, D1V);
    du[0] = D1U.X();
    du[1] = D1U.Y();
    du[2] = D1U.Z();

    dv[0] = D1V.X();
    dv[1] = D1V.Y();
    dv[2] = D1V.Z();
    if (xyz) {
      xyz[0] = P.X();
      xyz[1] = P.Y();
      xyz[2] = P.Z();
    }
  } else if (xyz) {
    gp_Pnt P;
    P = geometry->Value(uv[0], uv[1]);
    xyz[0] = P.X();
    xyz[1] = P.Y();
    xyz[2] = P.Z();
  }

  return STATUS_OK;
}

/*
 * This function specifies a transformation between two sets of face you
 * want to make periodic.  xyz contains the coordinates of a point.
 * The coordinates of the image are stored in xyz_image.  See
 * meshgems_cad_periodicity_transformation_t in meshgems/cad.h for
 * information about the function parameters
 */
static status_t periodicity_transformation(real * xyz, real * xyz_image,
                                           void *user_data)
{
  real *r = (real *) user_data;
  integer i;

  for (i = 0; i < 3; i++)
    xyz_image[i] = xyz[i] + (*r);

  return STATUS_OK;
}

typedef struct tdata_occ_t_ {
  const TopoDS_Shape *aShape;
   vector < Handle(Geom_Curve) > curv3dsp;
   vector < Handle(Geom2d_Curve) > curvsp;
   vector < Handle(Geom_Surface) > surfsp;
} tdata_occ_t;

void tdata_occ_delete_fun(void *c)
{
  tdata_occ_t *td = (tdata_occ_t *) c;

  delete td->aShape;
  td->curvsp.clear();
  td->curv3dsp.clear();
  td->surfsp.clear();
  delete td;
}

status_t import_occ_geometry(const TopoDS_Shape & the_shape,
                             context_t * ctx, cad_t ** pc, dcad_t ** pdc)
{
  status_t ret;
  cad_t *c = 0;
  dcad_t *dc = 0;

  assert(ctx);
  ret = STATUS_OK;

  c = cad_new(ctx);
  if (!c)
    return STATUS_NOMEM;

  if (CREATE_DCAD) {
    dc = dcad_new(c);
    if (!dc)
      return STATUS_NOMEM;
  }

  tdata_occ_t *td = new tdata_occ_t;
  if (!td)
    return STATUS_NOMEM;

  td->aShape = &the_shape;
  ret = cad_attach_object(c, td, tdata_occ_delete_fun);
  if (ret != STATUS_OK)
    return ret;

  vector < Handle(Geom_Curve) > &curves3d = td->curv3dsp;
  vector < Handle(Geom2d_Curve) > &curves = td->curvsp;
  vector < Handle(Geom_Surface) > &surfaces = td->surfsp;

  surfaces.resize(0);
  curves.resize(0);
  curves3d.resize(0);

  TopTools_IndexedMapOfShape fmap;
  TopTools_IndexedMapOfShape emap;
  TopTools_IndexedMapOfShape pmap;

  fmap.Clear();
  emap.Clear();
  pmap.Clear();

  Handle(Geom_Surface) geometry;
  Handle(Geom2d_Curve) pargeo;
  Handle(Geom_Curve) pargeo3d;

  int iface = 0;
  for (TopExp_Explorer face_iter(the_shape, TopAbs_FACE); face_iter.More();
       face_iter.Next()) {
    TopoDS_Face f = TopoDS::Face(face_iter.Current());
    if (fmap.FindIndex(f) > 0)
      continue;

    fmap.Add(f);
    iface++;
    surfaces.push_back(BRep_Tool::Surface(f));
    cad_face_t *fce =
        cad_face_new(c, iface, surf_function_occ, surfaces.back());
    if (!fce)
      return STATUS_NOMEM;

    ret = cad_face_set_tag(fce, iface);
    if (ret != STATUS_OK)
      return ret;

    if (f.Orientation() != TopAbs_FORWARD) {
      ret = cad_face_set_orientation(fce, CAD_ORIENTATION_REVERSED);
      if (ret != STATUS_OK)
        return ret;
    } else {
      ret = cad_face_set_orientation(fce, CAD_ORIENTATION_FORWARD);
      if (ret != STATUS_OK)
        return ret;
    }

    if (IMPORT_3D_CURVE) {
      Standard_Real umin, umax, vmin, vmax;
      real ru[2], rv[2];

      BRepTools::UVBounds(f, umin, umax, vmin, vmax);
      ru[0] = umin;
      ru[1] = umax;
      rv[0] = vmin;
      rv[1] = vmax;
      ret = cad_face_set_surface_parametric_range(fce, ru, rv);
      if (ret != STATUS_OK)
        return ret;
    }

    for (TopExp_Explorer edge_iter(f, TopAbs_EDGE); edge_iter.More();
         edge_iter.Next()) {
      TopoDS_Edge e = TopoDS::Edge(edge_iter.Current());
      int ic = emap.FindIndex(e);
      if (ic <= 0)
        ic = emap.Add(e);

      double tmin, tmax;
      curves.push_back(BRep_Tool::CurveOnSurface(e, f, tmin, tmax));
      cad_edge_t *edg;
      real xyz[3];
      cad_vertex_t *vtx;

      edg =
          cad_edge_new(fce, ic, tmin, tmax, curv_function_occ,
                       curves.back());
      if (!edg)
        return STATUS_NOMEM;

      if (IMPORT_3D_CURVE) {
        curves3d.push_back(BRep_Tool::Curve(e, tmin, tmax));
        if (!curves3d.back().IsNull()) {
          ret =
              cad_edge_set_curve3d(edg, curv3d_function_occ,
                                   curves3d.back());
          if (ret != STATUS_OK)
            return ret;
        }
      }

      ret = cad_edge_set_tag(edg, ic);
      if (ret != STATUS_OK)
        return ret;

      /* by default an edge is a boundary edge */
      if (e.Orientation() == TopAbs_INTERNAL) {
        ret = cad_edge_set_property(edg, EDGE_PROPERTY_INTERNAL);
        if (ret != STATUS_OK)
          return ret;
      }

      int ip1, ip2;
      TopoDS_Vertex v1 = TopExp::FirstVertex(e);
      TopoDS_Vertex v2 = TopExp::LastVertex(e);
      ip1 = pmap.FindIndex(v1);
      if (ip1 <= 0)
        ip1 = pmap.Add(v1);
      ip2 = pmap.FindIndex(v2);
      if (ip2 <= 0)
        ip2 = pmap.Add(v2);

      gp_Pnt P1 = BRep_Tool::Pnt(v1);
      xyz[0] = P1.X();
      xyz[1] = P1.Y();
      xyz[2] = P1.Z();
      vtx = cad_vertex_new(c, ip1, xyz);
      if (!vtx)
        return STATUS_NOMEM;

      gp_Pnt P2 = BRep_Tool::Pnt(v2);
      xyz[0] = P2.X();
      xyz[1] = P2.Y();
      xyz[2] = P2.Z();
      vtx = cad_vertex_new(c, ip2, xyz);
      if (!vtx)
        return STATUS_NOMEM;

      ret = cad_edge_set_extremities(edg, ip1, ip2);
      if (ret != STATUS_OK)
        return ret;
      ret = cad_edge_set_extremities_tag(edg, ip1, ip2);
      if (ret != STATUS_OK)
        return ret;

      if (CREATE_DCAD) {
        dcad_edge_discretization_t *de = 0;
        real tt, uv[2], xyz[3];
        integer n_required_vertices, i;
        status_t ret;

        /* dc must have been created earlier */

        /* Get the edge discretization associated to the current edge */
        ret = dcad_get_edge_discretization(dc, edg, &de);
        if (ret != STATUS_OK)
          return ret;

        /* Set its vertex count (extremities included) */
        //n_required_vertices = ...;
        ret =
            dcad_edge_discretization_set_vertex_count(de,
                                                      n_required_vertices);
        if (ret != STATUS_OK)
          return ret;

        /* Set coordinates (t,uv,xyz) of each vertex (extremities included) */
        for (i = 1; i <= n_required_vertices; i++) {
          //tt = ...;
          //uv[0] = ...;
          //uv[1] = ...;
          //xyz[0] = ...;
          //xyz[1] = ...;
          //xyz[2] = ...;
          ret =
              dcad_edge_discretization_set_vertex_coordinates(de, i, tt,
                                                              uv, xyz);
          if (ret != STATUS_OK)
            return ret;
        }
        /* Mark this discretization as required */
        ret =
            dcad_edge_discretization_set_property(de,
                                                  DCAD_PROPERTY_REQUIRED);
        if (ret != STATUS_OK)
          return ret;
      }
    }                           // for edge

  }                             //for face

  if (IMPORT_WIRE) {
    TopExp_Explorer aFloatingEdgeExp(the_shape, TopAbs_EDGE, TopAbs_FACE);
    for (; aFloatingEdgeExp.More(); aFloatingEdgeExp.Next()) {
      const TopoDS_Edge & e = TopoDS::Edge(aFloatingEdgeExp.Current());
      real xyz[3];
      cad_vertex_t *vtx;

      int ic = emap.FindIndex(e);
      if (ic <= 0)
        ic = emap.Add(e);

      double tmin, tmax;
      curves3d.push_back(BRep_Tool::Curve(e, tmin, tmax));
      cad_wire_t *wire;

      wire =
          cad_wire_new(c, ic, tmin, tmax, curv3d2_function_occ,
                       curves3d.back());
      if (!wire)
        return STATUS_NOMEM;

      ret = cad_wire_set_tag(wire, ic);
      if (ret != STATUS_OK)
        return ret;

      int ip1, ip2;

      TopoDS_Vertex v1 = TopExp::FirstVertex(e);
      TopoDS_Vertex v2 = TopExp::LastVertex(e);
      ip1 = pmap.FindIndex(v1);
      if (ip1 <= 0)
        ip1 = pmap.Add(v1);
      ip2 = pmap.FindIndex(v2);
      if (ip2 <= 0)
        ip2 = pmap.Add(v2);

      gp_Pnt P1 = BRep_Tool::Pnt(v1);
      xyz[0] = P1.X();
      xyz[1] = P1.Y();
      xyz[2] = P1.Z();
      vtx = cad_vertex_new(c, ip1, xyz);
      if (!vtx)
        return STATUS_NOMEM;

      gp_Pnt P2 = BRep_Tool::Pnt(v2);
      xyz[0] = P2.X();
      xyz[1] = P2.Y();
      xyz[2] = P2.Z();
      vtx = cad_vertex_new(c, ip2, xyz);
      if (!vtx)
        return STATUS_NOMEM;

      ret = cad_wire_set_extremities(wire, ip1, ip2);
      if (ret != STATUS_OK)
        return ret;
      ret = cad_wire_set_extremities_tag(wire, ip1, ip2);
      if (ret != STATUS_OK)
        return ret;
    }
  }


  /*
   * If you want to set a periodicity meshing constraint (mesh
   * matching) between two sets of cad faces.  See the file
   * meshgems/cad.h for more details
   * (meshgems_cad_add_face_multiple_periodicity_with_transformation_function),
   * and the documentation.
   */
  if (CREATE_PERIODICITY) {
    integer fid1[2], fid2[2];
    integer eid1[2], eid2[2];
    integer size1, size2;
    integer nb_pt1, nb_pt2;
    real p[9], p_im[9], periodic_transformation_user_data;

    /* Example of a translation of vector (1,1,1) : 
     * fill fid1, fid2, eid1, eid2, size1, size2 with your data 
     * (See file meshgems/cad.h)
     */

    assert(size1 == size2);
    /* Set the face periodicities */
    if (1) {
      /* Define the periodic tranformation with points coordinates */
      nb_pt1 = 3;
      nb_pt2 = 3;
      assert(nb_pt1 == nb_pt2);

      /* p contains nb_pt1 points on the first set of face you want to set periodic */
      p[0] = 0;
      p[1] = 0;
      p[2] = 0;

      p[3] = 0;
      p[4] = 1;
      p[5] = 0;

      p[6] = 0;
      p[7] = 0;
      p[8] = 1;

      /* while p_im contains their images on the second set of face */
      p_im[0] = 1;
      p_im[1] = 1;
      p_im[2] = 1;

      p_im[3] = 1;
      p_im[4] = 2;
      p_im[5] = 1;

      p_im[6] = 1;
      p_im[7] = 1;
      p_im[8] = 2;

      /*
       * Set a periodicity between the size1 cad faces of fid1 array and
       * the size2 faces of fid2 array using a transformation defined by
       * the coordinates of nb_pt1 points contained in p and their
       * images contained in p_im See the file meshgems/cad.h for more
       * details on the parameters of this function
       */
      ret =
          cad_add_face_multiple_periodicity_with_transformation_function_by_points
          (c, fid1, size1, fid2, size2, p, nb_pt1, p_im, nb_pt2);
      if (ret != STATUS_OK)
        return ret;
    } else {
      /* Define the periodic tranformation with a callback */

      /*
       * Set a periodicity between the size1 cad faces of fid1 array and
       * the size2 faces of fid2 array using a transformation defined by
       * the periodicity_transformation function See the file
       * meshgems/cad.h for more details on the parameters of this
       * function
       */

      periodic_transformation_user_data = 1;

      ret = cad_add_face_multiple_periodicity_with_transformation_function
          (c, fid1, size1, fid2, size2, periodicity_transformation,
           &periodic_transformation_user_data);
      if (ret != STATUS_OK)
        return ret;
      /* Please note that in case of a translation, you can set
       * periodicity_transformation = 0 and periodic_transformation_user_data = 0.
       * In this case, the CAD preprocessor of MG-CADSurf will compute a 
       * simple translation 
       */
    }

    /* Set the edge periodicities (ie periodicity between edges while
       the associated cad faces are not required to be periodic) */
    if (1) {
      /* Define the periodic tranformation with points coordinates */
      nb_pt1 = 3;
      nb_pt2 = 3;
      assert(nb_pt1 == nb_pt2);

      /* p contains nb_pt1 points on the first set of edge you want to set periodic */
      p[0] = 0;
      p[1] = 0;
      p[2] = 0;

      p[3] = 0;
      p[4] = 1;
      p[5] = 0;

      p[6] = 0;
      p[7] = 0;
      p[8] = 1;

      /* while p_im contains their images on the second set of edge */
      p_im[0] = 1;
      p_im[1] = 1;
      p_im[2] = 1;

      p_im[3] = 1;
      p_im[4] = 2;
      p_im[5] = 1;

      p_im[6] = 1;
      p_im[7] = 1;
      p_im[8] = 2;

      /*
       * Set a periodicity between the size1 cad edges of eid1 array and
       * the size2 faces of eid2 array using a transformation defined by
       * the coordinates of nb_pt1 points contained in p and their
       * images contained in p_im See the file meshgems/cad.h for more
       * details on the parameters of this function
       */
      ret =
          cad_add_edge_multiple_periodicity_with_transformation_function_by_points
          (c, eid1, size1, eid2, size2, p, nb_pt1, p_im, nb_pt2);
      if (ret != STATUS_OK)
        return ret;
    } else {
      /* Define the periodic tranformation with a callback */

      /*
       * Set a periodicity between the size1 cad edges of eid1 array and
       * the size2 faces of eid2 array using a transformation defined by
       * the periodicity_transformation function See the file
       * meshgems/cad.h for more details on the parameters of this
       * function
       */
      periodic_transformation_user_data = 1;
      ret = cad_add_edge_multiple_periodicity_with_transformation_function
          (c, eid1, size1, eid2, size2, periodicity_transformation,
           &periodic_transformation_user_data);
      if (ret != STATUS_OK)
        return ret;
      /* Please note that in case of a translation, you can set
       * periodicity_transformation = 0 and periodic_transformation_user_data = 0.
       * In this case, the CAD preprocessor of MG-CADSurf will compute a 
       * simple translation 
       */
    }
  }

  *pc = c;
  if (dc)
    *pdc = dc;

  return ret;
}

status_t generate_mesh_for_occ(TopoDS_Shape * aShape)
{
  status_t ret;
  cad_t *c = 0;
  dcad_t *dc = 0;
  context_t *ctx = 0;

  assert(aShape);
  ret = STATUS_OK;

  ctx = context_new();
  if (!ctx)
    return STATUS_NOMEM;

  ret = import_occ_geometry(*aShape, ctx, &c, &dc);
  if (ret != STATUS_OK) {
    context_delete(ctx);
    return ret;
  }

  ret = generate_mesh(ctx, c, dc, 0);

  cad_delete(c);
  if (dc)
    dcad_delete(dc);
  context_delete(ctx);

  return ret;
}
