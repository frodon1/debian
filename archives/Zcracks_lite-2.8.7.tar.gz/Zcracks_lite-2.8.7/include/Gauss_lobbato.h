#ifndef __Gauss_lobbato__ 
#define __Gauss_lobbato__ 

#include <Ref_Gauss_point.h> 

Z_START_NAMESPACE;

// ============================================================================ 
//   
// ============================================================================ 


//  
//  The next 2 should be split off to somewhere more basic, like 
//  utility mesh 
//  
// ------------------------------------------------------------
// ------------------------------------------------------------
// #define All_GL_GaussPoint (*_All_GL_GaussPoint())

ZCLASS GAUSS_LABBATO_GP : public REF_GAUSS_POINT {
 public : 
    GAUSS_LABBATO_GP() { } 
    virtual ~GAUSS_LABBATO_GP() { } 
    virtual int integ_type() { return GL_GAUSS; }
};
Z_END_NAMESPACE;

#endif
