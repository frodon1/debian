#define USE_SURFACE_SIZEMAP 0
#define DECIMATE_SURFACE 0
#define OPTIMIZE_ONLY 0
#define GENERATE_QUADRATIC 0

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/meshgems.h>
#include <meshgems/surfopt.h>

/* FOR OEM customers only, uncomment the following */
/* #include <meshgems_key_xxx.h> */

/**
 * Let's assume that the following structure holds data that
 * represents the input surface mesh on client side.  It could be a
 * database handle or anything else containing surface mesh data.  We
 * will build the mesh_t object that accesses it.  See the file
 * meshgems/mesh.h for more detailed information.
 */

struct your_internal_data_t_ {
  /* _your_data; */
};

typedef struct your_internal_data_t_ your_internal_data_t;

/**
 * Implementation of how the number of vertices in the mesh is obtained.
 * @param[out]	nbvtx	: the number of vertices
 * @param[in]     user_data	: a user pointer.
 * @return error code
 */

status_t mgtm_get_vertex_count(integer * nbvtx, void *user_data)
{
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *nbvtx = 0;                   /* the number of vertices in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the coordinates of a mesh vertex are obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	xyz	: real[3] array containing the coordinates of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_coordinates(integer ivtx, real * xyz,
                                     void *user_data)
{
  int j;
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    xyz[j] = 0.0;               /* j'th coordinate of the ivtx'th vertex */

  return STATUS_OK;
}

/**
 * Implementation of how the number of edges in the mesh is obtained.
 * @param[out]	nbedg	: the number of edges
 * @param[in]  user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_count(integer * nbedge, void *user_data)
{
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *nbedge = 0;                  /* the number of edges in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh edge are obtained.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	vedge	: integer[2] array containing the vertices of the edge
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_vertices(integer iedge, integer * vedge,
                                void *user_data)
{
  int j;
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  for (j = 0; j < 2; j++)
    vedge[j] = 0;               /* the j'th vertex index of the iedge'th edge */

  return STATUS_OK;
}

/**
 * Implementation of how the number of triangles in the mesh is obtained.
 * @param[out]	nbtri	: the number of triangles
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_count(integer * nbtri, void *user_data)
{
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *nbtri = 0;                   /* the number of triangles in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh triangle are obtained.
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]	vtri	: integer[3] array containing the vertices of the triangle
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_vertices(integer itri, integer * vtri,
                                    void *user_data)
{
  int j;
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    vtri[j] = 0;                /* the j'th vertex index of the itri'th triangle */

  return STATUS_OK;
}

/**
 * Implementation of how the required status of a mesh vertex is obtained.
 * @param[in]	ivtx	: index of the desired vertex from 1 to nbvtx
 * @param[out]	rvtx	: integer[1] containing the required status (0 or 1)of the vertex 
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_required_property(integer ivtx, integer * rvtx,
                                           void *user_data)
{
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *rvtx = 0;                    /* the ivtx'th vertex required property : 1 if the vertex is required or 0 if it is not */

  return STATUS_OK;
}

/**
 * Implementation of how the weight (sizemap) of a mesh vertex
 * is obtained. 
 * @param[in]	ivtx	: index of the desired vertex from 1 to nbvtx
 * @param[out]	wvtx	: real  containing the weight of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_weight(integer ivtx, real * wvtx, void *user_data)
{
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  /*
   * You have to implement this function if you want to
   * define a sizemap on the surface to drive the mesh 
   * generation (the macro USE_SURFACE_SIZEMAP is set to
   * 1 in this file).
   */

  *wvtx = 0;                    /* the weight of the ivtx'th vertex */

  return STATUS_OK;
}

/**
 * This is the message callback function that will call when
 * it wants to send a message to the caller
 * see meshgems/message.h for more details.
 *
 * @param[in] msg       : the message
 * @param[in] user_data : a user pointer.
 * @return an error code
 */
status_t my_message_cb(message_t * msg, void *user_data)
{
  char *desc;
  integer e, ibuff[6];
  real rbuff[3];

  message_get_description(msg, &desc);
  message_get_number(msg, &e);

  if (e == MESHGEMS_SURFOPT_CODE(xxx)) {
    /* This is the error xxx related to BLABLA.
     * Get the associated integer data [1..4]
     */
    message_get_integer_data(msg, 1, 4, ibuff);
    printf("Point/face intersection : %i in %i %i %i\n",
           ibuff[0], ibuff[1], ibuff[2], ibuff[3]);
  } else if (e == MESHGEMS_SURFOPT_CODE(-5120)) {
    .....;
  } else {
    /* No specific handler for this message. Just print its description */
    printf("Message (%i) : %s", e, desc);
  }

  return STATUS_OK;
}

status_t set_surfopt_parameters(surfopt_session_t * prs)
{
  status_t ret;

  /* You can here specify the MG-SurfOpt options, using the API function
   * surfopt_set_param().
   */

  /* Check the MG-SurfOpt API's Manual, section 3.4 to know what are the
   * available parameters.
   * See examples below.
   */

  /* For example : 
   * This option changes the verbosity level of MG-SurfOpt, between 1 and
   * 10.  The higher it is, the more messages MG-SurfOpt will send
   * through the message callback. Default is 3.
   */
  ret = surfopt_set_param(prs, "verbose", "3");
  if (ret != STATUS_OK)
    return ret;

  /* By default, MG-SurfOpt does enrich the input mesh on the first hand.
   * If you want to deactivate this, you have to set this parameter to "no"
   */
  if (DECIMATE_SURFACE) {
    ret = surfopt_set_param(prs, "enrich", "no");
    if (ret != STATUS_OK)
      return ret;
  }

  /* If you want MG-SurfOpt only to optimize the input mesh, without
   * coarsening nor refining it you have to set this parameter to "only" */
  if (OPTIMIZE_ONLY) {
    ret = surfopt_set_param(prs, "optimisation", "only");
    if (ret != STATUS_OK)
      return ret;
  }

  /* If you want MG-SurfOpt to use Hausdorff-like sizemap you have to set 
   * this parameter to "yes"
   */
  ret = surfopt_set_param(prs, "Hausdorff_like", "yes");
  if (ret != STATUS_OK)
    return ret;

  /* If you want MG-SurfOpt to generate a quadratic mesh, you have to set
   * this parameter to "quadratic"
   */
  if (GENERATE_QUADRATIC) {
    ret = surfopt_set_param(prs, "element_order", "quadratic");
    if (ret != STATUS_OK)
      return ret;
  }

  /* Set the desired maximum ratio between 2 adjacent triangle
   * edges. The closer it is to "1", the more uniform the mesh will be
   * Default value is "1.3"
   */
  ret = surfopt_set_param(prs, "gradation", "1.3");
  if (ret != STATUS_OK)
    return ret;

  return ret;
}

/* A macro we will call to cleanly return from the function in case of
 * failure. Deleting the context will delete all attached MeshGems
 * object (sessions, meshes, sizemaps, ...)
 */
#define RETURN_WITH_MESSAGE(_ret, _msg) do{				\
    fprintf(stderr,"%s\n",_msg);					\
    if(ctx) context_delete(ctx);					\
    return _ret;							\
  }while(0);

status_t generate_mesh(your_internal_data_t * your_internal_data)
{
  status_t ret;
  context_t *ctx;
  mesh_t *msh, *vmsh;
  surfopt_session_t *prs;
  sizemap_t *sizemap, *vsizemap;
  integer *buff;
  integer type;
  integer i, nvm, ntm;
  integer nsd;
  real q, qmin, qmax;

  ctx = 0;
  msh = 0;
  prs = 0;
  vmsh = 0;
  sizemap = 0;
  vsizemap = 0;

  /*
   * Create the meshgems working context
   */
  ctx = context_new();
  if (!ctx)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new context");

  /*
   * Set the message callback for our context.
   */
  ret = context_set_message_callback(ctx, my_message_cb, 0);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /*
   * Create the mesh_t structure holding the callbacks giving acces to your mesh data in
   * your_internal_data
   */
  msh = mesh_new(ctx);
  if (!msh)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new mesh");

  /*
   * Set the mesh_t callback functions that will query your_internal_data structure :
   * see meshgems/mesh.h for detailed function prototypes.
   */

  mesh_set_get_vertex_count(msh, mgtm_get_vertex_count,
                            your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_vertex_coordinates(msh, mgtm_get_vertex_coordinates,
                                  your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_vertex_required_property(msh,
                                        mgtm_get_vertex_required_property,
                                        your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  mesh_set_get_edge_count(msh, mgtm_get_edge_count, your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_edge_vertices(msh, mgtm_get_edge_vertices,
                             your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  mesh_set_get_triangle_count(msh, mgtm_get_triangle_count,
                              your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_triangle_vertices(msh, mgtm_get_triangle_vertices,
                                 your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  if (0) {
    /*
     * Display some statistics about the surface mesh.
     * The data is sent formatted to the context message callback
     * For debugging purposes
     */
    mesh_compute_statistics(msh);
  }
#ifdef __MESHGEMS_PRIVKEY_H__
  /* If you are an OEM customer for MG-SurfOpt, sign this mesh object with
   * your private key (else MG-SurfOpt would reject it) */
  ret = sign_mesh(msh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to sign input mesh");
#endif

  /*
   * Create a surfopt session
   */

  prs = surfopt_session_new(ctx);
  if (!prs)
    RETURN_WITH_MESSAGE(STATUS_NOMEM,
                        "unable to create a new surfopt session");

  /*
   * Set the input working surface mesh for this surfopt session
   */

  ret = surfopt_set_surface_mesh(prs, msh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to set surface mesh");

  if (USE_SURFACE_SIZEMAP) {
    sizemap =
        meshgems_sizemap_new(msh,
                             meshgems_sizemap_type_iso_mesh_vertex,
                             mgtm_get_vertex_weight, your_internal_data);
    if (!sizemap)
      RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new sizemap");
  }

  if (sizemap) {
    ret = surfopt_set_sizemap(prs, sizemap);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to set sizemap");
  }

  ret = set_surfopt_parameters(prs);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to set surfopt paramters");

  /* 
   * The mesh generation process. 
   * See the meshgems/surfopt.h file for more details
   */

  ret = surfopt_compute(prs);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "Unable to perform the mesh processing");

  /*
   * Mesh generation is completed. Get the generated surface
   * mesh. This output mesh belongs to the surfopt_session. Thus the
   * user does not have to delete it afterwards.
   */

  ret = surfopt_get_mesh(prs, &vmsh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting mesh");

  /*
   * If you are interested in this information, you can also
   * get the surface sizemap used by MG-SurfOpt to generate the mesh.
   * This output sizemap belongs to the surfopt_session.
   * Thus the user does not have to delete it afterwards.
   */

  ret = surfopt_get_sizemap(prs, &vsizemap);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting sizemap");

  /*
   * Read the output mesh data. See meshgems/mesh.h for more detailed
   * prototypes.
   */

  /* First get all the vertices */
  ret = mesh_get_vertex_count(vmsh, &nvm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex count");

  ret = mesh_get_triangle_count(vmsh, &ntm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting triangle count");

  for (i = 1; i <= nvm; i++) {
    real coo[3];
    ret = mesh_get_vertex_coordinates(vmsh, i, coo);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting vertices");
    if (0) {
      fprintf(stdout, "vertex %d coordinates are : %e %e %e \n", i,
              coo[0], coo[1], coo[2]);
    }
  }

  /* Then get all the triangle and compute some statistics on their aspect ratio */

  qmin = REAL_INFINITY;
  qmax = -REAL_INFINITY;
  buff = (integer *) mesh_calloc_generic_buffer(vmsh);

  for (i = 1; i <= ntm; i++) {
    integer vtx[3], tag;
    ret = mesh_get_triangle_vertices(vmsh, i, vtx);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting triangle");
    if (0) {
      fprintf(stdout, "triangle %d vertices are : %d %d %d \n", i,
              vtx[0], vtx[1], vtx[2]);
    }

    if (GENERATE_QUADRATIC) {
      ret = mesh_get_triangle_extra_vertices(vmsh, i, &type, buff);
      if (ret != STATUS_OK)
        return ret;

      if (type == MESHGEMS_MESH_ELEMENT_TYPE_TRIA6) {
        /* This is a quadratic triangle
         * buff is filled with the quadratic nodes indices
         */
        printf("triangle %d quadratic extra vertices are %d %d %d\n", i,
               buff[0], buff[1], buff[2]);
      }
    }

    ret = mesh_get_triangle_tag(vmsh, i, &tag);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting triangle tag");
    if (0) {
      fprintf(stdout, "triangle %d is in subdomain %d\n", i, tag);
    }
    mesh_get_triangle_aspect_ratio(vmsh, i, &q);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "internal error");
    if (q > qmax)
      qmax = q;
    if (q < qmin)
      qmin = q;
  }
  mesh_free_generic_buffer(buff);

  fprintf(stdout, "\nGenerated %d vertices and %d triangle  \n", nvm, ntm);
  fprintf(stdout, "          with a quality within [%f,%f]\n", qmin, qmax);

  /*
   * We can also directly write a .mesh formated file and a .sol formated file for the sizemap : 
   */

  fprintf(stdout, "Writing surface mesh in surfopt.mesh file\n");
  ret = mesh_write_mesh(vmsh, "surfopt.mesh");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a .mesh file");

  fprintf(stdout, "Writing surface sizemap in surfopt.sol\n");
  ret = sizemap_write_sol(vsizemap, "surfopt.sol");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a .sol file");

  if (0) {
    /*
     * Display some statistics about the output mesh.
     * The data is sent formated to the context message callback
     * for debugging purposes.
     */
    mesh_compute_statistics(vmsh);
  }

  /*
   * We are done, give the surface mesh and sizemap back to the session and clean up everything.
   */
  surfopt_regain_mesh(prs, vmsh);
  surfopt_regain_sizemap(prs, vsizemap);
  surfopt_session_delete(prs);

  mesh_delete(msh);
  if (sizemap)
    sizemap_delete(sizemap);

  context_delete(ctx);

  return STATUS_OK;
}
