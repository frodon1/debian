#ifndef __MESHGEMS_BASIC_TYPES_H__
#define __MESHGEMS_BASIC_TYPES_H__


/**

\defgroup basic_types Basic Types
@{

Basic MeshGems types.

In this section, we give a few basic MeshGems types and macros to work
with integer and real type.  The user should not assume anything about
these types and only use the types and macros defined here. The
implementation of these types may indeed be changed at some point for
some specific versions or platforms.

*/


/**
 * Defines the type we use in the API to represent integer numbers.
 */
typedef int meshgems_integer;

/**
 * Defines the type we use in the API to represent real numbers.
 */
typedef double meshgems_real;


#include <math.h>
#include <limits.h>

/**
 * \name Usefull macros
 */
/**@{*/

/**
 * Defines the infinity value for real numbers.
 */
#define MESHGEMS_REAL_INFINITY HUGE_VAL

/**
 * Defines the largest integer number that can be represented.
 */
#define MESHGEMS_INTEGER_MAX INT_MAX
/**@}*/
/**@}*/

#endif
