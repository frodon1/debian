#ifndef __Mesh_command__
#define __Mesh_command__

#include <Zmaster_extension.h>
#include <Mesh_command_wrapper.h>

Z_START_NAMESPACE;

class UTILITY_MESH;
class B_UTILITY_SET;
class GRAPHICS_DATA_DIALOG;
class UTILITY_NODE;
class MESH_COMMAND;

struct READ_GEOF_INFO
{
   DAO_GEOMETRY* geom;
   UTILITY_MESH* mesh;
   STRING        fname;
   STRING        fmt;
   GAUGE         *gauge;
   int           is_in_thread;
   int           Is_parallel_computation;
};

ZCLASS2 MESH_COMMAND : public ZMASTER_EXTENSION
{
  protected :
    int attempted_read_on_mesh;
    int skip_redraw;
    int needs_setup;

    UTILITY_NODE* last_click_node;

    ARRAY<STRING> nsets,  nset_visu;
    ARRAY<STRING> elsets, elset_visu;
    ARRAY<STRING> bsets,  bset_visu;

    AUTO_PTR<GRAPHICS_COMMAND>  SelectNset;
    AUTO_PTR<GRAPHICS_COMMAND>  SelectFaset;

    int show_node_nul;
    int show_elem_num;

    bool colored_elsets;

    GRAPHICS_DATA_DIALOG* its_dialog;
    GRAPHICS_DATA_DIALOG* its_nset_dialog;
    GRAPHICS_DATA_DIALOG* its_bset_dialog;
    GRAPHICS_DATA_DIALOG* its_elset_dialog;
    GRAPHICS_DATA_DIALOG* add_dialog;

    void setup_dialog();
    void setup_nset_dialog();
    void setup_bset_dialog();
    void setup_elset_dialog();

    VECTOR min_coord, max_coord, ave_coord;
    void check_extents();

    ARRAY<int> elems_color;
    ARRAY<int> save_options;
    ARRAY<int> save_nset_options, save_bset_options;
    ARRAY<int> save_elset_options;

    LIST<int>  options,nset_options,bset_options,elset_options;
    int        view_option;

    MESH_COMMAND_WRAPPER wrapper;

  public :
    VECTOR  vc_pos;

    MESH_COMMAND();
    virtual ~MESH_COMMAND();
    virtual void initialize(GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app);

    virtual bool do_command(STRING cmd);
    virtual bool do_click( int, GRAPHICS_POINT& clk, GRAPHICS_OBJECT* target);
    virtual bool do_click( );
    virtual void build_lists();

};

/*
ZCLASS2 MULTI_MESH_COMMAND : public ZMASTER_EXTENSION
{
   protected :
      bool meshes_unload_dialog_need_setup;

      ARRAY<STRING> meshes_names;

      GRAPHICS_DATA_DIALOG* meshes_unload_dialog;

      void setup_meshes_unload_dialog();

      // MESH_COMMAND_WRAPPER wrapper;

   public :
 
      MULTI_MESH_COMMAND();
      virtual ~MULTI_MESH_COMMAND();
      virtual void initialize(GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app);

      virtual bool do_command(STRING cmd);
};

*/
Z_END_NAMESPACE;

#endif
