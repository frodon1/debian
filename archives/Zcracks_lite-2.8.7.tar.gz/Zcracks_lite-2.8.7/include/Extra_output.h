#ifndef __Extra_output__
#define __Extra_output__

#include <Stringpp.h>
#include <File.h>

Z_START_NAMESPACE;

class PROBLEM;

// SQ: 10/29/02
// Used for example to output contact internal variables
// to .node files: see derived class CONTACT_EXTRA_OUTPUT
// Can be used for something else ?
// Only nodal variables stuff is implemented 
// and use is restricted to the OUTPUT_Z7 mode

ZCLASS2 EXTRA_OUTPUT {
  protected :
    PROBLEM* its_problem;

  public :
    LIST<STRING> ut_node_info;

    EXTRA_OUTPUT();
    virtual ~EXTRA_OUTPUT();

    virtual void initialize() { }
    virtual void initialize(PROBLEM*,ASCII_FILE&)=0;
    virtual void calc_val_at_node(int icomp,ARRAY<float>& val)=0; 
   
};

Z_END_NAMESPACE;
#endif
