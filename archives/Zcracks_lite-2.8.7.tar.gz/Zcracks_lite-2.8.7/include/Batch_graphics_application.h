#ifndef __Batch_graphics_application__
#define __Batch_graphics_application__

#include <Graphics_application_loader.h> 
#include <Batch_lexer_entry.h>

Z_START_NAMESPACE;

ZCLASS2 BATCH_APPLICATION_LOADER : public GRAPHICS_APPLICATION_LOADER {

  public :
     BATCH_LEXER_ENTRY *ble;

     BATCH_APPLICATION_LOADER();
     virtual ~BATCH_APPLICATION_LOADER();
    
     // 
     // Graphics app stuff 
     //
     virtual int do_begin();
     virtual void do_creator(GRAPHICS_APPLICATION* app); 
     virtual void do_destructor();
     virtual void do_quit();

     virtual void do_destruction_stuff();
     virtual void do_creation_stuff();
     virtual bool do_base_command(STRING str);

     // 
     // Graphics command stuff 
     //
     virtual GRAPHICS_COMMAND* fabricate_command(int x, int y, STRING type, 
                                   GRAPHICS_COMMAND* boss, 
                                   GRAPHICS_APPLICATION* app);

     virtual void              configure_command(int x, int y, 
                                   GRAPHICS_COMMAND* the_command, 
                                   GRAPHICS_COMMAND* boss, 
                                   GRAPHICS_APPLICATION* app);
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
