#ifndef __Dof_fix_spec__
#define __Dof_fix_spec__ 

//============================================================================
// This dof is used by BC_impose_nodal_file
//============================================================================

#include <Boundary_condition.h>
#include <Boundary.h>

Z_START_NAMESPACE;

ZCLASS2 DOF_FIX_SPEC { 

  public :

    BUFF_LIST<int>       node_id; 
    BUFF_LIST<DOF_TYPE*> dof_type;
    BUFF_LIST<double>    value; 

    double  time; 
    double  scale; 
    STRING  fname;

    int     current_id; 
 
    DOF_FIX_SPEC(); 
    void   load(int ipc); 
    void   load(int ipc, int no_vals_period,
                BUFF_LIST<DOF_TYPE*>& dt, BUFF_LIST<int>& node_list);
    double value_for_node(int n_id_in);     

}; 
Z_END_NAMESPACE;

#endif 
