This document gives some hints on how you can compile the teapot example

First, copy the corresponding dynamic libraries and the meshgems include directory in this directory.

Then, run 

      * ./compile.sh on a Linux platform
or 
      * compile.bat on a Windows platform

A teapot.exe executable will be created in this directory.

