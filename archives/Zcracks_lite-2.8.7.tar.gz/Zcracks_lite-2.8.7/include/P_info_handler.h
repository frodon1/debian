#ifndef __P_INFO_HANDLER__
#define __P_INFO_HANDLER__

#include <Bool.h>
#include <Handler_mp.h>
#include <Server.h>

Z_START_NAMESPACE;

#define P_INFO 1011

ZCLASS P_INFO_HANDLER : public HANDLER_MP
{
  protected :
    int how_many;
    LIST<STRING> hosts,cwds;
    LIST< LIST<int> > domains_rank;
    LIST<int> nbt;

  public :
    P_INFO_HANDLER() : HANDLER_MP() { how_many=0; }
   ~P_INFO_HANDLER(void) { }

    DECLARE_HANDLER;
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
