#ifndef __Zmat_standard_benchmark__
#define __Zmat_standard_benchmark__

#include <Base_problem.h>
#include <Stringpp.h>

Z_START_NAMESPACE;

class ZMAT_STANDARD_BENCHMARK : public BASE_PROBLEM {
  public :
    STRING dumpname;

    ZMAT_STANDARD_BENCHMARK();
    virtual ~ZMAT_STANDARD_BENCHMARK();

    virtual bool Execute(void);
    virtual void load(const STRING&,const STRING&);
};

Z_END_NAMESPACE;


#endif
