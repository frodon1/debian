#ifndef __Debound_behavior__
#define __Debound_behavior__


#include <Bool.h>
#include <Behavior.h>
#include <Int_variable_holder.h>
#include <Mat_data.h>

Z_START_NAMESPACE;

ZCLASS DEBOUND_BEHAVIOR : public BEHAVIOR {
  protected :
     VECTOR_FLUX Pt;
     SCALAR_FLUX Pn;
     VECTOR_GRAD Ut;
     SCALAR_GRAD Un;
  public :
     DEBOUND_BEHAVIOR();
     virtual void  initialize(ASCII_FILE&, int, LOCAL_INTEGRATION*);
     virtual bool  if_broken(const MAT_DATA& m)const=0;
     virtual bool  if_has_just_broken(MAT_DATA& m)=0;
     virtual bool  is_masvol_required(){return 0;}

     RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
