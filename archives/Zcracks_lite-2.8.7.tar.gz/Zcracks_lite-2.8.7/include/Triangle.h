#ifndef __triangle__
#define __triangle__
/*****************************************************************************/
/*                                                                           */
/*  (triangle.h)                                                             */
/*                                                                           */
/*  Include file for programs that call Triangle.                            */
/*                                                                           */
/*  Accompanies Triangle Version 1.6                                         */
/*  July 28, 2005                                                            */
/*                                                                           */
/*  Copyright 1996, 2005                                                     */
/*  Jonathan Richard Shewchuk                                                */
/*  2360 Woolsey #H                                                          */
/*  Berkeley, California  94705-1927                                         */
/*  jrs@cs.berkeley.edu                                                      */
/*                                                                           */
/*****************************************************************************/

struct triangulateio {
  double *pointlist;                                               
  double *pointattributelist;                                 
  int *pointmarkerlist;                                    
  int numberofpoints;                                   
  int numberofpointattributes;                         

  int *trianglelist;                                           
  double *triangleattributelist;                                   
  double *trianglearealist;                                      
  int *neighborlist;                                         
  int numberoftriangles;                                 
  int numberofcorners;                                  
  int numberoftriangleattributes;                  

  int *segmentlist;                            
  int *segmentmarkerlist;                    
  int numberofsegments;              

  double *holelist;                    
  int numberofholes;               

  double *regionlist;           
  int numberofregions;     

  int *edgelist;          
  int *edgemarkerlist;  
  double *normlist;      
  int numberofedges;
};

void triangulate(char *, struct triangulateio *, struct triangulateio *,
                 struct triangulateio *);

void trifree(void *memptr);

#endif

