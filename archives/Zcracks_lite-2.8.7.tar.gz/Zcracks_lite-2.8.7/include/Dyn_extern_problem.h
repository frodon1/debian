#ifndef __DYN_EXTERN_PROBLEM__
#define __DYN_EXTERN_PROBLEM__

#include <Clock.h>
#include <Discrete_timer.h>
#include <Dynamic.h>
#include <External_parameter.h>
#include <Localisation.h>

Z_START_NAMESPACE;

class GLOBAL_MATRIX;

ZCLASS2 DYN_EXTERN_PROBLEM : public PROBLEM_DYNAMIC_MECHANICAL 
{
  private :
    void error(int,...);

  protected :
    GLOBAL_MATRIX *K;

  public :
    DISCRETE_TIMER its_dt;

    DYN_EXTERN_PROBLEM();
    virtual ~DYN_EXTERN_PROBLEM();

    virtual void load(const STRING&,const STRING&);
    virtual bool verification(void);
    virtual void add_next_sequence(int,int,int,double,double,double,double,STRING,STRING,int);

    virtual void reload(const STRING&);
    virtual void save(const STRING&);

    void next_sequence();
    virtual void next_sequence(int&);
    virtual void set_name(const STRING&);

    virtual void output_data(bool forced=FALSE);
   
    void close_output_files();
    void reopen_output_files();
    void reset_sequence();

    virtual void apply_external_load(double,double);
    virtual int end_of_step(double,double);

    void set_globals();
    void unset_globals();

    virtual void localization_update_tg_matrix(SMATRIX& /* s */, LOCALISATION::LOCAL_INFO *infos=NULL) {
      ERROR("Not implemented : DYN_EXTERN_PROBLEM::localization_update_tg_matrix()"); 
    }
  
    LIST<EXTERNAL_PARAM*>* get_external_parameters() { return(&external_param); }
};
Z_END_NAMESPACE;

#endif
