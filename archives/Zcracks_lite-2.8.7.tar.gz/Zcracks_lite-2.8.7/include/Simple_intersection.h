#ifndef __Simple_intersection__ 
#define __Simple_intersection__ 

// ============================================================================ 
//  TRANSFER_SIMPLE_INTERSECTION                                 RF 01/19/2004
// 
//  Set of classes for simple geometrical intersection calculations, and 
//  point projected onto a curve. Used by crack methods and Xfem splitting 
//  of elements. 
//  
//  ** this is put at the zTransfer level because I want freedom to do 
//     specialized things possibly (and don't want the responsibility of 
//     making a general API). 
// ============================================================================ 

#include <List.h> 
#include <ZMath.h>

#include <Mesh.h> 
#include <Function.h>

Z_START_NAMESPACE;

ZCLASS2 TSI_OBJ_BASE {
  public :
   double tmin,tmax;
   TSI_OBJ_BASE() { tmin=0.0; tmax=1.0; } 
   virtual ~TSI_OBJ_BASE() { } 

   virtual VECTOR x(double t)=0;
   virtual VECTOR dxdt(double t)=0;
   virtual VECTOR d2xdt2(double t)=0;

   VECTOR normal(double t);

   static TSI_OBJ_BASE* make(ARRAY<UTILITY_NODE*>& nodes); 
};  

ZCLASS2 TSI_OBJ_LINE : public TSI_OBJ_BASE { 
  public : 
   VECTOR dx; 
   VECTOR p1, p2; 

   TSI_OBJ_LINE();
   virtual ~TSI_OBJ_LINE();

   virtual VECTOR x(double t); 
   virtual VECTOR dxdt(double t); 
   virtual VECTOR d2xdt2(double t); 
}; 

ZCLASS2 TSI_OBJ_MULTI_LINE : public TSI_OBJ_BASE {
  protected :
    int find_interval(double);

  public :
    double projection_tolerance;
    LIST<VECTOR> points;
    LIST<double> all_t;
    int last_t; // last interval access, for optimization (guessing that this object is used within a loop)
    bool closed;

    TSI_OBJ_MULTI_LINE();
    virtual ~TSI_OBJ_MULTI_LINE();

    virtual VECTOR x(double t);
    virtual VECTOR dxdt(double t);
    virtual VECTOR d2xdt2(double t);

//
// Returns the projection of pt on this multiline, trying to minimize the distance
//
   double normal_point(VECTOR& pt, double& t1); 
};

ZCLASS2 TSI_OBJ_FUNCTION : public TSI_OBJ_BASE {
  public :
   FUNCTION *Fx,*Fy;

   TSI_OBJ_FUNCTION();
   virtual ~TSI_OBJ_FUNCTION();
                                                                                                                                            
   virtual VECTOR x(double t);
   virtual VECTOR dxdt(double t);
   virtual VECTOR d2xdt2(double t);
};

ZCLASS2 TSI_OBJ_QUADRATIC : public TSI_OBJ_BASE { 
  public :
   VECTOR p1, p2, p3; 

   TSI_OBJ_QUADRATIC();
   virtual ~TSI_OBJ_QUADRATIC();

   virtual VECTOR x(double t);
   virtual VECTOR dxdt(double t);
   virtual VECTOR d2xdt2(double t); 
};  

ZCLASS2 TRANSFER_SIMPLE_INTERSECTION { 
  public : 
   double precision; 
   bool distance_at_ends; // JSB added 22Aug06

   TRANSFER_SIMPLE_INTERSECTION(); 
   ~TRANSFER_SIMPLE_INTERSECTION(); 

//
// Computes the couple of closests points bewteen obj1 and obj2
//   't1' and 't2', as results, contains the parametric of these points 
//   it returns the distance between the closests points
//
   double intersect(double& t1, TSI_OBJ_BASE& obj1, 
                    double& t2, TSI_OBJ_BASE& obj2 ); 

//
// Returns TRUE of FALSE if the given distance is small enough to be considered as zero
//
   bool   zero_distance(double dist); 

//
// Returns the projection of pt on obj1. Also returns the distance between the two (exterma point)
//
   double normal_point(VECTOR& pt, double& t1, TSI_OBJ_BASE& obj1); 
}; 
Z_END_NAMESPACE;

#endif 
