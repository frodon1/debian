#ifndef __PID_OBJECTIVE__
#define __PID_OBJECTIVE__

#include <File.h>
#include <Mesh.h>

Z_START_NAMESPACE;

class PID_OBJECTIVE
{
  public :
    PID_OBJECTIVE();
    virtual ~PID_OBJECTIVE();

    virtual double compute(MESH&)=0;
    virtual void initialize(ASCII_FILE&);
};
Z_END_NAMESPACE;

#endif
