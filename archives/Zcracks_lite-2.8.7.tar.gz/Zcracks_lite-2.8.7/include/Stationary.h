#ifndef __PROBLEM_THERMAL_STATIONARY__
#define __PROBLEM_THERMAL_STATIONARY__

#include <Thermal_problem.h>

Z_START_NAMESPACE;

class PROBLEM_THERMAL_STATIONARY : public PROBLEM_THERMAL {
   public :
      PROBLEM_THERMAL_STATIONARY();
      virtual ~PROBLEM_THERMAL_STATIONARY();

      virtual bool Initialize();
      RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
