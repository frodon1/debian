#ifndef __Crystal_hardening_matrix__
#define __Crystal_hardening_matrix__

#include <Material_piece.h>

Z_START_NAMESPACE;

ZCLASS CRYSTAL_HARDENING_MATRIX  : public MATERIAL_PIECE {
  protected :
     SMATRIX inter;
     void _initialize(int,MATERIAL_PIECE*);
   public :
     CRYSTAL_HARDENING_MATRIX();
     virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*)=0;
     virtual ~CRYSTAL_HARDENING_MATRIX();
     virtual void computeHq(const VECTOR&,VECTOR&);
     double  get_inter(int i, int j) { return inter(i,j); }
     RTTI_INFO;
};  
    
ZCLASS FCC_OCTAHEDRAL_IMATRIX : public CRYSTAL_HARDENING_MATRIX {
     COEFF h1,h2,h3,h4,h5,h6;
   public :
     FCC_OCTAHEDRAL_IMATRIX();
     virtual ~FCC_OCTAHEDRAL_IMATRIX();
     virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
     RTTI_INFO;
};  
    
ZCLASS BCC_IMATRIX : public CRYSTAL_HARDENING_MATRIX {
     COEFF h1,h2,h3,h4,h5,h6,h7,h8;
    public :
       BCC_IMATRIX();
       virtual ~BCC_IMATRIX();
       virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
     RTTI_INFO;
};  
    
    
ZCLASS SINGLE_SLIP_IMATRIX : public CRYSTAL_HARDENING_MATRIX {
     COEFF h1;
   public :
     SINGLE_SLIP_IMATRIX();
     virtual ~SINGLE_SLIP_IMATRIX();
     virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
     RTTI_INFO;
};

ZCLASS HCP_BASAL_IMATRIX : public CRYSTAL_HARDENING_MATRIX {
     COEFF h1,h2;
   public :
     HCP_BASAL_IMATRIX();
     virtual ~HCP_BASAL_IMATRIX();
     virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
     RTTI_INFO;
};
 
ZCLASS HCP_PRISMATIC_IMATRIX : public CRYSTAL_HARDENING_MATRIX {
     COEFF h1,h2;
   public :
     HCP_PRISMATIC_IMATRIX();
     virtual ~HCP_PRISMATIC_IMATRIX();
     virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
     RTTI_INFO;
};
 
ZCLASS HCP_PYRAMIDALPi1_IMATRIX : public CRYSTAL_HARDENING_MATRIX {
     COEFF h1,h2,h3,h4,h5,h6;
   public :
     HCP_PYRAMIDALPi1_IMATRIX();
     virtual ~HCP_PYRAMIDALPi1_IMATRIX();
     virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
     RTTI_INFO;
};

ZCLASS HCP_PYRAMIDALPi2_IMATRIX : public CRYSTAL_HARDENING_MATRIX {
     COEFF h1,h2,h3,h4,h5,h6;
   public :
     HCP_PYRAMIDALPi2_IMATRIX();
     virtual ~HCP_PYRAMIDALPi2_IMATRIX();
     virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
     RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
