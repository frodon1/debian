#ifndef __Mat_data_init__
#define __Mat_data_init__

#include <Stringpp.h>

#include <Mat_data.h>

Z_START_NAMESPACE;

// A base class used to init material variables were they are stored ...

class BEHAVIOR;

ZCLASS MATERIAL_DATA_INIT {
  protected :
     friend class BEHAVIOR;
     STRING var_name;

  public :
     MATERIAL_DATA_INIT(const STRING&);
     MATERIAL_DATA_INIT() { }

     virtual ~MATERIAL_DATA_INIT();
     virtual void do_init(MAT_DATA&,BEHAVIOR*,VECTOR&)=0;
     virtual void initialize() { }
};

ZCLASS CONSTANT_MATERIAL_DATA_INIT : public MATERIAL_DATA_INIT {
  protected :
     double val;
  public :
     CONSTANT_MATERIAL_DATA_INIT(const STRING&,double);
     virtual ~CONSTANT_MATERIAL_DATA_INIT();
     virtual void do_init(MAT_DATA&,BEHAVIOR*,VECTOR&);
};

Z_END_NAMESPACE;

#endif
