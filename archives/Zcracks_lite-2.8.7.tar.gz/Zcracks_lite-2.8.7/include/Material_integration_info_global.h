#ifndef __Material_integration_info__
#define __Material_integration_info__

#include <Vector.h> 
#include <Matrix.h> 
#include <Material_integration_info.h>

Z_START_NAMESPACE;

ZCLASS MATERIAL_INTEGRATION_INFO_GLOBAL : public MATERIAL_INTEGRATION_INFO {
  public :
    MATERIAL_INTEGRATION_INFO_GLOBAL() : MATERIAL_INTEGRATION_INFO() { }
    MATERIAL_INTEGRATION_INFO_GLOBAL(double _t0,double _dt) : MATERIAL_INTEGRATION_INFO(_t0,_dt)  { }
};

Z_END_NAMESPACE;

#endif
