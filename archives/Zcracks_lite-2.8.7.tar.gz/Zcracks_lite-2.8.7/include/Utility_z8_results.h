#ifndef __Utility_z8_results__
#define __Utility_z8_results__

// ============================================================================ 
//  Version 8 results and mesh files (really 8.4+)        RF Nov 2002 
// 
//  The creation is still a little bit roundabout. In Zmaster it only checks 
//  for a mesh-reader.. so that thing has to be able to bootstrap loading 
//  when the  user selects a .zres filesystem
// ============================================================================ 

#include <List.h> 
#include <Marray.h> 
#include <Vector.h> 
#include <Defines.h> 
#include <Utility_mesh.h> 
#include <Utility_results_database.h> 
#include <Utility_buffered_file.h> 
#include <Utility_dir_file_driver.h> 
#include <Utility_mesh_reader.h> 
#include <Pointer.h>

#include <Output_z8.h> 

Z_START_NAMESPACE;

ZCLASS2 UTILITY_Z8_RESULTS; 

// 
// ASCII meaning ascii geof.. 
// 
ZCLASS2 UTILITY_Z8_ASCII_READER : public UTILITY_MESH_READER, 
                                  public UTILITY_BUFFERED_FILE {
    STRING str; 
    int    read_z8_geom_failure; 

    void sniff_out_file();
    void buffer_setup();

    void read_node();
    void read_element();
    void read_nset();
    void read_elset();
    void read_bset();
    void read_ipset();
    void clear_next_cmd();



  public: 
    UTILITY_Z8_RESULTS* res;
    UTILITY_Z8_ASCII_READER();
    virtual ~UTILITY_Z8_ASCII_READER();

    virtual void initialize(ASCII_FILE&,UTILITY_MESH*);
    virtual void geof_load(ASCII_FILE&,UTILITY_MESH*);

    virtual bool update_mesh_for_results(bool ck, const ARRAY<int>&); 

    virtual void write_gmesh_to_geof(STRING out_name, GMESH& mesh); 
}; 

// 
// this is the results database interface used to contain the 
// OUTPUT_Z8's and pass messages on (e.g. get results, write 
// results) to the proper data set. 
// 
ZCLASS2 UTILITY_Z8_RESULTS : public UTILITY_RESULTS_DATABASE { 
  protected : 
    void    refresh_ut();
    void    refresh_ut_par();
    void    erase_ut();

    // 
    // Used for quick access to componentns from a requested name 
    // 
    bool parallel_computation;
    int  nb_domains,my_node;
    LIST< PTR<UTILITY_Z8_RESULTS> > sub_results;

    BUFF_LIST<STRING>       table_var; 
    BUFF_LIST<OUTPUT_COMPONENT*> table_comp; 

    bool check_map_for_mchange(int get_map); 


  public : 
    double last_when; 

    LIST<UTILITY_FILE_DRIVER*> cache_drivers; 
    LIST<UTILITY_MESH*>        cache_meshes; 
    ARRAY< ARRAY<int> >         cache_visible_elsets;

    double               last_m_time; 
    UTILITY_FILE_DRIVER* last_driver; 

    LIST<OUTPUT_COMPONENT*> components; 
    // SQ 01/06/09 : added driverp to load a zresp database in parallel with a zres one 
    //   o zresp components are automatically added to the components list
    //   o drivers for the zresp components are stored in the zres_to_zresp array 
    UTILITY_FILE_DRIVER *driver; 
    UTILITY_FILE_DRIVER *driverp; 
    UTILITY_Z8_ASCII_READER* its_reader; 

    ARRAY<UTILITY_FILE_DRIVER*> zres_to_zresp;

    UTILITY_Z8_RESULTS(); 
    virtual ~UTILITY_Z8_RESULTS(); 
    virtual bool has_results(); 

    // 
    // 
    // 
    virtual void initialize(const STRING& problem_name);
    virtual void configure_for_zres(STRING& fname); 

    virtual bool do_command(STRING cmd); 

    void get_maps_for_new_mesh(int from_map, ARRAY<int>& maps_for_this_mesh); 

    // 
    // Default error messages.. 
    // 
    virtual void mesh_reloaded();
    virtual void load(STRING);

    virtual bool get_node_results_through_time(UTILITY_NODE* node, const STRING& cname, int where);
    virtual bool get_integ_results_through_time(UTILITY_ELEMENT* ele, int gp, const STRING& cname);

    virtual bool get_results_at_time(double when, const STRING& cname, int where);
    virtual bool get_nodal_displacements(int map, const STRING& stub);
    virtual bool load_harmonic_disp(int get_map, const STRING& stub); 

    virtual bool get_node_results(int map, const STRING& comp);
    virtual bool get_ctnod_results(int map, const STRING& comp);
    virtual bool get_ctele_results(int map, const STRING& comp);
    virtual bool get_ctmat_results(int map, const STRING& comp);
    virtual bool get_integ_results(int map, const STRING& comp);

    virtual void generate_location_list(int& all_location_flags); 
    virtual void generate_node_variable_list(LIST<STRING>&); 
    virtual void generate_integ_variable_list(LIST<STRING>&); 

    static bool small_diff(double d1, double d2); 
  
    RTTI_INFO;
}; 
Z_END_NAMESPACE;

#endif
