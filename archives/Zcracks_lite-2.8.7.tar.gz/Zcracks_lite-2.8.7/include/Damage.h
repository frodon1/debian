#ifndef __Damage__
#define __Damage__

// ============================================================================ 
//   Models of damage...  update_damage should be called if DAMAGE_FLAG_ELASTIC
//                        is set in flags.. otherwise damage_rate
// ============================================================================ 

#include <ZMath.h>
#include <Visible.h>
#include <Int_variable_holder.h>
#include <Material_piece.h>
#include <Coefficient.h>

Z_START_NAMESPACE;

class ASCII_FILE;
class DAMAGE_HANDLER;

// ============================================================================ 
ZCLASS DAMAGE_MODEL : public MATERIAL_PIECE {
  protected :
     DAMAGE_HANDLER* its_dh;
     int             dam_flags;
     const VECTOR    *curr_dam_vars;
     VECTOR          rate;
     TENSOR2         eff_s;

  public :
     class DAMAGE_DATA { 
         public:
           DAMAGE_DATA(); 
           int need_evcum; int set_evcum; double keep_evcum; 
           int need_ybar;  int set_ybar;  double keep_ybar; 
     }; 
     DAMAGE_DATA its_data; 

     DAMAGE_MODEL(); 
     virtual ~DAMAGE_MODEL() { } 

     int    flags()const      { return dam_flags; }
     virtual int damage_size()    { return int_sz(); } 

     static DAMAGE_MODEL* read( ASCII_FILE& file, DAMAGE_HANDLER* dh ); 
     virtual void initialize( ASCII_FILE& file, DAMAGE_HANDLER* dh );                                

     virtual double  update_damage( const TENSOR2& sig, const TENSOR2&);

     virtual const VECTOR&  damage_rate( double         lamda,
                                         double         dt,
                                         double         Y,
                                         const TENSOR2& sig ); 

     // ------------------------------------------------------------ 
     //  These functions are all bugged in their interface
     // ------------------------------------------------------------ 
     virtual double   ddam_drate();             // BUG .. assumes isotropic
     virtual double   ddam_ddam(double theta);  // BUG .. assumes isotropic
     virtual MATRIX   ddam_deel(double theta);  
     RTTI_INFO;
};

ZCLASS ELASTIC_ISO_DAMAGE : public DAMAGE_MODEL {
  protected :
     SCALAR_VAUX          y_max;
     SCALAR_VAUX          damage;      
     COEFF                y0, alpha; 
     double               ym_root,yz_root;
     double               y_bar;
     double               ddam_dY;
     const TENSOR2*       m_real_stress;
  public :
     ELASTIC_ISO_DAMAGE(); 

     virtual int  damage_size()    { return 1; } 
     virtual void initialize( ASCII_FILE& file, DAMAGE_HANDLER* dh );

     virtual double   update_damage( const TENSOR2& sig, 
                                   const TENSOR2& eel);

     const VECTOR&    damage_rate( double         lamda,
                                   double         dt,
                                   double         Y,
                                   const TENSOR2& sig );

     virtual double   ddam_drate();             // BUG .. assumes isotropic
     virtual double   ddam_ddam(double theta);  // BUG .. assumes isotropic
     virtual MATRIX   ddam_deel(double theta);  
     RTTI_INFO;
};


 
ZCLASS PLASTIC_ISO_DAMAGE : public DAMAGE_MODEL {
  protected :
     SCALAR_VINT  damage; 
     COEFF        s0, S0;
     double       eta;
     double       Y_store, lam_store;
     double       ddam_dY;
  public :
     PLASTIC_ISO_DAMAGE();
     virtual void initialize( ASCII_FILE& file, DAMAGE_HANDLER* dh );

     double  update_damage( const TENSOR2&, const TENSOR2&) { return damage(); } 
     const VECTOR&    damage_rate( double         lamda,
                                   double         dt,
                                   double         Y,
                                   const TENSOR2& sig ); 

     virtual double   ddam_drate();             // BUG .. assumes isotropic
     virtual double   ddam_ddam(double theta);  // BUG .. assumes isotropic
     virtual MATRIX   ddam_deel(double theta);  
     RTTI_INFO;

};

ZCLASS VISCOPLASTIC_ISO_DAMAGE : public DAMAGE_MODEL {
  protected :
     SCALAR_VINT  damage;      
     COEFF        alpha, beta;
     COEFF        A, k, r;
     COEFF        max_damage; 
     TENSOR2      dev_s;
     double       dtime;
     double       chi, term1, term2;
     double        j0,  j1,  j2;
     TENSOR2      dj0, dj1, dj2;
     TENSOR2      princip;
     int          usz; 
     double pc1(TENSOR2& tin); 
  public :

     VISCOPLASTIC_ISO_DAMAGE();

     void initialize( ASCII_FILE& file, DAMAGE_HANDLER* dh );

     virtual double   update_damage( const TENSOR2&, const TENSOR2&) { return damage(); }
     const VECTOR&    damage_rate( double         lamda,
                                   double         dt,
                                   double         Y,
                                   const TENSOR2& sig );

     virtual double   ddam_drate(); // BUG .. assumes isotropic
     virtual double   ddam_ddam(double theta);  // BUG .. assumes isotropic
     virtual MATRIX   ddam_deel(double theta);
     RTTI_INFO;

};

ZCLASS VISCOPLASTIC_INTER_DAMAGE : public DAMAGE_MODEL {
  protected :
     SCALAR_VINT  damage;
     SCALAR_VAUX  concentration;
     COEFF        beta;
     COEFF        A, k, r;   
     COEFF        max_damage; 
     double       dtime;
     double       chi, term1, term2;
     double       sig3, sig4;
     double       N, T;
     TENSOR2      dN, dT;
     int          usz; 
     double pc1(TENSOR2& tin); 
  public :

     VISCOPLASTIC_INTER_DAMAGE();
     void initialize( ASCII_FILE& file, DAMAGE_HANDLER* dh );
     double  update_damage( const TENSOR2&, const TENSOR2&) { return damage(); } 
     const VECTOR&    damage_rate( double         lamda, 
                                   double         dt, 
                                   double         Y, 
                                   const TENSOR2& sig ); 

     virtual double   ddam_drate(); // BUG .. assumes isotropic
     virtual double   ddam_ddam(double theta);  // BUG .. assumes isotropic
     virtual MATRIX   ddam_deel(double theta);  
     RTTI_INFO;

};
Z_END_NAMESPACE;

#endif
