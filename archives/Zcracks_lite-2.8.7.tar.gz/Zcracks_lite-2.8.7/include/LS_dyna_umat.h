#ifndef __LS_dyna_umat__
#define __LS_dyna_umat__
// ============================================================================ 
//  Z-mat for LS-Dyna                                    8.3 RF 12/13/2003
// ============================================================================ 

#include <math.h> 
#include <stdlib.h> 

#include <Std_cc_stream.h>
#include <Message_passing_client.h>

#include <Zunistd.h> 
#include <Defines.h> 
#include <File.h> 
#include <Print.h> 
#include <Rotation.h> 
#include <Out_message.h> 
#include <Verbose.h> 
#include <Calcul_timer.h> 
#include <ZMath.h> 
#include <Zunistd.h> 
#include <Verbose.h> 

#include <Behavior.h> 
#include <Clock.h> 
#include <Coefficient.h> 
#include <External_parameter.h> 
#include <Integration_method.h>
#include <Mat_data.h> 
#include <ZeBaBa.h> 
#include <NT_tools.h>
#include <Unix_tools.h>
#include <Zmat_class.h>
#include <Utility.h>

#include <Global_parameter.h>
#include <P_container.h>

Z_START_NAMESPACE;

// #define USE_ALL_ATTACH

//---------------------------------------------------------------------------- 

ZCLASS LS_DYNA_ZMAT_HANDLER : public ZEBABA_HANDLER {
  public :
    LS_DYNA_ZMAT_HANDLER();
    virtual ~LS_DYNA_ZMAT_HANDLER();
    virtual bool read_option(STRING& key, ASCII_FILE& file);
    virtual void end_of_load_setup();

    int     elem_id; 
    int     gauss_id; 
    int     last_elem_id;
    double  last_time; 
    double  last_time_ini; 
  
    int     elem_count; //needed for tg_mats
   
//    Zfstream output;

    TENSOR2 xF;
    TENSOR2 xeto;

    VECTOR deto_hack;
    
    ARRAY<MATRIX> tg_mats; // N. Osipov  Array of tangent matrices for block of elements (one matrix per gp)
                           // 72 (nlq) elements in block
                           // test ideas for implicit ls-dyna version

    bool give_tg_mat;    // flag indicates which ls_dyna version is used implicit (1) or explicit (0);
    int  first_implicit_call;
   
    LIST<int>     fail_zero; 
    LIST<STRING>  fail_var; 
    LIST<MATERIAL_PIECE_VARIABLE_KEY*> fail_keys;
};


//---------------------------------------------------------------------------- 

#ifdef _WIN32
  #include <NT_tools.h>
  #define CERR Out
  #define COUT Out
#else
  #define CERR cerr
  #define COUT Out
#endif

WIN_THINGIE void zmat_check_license(); 

Z_END_NAMESPACE;

#endif 
