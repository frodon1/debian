#ifndef __RESULTS_LINEAR_ACTOR__
#define __RESULTS_LINEAR_ACTOR__

#include <Results_contour_actor.h>

Z_START_NAMESPACE;

class RESULTS_LINEAR_ACTOR : public RESULTS_CONTOUR_ACTOR
{
  public :
    RESULTS_LINEAR_ACTOR();
    virtual ~RESULTS_LINEAR_ACTOR();

    // virtual void put_results();
};
Z_END_NAMESPACE;

#endif
