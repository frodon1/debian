#ifndef __SPARSE_ITERATIVE_MATRIX__
#define __SPARSE_ITERATIVE_MATRIX__

#include <Sparse_global_matrix.h>
#include <CG_solver.h>
#include <Gmres.h>
#include <Preconditioner.h>
#include <Sparse_matrix_threads.h>

Z_START_NAMESPACE;

class ITERATIVE_SOLVER;
class SIM_CG_SOLVER;
class SIM_GMRES;
class SPARSE_MATRIX_THREAD;

ZCLASS2 SPARSE_ITERATIVE_PARAMETER : public SOLVER_PARAMETER {
  public :
    SOLVER_PARAMETER *local_solver_parameter;
    PRECOND_PARAMETER *local_precond_parameter;
    double shift,bc_factor;
    bool full_output,renumbering,debug_renumbering;
    STRING preco,solver;

    SPARSE_ITERATIVE_PARAMETER();
    virtual ~SPARSE_ITERATIVE_PARAMETER();

    virtual bool GetResponse(STRING&,ASCII_FILE&);
    RTTI_INFO;
};


ZCLASS2 SPARSE_ITERATIVE_MATRIX : public SPARSE_GLOBAL_MATRIX {
  friend class SIM_SOLVER;
  protected : 

    AUTO_PTR<ITERATIVE_SOLVER> solver;
    DIRECT_SPARSE_SOLVER sparse_solver;

//  For preconditioning
    AUTO_PTR<PRECONDITIONER> preconditioner;
    double  max_diag, shift;
    VECTOR  diagonal;
    VECTOR  precond_triangle;

//  Not used by economic_cholesky
//  Greatly accelerates factorization (SQ 01/19/04)
    ARRAY<int> column_pointers_i;
    ARRAY<int> not_null_i;
    ARRAY<int> col_to_line;

    bool full_output, debug_renumbering;

    LIST<int> dofs_mpc;
    bool has_mpc;
    MATRIX inv_AtA;

    SEMAPHORE wait_finish;
    ARRAY<SEMAPHORE> slave_synchro;
    PLIST<SPARSE_MATRIX_THREAD> threads;

  public :
    enum PRECOND { NONE , LUMPED , CHOLESKY, ECONOMIC_CHOLESKY };
    PRECOND preco;

    SPARSE_ITERATIVE_MATRIX(MESH& mesh,char* name = NULL);
    SPARSE_ITERATIVE_MATRIX();
    virtual void create(MESH& mesh,char* name = NULL);
    virtual ~SPARSE_ITERATIVE_MATRIX();     

    virtual bool solve(VECTOR& displ,VECTOR& force,int if_compute_inverse,int if_compute_kernel=0);

    virtual void global_matrix_structure_change(UPDATE_FLAGS ident_flags);
    virtual void set_parameter(SOLVER_PARAMETER*);

//  Preconditioners
    virtual int setup_precond(PRECOND type); 
    void build_precond(PRECOND type); 
    bool factorize_preconditioner();
    void solve_preconditioner(PRECOND type, VECTOR& v);
    bool economic_factorize_preconditioner();
    void solve_preconditioner(VECTOR&,const VECTOR&);
 
//  Overloaded or GRAD_CONJ related methods
    virtual void precond(VECTOR&,const VECTOR&);
    virtual void project(VECTOR&,VECTOR&);
    void prodA(VECTOR&,VECTOR&);
    void prodtA(VECTOR&,VECTOR&);
    void build_mpc_matrix();

    virtual void prodD(VECTOR &out, VECTOR &b);
    void do_debug_renumbering();
    RTTI_INFO;

};

ZCLASS2 SIM_SOLVER 
{
  protected :
    SPARSE_ITERATIVE_MATRIX *associated_matrix;
    ITERATIVE_SOLVER *boss;

  public :
    SIM_SOLVER(SPARSE_ITERATIVE_MATRIX &m) { associated_matrix=&m; }
    virtual ~SIM_SOLVER() { }
  
    virtual void convergence_info(double r, int n, int mn);
    virtual void check_status(ITERATIVE_SOLVER::CSTATUS,double,int);
};

ZCLASS2 SIM_CG_SOLVER : public CG_SOLVER , public SIM_SOLVER
{
  public :
    SIM_CG_SOLVER(SPARSE_ITERATIVE_MATRIX &m) : CG_SOLVER(),SIM_SOLVER(m) { boss=this; }
    virtual ~SIM_CG_SOLVER() { }

    virtual void prodD(VECTOR &out, VECTOR &a) { Timer_counter.stop_time("CG_solver"); associated_matrix->prodD(out,a); Timer_counter.start_time("CG_solver"); }
    virtual void precond(VECTOR &b, VECTOR &a) { Timer_counter.stop_time("CG_solver"); associated_matrix->precond(b,a); Timer_counter.start_time("CG_solver"); }
    virtual void project(VECTOR &b, VECTOR &a) { Timer_counter.stop_time("CG_solver"); associated_matrix->project(b,a); Timer_counter.start_time("CG_solver"); }

    virtual void convergence_info(double r, int n, int mn) { if(n%output_every_iter==0) SIM_SOLVER::convergence_info(r,n,mn); }
    virtual void check_status() { SIM_SOLVER::check_status(status,ratio,niter_2); }
  
    virtual void loop() { CG_SOLVER::loop(); lp=-1.*lp; }
};

ZCLASS2 SIM_GMRES : public GMRES , public SIM_SOLVER
{
  public :
    SIM_GMRES(SPARSE_ITERATIVE_MATRIX &m) : GMRES() , SIM_SOLVER(m) { boss=this; }
    virtual ~SIM_GMRES() { }

    virtual void prodD(VECTOR &out, VECTOR &a) { associated_matrix->prodD(out,a); }
    virtual void precond(VECTOR &b, VECTOR &a) { associated_matrix->precond(b,a); }

    virtual void convergence_info(double r, int n, int mn) { if(n%output_every_iter==0) SIM_SOLVER::convergence_info(r,n,mn); }
    virtual void check_status() { SIM_SOLVER::check_status(status,ratio,niter); }
};
Z_END_NAMESPACE;

#endif
