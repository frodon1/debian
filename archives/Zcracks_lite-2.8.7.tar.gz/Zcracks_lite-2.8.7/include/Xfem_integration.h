#ifndef __Xfem_integration__ 
#define __Xfem_integration__ 

// 
// Wrapped series of sub-geometries provide the integration 
// here 
// 

#include <Integration.h> 
#include <Buffered_list.h> 

Z_START_NAMESPACE;

class XFEM_ENHANCED_ELEMENT_WRAPPER;

ZCLASS2 XFEM_INTEGRATION : public INTEGRATION {
   protected :
   public : 
      XFEM_ENHANCED_ELEMENT_WRAPPER* xelem; 
      INTEGRATION*       kept_integration; 
      int                current_geo; 
      LIST<GEOMETRY*>    sub_geom;
      BUFF_LIST<MATRIX>  sub_coord;

      XFEM_INTEGRATION(); 
      virtual ~XFEM_INTEGRATION(); 

      virtual void attach(XFEM_ENHANCED_ELEMENT_WRAPPER* boss); 

      virtual void start(const MATRIX& elem_coord);
      virtual void start() const;
      virtual void next(const MATRIX& elem_coord);
      virtual void next() const;
    
      virtual int  ok() const;
      virtual void fail();

      virtual double get_position_of_integration_point(const VECTOR&)const;
      virtual const VECTOR& shape() const;
      virtual const VECTOR& shape_inv() const;
      virtual const MATRIX& deriv() const;
      virtual const double& weight() const;
      virtual const double& volum() const;
      virtual double& volum();
      virtual REF_GAUSS_POINT* current_gauss_point()const;

      virtual int nb_gauss_point()const;

      MATRIX& get_ec(int idx); 

      VECTOR  mapped_chi;             // chi position in actual element for sub geom current gp
      double  mapped_vol;             // gp's 
      virtual void compute_x_mapping(const MATRIX& elem_coord); 
}; 

Z_END_NAMESPACE;

#endif 
