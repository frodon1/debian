#ifndef __ZP_TENSOR2__
#define __ZP_TENSOR2__

#include <ZP_stack.h>
#include <Vector.h>
#include <Tensor.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>

Z_START_NAMESPACE;

ZCLASS ZP_TENSOR2 : public ZP_BASIC_TYPE< TENSOR2 >
{
  protected :
    ZP_FATAL_ERROR* plus(ZP_STACK&,int);
    ZP_FATAL_ERROR* minus(ZP_STACK&,int);
    ZP_FATAL_ERROR* times(ZP_STACK&,int);
    ZP_FATAL_ERROR* bar(ZP_STACK&,int);
    ZP_FATAL_ERROR* divide(ZP_STACK&,int);

    ZP_FATAL_ERROR* set(ZP_STACK&,int);
    ZP_FATAL_ERROR* size(ZP_STACK&,int);
    ZP_FATAL_ERROR* trace(ZP_STACK&,int);
    ZP_FATAL_ERROR* deviator(ZP_STACK&,int);
    ZP_FATAL_ERROR* resize(ZP_STACK&,int);
    ZP_FATAL_ERROR* reassign(ZP_STACK&,int);
    ZP_FATAL_ERROR* bracket(ZP_STACK&,int);
    ZP_FATAL_ERROR* assign(ZP_STACK&,int);
    ZP_FATAL_ERROR* mises(ZP_STACK&,int);
    ZP_FATAL_ERROR* add_sqrt2(ZP_STACK&,int);
    ZP_FATAL_ERROR* remove_sqrt2(ZP_STACK&,int);
    ZP_FATAL_ERROR* eigen(ZP_STACK&,int);
    ZP_FATAL_ERROR* eigen_vecs(ZP_STACK&,int);
    ZP_FATAL_ERROR* transpose(ZP_STACK&,int);
    ZP_FATAL_ERROR* I2(ZP_STACK&,int);
    ZP_FATAL_ERROR* dI2(ZP_STACK&,int);
    ZP_FATAL_ERROR* I3(ZP_STACK&,int);
    ZP_FATAL_ERROR* J3(ZP_STACK&,int);
    ZP_FATAL_ERROR* zp_syme(ZP_STACK&,int);
    ZP_FATAL_ERROR* zp_to_5_9(ZP_STACK&,int);
    ZP_FATAL_ERROR* mkmat(ZP_STACK&,int);
    ZP_FATAL_ERROR* pluse(ZP_STACK&,int);
    ZP_FATAL_ERROR* minuse(ZP_STACK&,int);
    ZP_FATAL_ERROR* timese(ZP_STACK&,int);
    ZP_FATAL_ERROR* unity(ZP_STACK&,int);
    virtual ZP_FATAL_ERROR* print(ZP_STACK&,int);

    virtual void type_init(char*) { type="TENSOR2"; }

  public :
    BASIC_CONSTRUCTORS(ZP_TENSOR2,TENSOR2)

    METHOD_DECLARATION_START
      METHOD("=",assign,1)
      METHOD("[]",bracket,1)
      METHOD("set",set,0)
      METHOD("size",size,0)
      METHOD("!",size,0)
      METHOD("resize",resize,1)
      METHOD("reassign",reassign,3)
      METHOD("mises",mises,0)
      METHOD("trace",trace,0)
      METHOD("deviator",deviator,0)
      METHOD("add_sqrt2",add_sqrt2,0)
      METHOD("remove_sqrt2",remove_sqrt2,0)
      METHOD("eigen",eigen,2)
      METHOD("eigen_vecs",eigen_vecs,1)
      METHOD("transpose",transpose,0)
      METHOD("I2",I2,0)
      METHOD("dI2",dI2,0)
      METHOD("I3",I3,0)
      METHOD("J3",J3,1)
      METHOD("+",plus,1)
      METHOD("-",minus,1)
      METHOD("*",times,1)
      METHOD("|",bar,1)
      METHOD("/",divide,1)
      METHOD("syme",zp_syme,0)
      METHOD("to_5_9",zp_to_5_9,0)
      METHOD("mkmat",mkmat,0)
      METHOD("+=",pluse,1)
      METHOD("-=",minuse,1)
      METHOD("*=",timese,1)
      METHOD("unity",unity,1)
    METHOD_DECLARATION_ANCESTOR(ZP_BASIC_TYPE< TENSOR2 >)

    ZPO_RTTI_INFO(TENSOR2)
};
Z_END_NAMESPACE;

#endif
