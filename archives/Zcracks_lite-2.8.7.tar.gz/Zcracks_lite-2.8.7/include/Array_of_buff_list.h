#ifndef __Array_buff_list__
#define __Array_buff_list__

#include <Buffered_list.h>

Z_START_NAMESPACE;

template <class T> ZCLASSt ARRAY_BUFF_LIST : public ARRAY< BUFF_LIST<T> >
{
  public :
    ARRAY_BUFF_LIST();
    virtual ~ARRAY_BUFF_LIST();

    /// resize array to size n.
    virtual void ab_resize(int n);
    virtual void ab_hard_resize(int n);

    /// the nn parameter is now deprecated
    virtual void ab_resize(int n, int nn) DEPRECATED ;
    virtual void ab_hard_resize(int n, int nn) DEPRECATED ;
}; 

template <class T> INLINE ARRAY_BUFF_LIST<T>::ARRAY_BUFF_LIST() { }

template <class T> INLINE void ARRAY_BUFF_LIST<T>::ab_resize(int n)
{
  assert(n>=0);
  if(n>this->sz) {
    if(this->x) delete[] this->x;
    this->sz=n;
    this->x=new BUFF_LIST<T> [this->sz];
  }
  else this->sz=n;
}

template <class T> INLINE void ARRAY_BUFF_LIST<T>::ab_hard_resize(int n)
{
  assert(n>=0);
  if(this->x) delete[] this->x;
  this->sz=n;
  this->x=new BUFF_LIST<T> [this->sz];
}


template <class T> INLINE void ARRAY_BUFF_LIST<T>::ab_resize(int n, int)
{
  ab_resize(n);
}

template <class T> INLINE void ARRAY_BUFF_LIST<T>::ab_hard_resize(int n, int)
{
  ab_hard_resize(n);
}

template <class T> INLINE ARRAY_BUFF_LIST<T>::~ARRAY_BUFF_LIST()
{
  if(this->x) { delete[](this->x); this->x=NULL; }
}
Z_END_NAMESPACE;

#endif
