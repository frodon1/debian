#ifndef __Fea_mat_wrapper_with_auto__
#define __Fea_mat_wrapper_with_auto__

// ============================================================================ 
//  A wrapper for FEA behaviors not having a simulator implemnetation. 
//  its like the RVE but doesn't need a fea license. 
//
//  RF 01/25/2007 re-modified the finite strain version, making it directly 
//  from this class / using F and PK1 as stress 
//
// 
// ============================================================================ 

#include <Dichotomy.h>
#include <Marray.h>
#include <Vector.h>
#include <Defines.h>

#include <Simulator_model.h>
#include <Simulator.h>
#include <Yield_spec.h>
#include <Basic_nl_behavior.h> 

Z_START_NAMESPACE;

class PARAMETRIC_STRAIN; 

ZCLASS FEA_MAT_WRAPPER_BASE: public SIMUL_MODEL {
   public:
     virtual bool load_real_behavior(ASCII_FILE&, 
                                      LOCAL_INTEGRATION*, 
                                      STRING real_mat, 
                                      SIMULATOR_TEST* tst)=0;
};

ZCLASS FEA_MAT_WRAPPER : public FEA_MAT_WRAPPER_BASE,
                        public DICHOTOMY {

  private : 

  public :
     SIMULATOR_TEST* its_tst; 

     int          algorithm;
     int          iterations;
     int          no_automatic_time;
     int 	  initial_increment;
  

     double       ratio;
     double       ratio_absolu;
     double       divergence_factor;
     double       security_factor;
     double       max_dtime;
     double       min_dtime;
     int          iter_optimal;

     int          first_time; 

     STRING       conv_type;
     MAT_DATA     m_mdat;

     double       dtime; 
     VECTOR       keep_dU; 
     double       limit_d_dof; 

     SMATRIX      stiff, stiff0, stiff1; 
     VECTOR       R, Fint, Fext, save_Fext; 
     VECTOR       dof, ddof, dof_ini, dof_tot; 

     virtual void get_flux0(VECTOR&);

     virtual void         solve(); 
     virtual INTEGRATION_RESULT* convergence_loop(int & iter); 

     virtual INTEGRATION_RESULT* internal_reaction(
                VECTOR& U, VECTOR& dU,
                VECTOR& resi,SMATRIX& stiff); 

     // 
     // For simulation multi-mode control 
     // 
     int         control; // 0 for strain 1 for stress
     int         num_sig;
     ARRAY<int>  sig_pos, eto_pos;

     TENSOR2      m_eth, m_deth; 
     PARAMETRIC_STRAIN* simul_thermal_strain; 

     //
     // For simulation yield surfaces
     //
     MAT_DATA keep_mdat; 
     static const double radeg;
     static const double tpi;
     YIELD_SPEC*  s_curr_spec;
     double       try_deg;
     VECTOR       keep_vars;
     TENSOR2      try_sig;

     virtual void copy_mat_data(MAT_DATA& dest, MAT_DATA& source);

  public :
     AUTO_PTR<BEHAVIOR>         behavior; 

                           FEA_MAT_WRAPPER();
     virtual               ~FEA_MAT_WRAPPER() { } 
     virtual bool          base_read(STRING str, ASCII_FILE& file); 


     virtual bool          load_real_behavior(ASCII_FILE&, 
                                      LOCAL_INTEGRATION*, 
                                      STRING real_mat, 
                                      SIMULATOR_TEST* tst);

     virtual void          set_control(const ARRAY<STRING>& ctl); 

     virtual void          set_external_parameters(const VECTOR& p0,
                                          const VECTOR&   pini,
                                          const VECTOR&   p); 

     virtual bool          simul_integrate(VECTOR& dgl, ARRAY<STRING>& ctl, double dtime);
     virtual void          results(VECTOR& res, ARRAY<STRING>& wht);

     virtual void          simul_calc_material(double fract); 

//   virtual void          setup(int& fp, int& gp, int& vip, int& vap);
     virtual void          set_ini_vals(STRING& wht, double value); 
     virtual void          init_problem(const ARRAY<STRING>& ctl, const VECTOR& vals);

     BUFF_LIST<STRING>    all_variable_names; 
     virtual LIST<STRING> get_all_variable_names();
     virtual VECTOR       get_all_variables();
     double compute_abs_variation(STRING str);

     VECTOR&        get_var_int() { return m_mdat.var_int(0); }
     VECTOR&        get_var_aux() { return m_mdat.var_aux(0); }
     VECTOR&        get_grad()    { return m_mdat.grad(0); }
     VECTOR&        get_flux()    { return m_mdat.flux(0); }

     // basically to maintain Fext for stress-controlled loadings
     virtual void save_problem_state();
     virtual void restore_problem_state();
     virtual void set_problem_state(const ARRAY<STRING>& ctl, const VECTOR&);

     DERIVED; 
};
Z_END_NAMESPACE;

#endif 
