#ifndef __ZP_UTILITY__
#define __ZP_UTILITY__

#include <ZP_env.h>
#include <ZP_piece.h>
#include <ZP_internal_list.h>

Z_START_NAMESPACE;

AUTO_PTR<ZP_PIECE> get_proc_for_args(ZP_STACK &stack, LIST< AUTO_PTR<ZP_PIECE> > &proc, bool mandatory=TRUE);
Z_END_NAMESPACE;

#endif
