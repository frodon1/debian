#ifndef __Results_make_post__
#define __Results_make_post__

#include <Graphics_area.h>
#include <Graphics_command.h>
#include <Graphics_data_dialog.h>

Z_START_NAMESPACE;

class MODIFY_INFO;
class RESULTS_BASE_COMMAND;
class RESULTS_MAKE_POST_COMMAND;
class DAO_GEOMETRY;
class LOCAL_POST_COMPUTATION;
class RESULTS_POST_RECORD;

ZCLASS2 RESULTS_MAKE_POST_COMMAND : public GRAPHICS_COMMAND {
  protected :
    LIST<STRING>          post_types;
    DAO_GEOMETRY*         its_dao;
    GRAPHICS_DATA_DIALOG* post_create_dialog;

    LIST<STRING> opts; LIST<int> ovals;

    RESULTS_BASE_COMMAND* its_base;

    STRING         chosen_component;

    MODIFY_INFO_RECORD* modif;
    int            current_opt_pos;
    int            doing_modify;

    RESULTS_POST_RECORD* active_post;

    GRAPHICS_DATA_DIALOG* data_dialog;
    bool make_info_field(MODIFY_INFO& info); 
    void update_lists(); 
    void add_active_post(); 
    void add_modif(MODIFY_INFO_RECORD* modif); 
    void add_to_dialog(MODIFY_INFO& info); 

  public :
    RESULTS_MAKE_POST_COMMAND(RESULTS_BASE_COMMAND* base);

    virtual void initialize(GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app);

    virtual ~RESULTS_MAKE_POST_COMMAND();
    virtual bool do_command(STRING cmd);
    virtual bool do_click(int track, GRAPHICS_POINT& click, GRAPHICS_OBJECT* target);

    virtual bool fabricate_post_dialog();
    virtual bool make_from_post_dialog(MODIFY_INFO_RECORD* m);
};
Z_END_NAMESPACE;

#endif
