#ifndef __THERMAL_ALGORITHM__
#define __THERMAL_ALGORITHM__


#include <Integration_result.h>

#include <Std_cc_stream.h>

#include <Error_messager.h>
#include <Table.h>
#include <Dof.h>

#include <Algorithm.h>
#include <Boundary_condition.h>
#include <Behavior.h>
#include <Clock.h>
#include <Discrete_timer.h>
#include <Front_matrix.h>
#include <Global_matrix_data.h>
#include <Output_thermal.h>
#include <Random_distribution.h>
#include <Sequence.h>
#include <Thermal_mesh.h>
#include <Print.h>
#include <Verbose.h>
#include <Feti_solver.h>
#include <Parallel_solver.h>
#include <Problem.h>
#include <Problem_includes.h>
#include <Problem_info.h>

Z_START_NAMESPACE;


//class DAMPING; 

ZCLASS2 THERMAL_ALGORITHM : public ALGORITHM {
  public :
    THERMAL_ALGORITHM();
    virtual ~THERMAL_ALGORITHM();
    virtual int can_parallel_computations() { return(1); }

    virtual INTEGRATION_RESULT* convergence_loop(MESH&, GLOBAL_MATRIX&);
    virtual INTEGRATION_RESULT* evaluate_residual( MESH&, GLOBAL_MATRIX&, VECTOR&, bool, bool get_only_elementary_matrix = FALSE);
};
Z_END_NAMESPACE;

#endif
