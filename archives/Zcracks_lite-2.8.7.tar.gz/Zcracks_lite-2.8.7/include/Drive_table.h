#ifndef __DRIVE_TABLE__
#define __DRIVE_TABLE__

#include <Table.h>

Z_START_NAMESPACE;

//
// FF, a specific table which can be imposed by other parts of the code
//   april, 2003
//

class DRIVE_TABLE : public TABLE
{
  public :
    double time,time_ini;
    double value,incr_value; // value at time_ini , increment between time and time_ini

    DRIVE_TABLE();
    virtual ~DRIVE_TABLE();

    virtual void initialize(ASCII_FILE&);

    virtual void   table_value(double& val, double time)const;
    virtual void   table_value(VECTOR& val, double time)const;
    virtual double incr_table_value(double time,double d_time)const;

    virtual bool   is_valid_timestep(double time,double d_time)const;
    virtual bool   is_valid_time(double time)const;

    void set(double v) { value=v; }
    void set_incr(double v) { incr_value=v; }

    void set_time(double t) { time=t; }
    void set_time_ini(double t) { time_ini=t; }

    void converged(); // called when the pid loop did converge
};
Z_END_NAMESPACE;

#endif
