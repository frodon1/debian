#ifndef __NON_LOCAL_LAYERED_ELEMENT__
#define __NON_LOCAL_LAYERED_ELEMENT__

//
// 2006-07-04 germain: a non local layered element 
//

#include<P_element.h>
#include<Mechanical_mesh.h>
#include<Behavior.h>
#include<Non_local_layered_geom_info.h>

Z_START_NAMESPACE;

class NON_LOCAL_LAYERED_ELEMENT : public P_ELEMENT
{
  protected :
    bool initialized,if_ps; 
    int nb_mdof,nb_nldof,nb_didof,nb_nldof_tot,nb_didof_tot;
    INTERPOLATION_FUNCTION *D_interpolation;
    ARRAY<STRING> name_nl_dof;
    NON_LOCAL_LAYERED_GEOM_INFO* geom_info;   
    ARRAY<ARRAY<int> > tab_mid;
    ARRAY<int> tab_top;

    int mechanical_tsz();
    void init();
    void mechanical_B(MATRIX&) const;
    void damage_Bc(MATRIX&) const;
    void damage_Mc(MATRIX&) const; 

  public :
     NON_LOCAL_LAYERED_ELEMENT();
     virtual ~NON_LOCAL_LAYERED_ELEMENT();
     virtual void setup_dofs(const char*);
     virtual int dof_location(int) const;
     virtual INTEGRATION_RESULT* internal_reaction(bool,VECTOR&,SMATRIX&,bool only_get_tg_matrix=FALSE);
     virtual double cal_val_at_node(NODE*,DOF_TYPE*);
     virtual bool get_nodal_values()const { return(TRUE); }
     virtual bool cal_val_at_integration(int key_index, VECTOR& val_gp)const;
     virtual void calcul_jacobian(SMATRIX&);
     virtual void get_elem_coord_linear(MATRIX&,bool) const;
     virtual void find_top();
     bool compute_B_NG(APPLICATION_MESSAGE*);
     DECLARE_ASK;
//     RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
