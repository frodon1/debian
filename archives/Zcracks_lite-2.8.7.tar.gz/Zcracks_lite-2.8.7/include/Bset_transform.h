#ifndef __Bset_transform__
#define __Bset_transform__

#include <Nset_transform.h>

// ============================================================================
//  Create a boundary set based on an equation (plane in cartesian or cylindrical)
//
//  Works by getting the nset fitting the eqn, then passing it to all the elements
//  to which it applies.  The elements therefore determine themselves if there's
//  a boundary to add, and add it if that's the case.
// ============================================================================

Z_START_NAMESPACE;

ZCLASS BSET_TRANSFORM : public NSET_TRANSFORM {
  protected :
     bool no_sort; // Set to TRUE is liset shall no be sorted
     int req_number;
     
     VECTOR start_near_position;

     void new_face_search(BUFF_LIST<UTILITY_BOUNDARY*>& faces, BUFF_LIST<UTILITY_BOUNDARY*>& use_faces);
     void sort_liset(UTILITY_LISET&)const;

  public :
     int use_dimension;
     BSET_TRANSFORM();
     virtual ~BSET_TRANSFORM() { no_sort=FALSE; }
     virtual void initialize(ASCII_FILE& file);
     virtual bool base_read(STRING str,  ASCII_FILE& file);

     virtual MODIFY_INFO_RECORD* get_modify_info_record();
     virtual void apply(UTILITY_MESH& mesh);
};

Z_END_NAMESPACE;

#endif
