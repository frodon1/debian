#ifndef __Empty_error_messager__
#define __Empty_error_messager__

#include <Buffered_list.h>
#include <Stringpp.h>
#include <Error_messager.h>

Z_START_NAMESPACE;

ZCLASS EMPTY_ERROR_MESSAGER : public ERROR_MESSAGER {
  protected :

    int forgetit; 
    virtual void  err_message(STRING cname, STRING err, const char* fle, int ln);
    virtual void  err_message(STRING err, const char* fle, int ln);
    virtual void  err_message(STRING err);
    virtual void  input_error(STRING str);
    virtual void  not_implemented_error(STRING err, const char* fle, int ln);
    virtual void  critical(STRING err);
    virtual void  message(STRING msg);
    virtual void  alert(STRING msg);

#ifdef ZEXCEPTIONS
    virtual void do_EXIT() throw();
#else
    virtual void do_EXIT();
#endif
  public :
   EMPTY_ERROR_MESSAGER();
   virtual ~EMPTY_ERROR_MESSAGER();
};

Z_END_NAMESPACE;
#endif

