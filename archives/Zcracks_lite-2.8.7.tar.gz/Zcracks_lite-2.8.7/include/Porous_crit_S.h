#ifndef __Porous_crit_S__
#define __Porous_crit_S__

#include <ZMath.h>
#include <List.h>
#include <Newton_raphson.h>
#include <Material_piece.h>
#include <Coefficient.h>
#include <PorousCriterion.h>

Z_START_NAMESPACE;

ZCLASS POROUS_CRITERION_WITH_S : public POROUS_CRITERION {
  protected :
     SCALAR_VINT S;
     TENSOR2 delta;
     // parameters transmitted to perform the residual calculations
     double Dl, density, density2, Fp;
     const VECTOR * _f_vec; VECTOR *_d_chi; SMATRIX* _grad;
   
     double& S_dv() { return (*_d_chi)[S.start_pos]; }
  public :
     POROUS_CRITERION_WITH_S();
     virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);

     //void give_parameter(double,double,double,const TENSOR2&);

     virtual  ZBOOL has_S() { return TRUE; }
     virtual void setup_end(POROUS_POTENTIAL_DATA&);

     TENSOR2   d2phi_dstress_dS,
               d2seq_dstress_dS;
     double    dseq_dS, dphi_dS,d2phi_dseq_dS;

     SCALAR_VINT& get_S() { return S; }
     virtual  void set_residual_data(double,double,double,const VECTOR&,VECTOR&,SMATRIX&);
     virtual  double   RS() = 0;
     virtual  const TENSOR2& dRe_dS() = 0;
     virtual  double   dRp_dS() = 0;
     virtual  double   dRf_dS() = 0;

     virtual  double   dRS_dS() = 0;
     virtual  const TENSOR2&   dRS_dstress() = 0;
     virtual  double   dRS_df() = 0;
     virtual  double   dRS_ddl() = 0;
};

Z_END_NAMESPACE;
#endif

