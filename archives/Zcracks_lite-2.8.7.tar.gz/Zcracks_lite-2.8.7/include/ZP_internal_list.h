#ifndef __ZP_INTERNAL_LIST__
#define __ZP_INTERNAL_LIST__

#include <ZP_object.h>

Z_START_NAMESPACE;

ZCLASS ZP_INTERNAL_LIST : public ZP_OBJECT
{
  public :
    BUFF_LIST< AUTO_PTR<ZP_OBJECT> > items; 

    ZP_INTERNAL_LIST() : items() { contens=NULL; type="internal_list"; }
    virtual ~ZP_INTERNAL_LIST() { }

    virtual void type_init(char*) { }
};
Z_END_NAMESPACE;

#endif
