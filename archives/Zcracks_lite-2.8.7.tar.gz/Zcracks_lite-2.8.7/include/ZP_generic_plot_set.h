#ifndef __ZP_GENERIC_PLOT_SET__
#define __ZP_GENERIC_PLOT_SET__

#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>
#include <Plot_set.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_GENERIC_PLOT_SET : public ZP_OBJECT
{
  protected :
    MODIFY_INFO_RECORD *its_record;
    int dont_delete;

    void set_fields();
    ZP_FATAL_ERROR* set_type(ZP_STACK&,int);
    ZP_FATAL_ERROR* reset(ZP_STACK&,int);
    virtual void type_init(char*) { type="PLOT_SET"; }
    AUTO_PTR<ZP_OBJECT> make_from_info(MODIFY_INFO &info);

  public :
    ZP_GENERIC_PLOT_SET() : ZP_OBJECT() , dont_delete(0) { contens=NULL; type_init(NULL); }
    ZP_GENERIC_PLOT_SET(PLOT_SET *d) : ZP_OBJECT() , dont_delete(1) { contens=d; type_init(NULL); set_fields(); }
    virtual ~ZP_GENERIC_PLOT_SET() { if(!dont_delete) delete((PLOT_SET*)contens); }

    METHOD_DECLARATION_START
      METHOD("set_type",set_type,1)
      METHOD("reset",reset,0)
    METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)

    PLOT_SET& get() { return(*((PLOT_SET*)contens)); }

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
    ZPO_RTTI_INFO(PLOT_SET)
};
Z_END_NAMESPACE;

#endif
