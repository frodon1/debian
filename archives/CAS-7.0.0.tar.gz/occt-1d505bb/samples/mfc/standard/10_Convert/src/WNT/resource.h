//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OCCDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TOOLBAR1                    130
#define IDB_OCCLOGO                     138
#define IDB_OPENLOGO                    142
#define ID_BUTTONWire                   50015
#define ID_BUTTONShade                  50016
#define ID_BUTTONStart                  50103
#define ID_BUTTONNext                   50104
#define ID_BUTTONShowResult             50105
#define ID_DUMP_VIEW                    50106
#define ID_BUTTONEnd                    50107
#define ID_BUTTONPrev                   50109
#define ID_BUTTONRepeat                 50110

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         40111
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
