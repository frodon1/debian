#ifndef __Graphics_view_manager__
#define __Graphics_view_manager__

#include <Bool.h> 
#include <Stringpp.h> 
#include <Defines.h> 

#include <Graphics_object.h> 
#include <Graphics_operators.h> 

#include <View_manager_wrapper.h>
#include <Z_object.h>

Z_START_NAMESPACE;

class GRAPHICS_AREA;
class ZP_STACK;
class ZP_FATAL_ERROR;

ZCLASS GRAPHICS_VIEW_MANAGER : public Z_OBJECT { 
  friend class ZP_TRACKBALL;
  friend class BATCH_TRACKBALL_TOOL;
  protected : 
    VIEW_MANAGER_WRAPPER wrapper;
    GRAPHICS_AREA* its_graphics_area; 

    GRAPHICS_POINT _rot_center; 
    // SQ 12/03/2102 : a new rot_center defined by means Dao_select_rot_center.c
    //  is stored in _updated_rot_center and the implications of this definition
    //  is handled only when needed : rotation in Graphics_trackball.c
    VECTOR _updated_rot_center;

    GRAPHICS_POINT _center; 
    double         _mag;                          // Magnification factor. If _res_x and _res_y are
                                                  // well configured, this should actually be the
                                                  // magnification wrt the Real World(tm)! (A_R)
    double         unit_convert;                  // in mm/inch. Should not be used anymore (A_R).

    // shoudn't be here but it is for convenience.
    VECTOR _VPN, _VUP, _VX;                       // eq to z, y, x resp. 

    double         _view_width, _view_height;     // in mm.      Denotes the physical size corresponding
                                                  //             to screen_width and screen_height.
    double         _u_minimum, _v_minimum;        // in dots.    Denote the lower draw screen limits
                                                  //             in "display" coordinates
    double         _u_maximum, _v_maximum;        // in dots     Denote the upper draw screen limits
                                                  //             in "display" coordinates
    double         _screen_height, _screen_width; // in dots.    Denote the draw screen size
    double         _res_x, _res_y;                // in dots/mm. Your OS / Window manager needs to know
                                                  //             the physical display size for this to be
                                                  //             accurate.
    int            ctrl_a_flag;
    int            auto_adjust_extents; 
    VECTOR         maxs, mins;                    // the max/min Real World(tm) coordinates of all points,
                                                  // independently of how its shown (in mm)

    virtual void   recalc_view()=0; 

    // 
    // used for pop zoom
    // 
    int            ok_to_pop;
    GRAPHICS_POINT keep_center; 
    double         keep_offset_x; 
    double         keep_offset_y; 
    double         keep_mag;
 
  public : 
    const double   &mag;
    const GRAPHICS_POINT &center; 
    const GRAPHICS_POINT &rot_center; 
    const VECTOR   &VPN, &VUP, &VX;

    const double   &view_width, &view_height;
    const double   &u_minimum, &v_minimum; 
    const double   &u_maximum, &v_maximum; 
    const double   &screen_height, &screen_width; 
    const double   &res_x, &res_y; 
    double         xfact, yfact;

    GRAPHICS_VIEW_MANAGER(); 
    GRAPHICS_VIEW_MANAGER(const GRAPHICS_VIEW_MANAGER&); 
    virtual ~GRAPHICS_VIEW_MANAGER(); 
    virtual GRAPHICS_VIEW_MANAGER* copy_self()const; 

    virtual bool do_command(STRING cmd); 

    virtual ZP_FATAL_ERROR* auto_center(ZP_STACK&);
    virtual ZP_FATAL_ERROR* set_rot_center(ZP_STACK&,double*,double*,double*,bool*);
    virtual ZP_FATAL_ERROR* set_center(ZP_STACK&,double*,double*,double*,bool*);
    virtual ZP_FATAL_ERROR* zoom_in(ZP_STACK&);
    virtual ZP_FATAL_ERROR* zoom_out(ZP_STACK&);
    virtual ZP_FATAL_ERROR* zoom_origin(ZP_STACK&);
    virtual ZP_FATAL_ERROR* zoom(ZP_STACK&,double*);
    virtual ZP_FATAL_ERROR* zoom_absolute(ZP_STACK&,double*);
    virtual ZP_FATAL_ERROR* zoom_to2(ZP_STACK&,double*,double*,double*,double*);
    virtual ZP_FATAL_ERROR* zoom_to(ZP_STACK&,double*,double*,double*,double*);

    virtual ZP_FATAL_ERROR* move_left(ZP_STACK&);
    virtual ZP_FATAL_ERROR* move_right(ZP_STACK&);
    virtual ZP_FATAL_ERROR* move_up(ZP_STACK&);
    virtual ZP_FATAL_ERROR* move_down(ZP_STACK&);

    // The draw screen coordinates, followed by the resolution 
    // in pixels/mm  (not inch!) 
    virtual int  reset_window(double umin, double vmin, double umax, double vmax, double rx, double ry); 

    virtual void convert_point(GRAPHICS_POINT& p)=0; 
    virtual void project(GRAPHICS_POINT& p)=0; 
    virtual void inverse_conversion(GRAPHICS_POINT& p)=0; 

    virtual void convert_vector(VECTOR& p)=0; 
    virtual void inverse_vector_conversion(VECTOR& p)=0; 

    void add_graphics_area(GRAPHICS_AREA* area) { its_graphics_area=area; } 

    double  get_mag() const { return(mag); } 
    double&  get_mod_mag() { return(_mag); } 
    bool    check_converted_point(GRAPHICS_POINT& p); 

    virtual void set_rotation(double, double, double)    { NOT_IMPLEMENTED_ERROR("GRAPHICS_VIEW_MANAGER::set_rotation");    }
    virtual void relative_rotate(double, double, double) { NOT_IMPLEMENTED_ERROR("GRAPHICS_VIEW_MANAGER::relative_rotate"); }
    virtual void rotate(double, double, double)          { NOT_IMPLEMENTED_ERROR("GRAPHICS_VIEW_MANAGER::rotate");          }
    virtual VECTOR get_parameters();

    void update_rot_center(const VECTOR& v) { _updated_rot_center.resize(3); for(int i=0;i<!v;i++) _updated_rot_center[i] = v[i]; }

    int view_key; 

    RTTI_INFO;
}; 

// ------------------------------------------------------------
//  This is the one used in Zmaster as of 05/2001
// ------------------------------------------------------------
ZCLASS GRAPHICS_3D_VIEW_MANAGER : public GRAPHICS_VIEW_MANAGER {
  friend class ZP_TRACKBALL;
  protected :
    VECTOR  vtemp;
    SMATRIX inv_rot, rot;

  public :
    double  r00, r01, r02;
    double  r10, r11, r12;
    double  r20, r21, r22;

    double  x_minimum, y_minimum, z_minimum;

    virtual void recalc_view();

    GRAPHICS_3D_VIEW_MANAGER();
    GRAPHICS_3D_VIEW_MANAGER(const GRAPHICS_3D_VIEW_MANAGER&);
    virtual GRAPHICS_VIEW_MANAGER* copy_self()const;

    virtual bool do_command(STRING cmd);

    virtual void convert_point(     GRAPHICS_POINT& p);
    virtual void project(     GRAPHICS_POINT& p);
    virtual void inverse_conversion(GRAPHICS_POINT& p);
    virtual void convert_vector(            VECTOR& p);
    virtual void inverse_vector_conversion( VECTOR& p);
    virtual VECTOR get_parameters();

    ZP_FATAL_ERROR* set_screen_size(ZP_STACK&, double*, double*, double*, double*);
    ZP_FATAL_ERROR* set_min_max(    ZP_STACK&, double*, double*, double*, double*);

    RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
