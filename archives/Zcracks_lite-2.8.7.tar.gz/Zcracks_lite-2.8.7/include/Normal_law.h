#ifndef __NORMAL_LAW__
#define __NORMAL_LAW__

#include <Z_Random.h>

Z_START_NAMESPACE;

/// a law following a normal distribution
ZCLASS NORMAL_LAW : public RANDOM_LAW {
  protected :
     /// mean
     double mean;
     /// variance
     double variance;
     double xmin, xmax;
     bool if_bound;
  public :
     /// initialize from a file
     NORMAL_LAW(ASCII_FILE&);
     virtual void initialize(ASCII_FILE& file);
     /// initialize using given mean and variance (default value 0. and 1.)
     NORMAL_LAW(double m = 0., double v = 1.) : mean(m), variance(v) { }

     /// return a randomized value following the corresponding normal law
     double get_random_value();
     double get_random_value(const double,const double);
     double get_bounded_random_value(const double,const double,const double,const double);
     double get_bounded_random_value(const double,const double);
};
Z_END_NAMESPACE;

#endif
