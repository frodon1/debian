#ifndef __Elastic_Phasefield_behavior__
#define __Elastic_Phasefield_behavior__

#include <PF_Chemical_energy.h>

Z_START_NAMESPACE;

class MAT_DATA; class ASCII_FILE;
class PHASEFIELD_PHIC_ENERGY;

ZCLASS2 ELASTIC_PHASEFIELD_BEHAVIOR : public BEHAVIOR {
  protected:
      AUTO_PTR<ELASTICITY> elas1;
      AUTO_PTR<ELASTICITY> elas2;
      COEFF eigen_coeff1,eigen_coeff2; 
      COEFF delta1,delta2;        	       
      COEFF c_ref1,c_ref2;       
      TENSOR2_FLUX sig;
      TENSOR2_GRAD eto;
      TENSOR2_VAUX Eel;
      TENSOR2_VAUX defo_tr; 
      VECTOR_FLUX xi;
      VECTOR_FLUX J;
      VECTOR_GRAD C_grad;
      VECTOR_GRAD Phi_grad;
     // VECTOR_GRAD mu_grad;
     
     
      SCALAR_VINT eto1;
      VECTOR_VAUX grad_eto1;
      SCALAR_VINT eto2;
      VECTOR_VAUX grad_eto2;
      SCALAR_VINT eto3;
      VECTOR_VAUX grad_eto3;
      SCALAR_VINT eto4;
      VECTOR_VAUX grad_eto4;
      SCALAR_VINT eto5;
      VECTOR_VAUX grad_eto5;
      SCALAR_VINT eto6;
      VECTOR_VAUX grad_eto6;
                 
      MATRIX grad_eto;
      
      SCALAR_VAUX mu;
      SCALAR_VAUX Phi;
      SCALAR_VAUX C;
      SCALAR_VAUX pi, pi_c;

      COEFF function,function2;

      STRING homog_name;
      double h, dh,d2h;
      double h_mech, dh_mech,d2h_mech;

      TENSOR2 dWe_ddef, d2We_dphiddef;
      SMATRIX d2We_d2def, d3We_d2defdc; 
      double dWe_dphi, d2We_d2phi; 
      
      VECTOR d2We_ddefdc,d3We_ddefd2c, d3We_ddefdphidc;
      double dWe_dc, d2We_d2c, d3We_d3c;
      double d2We_dphidc,d3We_dphid2c,d3We_d2phidc;     
      
		SMATRIX Ceff;

      COEFF alpha,beta;
      COEFF onsag2,onsag1;

      PHASEFIELD_PHIC_ENERGY *energy;

  public:
      ELASTIC_PHASEFIELD_BEHAVIOR();
      virtual void initialize(ASCII_FILE&,int,LOCAL_INTEGRATION*);

      virtual INTEGRATION_RESULT* integrate(MATERIAL_INTEGRATION_INFO&);
};

Z_END_NAMESPACE; 

#endif
