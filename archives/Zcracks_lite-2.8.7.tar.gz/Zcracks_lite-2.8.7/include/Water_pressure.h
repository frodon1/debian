#ifndef __WATER_PRESSURE__
#define __WATER_PRESSURE__

#include <Array.h>
#include <Defines.h>
#include <Error_messager.h>
#include <File.h>
#include <ZMath.h>
#include <Math_function.h>
#include <Marray.h>
#include <Stringpp.h>

#include <Behavior.h>
#include <Boundary.h>
#include <Boundary_condition.h>
#include <Basic_value.h>
#include <Clock.h>
#include <Direction.h>
#include <Dof.h>
#include <Global_matrix.h>
#include <Mesh.h>
#include <NNset.h>
#include <Node.h>
#include <P_element.h>
#include <Set.h>
#include <Table.h>
#include <Verbose.h>
#include <Print.h>
#include <Dimension.h>

Z_START_NAMESPACE;

class BC_WATER_PRESSURE : public BC 
{
  protected :
     STRING bset_name; // should be accessed by Gtheta for instance
     BOUNDARYSET *bset;
     VECTOR dir,base; double rho;
     MESH* _mesh;
     VECTOR force_dir;

     void init(MESH&);

  public :
     BC_WATER_PRESSURE();
     virtual ~BC_WATER_PRESSURE() { }

     virtual void load(ASCII_FILE&,PROBLEM&,int);
     virtual void _update(MESH&);

     virtual KIND kind() { return(DUAL); }
     virtual STRING applied_on();

     RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
