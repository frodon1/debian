#ifndef __E2_5_PERIODIC__
#define __E2_5_PERIODIC__

#include <Mcesd.h>

Z_START_NAMESPACE;

ZCLASS2 E2_5_PERIODIC : public MCESD {
      bool origin_computed;
   protected :
      virtual void compute_B(MATRIX&);
      void compute_origin();
      double X0,Y0;
      int pos_t1, pos_t2, pos_t3, pos_w1, pos_w2, pos_w3;
      int pos_E11,pos_E22,pos_E33, pos_E12, pos_E23, pos_E31;
      int nb_displ;
    public :
      E2_5_PERIODIC(); 
      virtual ~E2_5_PERIODIC();
      virtual void setup_dofs(const char* ele_type);

      virtual int material_dimension()const;
};
Z_END_NAMESPACE;

#endif

