#ifndef __ZP_EXT_PARAMS__
#define __ZP_EXT_PARAMS__

#include <Stringpp.h>
#include <Bool.h>
#include <List.h>
#include <ZP_env.h>

Z_START_NAMESPACE;

ZCLASS ZP_EXT_PARAMS {
  protected :
    LIST<STRING> prg_names;

  public :
    STRING keyword;

    LIST<STRING> global_names;
    LIST<STRING> global_types;
    LIST<STRING> default_values;
    ARRAY<void*>  global_values;

    ZP_EXT_PARAMS() { }
    virtual ~ZP_EXT_PARAMS() { }

    bool test(STRING&);
    void create_global_vars(ZP_ENV&);
};
Z_END_NAMESPACE;

#endif
