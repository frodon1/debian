Compiler : gcc-4.4.6

Compiler options : -m64 -fPIC

Environment : 
  * libc6 (glibc-2.3.6)
  * linux kernel 2.6
