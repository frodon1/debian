/*******************************************************************************/
/* this class is derived from Pb_component and Initialize_with_transfert       */
/*******************************************************************************/
#include <Auto_remesh.h>
#include <Unshared_removed_middle_nodes.h>

Z_START_NAMESPACE;

class BLOCK_REMOVED_DOFS : public BC {

   public :

    ARRAY<DOF*> dofs;

    BLOCK_REMOVED_DOFS() { }
    virtual ~BLOCK_REMOVED_DOFS();
    virtual void load(ASCII_FILE&,PROBLEM&,int ipc=0);
    virtual void _update(MESH&);
    virtual void write_restart(RST_FSTREAM&);

};

class AUTO_CRACK_REMOVE_ELEMENT : public AUTO_REMESHING
{
  private :

    // BC's due to remove elements
    BLOCK_REMOVED_DOFS removed_bc;

    // MPC's added to middle nodes not shared
    // by at least 2 elements not removed
    AUTO_PTR<UNSHARED_REMOVED_MIDDLE_NODES> removed_mpc;
    void set_removed_middle_nodes();

  public :

    bool remove_after, add_mpc;
    STRING var;
    double value;
    int nb;

    AUTO_CRACK_REMOVE_ELEMENT();
    virtual ~AUTO_CRACK_REMOVE_ELEMENT();

    virtual void load(ASCII_FILE& f, PROBLEM* pb);
    virtual bool initialize();
    virtual void init_problem();

    void remove(ELSET*);
    virtual void init_mat_data_from_dump();
    virtual void post_manage_restart();

    RTTI_INFO;
};

Z_END_NAMESPACE;
