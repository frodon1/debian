#ifndef _INVERSE_BSET__

#include <Modify_record.h>
#include <Transform_geometry.h>
#include <Utility_mesh.h>

Z_START_NAMESPACE;

class INVERSE_BSET : public TRANSFORMERS {
  public :
     LIST<STRING> names;

     INVERSE_BSET() { }
     virtual ~INVERSE_BSET() { }
     virtual MODIFY_INFO_RECORD* get_modify_info_record();
     virtual void apply(UTILITY_MESH&);
};

Z_END_NAMESPACE;

#endif


