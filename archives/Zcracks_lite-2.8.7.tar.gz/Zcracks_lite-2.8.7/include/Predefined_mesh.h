#ifndef __Predefined_mesh__
#define __Predefined_mesh__

#include <Defines.h> 

Z_START_NAMESPACE;

ZCLASS2 PREDEFINED_MESH 
{ public :
    virtual ~PREDEFINED_MESH() {}
    virtual void initialize(Zofstream&)=0;
};
Z_END_NAMESPACE;

#endif
