//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OCCDemo.rc
//
#define IDR_MAINFRAME                   128
#define IDR_TOOLBAR1                    130
#define IDD_ResultDialog                133
#define IDC_CopySelectionToClipboard    1000
#define IDC_CopyAllToClipboard          1001
#define IDC_RICHEDIT_ResultDialog       1005
#define IDB_OCC_LOGO                    1300
#define IDD_ABOUTBOX                    10000
#define IDC_ABOUTBOX_TITLE              10001
#define ID_BUTTONZoomAll                40000
#define ID_BUTTONZoomWin                40002
#define ID_BUTTONZoomProg               40003
#define ID_BUTTONPan                    40004
#define ID_BUTTONPanGlo                 40005
#define ID_BUTTONFront                  40006
#define ID_BUTTONLeft                   40007
#define ID_BUTTONTop                    40008
#define ID_BUTTONBack                   40009
#define ID_BUTTONRight                  40010
#define ID_BUTTONBottom                 40011
#define ID_BUTTONAxo                    40012
#define ID_BUTTONRot                    40013
#define ID_BUTTONReset                  40014
#define ID_BUTTONWire                   40015
#define ID_BUTTONShade                  40016
#define ID_BUTTONHlrOn                  40017
#define ID_BUTTONStart                  40103
#define ID_BUTTONNext                   40104
#define ID_BUTTONShowResult             40105
#define ID_DUMP_VIEW                    40106
#define ID_BUTTONEnd                    40107
#define ID_BUTTONPrev                   40109
#define ID_BUTTONRepeat                 40110

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         40111
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
