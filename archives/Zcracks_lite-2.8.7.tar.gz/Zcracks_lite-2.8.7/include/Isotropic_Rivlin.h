#ifndef _Isotropic_Rivlin_
#define _Isotropic_Rivlin_

// ============================================================================  
//  RIVLIN hyperelasticity.  
//
// ============================================================================  
#include <Behavior.h>
#include <Isotropic_hyperelastic.h>

Z_START_NAMESPACE;

ZCLASS RIVLIN_HYPERELASTIC_LAW : public ISOTROPIC_HYPERELASTIC_LAW {
  public :
      COEFF c10, c01, c20, c11;
      COEFF c02, c30, c21, c12;
      COEFF c03;
      COEFF Kv;

      virtual void verify_read();

      RIVLIN_HYPERELASTIC_LAW();
      virtual ~RIVLIN_HYPERELASTIC_LAW();
      virtual int base_read(const STRING&,ASCII_FILE&);
      virtual bool potential(double I1,double I2,double J,
                             double& W,VECTOR& dW,SMATRIX& d2W,double& d2U);
      virtual bool separable_potential(double I1,double I2,double J,
                             double& W,VECTOR& dW,SMATRIX& d2W);


};
Z_END_NAMESPACE;

#endif
