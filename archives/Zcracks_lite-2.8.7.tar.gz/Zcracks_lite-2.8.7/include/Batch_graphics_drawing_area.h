#ifndef __Batch_graphics_drawing_area__
#define __Batch_graphics_drawing_area__

// ============================================================================ 
// 
// ============================================================================ 

#include <Buffered_list.h> 
#include <Darray.h> 

#include <Graphics_area.h> 
#include <Graphics_object.h> 

Z_START_NAMESPACE;

class SUB_TRIANGLE; 

ZCLASS2 BATCH_DRAWING_AREA : public GRAPHICS_AREA { 
  protected : 
     // 
     // Status + efficiency data 
     // 
     double click_tolerance; 
     enum { MOUSE_OFF, MOUSE_ON, MOUSE_TRACK } mouse_stat; 
     GRAPHICS_POINT last_click; 

     double mag_ini; 
     int    o_offset_x, o_offset_y; 

     virtual void draw_block(GRAPHICS_POINT&, int solid=1, int size=6);
     virtual void draw_symbol(GRAPHICS_POINT&, GRAPHICS_SYMBOL type=GRAPHICS_SYMBOL_DOT);
     virtual void draw_line(GRAPHICS_POINT&, GRAPHICS_POINT&, int width=1);
     virtual void draw_rectangle(GRAPHICS_POINT&, GRAPHICS_POINT&);
     virtual void draw_arrow(GRAPHICS_POINT&, GRAPHICS_POINT&);
     virtual void draw_text(GRAPHICS_POINT& p1, STRING& txt);
     virtual void draw_rotated_text(GRAPHICS_POINT& p1, STRING& txt, double angle, int align);
     virtual void get_text_extent(STRING&,int&,int&);

  public : 
     BATCH_DRAWING_AREA(GRAPHICS_APPLICATION* boss); 
     virtual ~BATCH_DRAWING_AREA(); 

     virtual void activate(); 

     virtual bool do_command(STRING cmd); 

     virtual void set_background();
     virtual void set_foreground();
     virtual void set_highlight(GRAPHICS_COLOR_SPEC col=GRAPHICS_RED);

     virtual void draw_all();
}; 
Z_END_NAMESPACE;

#endif 
