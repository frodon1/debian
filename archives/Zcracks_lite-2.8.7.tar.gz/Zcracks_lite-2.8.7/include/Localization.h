#ifndef __Localization__
#define __Localization__

#include <Material_piece.h>
#include <Darray.h>

Z_START_NAMESPACE;

ZCLASS LOCALIZATION : public MATERIAL_PIECE { 
   public :
      double consistency;
      LOCALIZATION();
      virtual ~LOCALIZATION();
      LOCALIZATION(const LOCALIZATION& cpy, MATERIAL_PIECE* mat_piece_owning_this); 

      virtual void initialize(ASCII_FILE&      mat_file,
                              MATERIAL_PIECE*  mat_piece_owning_this);

      // ------------------------------------------------------------
      // Methods for the 8.1 version multimat work (bugat's work, etc). 
      // ------------------------------------------------------------
      virtual void compute_L(const TENSOR2& E_p, 
                             const TENSOR2& Sigma, 
                             const TENSOR2& dEp, 
                             const TENSOR2& dSigma, 
                             TENSOR4& computed_L);

      virtual bool homogeneous()const;
      inline  bool heterogeneous()const { return (homogeneous()) ? FALSE : TRUE; }

      virtual bool constant()const { return TRUE; } 
      virtual LOCALIZATION* copy_self()const;


      // ------------------------------------------------------------ 
      // General TFA multimat methods RF 7/15/2001 
      // Functions are default error 
      // ------------------------------------------------------------ 
      // 
      // These matrices should be prepared and correct for application of the 
      // TFA localization, but are not generally used all the time because the
      // TFA_localize_strain function can be optimized for e.g. unity or zero terms
      // 
      void  size_matrices(int num); 
      ARRAY<SMATRIX>    A; 
      ARRAY<SMATRIX>    Ac; 
      DARRAY<SMATRIX>   D, E; 

      // Compute the A and D matrices for the localization, and put the resulting 
      // composite effective elasticity in L 
      // 
      // L = Sum f_i L_i A_i
      // 
      virtual void TFA_compute_matrices( TENSOR4& L,
                                         const LIST<TENSOR4>& L_r,
                                         const LIST<TENSOR4>& Linv_r,
                                         const LIST<double>& concentrations); 

      // 
      // A*E - Sum (D_sr gamma_r + E_sr xi_r)
      // 
      virtual TENSOR2 TFA_localize_strain(const TENSOR2& E,
                             int index, 
                             ARRAY<TENSOR2*>& gamma_r, 
                             ARRAY<TENSOR2*>& xi_r,
                             bool if_eigen_model_is_stress_based); 

      // 
      // Assumes Q already has 1 on diagonal 
      // Q = delta_sr One + D_sr L^-1_r(D_r - L_r) - E_sr P_r
      // 
 //   virtual void TFA_add_jacobian(SMATRIX& Q, int s, int r, 
 //                                 const LIST<TENSOR4>& L_r,
 //                                 const LIST<TENSOR4>& L_r_inv,
 //                                 SMATRIX& D_r, 
 //                                 SMATRIX& P_r); 

      // ------------------------------------------------------------
      // Some TFA utility methods 03/25/2002 AR
      // ------------------------------------------------------------
      virtual void TFA_consistency_check(const LIST<TENSOR4>& L_r,
                           const LIST<TENSOR4>& Linv_r,
                           const LIST<double>& frac);
     RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
