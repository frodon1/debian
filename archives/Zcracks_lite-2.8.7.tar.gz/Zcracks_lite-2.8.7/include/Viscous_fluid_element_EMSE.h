#ifndef __Viscous_fluid_element_emse__
#define __Viscous_fluid_element_emse__

#include <Array.h>
#include <Matrix.h>
#include <Stringpp.h>

#include <P_element.h>

Z_START_NAMESPACE;

ZCLASS2 VISCOUS_FLUID_ELEMENT_EMSE : public P_ELEMENT {
 protected :
    int ele_flags;
    int m_grad_size;
    void make_b_mat (const MATRIX&,MATRIX&) const;

    enum { NONE=0,
           USE_CONV_TERMS=1,
           REDUCE_ORDER_OF_P=2
    };


 public :
    VISCOUS_FLUID_ELEMENT_EMSE(); 
    virtual ~VISCOUS_FLUID_ELEMENT_EMSE();

    virtual int grad_size()const { return m_grad_size; }

    DERIVED;
};
Z_END_NAMESPACE;

#endif
