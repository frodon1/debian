#ifndef __Yield_spec__
#define __Yield_spec__

#include <Zstream.h>

#include <File.h>
#include <List.h>
#include <Stringpp.h>
#include <Tensor.h>
#include <Buffered_list.h>

#include <Simul_extra_output.h>

Z_START_NAMESPACE;

ZCLASS YIELD_SPEC : public SIMUL_EXTRA_OUTPUT {
 public : 
   int          first_write; 
   Zofstream    ofile; 
   int          current_t_index; 
   int          current_r_index; 
   LIST<double> rate;
   LIST<double> time;
 public :
   double       deg;
   int          angle_idx; 
   BUFF_LIST<double> angles; 
// bool         radians_in, radians_out;

   ARRAY<int>   type;
   int          done;
   double       try_deg;

   STRING       fname;

   LIST<int>    pot;
   LIST<STRING> cname;

   int          do_rate;
   double       facto;
   double       eps;
   TENSOR2      offset;

   double       search_rate; 

   int          find_offset;
   TENSOR2      direction1;
   TENSOR2      direction2;

   YIELD_SPEC(); 
   YIELD_SPEC(const YIELD_SPEC& yin); 
   virtual void initialize(ASCII_FILE& file, SIMULATOR_TEST* boss);
   virtual ~YIELD_SPEC(); 

   void start(); 
   void next(); 
   bool ok(); 

   double get_time()const; 
   double get_rate()const; 
   void   set_rate(double val); 

   void do_output(SIMUL_MODEL* model);
   int  do_time(double t);
   YIELD_SPEC& operator=(const YIELD_SPEC& yin);

   void update(TENSOR2& try_sig, double fact);
   void write(Zofstream& ofile, const TENSOR2& try_sig);
};

Z_END_NAMESPACE;
#endif

