#ifndef __Post_fmin_fmax__
#define __Post_fmin_fmax

#include <Zminmax.h>
#include <Tensor.h>
#include <Local_post_computation.h>

Z_START_NAMESPACE;

//
// ----------------------------------------------
//

ZCLASS2 FMIN_FMAX_LOCAL_COMPUTATION : public LOCAL_POST_COMPUTATION {
  protected :
      LIST<STRING> vars;
      STRING class_name; 
  public :
      virtual MODIFY_INFO_RECORD* get_modify_info_record();
      virtual bool verify_info();

      virtual void input_i_need(int,ARRAY<STRING>&);
      void load_fmm(LIST<STRING>& lname) {vars=lname;return;};
      void set_input_data(const STRING&, void* vptr);
};

//
// ----------------------------------------------
//

ZCLASS2 FMIN_LOCAL_COMPUTATION : public FMIN_FMAX_LOCAL_COMPUTATION {
  public :
      FMIN_LOCAL_COMPUTATION() { class_name = "fmin"; } 
      virtual void output_i_give(bool&,ARRAY<STRING>&);
      virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
};

//
// ----------------------------------------------
//

ZCLASS2 FMAX_LOCAL_COMPUTATION : public FMIN_FMAX_LOCAL_COMPUTATION {
  public :
      FMAX_LOCAL_COMPUTATION() { class_name = "fmax"; } 
      virtual void output_i_give(bool&,ARRAY<STRING>&);
      virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
};
Z_END_NAMESPACE;

#endif
