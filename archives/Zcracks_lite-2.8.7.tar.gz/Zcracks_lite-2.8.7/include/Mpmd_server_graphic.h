#ifndef __MPMD_SERVER__
#define __MPMD_SERVER__

#include <Server.h>
#include <Stringpp.h>
#include <Buffered_list.h>

Z_START_NAMESPACE;

  ZCLASS MPMD_SERVER_GR : public ZSERVER {
  protected :
    STRING zgroup;

  public :
    int my_tid;
    int n_host;
    BUFF_LIST<COMPUTE_NODE> node_list;
    BUFF_LIST<COMPUTE_NODE> daemon_node_list;
    STRING other_program_name,launch_option_1,launch_option_2;
    MPMD_SERVER_GR();
    virtual ~MPMD_SERVER_GR(); 

    virtual void init_vm(ASCII_FILE& inp);
    virtual void start_vm();
    virtual void activity_loop(void);

    virtual void get_vm_description(BUFF_LIST<STRING> &VM_description);
    virtual int Add_task_to_vm(STRING host_name,STRING work_dir);
    virtual int Add_daemon_task_to_vm(STRING host_name,STRING work_dir, int parent_tid);
};
Z_END_NAMESPACE;

#endif

