gcc -I. -L. mg-cleaner_example.c -lmg-cleaner -lmeshgems -lmeshgems_stubs -lm -lc  -o mg-cleaner_example.exe
