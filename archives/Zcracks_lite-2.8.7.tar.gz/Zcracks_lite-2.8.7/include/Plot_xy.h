#ifndef __XY_PLOT__
#define __XY_PLOT__

// ============================================================================ 
//   Zebulon_plotting.h       RF  1999 
// 
//   The implementation of plots is rather difficult... and really not 
//   easy to add onto.. look in Zebulon_plotting_base_set.h for the base 
//   types of "plot sets" which are associated to different file formats. 
// ============================================================================ 

#include <Buffered_list.h>
#include <Defines.h>
#include <File.h>
#include <List.h>
#include <Print.h>
 
#include <Graphics_area.h>
#include <Graphics_face.h>
#include <Graphics_command.h>
#include <Graphics_object.h>
#include <Results_base.h>
#include <Plot_set.h>
#include <Plot_config.h>

#include <Plot_xy_actor.h>
#include <Plot_xy_wrapper.h>

Z_START_NAMESPACE;

class FUNCTION; 
class PLOT_COMMAND; 
class XY_PLOT; 
class GRAPHICS_DATA_DIALOG;
class CALCUL_COMMAND;


// ---------------------------------------------------------------------------- 
//  it's kindof jumping in too fast for this thing to be a RESULTS_BASE_COMMAND.
//  there should be some type of basic plot or whatever, but i'm really going
//  for fast implementation here. 
// ---------------------------------------------------------------------------- 

ZCLASS2 XY_PLOT : public RESULTS_BASE_COMMAND
{
  protected :
    LIST<STRING> opts; LIST<int> ovals;
    LIST<STRING> active_plots_name_list;
    LIST<STRING> usable_plots_name_list;
    PLOT_SET *active_plot_set;
    STRING active_name;
    int nbp;
    bool doing_modify;

    void fabricate_plot_set_dialog(PLOT_SET*,bool b=FALSE);
    void add_to_dialog(MODIFY_INFO& info);

  public : 
    int             last_clear_flag; 
    STRING fname_store;

    LIST<STRING>          plot_types; 

    int last_grf; 
    GRAPHICS_DATA_DIALOG *more_dialog,*data_dialog;
    GRAPHICS_POINT*      clk_hlt; 

    PLOT_XY_ACTOR      *actor;
    PLOT_XY_WRAPPER     wrapper;

    // 
    // Special for making merged plots 
    // 
    int                   merged_check; 
    GRAPHICS_DATA_DIALOG* merged_dialog;
    int                   merged_current_pset; 
    ARRAY< ARRAY<int> >   merged_current_selections; 
    virtual bool          merged_plot_cmd(STRING cmd);

    GRAPHICS_DATA_DIALOG* its_dialog;
    GRAPHICS_DATA_DIALOG* add_dialog;
    GRAPHICS_DATA_DIALOG* copy_plot_dialog;
    GRAPHICS_DATA_DIALOG* config_dialog;

    void setup_more_dialog();

    CALCUL_COMMAND* run_command; 
    PLOT_COMMAND*         plotter;

    STRING  input_name; 
    void    clear_all(); 

    virtual void   draw_plot(bool redraw=FALSE); 
    // redraw means : use previous values instead of scanning the whole result file set

    XY_PLOT(); 
    virtual ~XY_PLOT();

    virtual void initialize(GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app);
    virtual void update_all_lists();
    virtual bool do_command(STRING cmd);
    virtual bool config_plot_cmd(STRING cmd); 

    virtual bool do_click( int , GRAPHICS_POINT& clk, GRAPHICS_OBJECT* ); 

    virtual void read(ASCII_FILE&);
};
Z_END_NAMESPACE;

#endif
