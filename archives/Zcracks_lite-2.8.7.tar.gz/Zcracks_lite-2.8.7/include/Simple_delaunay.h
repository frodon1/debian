#ifndef __Simple_delaunay__
#define __Simple_delaunay__

// ============================================================================ 
//   SIMPLE_DELAUNAY       a simple class for generating a delaunay triangulation
//                         out of a list of vectors being the points. its a 2d 
//                         algorithm but points can be 3d..   RF 07/29/2002 
// 
//  * brute force implementation... meant for *small* applications.. really these 
//    are designed for cutting single elements for e.g. slice views, xfem, crack
//    insertion etc. 
//  * you can get the trianglulation, insert points and re-triangulate per normal 
//    meshing practice. 
//  * added tesselation of 3d points RF Feb 05 2005 
//
//  **************************************************************************
//  *** Note these routines are not supposed to be general library quality *** 
//  *** They are serving a specific purpose, which may or may not work for ***
//  *** other applications. Altering this code for general use may break   *** 
//  *** assumptions which need to be made, and therefore should not be     ***
//  *** undertaken without a lot of thought and care                       *** 
//  **************************************************************************
// 
//  One should usually use Create_object(SIMPLE_DELAUNAY, "default"); 
//  so that the object can be patched (likely occurance with this thing, perhaps
//  using someone elses code wrapped). 
// 
// ============================================================================ 

#include <Vector.h>
#include <List.h>
#include <Marray.h>
#include <Buffered_list.h>

Z_START_NAMESPACE;

class SIMPLE_DELAUNAY_TRIANGLE; 

ZCLASS SD_VECTOR_HOLDER {
   public:
    int     locked; 
    VECTOR* v_in; 
    int rank; 
   
    SD_VECTOR_HOLDER() { locked = 0; v_in = NULL; rank = -1; }
    SD_VECTOR_HOLDER(const SD_VECTOR_HOLDER& vv) { operator=(vv); }
    SD_VECTOR_HOLDER(const VECTOR* vv) { operator=(vv); }

    SD_VECTOR_HOLDER& operator=(const VECTOR* vv) { locked = 0; v_in = (VECTOR*)vv; rank = -1; return *this; } 
    SD_VECTOR_HOLDER& operator=(const SD_VECTOR_HOLDER& vv) { 
            v_in = (VECTOR*)vv.v_in; 
            rank = vv.rank; 
            locked = vv.locked; 
            return *this; 
    } 
    operator VECTOR*()  { return v_in; }
    operator const VECTOR*()const  { return v_in; }
    VECTOR& operator*() { return *v_in; } 
    VECTOR* operator->() { return v_in; } 

    double& operator[](int i ) { return (*v_in)[i]; } 


//  bool operator==(VECTOR* v) { return (v_in==v) ? TRUE : FALSE; } 
//  bool operator==(SD_VECTOR_HOLDER v)const { return (v_in==v.v_in && rank==v.rank) ? TRUE : FALSE; } 

    void write_mast(Zofstream& of);
}; 

ZCLASS SIMPLE_DELAUNAY_TET {
  public:
    double R2; 
    VECTOR c_cent; 
    void   setup_c_cent(); 

    VECTOR center; 
    BUFF_LIST<SIMPLE_DELAUNAY_TET*> connex; // optional.. may not be setup

    CARRAY<SD_VECTOR_HOLDER> v;

    SIMPLE_DELAUNAY_TET();
    SIMPLE_DELAUNAY_TET(const SIMPLE_DELAUNAY_TET&);
    ~SIMPLE_DELAUNAY_TET(); 

    SIMPLE_DELAUNAY_TET* invert();
    ARRAY<SIMPLE_DELAUNAY_TRIANGLE> face;
    void make_faces(int allow_inval=FALSE); 

    // 
    // Faces 
    //

    bool operator==(const SIMPLE_DELAUNAY_TET& in);
    bool operator!=(const SIMPLE_DELAUNAY_TET& in);
    SIMPLE_DELAUNAY_TET& operator=(const SIMPLE_DELAUNAY_TET& in);

    bool is_in(SD_VECTOR_HOLDER& v); 

    void clear_matched(); 
    bool in_sphere(SD_VECTOR_HOLDER& v); 

    void write_mast(Zofstream& of);
};

ZCLASS SIMPLE_DELAUNAY_TRIANGLE { 
  public: 
    int    matched; 
    VECTOR center; 
    VECTOR norm, b,c; 
    CARRAY<SD_VECTOR_HOLDER> v;
    LIST<SIMPLE_DELAUNAY_TET*> attached_tet;

    SIMPLE_DELAUNAY_TRIANGLE(); 
    SIMPLE_DELAUNAY_TRIANGLE(const SIMPLE_DELAUNAY_TRIANGLE&); 
    ~SIMPLE_DELAUNAY_TRIANGLE(); 

    SIMPLE_DELAUNAY_TRIANGLE* invert(); // returns this 
    VECTOR normal();    // not normalized
    void   make_center();

    bool operator==(const SIMPLE_DELAUNAY_TRIANGLE& in);
    bool operator!=(const SIMPLE_DELAUNAY_TRIANGLE& in);
    SIMPLE_DELAUNAY_TRIANGLE& operator=(const SIMPLE_DELAUNAY_TRIANGLE& in);

    void write_mast(Zofstream& of);
}; 

ZCLASS SIMPLE_DELAUNAY_EDGE {
  public: 
    SD_VECTOR_HOLDER p1; 
    SD_VECTOR_HOLDER p2; 
    LIST<SIMPLE_DELAUNAY_TRIANGLE*> attached_tri;

    SIMPLE_DELAUNAY_EDGE();
    SIMPLE_DELAUNAY_EDGE(const SIMPLE_DELAUNAY_EDGE&);
    ~SIMPLE_DELAUNAY_EDGE();

    bool operator==(const SIMPLE_DELAUNAY_EDGE& in); 
    bool operator!=(const SIMPLE_DELAUNAY_EDGE& in); 
    SIMPLE_DELAUNAY_EDGE& operator=(const SIMPLE_DELAUNAY_EDGE& in); 
};

ZCLASS SIMPLE_ISECT_DAT { 
   public: 
     VECTOR p0; 
     VECTOR D; 

     VECTOR t1;           // t values on intersect line p0+t*D for 1st triangle 
     VECTOR t2;           // t vals for 2nd triangle 

     SIMPLE_ISECT_DAT(); 
}; 

ZCLASS  SD_TET_MESH_OPTIONS {
     public:
       SD_TET_MESH_OPTIONS(); 

       int allow_refinement; 

       LIST<SIMPLE_DELAUNAY_TRIANGLE*> enforce_faces;
};

ZCLASS SIMPLE_DELAUNAY { 
  protected:
    SD_TET_MESH_OPTIONS default_opts;

    VECTOR origin; 
    MARRAY<VECTOR>   axes; 
    virtual bool check_intersections(int st, CARRAY<SD_VECTOR_HOLDER>& f_f_v, SD_VECTOR_HOLDER& pt2);
    virtual bool check_tri_tri_intersections(int st, CARRAY<SD_VECTOR_HOLDER>& f_f_v, SD_VECTOR_HOLDER& pt2);
    virtual bool tri_intersect(SIMPLE_ISECT_DAT& dat, 
                               SIMPLE_DELAUNAY_TRIANGLE& t1, 
                               SIMPLE_DELAUNAY_TRIANGLE& t2);

  public : 
    // 
    // 2d data strucutures 
    // 
    BUFF_LIST<SD_VECTOR_HOLDER>      free_pts;
    BUFF_LIST<SIMPLE_DELAUNAY_EDGE*> edge_front;
    ARRAY< BUFF_LIST<SD_VECTOR_HOLDER> > connected;
    LIST<SIMPLE_DELAUNAY_TRIANGLE*>  triangles; 
    void check_add_edge(SD_VECTOR_HOLDER v1, SD_VECTOR_HOLDER v2);


    // 
    // 3d data strucutures 
    // 
    BUFF_LIST<SIMPLE_DELAUNAY_TRIANGLE*> face_front;
    LIST<SIMPLE_DELAUNAY_TET*>       tetrahedrons; 
    void check_add_face(SIMPLE_DELAUNAY_TRIANGLE* face); 
    void rebuild_tet_connections();

    SIMPLE_DELAUNAY(); 
    virtual ~SIMPLE_DELAUNAY(); 

    virtual void clear_all();

    // 
    // Straight up triangulate points 
    // 
    virtual bool triangulate(const ARRAY<VECTOR*>& v); 
    virtual bool tessellate(const ARRAY<VECTOR*>& v, 
                            SD_TET_MESH_OPTIONS* opts=NULL); 

    // 
    // Try to figure out "outer box" so non convex boundaries will be ok 
    // you'll still have to figure out internal boundaries 
    // 
    // bool triangulate_with_box(const ARRAY<VECTOR*>& v); 
}; 

//
// In case you want a function for doing this. The triangles storage is 
// created in the function, so you need to delete them.
//
WIN_THINGIE bool simple_delaunay(LIST<SIMPLE_DELAUNAY_TRIANGLE*>& triangles, 
                            const ARRAY<VECTOR*>& vertices_in, 
                            const char* solver="default");

WIN_THINGIE bool simple_delaunay(LIST<SIMPLE_DELAUNAY_TET*>& tets, 
                            const ARRAY<VECTOR*>& vertices_in, 
                            const char* solver="default", 
                            SD_TET_MESH_OPTIONS* opts=NULL);
Z_END_NAMESPACE;

#endif 
