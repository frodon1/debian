#ifndef __Problem_callback__
#define __Problem_callback__

/*

FF, april 20th, 2012

This callback class is a pure container to be used in various places of the code when any
class (and not only PROBLEM) wants to declare callbacks.

*/

#include <Z_object.h>

Z_START_NAMESPACE;

class INTEGRATION_RESULT;

ZCLASS ZSET_CALLBACK : public Z_OBJECT { 
  public : 
    ZSET_CALLBACK() : Z_OBJECT() { }
    virtual ~ZSET_CALLBACK() { }
 
    virtual void activate() { }
    virtual bool verification()  { return true; }

    virtual void pre_create_dof() { }
    virtual void before_mesh_build() { }
    virtual void after_mesh_setup() { }
    virtual void before_material() { }
    virtual void after_material()  { }

    virtual void init_problem() { }
    virtual void make_increment(double) { }
    virtual void start_increment() { }
    virtual void end_increment(INTEGRATION_RESULT*&) { }

    virtual void start_iteration() { }
    virtual void start_fictious_iteration(bool &if_compute_stiffness) { }
    virtual void compute_internal_reactions() { }
    virtual void end_iteration() { }
    virtual void end_fictious_iteration(bool &efi) { }
    virtual bool end_iteration_converge() { return(true); }
    virtual void manage_restart() { }
    virtual void pre_manage_restart() { }
    virtual void post_manage_restart() { }
    virtual bool has_relationship() { return(false); }

    virtual void mesh_will_change() { }
    virtual void mesh_changed() { }
    virtual void clean_after_remesh() { }
    virtual void reinit() { }
    virtual void reset() { }

    virtual void end_problem() { }
    virtual void end_of_zset() { }

    virtual void message_1() { }
    virtual void message_2() { }
    virtual void message_3() { }

    RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
