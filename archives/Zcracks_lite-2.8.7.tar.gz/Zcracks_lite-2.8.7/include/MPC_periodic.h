#ifndef __MPC_PERIODIC__
#define __MPC_PERIODIC__

#include <Array.h>
#include <Error_messager.h>
#include <Defines.h>
#include <File.h>
#include <ZMath.h>
#include <Stringpp.h>


#include <Dof.h>
#include <Mesh.h>
#include <NNset.h>
#include <Node.h>
#include <Relationship.h>
#include <Set.h>
#include <Verbose.h>

Z_START_NAMESPACE;

// *****************************************************************************

// MPC_PERIODIC
// *****************************************************************************

ZCLASS2 MPC_PERIODIC : public RELATIONSHIP 
{
  public :
    enum MODE { TABLE, EXTERNAL };

  private :
    enum components { _E11_, _E22_,  _E12_,_E21_, _E33_, _E13_, _E31_, _E23_, _E32_};

    MODE _mode;
    double val;
    int dimension;

    NNSET *nset1, *nset2;
    NNSET* nset;
    DOF_TYPE* dof1;
    MATRIX e_mat;
    VECTOR epsilon;

    void initialize_internals();

    void impose_deformation(VECTOR&);
    void build_relation_ship(MESH&);
    static int max_nb_def(int dim);
    static int matrix_size(int dim);
    virtual void _set_relationship(MESH&);

  public :
    STRING nset_name1,nset_name2;
    STRING dof_name;
    bool inversion;
    LIST<double> bval;
    LIST<STRING> tnames;
    LIST<int> idx;

    const MODE &mode;

    MPC_PERIODIC();
    virtual void load(ASCII_FILE&); // from a file -> TABLE
    MPC_PERIODIC(bool,STRING&,STRING&,STRING&,MESH&); // from given names => EXTERNAL
    void set_epsilon(VECTOR&);
};
Z_END_NAMESPACE;

#endif
