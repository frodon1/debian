#ifndef __CRACK_FC__
#define __CRACK_FC__

#include <Vector.h>
#include <Matrix.h>
#include <List.h>
#include <Stringpp.h>

#include <Element.h>
#include <Crack_FE.h>
#include <Crack_FG.h>
// #include <Crack_FS.h>
// #include <Node.h>
// #include <Boundary_condition.h>
#include <B3Splines_interpolation.h>
#include <CFV_build.h>
#include <BB_tree_utility_mesh.h>
#include <GMesh.h>

#include <GTH_element.h>
#include <Thread_slave.h>
#include <Global_parameter.h>
#include <Clock.h>

Z_START_NAMESPACE;

//
// 2006-02-22 chiaruttini: describes a curved crack front
//

class CRACK_FE;
class CRACK_FS;
class CRACK_FV;
class BC;
class CRACK_INFO_XFEM;
class MESH;

class CRACK_FC_THREAD;

//WIN_THINGIE2 void _a_bb_function_un(const UTILITY_NODE&,VECTOR&,VECTOR&);

class CRACK_FC : public LIST<CRACK_FE*>
{
  private :
    MATRIX _BM; // Base matrix for Catmull-Rom spline
    VECTOR GP_ksi,GP_factor; // Gauss point postion and factor [0,1]
    int _nb_ddl;
    int fnnode;
    MARRAY<VECTOR> ffront_nodes,ffront_save;
    bool ffnode_set();

  public :
    int  frac_mode;
    bool if2D;
    double identify_orientation();
    void clipping(VECTOR &G,int bnd=2);
    void average(VECTOR &G,int bnd=0, int iter=1);
    void exclude_be(VECTOR &G);
    void exclude_be2(VECTOR &G);

    double sigy;
    VECTOR vradius,vlambda,vmu,rp,rp_,vtemp,vnbgp;
    void compute_vradius(int nb_elemr,B_UTILITY_SET *slip);
    void compute_s();
    double hmin;
    BB_TREE<UTILITY_NODE> *bb_nodes;
    BUFF_LIST<UTILITY_NODE*> gp_pos;
    void check_bb_nodes();
    void find_bb_nodes(VECTOR &pos,double &radius,int min_number,BUFF_LIST<UTILITY_NODE*> &lnodes,double t_pos=-1.);
    void field_grad(VECTOR &pos,BUFF_LIST<UTILITY_NODE*> &lnodes,MATRIX &grad);

    void filter_error(MATRIX &values, VECTOR &error, int nb_spt);

    ARRAY <int> closest_node;

    void clean_threads();
    void delete_threads();
    void* its_boss;
    ARRAY<CRACK_FC_THREAD*> threads;
    bool init_threads(MATRIX *matrix,VECTOR *vector,int mode=0);

    void build_integ_mesh(int nbth,int nbr,STRING &fname);

    ARRAY <int> pnode_i;
    double bb_radius;

    void compute_stable();
    int _dim;
    bool if_xfem;
    B_UTILITY_SET *lip; // for conform mesh pointer on lip side 
    int nelemr; // number of element required to represent cracked surface
    double _a,_amax;

    LIST <BC*> centrifugal_bcs;
    
    VECTOR G_values;

    void move_nodes(double);
    void unmove_nodes();

    void compute_K(double t, VECTOR &K,double &T,double g=-1.); // Compute SIF at a local t coordinate along crack front
    bool compute_mechanical_values(double t, double &E, double &nu, double &mu);

    bool check_bbtree(); // Build bbtree if possible (build on complete structure for xfem
    BC *centrifugal;
    STRING nset_name;
    bool if_plane;
    VECTOR front_angle; // angle between propag direction and front normal 
    VECTOR front_sina,front_cosa;
    VECTOR front_sign; // sign for normal
    MARRAY <VECTOR> front_normals,front_normals_saved;
    void swap_normals() {
      MARRAY <VECTOR> tmp=front_normals;
      front_normals=front_normals_saved;
      front_normals_saved=tmp;
    }
    // POST VERSION
    bool initialize(B_UTILITY_SET&,double,double,int);
    bool initialize_volume(ARRAY<ELEMENT*>&,GMESH *gmesh,double _radius);
    // 
    bool initialize(B_UTILITY_SET&,GMESH&,int,double,double,double,bool,int,VECTOR&,VECTOR&,VECTOR&,STRING&,int nb_spt=0);
    bool initialize(CRACK_INFO_XFEM &xfem_infos, MESH &_mesh,double _radius_i,double _radius_v,int nb_nodes,bool _if_closed);
    BB_TREE_UTILITY_MESH *bb_tree; 

    void compute_normal_sincos();

    VECTOR OM(double);
    VECTOR dOM(double);
    VECTOR d2OM(double);
    VECTOR d3OM(double);
    double t_to_xi(double,int i_seg=-1); // For conversion from [0,t_max] to [-1,1]i_seg
    double xi_to_t(double,int); // For conversion from [-1,1]i_seg to [0,t_max]
    double s_l(double,int i_seg=-1);
    double s(double);
    double ds(double);
    double d2s(double);
    double find_t(VECTOR,double);
    VECTOR T(double);
    VECTOR N(double);
    VECTOR B(double);
    void build_dnds();
    double TNds(double t,VECTOR &T,VECTOR &N,VECTOR &dnds,double h=1.e-7);
    double TNds(double t,VECTOR &T,VECTOR &N);
    SMATRIX frenet(double,double&,double&,double&);
    SMATRIX compute_jacobian(VECTOR,SMATRIX,double,double);
    double projection_lin(const VECTOR&,VECTOR&,double&);
    double projection_lin(const VECTOR &a) {VECTOR b; double c,r; r=projection_lin(a,b,c); return r; }
    double projection_lin_fast(const VECTOR &);
    double projection(const VECTOR&,VECTOR&,double&,double&,double&);
    double projection(const VECTOR&,VECTOR&,double&);
    double fast_projection(const VECTOR&,VECTOR&,double&);
    double _dist(double&,const VECTOR&);
    CFV_VOLUME_INFOS* build_CFV_for_mesher(int nb_cut=1);

    bool compute_normal_from_lip(B_UTILITY_SET *,double dist=-1.);

    VECTOR theta(double&,VECTOR&,VECTOR&);
    VECTOR theta(VECTOR&,VECTOR&,VECTOR*,double&,double&,VECTOR &G,double &gvalue);
//    VECTOR theta(VECTOR&,VECTOR&,VECTOR*,double&,double&); 
    VECTOR theta(VECTOR &M,VECTOR &theta_dof,VECTOR *_dir=NULL,double ra=-1.,double rb=-1.)
      { VECTOR G=theta_dof; double gvalue; return theta(M,theta_dof,_dir,ra,rb,G,gvalue); }
//    VECTOR theta(VECTOR &M,VECTOR &theta_dof,VECTOR *_dir=NULL)
//      { double ra=-1.,rb=-1.; VECTOR G=theta_dof; double gvalue; return theta(M,theta_dof,_dir,ra,rb,G,gvalue); }
    VECTOR theta(VECTOR &M,VECTOR &theta_dof,VECTOR &G,double &gvalue)
      { double ra=-1.,rb=-1.; VECTOR *_dir=NULL; return theta(M,theta_dof,_dir,ra,rb,G,gvalue); }
    bool apply_theta(VECTOR&);

    double t_max,radius,radius_i,radius_v;
    bool   if_check_normal;
    int nb_ddl() { return _nb_ddl; }

    SMATRIX integrate_curve();
    VECTOR  Compute_G_by_gth(SMATRIX *IC=NULL,int mode=0,MATRIX *others=NULL); 
    VECTOR  integrate_volume_gth(int mode=0,MATRIX *others=NULL);
    MATRIX  Compute_Ki_by_gth(SMATRIX *IC=NULL); 
    MATRIX  Compute_Wcrack(SMATRIX *IC=NULL); 
    MATRIX  integrate_volume_Ki();
    MATRIX  integrate_volume_WC();
    SMATRIX integrate_curve_D2(VECTOR&,int type=0);
    MATRIX  Compute_F_by_gth();
    SMATRIX Compute_J2_by_gth(MATRIX& u1);

    // Crack front modelized by Catmull-Rom spline (insure C^1 continuity)
    B3_SPLINES_INTERPOLATION *interpolation;
    CRACK_FG_3D *crack_geom;
    CRACK_FV *volume;
    CRACK_FS *surface;
    GMESH *mesh,*mesh_FV; // real mesh and mesh used for front volume
    UTILITY_MESH *zmesh;

    int volExtType,derMethod,last_seg;
    bool if_closed;
    LIST<UTILITY_NODE*> node_liset;	// nodes in liset (ordered) 
    LIST<VECTOR> node;	// node coordinates of the spline (first and last one for computation only)
    ARRAY<double> s_node; // s coordinate of each node (used for integration)
    ARRAY<double> t_smooth,dt_smooth; // t postion and associated dt correction for node smoothing

    VECTOR _N0,_N1,_P_dir; // Vector for bc on theta field and direction of propagation (for normal orientation)

    bool check_normal(int,const double&,VECTOR&,VECTOR&,VECTOR&); // near external boundaries
    MARRAY<VECTOR> *Delta_A;

    void compute_smoothing();

    void erase();

    CRACK_FC() ;
    ~CRACK_FC() { this->erase(); }

    int space_dimension() { return _dim;}
    VECTOR reshape_front(int nb_node);

    void build_surface();

    void Compute_K_interaction_integral(MATRIX &Ki,SMATRIX *IC=NULL); 
    void integrate_volume_ii(MATRIX &i_vol);
    void integrate_surface_ii(MATRIX &i_surf);

    bool print_G_info(STRING &fname,int N,VECTOR *G,VECTOR *KI,VECTOR *T,VECTOR *angle,MATRIX *K,int nb_node);
    bool print_front(STRING &fname,int N,int);
};

class CRACK_FC_THREAD :  public THREAD_SLAVE 
{
  public:
  bool if_zero;

  LIST<BEHAVIOR*>         behaviors;
  LIST<EXTERNAL_PARAM*>*  ep_copy;
  CLOCK                   clock;

  enum OPERATIONS { UNKNOWN, LOAD_BEHAVIORS, COMPUTE_SIF, COMPUTE_G , COMPUTE_WC, CLEAN_GP };

  CRACK_FC_THREAD() { if_zero=FALSE; elements.resize(0); behaviors.resize(0); Mvalues=NULL; Vvalues=NULL; front=NULL; ep_copy=NULL; }
  ~CRACK_FC_THREAD();

  bool load_behaviors();
  bool integ_Ki();
  bool integ_G();
  bool integ_WC();
  bool clean_GP();

  int mode;
  CRACK_FC *front;
  ARRAY<GTH_ELEMENT*> elements;   

  MATRIX *Mvalues;
  VECTOR *Vvalues;

  TS_DECLARE_EVENT;
};

Z_END_NAMESPACE;

#endif
