#ifndef __Transform_geometry__
#define __Transform_geometry__


// ============================================================================ 
//   TRANSFORMERS     Take a utility mesh, and change it however you 
//                    want. 
// ============================================================================ 

#include <Stringpp.h>
#include <List.h>
#include <Zstream.h>
#include <Modify_record.h>
#include <Ask.h>

Z_START_NAMESPACE;

class ASCII_FILE; 
class UTILITY_MESH; 
class GAUGE;
class FUNCTION;
class BASE_PROBLEM;

ZCLASS TRANSFORMERS : public Z_OBJECT {
  protected : 
     double eval_func(const VECTOR& v, FUNCTION& f);

  public : 
     GAUGE *gauge;
     STRING name;

     BASE_PROBLEM *its_boss;

     TRANSFORMERS(); 
     virtual ~TRANSFORMERS(); 

     // 
     // The base class methods can now handle the input, 
     // given that the get_modify_info_record is properly 
     // implemented... 
     // 
     virtual void initialize(ASCII_FILE&); 
     virtual void write(Zofstream& out); 

     static TRANSFORMERS* load(STRING param); 
     static TRANSFORMERS* load(const LIST<STRING>& param); 

     // 
     // Default method returns NULL... LOOK FOR IT 
     // 
     virtual MODIFY_INFO_RECORD* get_modify_info_record();
     virtual bool                verify_info(); 

     virtual void apply(UTILITY_MESH& mesh)=0; 

     DECLARE_ASK;
}; 
Z_END_NAMESPACE;

#endif
