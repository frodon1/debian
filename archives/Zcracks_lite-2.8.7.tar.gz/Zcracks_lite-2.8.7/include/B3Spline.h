#ifndef __B3S__
#define __B3S__

#include <Interpolation.h>

Z_START_NAMESPACE;

ZCLASS B3_SPLINE : public INTERPOLATION_FUNCTION
{
 public : 
  B3_SPLINE(int,int);
  ~B3_SPLINE();
  
  virtual void cal_shape_function(const VECTOR& chi,VECTOR& ni) const;

  virtual VECTOR shape(const VECTOR& chi) const;
  virtual MATRIX deriv(const VECTOR& chi) const;
  MATRIX deriv2(const VECTOR& chi) const; 
  MATRIX deriv3(const VECTOR& chi) const; 

  virtual void get_sides(ARRAY<ARRAY<int> >&) const;
  virtual void local_position_of_node(int, VECTOR&) const;
};
Z_END_NAMESPACE;

#endif
