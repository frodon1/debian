#ifndef __Penalty_Diffusion_behavior__
#define __Penalty_Diffusion_behavior__

#include <Defines.h>
#include <File.h>
#include <ZMath.h>

#include <Behavior.h>
#include <Mat_data.h>
#include <Coefficient.h>
#include <Int_variable_holder.h>
#include <Utility.h>
#include <Print.h>

Z_START_NAMESPACE;

ZCLASS2 DIFF_PENALTY_BEHAVIOR : public BEHAVIOR { 
  protected :
      SCALAR_FLUX C_flux;
      SCALAR_GRAD C_grad;

      double penalty;
 
      MATRIX m_tg_matrix; 

  public:
      DIFF_PENALTY_BEHAVIOR();
      virtual ~DIFF_PENALTY_BEHAVIOR();
      virtual void initialize(ASCII_FILE&,int,LOCAL_INTEGRATION*);
      INTEGRATION_RESULT* integrate(
                           MAT_DATA&        mdat,
                           const VECTOR&    /*delta_grad*/,
                           MATRIX*&         tg_matrix,
                           int              flags        );
};

Z_END_NAMESPACE;
#endif
