#ifndef __NT_tools__ 
#define __NT_tools__ 

#include <Defines.h>
#include <Stringpp.h>
#include <Unix_tools.h>

Z_START_NAMESPACE;

#ifdef _WIN32
  #define SL_NAME(a) a+STRING(".dll")
#elif defined AIX
  #ifdef ZCHECK
     #define SL_NAME(a) STRING("libg")+a+"_"+STRING(STD_GETENV("Z7MACHINE"))+".a";
  #else
    #define SL_NAME(a) STRING("lib")+a+"_"+STRING(STD_GETENV("Z7MACHINE"))+".a";
  #endif
#elif defined HPUX64
  #ifdef ZCHECK
     #define SL_NAME(a) STRING("libg")+a+"_"+STRING(STD_GETENV("Z7MACHINE"))+".sl"
  #else
     #define SL_NAME(a) STRING("lib")+a+"_"+STRING(STD_GETENV("Z7MACHINE"))+".sl"
  #endif
#elif defined HPUX
  #define SL_NAME(a) STRING("lib")+a+STRING(".sl")
#else
  #ifdef Darwin
    #ifdef ZCHECK
       #define SL_NAME(a) STRING("libg")+a+"_"+STRING(STD_GETENV("Z7MACHINE"))+".so"
    #else
       #define SL_NAME(a) STRING("lib")+a+"_"+STRING(STD_GETENV("Z7MACHINE"))+".so"
    #endif
  #else
    #ifdef ZCOV 
         #define SL_NAME(a) STRING("libcov")+a+"_"+STRING(STD_GETENV("Z7MACHINE"))+".so"
    #elif defined ZCHECK 
      #ifdef ZINSURE
         #define SL_NAME(a) STRING("libig")+a+"_"+STRING(STD_GETENV("Z7MACHINE"))+".so"
      #else
         #define SL_NAME(a) STRING("libg")+a+"_"+STRING(STD_GETENV("Z7MACHINE"))+".so"
      #endif
    #else 
       #define SL_NAME(a) STRING("lib")+a+"_"+STRING(STD_GETENV("Z7MACHINE"))+".so"
    #endif 
  #endif
#endif

WIN_THINGIE STRING cut_out_nt_path(STRING sin); 
extern WIN_THINGIE int nt_thread_failure;
extern WIN_THINGIE STRING nt_thread_failure_type;
extern WIN_THINGIE STRING nt_thread_failure_msg;
extern WIN_THINGIE int nt_isa_thread;

extern WIN_THINGIE void convert_short_win_name(STRING& fname); 


#ifdef _WIN32
extern WIN_THINGIE bool load_library(STRING); 
extern WIN_THINGIE void load_shared_libs(STRING prefix=STRING::EMPTY); 
extern WIN_THINGIE void free_shared_libs(); 
#endif
Z_END_NAMESPACE;

#endif
