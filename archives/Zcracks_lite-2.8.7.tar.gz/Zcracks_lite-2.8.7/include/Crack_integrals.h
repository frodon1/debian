#ifndef __Crack_integrals__
#define __Crack_integrals__

// ============================================================================ 
//   Crack integrals as calculated from direct integration over a path. 
//         RF Dec 1996 
//
//   o  As the calc is done as part of a DATA_TEST class, the frequency for 
//      the output being used should be at every step.  For Delta J this could 
//      be only over the segment of application, but the sig0 won't be stored 
//      correctly.. so if you want to be confused, use freq. over the integ time
//      with the step before included.. (i.e. use freq at every step and pay a 
//      bit of CPU). 
//
//   o 
// ============================================================================ 
#include <Calcul_timer.h>
#include <Defines.h>
#include <Marray.h>

#include <Boundary.h>
#include <Behavior.h>
#include <Clock.h>
#include <Data_test.h>
#include <Discrete_timer.h>
#include <Dof.h>
#include <Hyper_plane_space.h>
#include <Interpolation.h>
#include <Mesh.h>
#include <Node.h>
#include <P_element.h>
#include <Strain_trans_matrix.h>
#include <Verbose.h>

Z_START_NAMESPACE;

class J_INTEGRAL; 

ZCLASS2 PATH_ELEMENT : public P_ELEMENT { 
   J_INTEGRAL* its_boss; 
   VECTOR center; 
   VECTOR W; 

   void get_d_dof(MATRIX& d_dof, int tot);
   void get_d_dof(VECTOR& d_dof, int tot);

 public : 
   int is_delta; 
   int start_seq, end_seq; 
   int current_cycle; 

   // sig[0] is sig11 for nodes 1->nb_node .. 
   // sig[4] is sig12 for nodes 1->nb_node .. etc. 
   MARRAY<VECTOR> sig; 
   MARRAY<VECTOR> sig0; 

   MARRAY<VECTOR> cauchy; 

   MARRAY<VECTOR> eto; 
   MARRAY<VECTOR> eto0; 

   // 
   // These are used for delta J All are sized #gp <size of item>
   // 
   MARRAY<TENSOR2> sig_ini; // #gp 4
   MARRAY<TENSOR2> eto_ini; // #gp 4
   MARRAY<VECTOR> T_ini;   // sized #gp 2 
   VECTOR         u_ini; 

   PATH_ELEMENT() { }

   void setup_path( J_INTEGRAL* boss, 
                 int nb_gp, 
                 MESH* min,
                 GEOMETRY* geo,
                 int idin,
                 ARRAY<GNODE*>& connec, 
                 VECTOR center_in); 

   virtual INTEGRATION_RESULT* internal_reaction(bool,VECTOR&,SMATRIX&,bool=FALSE);
   virtual double integrate_path(); 
};

ZCLASS2 J_INTEGRAL : public DATA_TEST_AT {
  protected : 
     int              start_seq; 
     int              end_seq; 
     int              is_delta; 
     int              num_gp; 
     int              num_node; 
     STRING           path_name; 
     MESH*            its_mesh;
     BOUNDARYSET*     the_boundary;
     PLIST<PATH_ELEMENT> path; 
     LIST<ELEMENT*>   connected_elements; 
     VECTOR           center; 
     
     int              first_time; 
     STRING           sig_stub, eto_stub; 
     enum L_DEF {     NOPE=0, 
                      TOTAL_LAGRANGE=1, 
                      UPDATED_LAGRANGE=2 } large_def;             

     double           get_var(STRING wht, GNODE* node); 
     double           evaluate_integral(); 

     void  setup(MESH&);
  public :
     J_INTEGRAL();
     virtual void initialize(DATA_TEST*,ASCII_FILE&);
     ~J_INTEGRAL(); 
     void  write_test(MESH&);
     void  write_test_plot(MESH&);

     void calc_ddisp_dx(PATH_ELEMENT* path, 
                        MATRIX& ddisp_dx ); 
     RTTI_INFO;
};
Z_END_NAMESPACE;
#endif

