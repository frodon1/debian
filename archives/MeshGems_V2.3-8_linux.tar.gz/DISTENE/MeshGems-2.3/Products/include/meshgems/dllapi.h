#ifndef __MESHGEMS_DLLAPI_H__
#define __MESHGEMS_DLLAPI_H__

#include <windows.h>

#define MESHGEMS_DLL

#include <meshgems/meshgems.h>

#endif
