#include <Remeshing_criterion.h>
#include <Stringpp.h>
#include <Discrete_timer.h>
#include <Print.h>

Z_START_NAMESPACE;

class REMESH_WHEN_ASKED : public REMESHING_CRITERION
{
  protected :
  STRING filename;
    
  public :
  REMESH_WHEN_ASKED() : REMESHING_CRITERION() { filename="";}
    virtual ~REMESH_WHEN_ASKED() { }
    virtual bool GetResponse(STRING &key, ASCII_FILE &inp);
    virtual bool time_for_remesh(const MESH&);
};

Z_END_NAMESPACE;
