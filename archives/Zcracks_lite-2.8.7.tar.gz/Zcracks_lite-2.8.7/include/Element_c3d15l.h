#ifndef __C3D15_L_UTILITY_ELEMENT__
#define __C3D15_L_UTILITY_ELEMENT__

#include <Array.h>
#include <Object_factory.h>
#include <Utility_boundary.h>
#include <Utility_elements.h>
#include <Std_utility_element.h>
#include <GeomSpace.h>
#include <Graphics_area.h>
#include <Graphics_face.h>
#include <Graphics_view_manager.h>
#include <Integration_point_computer.h>

Z_START_NAMESPACE;

//
// A c3d15 element, but layered
//

class NON_LOCAL_LAYERED_GEOM_INFO;

class C3D15_L_UTILITY_ELEMENT : public C3D15_UTILITY_ELEMENT 
{
  protected :
    int active_layer,nb_layer,nb_gauss_layer,nb_gp_tot;
    int nb_surface_gauss;
    bool g_faces_inited;
    NON_LOCAL_LAYERED_GEOM_INFO *its_info;

 public :
    C3D15_L_UTILITY_ELEMENT() : C3D15_UTILITY_ELEMENT() { space_dim=3; g_faces_inited=FALSE; its_info=NULL; }
    C3D15_L_UTILITY_ELEMENT(const C3D15_L_UTILITY_ELEMENT& in) : C3D15_UTILITY_ELEMENT(in) {num_gp=0;active_layer=nb_layer=nb_gauss_layer=nb_gp_tot=-1;g_faces_inited=FALSE;}
    virtual ~C3D15_L_UTILITY_ELEMENT() {active_layer=-1;}

    virtual void set_integ(VECTOR&,int&);
    virtual bool do_command(STRING);
    virtual void run_face_setup(int force_setup=0);
    virtual void run_face_setup_disp(const ARRAY<VECTOR>& disp,double mag);
    bool set_info();
    virtual ARRAY<UTILITY_BOUNDARY>& get_faces();

    // not implemented in the first version but i have a seg fault so ...
    virtual void initialize(const STRING& t) { C3D15_UTILITY_ELEMENT::initialize(t);nodes.resize(15);num_gp=0;active_layer=nb_layer=nb_gauss_layer=nb_gp_tot=-1;}
    void* operator new(size_t t) { return(::new char[t]); }
    void  operator delete(void* oo) { delete[]((char*)oo); }
    virtual UTILITY_ELEMENT* copy_to_linear(ARRAY<UTILITY_NODE*>& /* rem */){return new C3D15_L_UTILITY_ELEMENT(*this);
}
    virtual void invert_element(int /* axe_number */){NOT_IMPLEMENTED_ERROR("C3D16_L_UTILITY_ELEMENT::invert_element()");}
    virtual void build_gp_position();
};

Z_END_NAMESPACE;

#endif
