#ifndef __Thermal_cavity_radiation__
#define __Thermal_cavity_radiation__

// ----------------------------------------------------------------------------
// Thermal_cavity_radiation.h                                 RF Dec 19, 2006
//
// See .c file for more comments. 
// ----------------------------------------------------------------------------

#include <Pointer.h>
#include <File.h>

#include <Utility_simple_intersection.h>

#include <Problem.h>
#include <Problem_component.h>

#include <Thermal_mesh.h>
#include <Behavior.h>

#include <Sparse_matrix.h>

Z_START_NAMESPACE;


// ------------------------------------------------------------
//  behavior for the emmisivity. Mainly just so that the coefficient
//  mechanisms can be used.
// ------------------------------------------------------------
ZCLASS2 EMISSIVITY_BEHAVIOR : public BEHAVIOR {
  protected :
      SCALAR_GRAD T;
      SCALAR_FLUX epsilon;

      COEFF  coef;

  public:
      EMISSIVITY_BEHAVIOR();
      virtual void initialize(ASCII_FILE&,int,LOCAL_INTEGRATION*);

      virtual INTEGRATION_RESULT* integrate(MATERIAL_INTEGRATION_INFO&);
};

// ------------------------------------------------------------
//  A big element w/o geometry in order to establish the connections
// ------------------------------------------------------------
class BC_RAD_MIRROR; 

ZCLASS2 BC_RAD_ELEMENT : public D_ELEMENT {
  protected: 
    STRING   dump_res; 
    void     dump_from_results();

    void dump_faces(); 

    void calc_reac_u(bool ics,
                     VECTOR& resi,
                     SMATRIX& stiff, 
                     VECTOR elem_U,
                     VECTOR elem_U_ini); 

  public :
    int      skip_ambient;
    int      finite_difference;
    int      norm_view_factor;
    ARRAY<int> global_to_local_nrank; 
    double   sigma; 
    double   abs_zero; 
    double   ambient_temp; 
    enum TSCALE { 
        CELCIUS, 
        KELVIN, 
        DEG_F
    }; 
    TSCALE use_tscale; 
 
    SMATRIX F;
    SPARSE_MATRIX Fsparse;

    LIST<STRING> bset_name;
    PROBLEM* boss; 

    class FACE_DEF {
      public:
         int      rank; 
         double   A;
         VECTOR   C; 
         VECTOR   normal; 
         BOUNDARY* face;
         double   sum;
 
         MARRAY<VECTOR> pts; 

         void reset(); 
         FACE_DEF& operator=(const FACE_DEF& in); 
    };
    PTR<EMISSIVITY_BEHAVIOR> behavior;

    BUFF_LIST<FACE_DEF*> faces;
    BUFF_LIST<FACE_DEF*> mirrored_faces;
    BUFF_LIST<FACE_DEF*> total_faces;

    BC_RAD_MIRROR*  mirror; 

    bool face_visible(int i, int j);

    BC_RAD_ELEMENT();
    virtual ~BC_RAD_ELEMENT();

    virtual void initialize(ASCII_FILE& file, PROBLEM* pb);
    virtual bool base_read(STRING& str, ASCII_FILE& file);

    virtual void configure_rad(MESH& mesh);
    virtual void setup_dofs(const char* key);

    virtual INTEGRATION_RESULT* internal_reaction(bool ics,
                                 VECTOR& resi, 
                                 SMATRIX& stiff,
                                 bool check);

};

// ------------------------------------------------------------
//  For symmetry conditions 
// ------------------------------------------------------------
ZCLASS2 BC_RAD_MIRROR { 
   public:
      BC_RAD_MIRROR(); 
      virtual ~BC_RAD_MIRROR(); 
      virtual void initialize(ASCII_FILE& file); 

      virtual void do_mirror(BUFF_LIST<BC_RAD_ELEMENT::FACE_DEF*>& mirrored_faces,
                             BUFF_LIST<BC_RAD_ELEMENT::FACE_DEF*>& original_faces); 
};

ZCLASS2 BC_RAD_3D_PERIODIC : public BC_RAD_MIRROR {
   public:
      VECTOR   a,b,c;
      MARRAY<VECTOR>   dx; 
      int num; 

      BC_RAD_3D_PERIODIC();
      virtual ~BC_RAD_3D_PERIODIC();
      virtual void initialize(ASCII_FILE& file);

      virtual void do_mirror(BUFF_LIST<BC_RAD_ELEMENT::FACE_DEF*>& mirrored_faces,
                             BUFF_LIST<BC_RAD_ELEMENT::FACE_DEF*>& original_faces);
};


// ------------------------------------------------------------
//  The problem component which loads the elements
// ------------------------------------------------------------

class BC_RAD_PROBLEM_COMPONENT : public PROBLEM_COMPONENT {
  protected :
     LIST<BC_RAD_ELEMENT*>  rad_elem;

     enum UNIT_T {
         KELVIN,
         CELCIUS
     };
     UNIT_T    unit_t;

     BOUNDARYSET* the_boundary;
     double       radiation_coefficient;

  public :
     BC_RAD_PROBLEM_COMPONENT();
     virtual ~BC_RAD_PROBLEM_COMPONENT();

     virtual bool initialize() { return true; }
     virtual void load(ASCII_FILE& inp_file, PROBLEM* boss);
     virtual void pre_create_dof();

     virtual bool is_first_round() { return TRUE; }

     virtual bool verification();
};

Z_END_NAMESPACE;

#endif 
