#ifndef __Z_PROGRAM__
#define __Z_PROGRAM__

#include <ZP_base_piece.h>
#include <Defines.h>
#include <Auto_ptr.h>

Z_START_NAMESPACE;

class ZP_PROC;
class ZP_ENUMERATION;
class ZP_PROC_DECL;
class ZP_DECL;
class ZP_CLASS;
class ZP_PROGRAM_ITEM_LIST;
class P_LEXER;
class ZP_PIECE_STATEMENT;

ZCLASS ZP_PROGRAM_ITEM : public ZP_PIECE {
  public :
    ZP_PROGRAM_ITEM() : ZP_PIECE() { }
    virtual ~ZP_PROGRAM_ITEM() { }

    virtual void link_stage_1(AUTO_PTR<ZP_PIECE>) {
         STRING msg = "No link method defined for type : "+STRING(__type()); 
         ERROR(msg);
    }
    virtual void link_stage_2(P_LEXER*) {
         STRING msg = "No link method defined for type : "+STRING(__type()); 
         ERROR(msg); 
    }
    CAST(ZP_PROGRAM_ITEM);
    RTTI_INFO;
};

ZCLASS ZP_PROGRAM_ITEM_LIST : public ZP_PIECE {
  public :
    LIST< AUTO_PTR<ZP_PIECE> > items;

    ZP_PROGRAM_ITEM_LIST() : ZP_PIECE() { }
    virtual ~ZP_PROGRAM_ITEM_LIST();

    void add( AUTO_PTR<ZP_PIECE> i) { items.add(i); children.add(i); }
    virtual void print(int &b) { for(int i=0;i<!items;i++) items[i]->print(b); }

    LIST< AUTO_PTR<ZP_PIECE> > find_proc(STRING &n, STRING &ns=(STRING&)STRING::EMPTY);
    ZP_CLASS* find_class(STRING&);
    CAST(ZP_PROGRAM_ITEM_LIST);
    RTTI_INFO;
};

ZCLASS ZP_PROGRAM_ITEM_PROC : public ZP_PROGRAM_ITEM {
  public :
    AUTO_PTR<ZP_PIECE> proc;

    ZP_PROGRAM_ITEM_PROC() : ZP_PROGRAM_ITEM() { }
    virtual ~ZP_PROGRAM_ITEM_PROC();

    virtual void print(int &b);
    virtual void link_stage_1(AUTO_PTR<ZP_PIECE>) { }
    virtual void link_stage_2(P_LEXER*) { }
    CAST(ZP_PROGRAM_ITEM_PROC);
    RTTI_INFO;
};

ZCLASS ZP_PROGRAM_ITEM_STATEMENT : public ZP_PROGRAM_ITEM {
  public :
    AUTO_PTR<ZP_PIECE> statement;

    ZP_PROGRAM_ITEM_STATEMENT() : ZP_PROGRAM_ITEM() { }
    virtual ~ZP_PROGRAM_ITEM_STATEMENT();

    virtual void print(int &b);
    virtual void link_stage_1(AUTO_PTR<ZP_PIECE>) { }
    virtual void link_stage_2(P_LEXER*) { }
    CAST(ZP_PROGRAM_ITEM_STATEMENT);
    RTTI_INFO;
};

class ZP_CLASS_DESCRIPTION;

ZCLASS ZP_PROGRAM_ITEM_ENUM : public ZP_PROGRAM_ITEM {
  public :
    AUTO_PTR<ZP_PIECE> zenum;
    AUTO_PTR<ZP_PIECE> class_description;

    ZP_PROGRAM_ITEM_ENUM() : ZP_PROGRAM_ITEM() { }
    virtual ~ZP_PROGRAM_ITEM_ENUM();

    virtual void print(int &b);
    virtual void link_stage_1(AUTO_PTR<ZP_PIECE>);
    virtual void link_stage_2(P_LEXER*);
    CAST(ZP_PROGRAM_ITEM_ENUM);
    RTTI_INFO;
};

ZCLASS ZP_PROGRAM_ITEM_DECL : public ZP_PROGRAM_ITEM {
  public :
    AUTO_PTR<ZP_PIECE> decl;

    ZP_PROGRAM_ITEM_DECL() : ZP_PROGRAM_ITEM() { }
    virtual ~ZP_PROGRAM_ITEM_DECL();

    virtual void print(int &b);
    virtual void link_stage_1(AUTO_PTR<ZP_PIECE>) { }
    virtual void link_stage_2(P_LEXER*) { }
    CAST(ZP_PROGRAM_ITEM_DECL);
    RTTI_INFO;
};

ZCLASS ZP_PROGRAM_ITEM_PROC_DECL : public ZP_PROGRAM_ITEM {
  public :
    AUTO_PTR<ZP_PIECE> decl;

    ZP_PROGRAM_ITEM_PROC_DECL() : ZP_PROGRAM_ITEM() { }
    virtual ~ZP_PROGRAM_ITEM_PROC_DECL();

    virtual void print(int &b);
    virtual void link_stage_1(AUTO_PTR<ZP_PIECE>) { }
    virtual void link_stage_2(P_LEXER*) { }
    CAST(ZP_PROGRAM_ITEM_PROC_DECL);
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
