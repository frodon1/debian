#ifndef __Sorted_list__
#define __Sorted_list__

#include <Defines.h>
#include <Buffered_list.h>
#include <Error_messager.h>

Z_START_NAMESPACE;

//
// a sorted LIST by increasing items, with dichotomy search.
//
template <class T> ZCLASSt SORTED_LIST : public BUFF_LIST<T> {
   public :
     enum SORTED_LIST_MODE { 
         ADD_ALL, 
         WEIRDO
     };
     SORTED_LIST_MODE  mode; 

     SORTED_LIST(): BUFF_LIST<T>(), mode(WEIRDO) { }
     SORTED_LIST(int bsz): BUFF_LIST<T>(bsz), mode(WEIRDO) { }

     SORTED_LIST(const ARRAY<T>&);
     SORTED_LIST(const SORTED_LIST<T>&);

     virtual ~SORTED_LIST();

     bool is_in(const T& t)const;
     bool is_in(const T& t, int& rk)const;

     virtual int  count_occurrence(const T& t)const;
     virtual int  first_occurrence(const T& t) const;
     virtual void unique();
     
     using BUFF_LIST<T>::add;
     virtual T& add(const T& t);
     virtual T& add(const T& t, int& index_added);
     virtual T& add_at(int,const T&);

     virtual void add_if_not_in(const T& xx);
     virtual void add_if_not_in(const ARRAY<T>& xx);
};

template <class T> INLINE SORTED_LIST<T>::SORTED_LIST(const ARRAY<T>& a) : BUFF_LIST<T>(), mode(WEIRDO)
{
  for(int i=0;i<a.size();i++) add(a[i]);
}

template <class T> INLINE SORTED_LIST<T>::SORTED_LIST(const SORTED_LIST<T>& a) : BUFF_LIST<T>(), mode(a.mode)
{
  this->resize( a.size() );
  for(int i=0;i<a.size();i++) this->x[i]=a[i];
}

template <class T> INLINE SORTED_LIST<T>::~SORTED_LIST() { }          

template <class T> INLINE bool SORTED_LIST<T>::is_in(const T& item) const 
{
  int rank;
  return is_in(item,rank);
}

template <class T> INLINE bool SORTED_LIST<T>::is_in(const T& t,int& rank) const 
{ 
  if(this->sz==0) return FALSE; 
  int beg=0; int end=this->sz-1;
  if(this->x[beg]==t) { rank=beg; return TRUE; }
  if(this->x[end]==t) { rank=end; return TRUE; }
  for(;;) {
    rank=beg+(end-beg)/2;
    if(rank==beg) break;
    if(this->x[rank]==t) return TRUE;
    else if(this->x[rank]>t) end=rank;
    else beg=rank;
  } 
  return FALSE;
}

template <class T> INLINE void SORTED_LIST<T>::add_if_not_in(const T& t)
{ 
  // Optimisation w.r. to the buff_list implementation, 
  // because we already know where insertion should be 
  if(this->sz==0) { 
    this->add(t); 
    return; 
  }
  int beg=0; 
  int end=this->sz-1;
  int mid;

  if (t < this->x[beg]) { add_at(beg,t) ; return ; } 
  if (t > this->x[end]) { BUFF_LIST<T>::add(t) ; return ; }

  for (;;) {
    mid = beg+(end-beg)/2;
    if (t == this->x[mid]) return; 
    if (beg==end)  { add_at(beg+1,t) ; return ; }

    if (t < this->x[mid]) {
      end=mid; 
    }
    else if (t > this->x[mid]) {
      if (beg!=mid) beg=mid; 
      else { // special care needed when beg+1==end
	if (t==this->x[end]) return; 
	else { add_at(beg+1,t) ; return ; }
      }
    }
    else { return ; }  // found the item, don't add it
  }
}

template <class T> INLINE void SORTED_LIST<T>::add_if_not_in(const ARRAY<T>& xx)
{
  // IMPROVEME: sort xx before adding
  for(int i=0;i<xx.size();i++) {
    this->add_if_not_in(xx[i]); 
  }
}


template <class T> INLINE int SORTED_LIST<T>::count_occurrence(const T&) const
{
  return 1;
}
  
template <class T> INLINE int SORTED_LIST<T>::first_occurrence(const T& item) const
{ 
  int res=-1;
  is_in(item,res);
  return res;
}

#if defined SUNCC5 || defined SOLARIS
#undef INLINE  
#define INLINE 
#endif 

template <class T> INLINE T& SORTED_LIST<T>::add(const T& item_in)
{  int idx=0; 
   return add(item_in,idx); 
}

template <class T> INLINE T& SORTED_LIST<T>::add(const T& item_in, int& rank)
{ int i;
#ifdef ZCHECK 
  rank = -1; 
#endif
  if (this->sz==0) {
      rank = 0;
      BUFF_LIST<T>::add(item_in); 
  }
  else {
      if (this->x[0]>item_in) {
          rank=0;
      }
      else if (this->x[this->sz-1]<item_in) { 
          rank=this->sz;
      }
      else {
          int beg=0;
          int end=this->sz-1; 
          int add;
          // 
          // RF 08/04/2005 added the mode switch here. It was not at all what 
          // I expected.. That behavior should be in add_if_not_in or something
          // 
          if (mode==ADD_ALL) { 
              if (this->x[beg]==item_in) { 
                  rank = beg; 
              }
              else if (this->x[end]==item_in) {
                  rank = end; 
              }
              else { 
                  for (;;) {
                      add=(end-beg)/2;
                      if (add==0) { rank=end; break; }
                      rank=beg+add;
                      if (this->x[rank]==item_in) { 
                          break; 
                      }
                      else if (this->x[rank]<item_in) beg=rank;
                      else end=rank;
                  }
              }
          }
          else {
              if((this->x[beg]==item_in)||(this->x[end]==item_in)) return this->x[end];
              for(;;) {
                add=(end-beg)/2; if(add==0) { rank=end; break; }
                rank=beg+add;
                if(this->x[rank]==item_in) return this->x[rank];
                else if(this->x[rank]<item_in) beg=rank;
                else end=rank;
              }
          }
      }

      if (this->sz >= this->tot_sz) {
          this->tot_sz = this->estimate_buffer_size(this->sz+1);
          T* t=new T [this->tot_sz];
          int j=0;
          for (i=0;i<rank;i++) t[i]=this->x[j++];
          t[rank]=item_in;
          for (i=rank+1;i<=this->sz;i++) t[i]=this->x[j++];
          delete[] this->x;
          this->x=t; this->sz++;
      }
      else {
          for(i=this->sz;i>rank;i--) this->x[i]=this->x[i-1];
          this->x[rank]=item_in; this->sz++;
      }
  }

  // 
  // Changed RF 08/04/2005 
  // 
  return this->x[rank]; 
}

template <class T> INLINE T& SORTED_LIST<T>::add_at(int rank,const T& xx)
{
  /// Insert item at the given position (rank).
  /// Use instead of add() if you already know the correct insertion position (avoids a dichotomy).
  /// Raises an error if it unsorts the list (verification is only made in debug mode)
  if (rank<0) rank=0; 
  if (rank>this->sz) rank=this->sz; 
  int end = this->sz;
  if (end==0) {
      rank = 0; 
      BUFF_LIST<T>::add(xx); 
  }
  else { 
      BUFF_LIST<T>::add(this->x[end-1]); 
      if (end>1) { 
          for (int i=end-1;i>rank;i--) { 
               this->x[i] = this->x[i-1]; 
          } 
      } 
      this->x[rank] = xx; 
  }
#ifdef ZCHECK
  if (rank==0) {
    if ((this->sz>1) && (this->x[0] > this->x[1])) ERROR ("SORTED_LIST::add_at() was called with invalid rank: it has unsorted the list");
  }
  else if (rank==end) {
      if ((this->sz>1) && (this->x[end-1] > this->x[end])) ERROR ("SORTED_LIST::add_at() was called with invalid rank: it has unsorted the list");
  }
  else {
    if ((this->x[rank-1] > this->x[rank]) || (this->x[rank] > this->x[rank+1])) ERROR ("SORTED_LIST::add_at() was called with invalid rank: it has unsorted the list");
  }
#endif 
  return this->x[rank]; 
}

template <class T> INLINE void SORTED_LIST<T>::unique()
{
  // much faster than the CARRAY one
  SORTED_LIST& me = *this;
  for (int i=0; i<me.size()-1; i++) {
    if (me[i+1] == me[i])
      me.suppress(i+1);
  }
}

Z_END_NAMESPACE;

#endif
