#ifndef __GMesh__
#define __GMesh__

// ============================================================================ 
//  GMESH  is cleaned up to remove the costly dictionary templates, and use
//         the utility mesh in place of file mesh. 
//
//  * I absolutely fail to see the purpose of having element, node, elset, etc
//    protected, while there are all those interface functions.  
// ============================================================================ 

#include <ZMath.h>
#include <Auto_ptr.h>
#include <Zset_callback.h>
#include <Stringpp.h>
#include <Buffered_list.h>
#include <File.h>

#include <Boundary.h>
#include <Dictionnary.h>
#include <Element.h>
#include <Geometry.h>
#include <Geometrical_element.h>
#include <G_F_sub_domains.h>
#include <GeomSpace.h>
#include <Integration.h>
#include <Geometry_info.h>
#include <Z_object.h>
#include <Parallel_set.h>
#include <Utility_connections.h>
#include <Message_passing_exchange.h>

Z_START_NAMESPACE;

class ELEMENT;
class NODE;
class GEOMETRICAL_MESH;
class G_F_SUB_DOMAINS;

class UTILITY_MESH; 
class UTILITY_ELSET; 
class ZSET_CALLBACK;

// a utility class used to dynamically link elements to meshes

// typedef ELEMENT* (*element_maker)(GEOMETRY*,GMESH*,int,ARRAY<GNODE*>&);
typedef ELEMENT* (*element_maker)(); 

ZCLASS2 ELEMENT_TO_MESH_LINKER {
   friend class GMESH;
  public :
      ELEMENT_TO_MESH_LINKER(const char*,const char*,GEOM_TYPE,SPACE_TYPE,element_maker);
};

#define INSTALL_ELEMENT(mesh,key,gt,st,name) \
\
static ELEMENT* mesh##key##gt##st##name##fk ()\
{ name * ret = new name ; \
  return ret; \
} \
static ELEMENT_TO_MESH_LINKER mesh##key##gt##st##name##kw(#mesh,#key,gt,st,mesh##key##gt##st##name##fk);


ZCLASS2 GMESH : public Z_OBJECT {
    protected :
      _ZSYSCLOCK _creation_date;
      UTILITY_CONNECTION mesh_connection;
      ZSET_CALLBACK *zset_callback;

      virtual NSET* build_nset(const STRING& name_in,const CARRAY<GNODE*>& node,int dim);
      virtual ELSET* build_elset(const STRING& name_in,const CARRAY<ELEMENT*>& elem,int dim);
      virtual BOUNDARYSET* build_bset(const STRING& name_in, CARRAY<BOUNDARY*> &bound, int dim);

      // temporary infos to be used by derived classes, will be removed when needed
      ARRAY<int> n_global_ranks,n_local_ranks,n_space_dim,n_global_ids;

      virtual void end_of_read();
      virtual void unpack_extra_node_infos(MP_EXCHANGE&,int); 
      virtual void pack_extra_node_infos(MP_EXCHANGE&);

    public : 
        UTILITY_MESH    *zmesh; 
        int              _Is_parallel_computation;
        const int        &mesh_pgm;
        bool             allow_set_auto_creation; // true (default) to allow certain set auto creation (eg ALL_ELEMENT, ALL_NODE,...)
        STRING           meshfile;
        PTR<G_F_SUB_DOMAINS>  domain;
        PTR<G_F_SUB_DOMAINS>  mandatory_domain;

        LIST<GNODE*>     node;  
        LIST<ELEMENT*>   element; 
    
        LIST<NSET*>               nset;
        LIST<ELSET*>              elset;
        LIST<BOUNDARYSET*>        boundaryset;
        LIST<IPSET*>              ipset;

        // 
        // The indexes no longer include a +1 .. they are the 
        // real element index as was arranged by the utility mesh
        // 
        PLIST< LIST<int> >        pelset;
        LIST<STRING>              pelset_name;
        LIST<STRING>              pelset_type;
        LIST<GEOMETRY_INFO*>      pelset_gi;
        ARRAY<ELSET*>             elem_to_pelset;

        // 
        // Material or other local frames... These can be defined by name 
        // in the geof file.. duplicated from utility mesh. 
        // 
        // ** the ele_lf should be coupled automatically to the material 
        //    orientation. 
        // ** Bunch all these things up into a mesh-local-frame-manager class
        //    rather than a bunch of seperate lists. (Note RF.. didn't have time now).
        // 
        LIST<STRING>              local_frame_names; 
        LIST<LOCAL_FRAME*>        local_frames; 
        LIST<LOCAL_FRAME*>        ele_lf;
        LIST<int>                 ele_lf_index; // rank of local_frames for each element
        LOCAL_FRAME*              get_local_frame_for_element(int ele_rank, int gp_rank);
        LOCAL_FRAME*              get_local_frame(STRING name);

        bool changed(_ZSYSCLOCK zs) { return(zs!=_creation_date); }
        _ZSYSCLOCK creation_date() { return(_creation_date); }

        void      prepare_element_type(const CARRAY<STRING>&,
                                       const ARRAY<STRING>&,
                                       ARRAY<GEOMETRY_INFO*>*,
                                       UTILITY_MESH&);

        GEOMETRY_INFO* get_element_geom_info(int id);
        STRING    get_element_type(int id);
        void      read(const STRING&,const STRING&,UTILITY_MESH&);
        void      initialize_elem_pelset(const CARRAY<STRING>& elset_name);
        void      make_geom(UTILITY_MESH&);
        void      make_group(UTILITY_MESH&);
        void      make_section(const STRING&,UTILITY_MESH&);
        void      parallel_make_geom(UTILITY_MESH&);
        void      parallel_make_group(UTILITY_MESH&);
        void      parallel_make_section(const STRING&,UTILITY_MESH&);
        void      write_predefined_mesh(ASCII_FILE&);
        virtual G_F_SUB_DOMAINS* create_sub_domain(UTILITY_MESH&,const STRING&,int,int rcf=1);

        element_maker look_for( const STRING &type , const STRING &mesh_name , GEOM_TYPE the_gt , SPACE_TYPE the_st);

        virtual GNODE* make_node(int,const VECTOR&);

        static LIST<STRING> Element_Type;
        const int &Is_parallel_computation;

        LIST<STRING>              section_name; 
        LIST<GEOMETRICAL_MESH*>   section_mesh;

        GMESH();
        virtual ~GMESH();

        virtual ZSET_CALLBACK* get_callback();
        virtual void set_callback(ZSET_CALLBACK *cb);

        virtual void build(const STRING&         problem_name, 
                           UTILITY_MESH         *u_mesh,
                           const CARRAY<STRING>& elset_name,
                           const ARRAY<STRING>&  elset_type,
                           LIST<GEOMETRY_INFO*>  *ginfo=NULL);

        virtual void build(const STRING&         problem_name, 
                           const STRING&         geof_file_name,
                           const CARRAY<STRING>& elset_name,
                           const ARRAY<STRING>&  elset_type,
                           LIST<GEOMETRY_INFO*>  *ginfo=NULL);

        virtual bool verification();

        ELEMENT* create_element(const STRING& geom, const STRING& type,
                                GEOMETRY_INFO*,int elem_id, ARRAY<GNODE*>& elem_node,
                                const ARRAY<double>& ,
                                BUFF_LIST<UTILITY_ELSET*>&);
        ELEMENT* create_element_ext(const STRING& geom, const STRING& type,
                                GEOMETRY_INFO*,int elem_id, ARRAY<GNODE*>& elem_node,
                                const ARRAY<double>& ,
                                BUFF_LIST<UTILITY_ELSET*>&,int,int);

        void enable_parallel_computation() { _Is_parallel_computation=1; }

        const G_F_SUB_DOMAINS* get_domain()const { return( ((GMESH*)this)->domain()); }
              G_F_SUB_DOMAINS* get_domain()      { return(domain()); }

        // 
        // Nodes and elements making up the mesh
        // 
        int           nb_node()const { return !node; }
              GNODE*  get_node(int i)      { return node[i]; }
        const GNODE*  get_node(int i)const { return node[i]; }
              GNODE*  find_node(int,bool issue_error=FALSE);
        const GNODE*  find_node(int,bool issue_error=FALSE)const;

        int nb_elem()const { return !element; }
              ELEMENT* get_element(int i)      { return(element[i]); }
        const ELEMENT* get_element(int i)const { return(element[i]); }
              ELEMENT* find_element(int,bool issue_error=FALSE);
        const ELEMENT* find_element(int,bool issue_error=FALSE)const;


        // 
        // Node set utility/access 
        // 
        int           nb_nset()const       { return !nset; }
        void          add_nset(NSET*  n)   { nset.add(n); }
        NSET*         find_nset(const STRING& group_name,bool issue_error=TRUE);
        NSET*         find_nset(const GNODE*);
        const NSET*   find_nset(const GNODE*)const;
        NSET*         get_nset(int i)      { return nset[i]; }
        const NSET*   get_nset(int i)const { return ((GMESH*)this)->nset[i]; }

        // 
        // Element set utility/access
        // 
        int           nb_elset()const      { return !elset; }
        void          add_elset(ELSET*  e) { elset.add(e); }
        ELSET*        find_elset(const STRING& group_name,bool issue_error=TRUE);
        const ELSET*  find_elset(const STRING& group_name,bool issue_error=TRUE) const;
        ELSET*        find_elset(const ELEMENT*);
        const ELSET*  find_elset(const ELEMENT*)const;
        ELSET*        get_elset(int i) { return elset[i]; }
        const  ELSET* get_elset(int i)const { return ((GMESH*)this)->elset[i]; }
        ELSET*        find_elset_in_pelset(const ELEMENT*);

        // 
        // Integration point sets 
        // 
        int           nb_ipset()const { return !ipset; }
        IPSET*        find_ipset(const STRING&,bool issue_error=TRUE);
        IPSET*        get_ipset(int i) { return ipset[i]; }
        const IPSET*  get_ipset(int i)const  { return ((GMESH*)this)->ipset[i]; }

        // 
        // Boundary sets can be integrated... liset/faset
        // 
        int           nb_boundaryset()const { return !boundaryset; }
        void          add_boundaryset(BOUNDARYSET* b) { boundaryset.add(b); }
        BOUNDARYSET*  find_boundaryset(const STRING& group_name,bool issue_error=TRUE);
        BOUNDARYSET*  find_boundaryset(const BOUNDARY*);
        BOUNDARYSET*  get_boundaryset(int i) { return boundaryset[i]; }
        const BOUNDARYSET* get_boundaryset(int i)const { return ((GMESH*)this)->boundaryset[i]; }

        // 
        // These are brute search methods.. the utility mesh has all this 
        // information set up however. 
        // 
        void           connect_node_to_elem();

        LIST<const ELEMENT*> element_it_belongs_to(const ARRAY<GNODE*>&)const;
        LIST<ELEMENT*>       element_it_belongs_to(const ARRAY<GNODE*>&);

//      SQ: added those 04/24/02 to speed up bset creation
        LIST<const ELEMENT*> element_it_belongs_to(const ARRAY<GNODE*>&,UTILITY_MESH&)const;
        LIST<ELEMENT*>       element_it_belongs_to(const ARRAY<GNODE*>&,UTILITY_MESH&);

        void           all_elements_it_belongs_to(const ARRAY<GNODE*>&,LIST<ELEMENT*>&);

        const STRING&  get_mesh_name() { return meshfile; }
        int            max_dimension()const; 
        void           set_mesh_name(const STRING &s) { meshfile=s; }
        int            get_next_elem_id()const ;
        int            get_next_node_id()const ;

        // 
        // This method allows one (a mesh command in pb) to add section 
        // meshes to the problem without files... the section_mesh is a complete 
        // mesh of the section... duplicates build except for readign the files. 
        // 
        void    add_section(STRING elset_name, UTILITY_MESH& section_mesh);
        virtual void reset();

        RTTI_INFO;
};

ZCLASS2 GEOMETRICAL_MESH : public GMESH {
    int _nb_gp;
  public :
    GEOMETRICAL_MESH();
    virtual ~GEOMETRICAL_MESH();
    int nb_gp()const;
    GEOMETRICAL_ELEMENT* get_elem(int i)
             { return (GEOMETRICAL_ELEMENT*)GMESH::get_element(i); }
    const GEOMETRICAL_ELEMENT* get_elem(int i)const
             { return (GEOMETRICAL_ELEMENT*)GMESH::get_element(i); }

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
