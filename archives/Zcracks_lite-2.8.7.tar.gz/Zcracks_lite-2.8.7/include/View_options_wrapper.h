#ifndef __VIEW_OPTIONS_WRAPPER__
#define __VIEW_OPTIONS_WRAPPER__

#include <Stringpp.h>
#include <Vector.h>

Z_START_NAMESPACE;

class VIEW_OPTIONS_WRAPPER
{
  protected :
    STRING base;

  public :
    VIEW_OPTIONS_WRAPPER();
    virtual ~VIEW_OPTIONS_WRAPPER();

    void set_view_elsets( LIST<STRING>&);
    void set_hidden_fasets( LIST<STRING>&);
    void set_axes();
    void set_noaxes();
    void set_lisets();
    void set_nolisets();
};
Z_END_NAMESPACE;

#endif
