#ifndef __Problem_component__
#define __Problem_component__
// ============================================================================ 
//   PROBLEM_COMPONENT   A very abstract class for inserting little brickolage
//                       items into the problem.  RF Apr 29 2000 
//
//   I am putting this into 8.0 in order to widen the possiblity of deep plug-in 
//   implementations. 
// 
//   many of the hooks into this are done in the base algorithm when conv. etc 
//   is checked
// ============================================================================ 

#include <Defines.h> 
#include <File.h> 
#include <Ask.h>
#include <Z_object.h>
#include <Base_restart_defines.h>
#include <Zset_callback.h>
#include <Mesh.h>

Z_START_NAMESPACE;

class PROBLEM; 
class INTEGRATION_RESULT;
class GLOBAL_MATRIX;
class OUTPUT_CONTROL;
class MESH;

ZCLASS2 PROBLEM_COMPONENT  : public ZSET_CALLBACK { 
  public : 
    STRING name;
    bool dont_care_name,mandatory;
//
// Meaning of dont_care_name : set it to TRUE if your PROBLEM_COMPONENT requires input like :
//   ***my_pb_component option1 option2 (ie options declared directly without stars)
// Instead of the legacy ZSet input style :
//   ***my_pb_component **option1 **option2 (ie options declared with stars)
//
    PROBLEM* its_boss; 
    PROBLEM_COMPONENT(); 
    virtual ~PROBLEM_COMPONENT(); 
 
    // 
    // The base class initialize does a loop using start_key/next_key
    // and sending each key to GetResponse, so in general that is 
    // the function to re-define. It is however not required. 
    // 
    virtual void load(ASCII_FILE& inp_file, PROBLEM* boss)=0; 

    // as expected, the initialize() method is called **after** the component has been
    // properly loaded from a file (using the wrongly named initialize(...) method)
    // a component can delay its Initialization by returning false, in which case the master problem
    // will call it again later. By default, it returns true which means 'Initialization successfull'
    virtual bool initialize()=0; //  { return(true); }
     
    // 
    // Some standard locations and tasks 
    // 
    virtual void activate(); // called for mandatory PROBLEM_COMPONENT right after creation
    virtual bool verification(); 

    virtual void pre_create_dof(); 
    virtual void before_mesh_build(); 
    virtual void after_mesh_setup(); 
    virtual void before_material(); 
    virtual void after_material(); 
    virtual void read_restart_phase_1(RST_FSTREAM& obin); 
    virtual void write_restart_phase_1(RST_FSTREAM& rep); 
    virtual void read_restart(RST_FSTREAM& obin); 
    virtual void write_restart(RST_FSTREAM& rep); 
    virtual bool needs_restart() { return(true); }

    virtual void init_problem();
    virtual void make_increment(double);
    virtual void start_increment();
    virtual void end_increment(INTEGRATION_RESULT*&);

    virtual void start_iteration();
    virtual void start_fictious_iteration(bool &if_compute_stiffness);
    virtual void if_accuracy(VECTOR &residual, VECTOR &dof, MESH &mesh);
    virtual void end_iteration();
    virtual bool end_iteration_converge();
    virtual void end_fictious_iteration(bool &efi);
    virtual void pre_manage_restart();
    virtual void manage_restart();
    virtual void post_manage_restart();
    virtual bool apply_bc(GLOBAL_MATRIX*&);
    virtual bool set_relationship(GLOBAL_MATRIX*&);
    virtual bool has_relationship();

    virtual void mesh_will_change();
    virtual void mesh_changed();
    virtual void mesh_changed_after_transfer();
    virtual void clean_after_remesh();
    virtual OUTPUT_CONTROL* get_remesh_frequency() { return(NULL); }
    virtual void reinit();
    virtual void reset();
    virtual bool output_data() { return(TRUE); }

    virtual void end_problem();
    virtual void end_of_zset();

    // 
    // These are called by algorithm
    // 
    virtual void message_1(); 
    virtual void message_2(); 
    virtual void message_3(); 

    virtual bool is_first_round() { return FALSE; } 

    virtual bool uses_sub_types() { return FALSE; } 
    virtual const char* sub_type_obj_factory() { return "none"; } 
    virtual bool ok_for_convergence() { return(TRUE); }
    virtual int restrict_multithreading_to();

    DECLARE_ASK;

    RTTI_INFO;
}; 
Z_END_NAMESPACE;

#endif
