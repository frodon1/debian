#ifndef __Post_mat_sim__ 
#define __Post_mat_sim__ 

// ============================================================================ 
//  Post_mat_sim.c                                           RF 11/19/2004
// 
//  Runs a material behavior through the strain history recorded and adds 
//  additional requested variables. This can be used to: 
//   1) save space, so the FEA calc only saves eto, and then any other var 
//      can be generated via post. 
//   2) can be used to evaluate the (uncoupled) stress differences between 
//      different material models as an error measure. 
//
//  We can either store a new state at every step, or just save the ending
//  state (every_card=FALSE) so that we can really save space. 
// 
//  * normally just eto is used.. eventually add F case also. 
//  * need to specify extra variables to become external parameters for 
//    the material model to use. 
// ============================================================================ 

#include <Buffered_list.h>
#include <Dimension.h>
#include <Clock.h>
#include <Print.h>

#include <External_parameter.h>
#include <Behavior.h>

#include <Local_post_computation.h>
#include <Post_simple.h>
#include <Post_eigen.h>
#include <Post_mises.h>
#include <Post_trace.h>
#include <Post_delay.h>

#include <Utility.h>
#include <Error_messager.h>
#include <Mises_sqrt2.h>

#include <Post_timer.h>
#include <Post_utility.h>
#include <Tool_debug.h>

#include <Behavior.h>

Z_START_NAMESPACE;

ZCLASS2 POST_MAT_SIM : public LOCAL_POST_COMPUTATION { 
 private :

 public :
  int  allow_substeps;
  int  every_increment;
  int  tsz;
  double            t_end; 
  STRING            fname; 
  STRING            prefix;
  LIST<STRING>      params; 
  BUFF_LIST<STRING> change_param_from; 
  BUFF_LIST<STRING> change_param_to; 

  BUFF_LIST<STRING> out_variables_names; 
  BUFF_LIST<STRING> out_variables; 
  BUFF_LIST<double> p_init_vals; 
  VECTOR p0; 

  MAT_DATA       m_mdat;
  PTR<BEHAVIOR>  behavior;
  PTR<ROTATION>  simulation_rotation; 
  LOCAL_INTEGRATION* integ;
  LIST<EXTERNAL_PARAM*> external_params;

  BUFF_LIST<int> look_nodes; 

  PTR<LOCAL_POST_COMPUTATION> matsim; 

  POST_MAT_SIM();
  virtual ~POST_MAT_SIM();

  virtual void load(ASCII_FILE& file,ASCII_FILE& mat_file, bool verify);

  virtual void input_i_need(int,ARRAY<STRING>&);
  virtual void output_i_give(bool&,ARRAY<STRING>&);

  virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);


  void         results(VECTOR& res, ARRAY<STRING>& wht);
//VECTOR       get_all_variables();
//LIST<STRING> get_all_variable_names();
  void         set_external_parameters(const VECTOR& p0,
                                          const VECTOR&   pini,
                                          const VECTOR&   p);
  void         update_mdat(int reset);
};

// 
// Use the post mat sim in order to fake variables which aren't stored in 
// the database. This takes CPU so it's useful for things which are local, like 
// extracting stress-strain curves, or when running in // post and intermediate 
// files are the bottleneck. 
// 
ZCLASS2 POST_MAT_SIM_TOOL { 
  public: 

  int              do_matsim;
  PTR<LOCAL_POST_COMPUTATION> matsim;
  ARRAY<int>       remap1;
  ARRAY<int>       remap2;
  ARRAY<STRING>    my_input;
  ARRAY<VECTOR>    matsim_out;
  ARRAY<VECTOR>    in_conv;
  int              evcum_idx;

  LIST<STRING> matsim_inp_names;
  LIST<STRING> matsim_out_names;

  POST_MAT_SIM_TOOL(); 
  virtual ~POST_MAT_SIM_TOOL(); 

  virtual bool base_read(STRING str, ASCII_FILE& file); 
  virtual void matsim_rename_input(ARRAY<STRING>& ret, int in_dim, BUFF_LIST<STRING>& names);
  virtual const ARRAY<VECTOR>& matsim_generate_input(const ARRAY<VECTOR>& xx_in);

}; 
Z_END_NAMESPACE;

#endif 
