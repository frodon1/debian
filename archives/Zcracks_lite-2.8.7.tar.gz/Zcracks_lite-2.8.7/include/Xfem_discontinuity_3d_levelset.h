#ifndef __XFEM_3D_LEVELSET__
#define __XFEM_3D_LEVELSET__

#include <Split_3d_element.h>
#include <Dimension.h>
#include <Error_messager.h>
#include <Object_factory.h>
#include <Base_restart_defines.h>
#include <Xfem_problem_component.h>
#include <Simple_intersection.h>
#include <Utility_mesh.h>
#include <Utility_elements.h>
#include <Node.h>
#include <Swap.h>

#include <Xfem_discontinuity.h>
#include <Xfem_enhanced_element_wrapper.h>
#include <Xfem_levelset.h>
#include <Print.h>

Z_START_NAMESPACE;

//
// A 3D levelset based discontinuity, FF Oct. 5th 2006 
//   -> coded according to :
//
//   "Modelling crack growth by level sets in the extended finite element method"
//   Stolarska, Chopp, Moes & Belytschko
//   Int. J. Numer. Meth. Engng., 2001, 51, pp 943-960
//

class LEVELSET_INITIALIZER;
class DUAL_LEVELSET_INITIALIZER;

class XFEM_3D_LEVELSET : public XFEM_DISCONTINUITY 
{
  protected:
    bool initialized;
    VECTOR ct_1,ct_2;
    XFEM_LEVELSET *Phi,*Psi;
    bool use_narrow_band;
    XFEM_LEVELSET *Narrow_band;  ///< This field is used to avoid enrichment out of narrow band
    STRING par_psi_name,par_phi_name;
    VECTOR *V_Psi,*V_Phi, *V_Narrow_band;

    double fit_to_vertice_tolerance;

    void reorder_tet(UTILITY_BOUNDARY&);
    void initialize_level_sets();
    XFEM_LEVELSET* find_external_parameter(STRING&);

    void fit_to_vertices(VECTOR&);
    void fit_to_edges(VECTOR&);

  public:
    LEVELSET_INITIALIZER *init_phi,*init_psi;
    DUAL_LEVELSET_INITIALIZER *init_phi_psi;

    XFEM_3D_LEVELSET();
    virtual ~XFEM_3D_LEVELSET();

    virtual bool GetResponse(STRING &ctl, ASCII_FILE &file);


    virtual double Heaviside(XFEM_ENHANCED_ELEMENT_WRAPPER* elem, VECTOR& coord);
    virtual double Heaviside2(XFEM_ENHANCED_ELEMENT_WRAPPER* elem, VECTOR& coord);
    virtual void compute_H_values();
    virtual void compute_distances(const int rk, ARRAY<double> &val) {
      val.resize(2); val[0]=(*V_Phi)[rk]; val[1]=(*V_Psi)[rk];
    }

    virtual void get_edges_on_discontinuity(LIST< LIST<int> >&,XFEM_ENHANCED_ELEMENT_WRAPPER*);
    virtual void get_nodes_on_discontinuity(SORTED_LIST<int>&,XFEM_ENHANCED_ELEMENT_WRAPPER*);
    virtual void get_face_on_discontinuity(LIST<int>&,int&,XFEM_ENHANCED_ELEMENT_WRAPPER*);
    virtual void get_sub_faces_ranks_on_discontinuity(BUFF_LIST<int>&,XFEM_ENHANCED_ELEMENT_WRAPPER*);

    virtual X_TYPE compute_intersection(MESH& mesh,
                XFEM_ENHANCED_ELEMENT_WRAPPER* elem,
                XFEM_3D_SUBDIV& subdiv_left,
                XFEM_3D_SUBDIV& subdiv_right,
                XFEM_3D_SUBDIV& middle);

    virtual int    tip_coord(XFEM_ENHANCED_ELEMENT_WRAPPER *elem, 
                             const VECTOR& pos,
                             VECTOR& tip_position,
                             VECTOR& growth_dir,
                             VECTOR& g_norm);

    virtual void propagate();
    virtual void mesh_changed();
    virtual void get_levelset_grids(GRID_3D<double>*& gphi, GRID_3D<double>*& gpsi);

    virtual void update_for_added_mpc_nodes(ARRAY<NODE*> duplicated_nodes);

    virtual void read_restart(RST_FSTREAM& obin);
    virtual void write_restart(RST_FSTREAM& rep);
};

Z_END_NAMESPACE;

#endif
