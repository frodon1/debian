#ifndef __INP_FILE__
#define __INP_FILE__

#include <Defines.h>
#include <File.h>
#include <List.h>
#include <Stringpp.h>

Z_START_NAMESPACE;

/// An class representing an .inp file. Not finished yet, so not documented.
ZCLASS INP_FILE : public ASCII_FILE {
    LIST<STRING> lbuffer;
  public :
    INP_FILE();
    INP_FILE( const char* );
    INP_FILE( const char*, const STRING, int );

    void load_sections_until( const STRING, const STRING );
    void load_sections_after_until( const STRING, const STRING, const STRING );

    bool optional( const STRING, int& );
    bool optional( const STRING, double& );
    bool optional( const STRING, STRING& );
//    bool optional( const STRING, bool& );
    bool optional( const STRING, LIST<STRING>& );
    bool optional( const STRING, STRING&, int& );
//    bool optional( const STRING, const STRING, bool& );
    bool optional( const STRING, const STRING, const STRING, bool& );

    bool mandatory( const STRING, int& );
    bool mandatory( const STRING, double& );
    bool mandatory( const STRING, STRING& );
//    bool mandatory( const STRING, bool& );
    bool mandatory( const STRING, LIST<STRING>& );
    bool mandatory( const STRING, STRING&, int& );
//    bool mandatory( const STRING, const STRING, bool& );
    bool mandatory( const STRING, const STRING, const STRING, bool& );

};
Z_END_NAMESPACE;

#endif
