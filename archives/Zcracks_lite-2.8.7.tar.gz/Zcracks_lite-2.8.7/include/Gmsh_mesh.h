// -*- C++ -*-
#ifndef __Gmsh_mesh_
#define __Gmsh_mesh_

#include <Utility_mesh_reader.h>
#include <Abaqus_zebulon.h>

Z_START_NAMESPACE;

// First authors are Nicolas MOULIN (nmoulin@emse.fr)  and Benoit SERRE 
// (serre@emse.fr) from Ecole Nationale Superieure des Mines de Saint-Etienne

class GMSH_MESH : public UTILITY_MESH_READER {
protected :
	bool if_shell_warning;
    int output_level;

    STRING gmsh;
    int msh_version;
    int msh_file_type;
    int msh_data_size;

    int current_node;
    int current_element;
    int pb_dim;

    BUFF_LIST<int> physical_number;
    BUFF_LIST<STRING> physical_name;    

    void read_elset(ASCII_FILE*);
    int read_one_elset(ASCII_FILE*, int&, STRING&);

    void gmsh_file_type_detection(ASCII_FILE*);
    void clear_to_next_command(ASCII_FILE*);
    bool faset_verification();
	bool if_real_faset(UTILITY_ELEMENT*);

    void create_elset(UTILITY_ELEMENT*, int, int);
    UTILITY_ELSET* find_elset(int, STRING);

    void write_header(Zofstream&);
    void write_PhysicalNames(Zofstream&);
    void write_Nodes(Zofstream&);
    void write_Elements(Zofstream&);
    void physical_reg_elset(UTILITY_ELEMENT*, UTILITY_ELSET*&, UTILITY_ELSET*&); 

public :
    GMSH_MESH();
    virtual ~GMSH_MESH() { }

    virtual void initialize(ASCII_FILE&,UTILITY_MESH*);
    void special_initialize(ASCII_FILE&, UTILITY_MESH*, int);

    void read_element(ASCII_FILE*);
    void read_node(ASCII_FILE*);
    void read_gmsh_element(ASCII_FILE*, int&, STRING&, int&, int&, 
                           ARRAY<UTILITY_NODE*>&);
    virtual bool verify();
    virtual void write(STRING);
};
Z_END_NAMESPACE;

#endif
