#ifndef __Plastic_micromorph_Phasefield_behavior__
#define __Plastic_micromorph_Phasefield_behavior__
#include <PF_Chemical_energy.h>




Z_START_NAMESPACE;

class MAT_DATA; class ASCII_FILE;
class PHASEFIELD_PHIC_ENERGY;

class PLASTIC_MICROMORPH_PHASEFIELD_BEHAVIOR : public BEHAVIOR, 
                                          public RUNGE_INTEGRATOR,
				          public THETA_INTEGRATOR {
  protected:
      AUTO_PTR<ELASTICITY> elas1;
      AUTO_PTR<ELASTICITY> elas2;
      COEFF eigen_coeff1,eigen_coeff2; 
      COEFF delta1,delta2;        	       
      COEFF c_ref1,c_ref2; 
      TENSOR2_FLUX sig;
      TENSOR2_VAUX sig1,sig2;
      TENSOR2_GRAD eto;
      TENSOR2_VINT Eel1, Eel2;
      double dot_Phi,dot_epk;
      
      TENSOR2_VAUX Ep1, Ep2, Ep,Eel;
      SCALAR_VINT  epcum1, epcum2;
      SCALAR_VAUX misec1, misec2;

      COEFF Aki1,Aki2,Hk1,Hk2;
      COEFF H1, H2;
      COEFF R01, R02;
      AUTO_PTR<RUNGE> runge;
      AUTO_PTR<THETA> integ_theta;
      VECTOR dgrad;
      TENSOR4   unit, unit32;   // utility dev operator s' = unit*sigma
      
      SMATRIX  dn1_ds1, dn1_dEel1;
      SMATRIX  dn2_ds2, dn2_dEel2;
            
      VECTOR   f_vec_Eel1,      f_vec_Eel2;
      SMATRIX  dEel1_dEel1,     dEel2_dEel2;
      MATRIX   dEel1_depcum1,   dEel2_depcum2;
      
      MATRIX   depcum1_dEel1,   depcum2_dEel2;
      
      TENSOR2 normsig1, normsig2;
     
      TENSOR2_VAUX defo_tr;    
      VECTOR_FLUX xi;
      VECTOR_FLUX J;
      VECTOR_GRAD C_grad;
      VECTOR_GRAD Phi_grad;
      SCALAR_VAUX mu;
      SCALAR_VAUX Phi;
      SCALAR_VAUX C;
      SCALAR_VAUX pi;
      TENSOR2 deto;
      
      COEFF function, function2;
      
      double h, dh,d2h;
      double h_mech, dh_mech,d2h_mech;

      SCALAR_VINT eto1;
      VECTOR_VAUX grad_eto1;
      SCALAR_VINT eto2;
      VECTOR_VAUX grad_eto2;
      SCALAR_VINT eto3;
      VECTOR_VAUX grad_eto3;
      SCALAR_VINT eto4;
      VECTOR_VAUX grad_eto4;
      SCALAR_VINT eto5;
      VECTOR_VAUX grad_eto5;
      SCALAR_VINT eto6;
      VECTOR_VAUX grad_eto6;
                 
      MATRIX grad_eto;            
      
         
      double df_dphi, df_dc, d2f_dphi2, d2f_dc2, d2f_dphidc,d3f_dphidc2, d3f_dphi2dc;
      VECTOR grad_mu;
      
      TENSOR2 dWe_ddef, d2We_dphiddef;
      SMATRIX d2We_ddef2, d3We_d2defdc; 
      double dWe_dphi, d2We_d2phi; 
      
      VECTOR d2We_ddefdc,d3We_ddefd2c, d3We_ddefdphidc;
      double dWe_dc, d2We_d2c, d3We_d3c;
      double d2We_dphidc,d3We_dphid2c,d3We_d2phidc,d3We_dphi2dc;     
      
      TENSOR2 dEel_dphi, d2Eel_d2phi, d3Eel_d3phi; 
      TENSOR2 dEel_dc, d2Eel_d2c, d3Eel_d3c; 
      TENSOR2 d2Eel_dphidc,d3Eel_dphid2c,d3Eel_d2phidc;      
      
      SMATRIX Ceff, dCeff_dphi, d2Ceff_d2phi;//, d3Ceff_d3phi;     
      SMATRIX dCeff_dc, d2Ceff_d2c, d3Ceff_d3c;     
      SMATRIX d2Ceff_dphidc,d3Ceff_dphid2c,d3Ceff_d2phidc;





      double dWp_dphi,d2Wp_dphi2;
      double d2Wp_depkdphi,dWp_depk,d2Wp_d2epk, d2Wp_d2gradepk;
      VECTOR dWp_dgradepk, d2Wp_dgradepkdphi;


      COEFF alpha,beta;
      COEFF onsag2,onsag1;
      
      SMATRIX m_tg;
      MATRIX tg_u_u, tg_c_c, tg_c_phi, tg_phi_phi,tg_c_u,tg_epk_epk;      
     
      TENSOR4 tgmat;  
      
      PHASEFIELD_PHIC_ENERGY *energy;


      VECTOR_GRAD epk_grad;
      SCALAR_VAUX epk;
      VECTOR_FLUX bk;
      SCALAR_VAUX ak;

  public:
      PLASTIC_MICROMORPH_PHASEFIELD_BEHAVIOR();
      virtual ~PLASTIC_MICROMORPH_PHASEFIELD_BEHAVIOR();
      virtual void initialize(ASCII_FILE&,int,LOCAL_INTEGRATION*);
      virtual void calc_grad_f(VECTOR&,SMATRIX&,const VECTOR&,const VECTOR&,double,double);
      virtual void derivative(double,const  VECTOR&,VECTOR&);
      virtual INTEGRATION_RESULT* integrate(MATERIAL_INTEGRATION_INFO&);
      //virtual INTEGRATION_RESULT* integrate_runge();
      //virtual INTEGRATION_RESULT* integrate_theta_a(); 
      //virtual void setup(int& flux_pos, int& grad_pos, int& vi_pos, int& va_pos);
      //virtual void set_up_theta();
      
};

Z_END_NAMESPACE;

#endif
