#include <Adapter.h>
#include <Transform_geometry.h>
#include <Matrix.h>
#include <Tensor2.h>
#include <List.h>
#include <Utility.h>
#include <P_element.h>
#include <Interpolation.h>
#include <Behavior.h>
#include <Problem.h>
#include <Object_factory.h>
#include <Utility_mesh.h>
#include <Utility_results_database.h>
#include <Node.h>
#include <Dof.h>

Z_START_NAMESPACE;

class POSITIVE_IP_VALUES : public ADAPTER
{
  protected :
    LIST <int> icol;

  public :
    POSITIVE_IP_VALUES() : ADAPTER() { }
    virtual ~POSITIVE_IP_VALUES() { }

    virtual void initialize(const UTILITY_MESH&, const MESH&, const LIST<STRING>); 
    virtual ARRAY< ARRAY<double> > apply_on_old_values(const LIST<STRING> ,const ARRAY< ARRAY<double> >);
    virtual ARRAY< ARRAY<double> > apply_on_new_values(const ARRAY< ARRAY<double> >);
};

Z_END_NAMESPACE;
