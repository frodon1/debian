#ifndef __NO_BUF__ 
#define __NO_BUF__

#include <Zbuffer.h>

Z_START_NAMESPACE;

ZCLASS NOBUF : public ZFILEBUFFER {
  public :
    NOBUF();
    virtual ~NOBUF();

    virtual ZFILEBUFFER* open(const char *filename, IOS_OPENMODE mode, int prot = 0664);
    virtual ZFILEBUFFER* close();

    virtual int underflow();
    virtual int overflow(int c = EOF);


    virtual int doallocate();

    virtual ZSTREAMPOS seekoff(ZSTREAMOFF pos, _SEEK_DIR dir);
    virtual ZSTREAMPOS seekoff(ZSTREAMOFF pos, _SEEK_DIR dir, int mode);

    virtual int sync();
};
Z_END_NAMESPACE;

#endif
