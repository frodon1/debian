#ifndef __B3_Splines_field__
#define __B3_Splines_field__

//
// Field function on B3-Spline
// 4 points  0 --- 1 --- 2 --- 3
//

#include <Interpolation.h>

Z_START_NAMESPACE;

ZCLASS B3_SPLINES_INTERPOLATION : public INTERPOLATION_FUNCTION
{
 public : 
  B3_SPLINES_INTERPOLATION(int,int);
  ~B3_SPLINES_INTERPOLATION();
  
  virtual VECTOR shape(const VECTOR& chi) const;
  virtual MATRIX deriv(const VECTOR& chi) const;
  MATRIX deriv2(const VECTOR& chi) const; 
  MATRIX deriv3(const VECTOR&) const; 

  virtual void get_sides(ARRAY<ARRAY<int> >&) const;
  virtual void local_position_of_node(int, VECTOR&) const;
};
Z_END_NAMESPACE;

#endif
