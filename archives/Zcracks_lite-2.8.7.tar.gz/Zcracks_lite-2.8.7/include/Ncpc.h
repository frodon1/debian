#include <Elasticity.h>
#include <Basic_nl_behavior.h>
#include <Basic_nl_simulation.h>
#include <Defines.h>
#include <Gen_visco.h>

Z_START_NAMESPACE;

class NCPC;

class NCPC_LOCALIZATION {
   protected :
     NCPC* its_boss;

   public :
      AUTO_PTR<ELASTICITY> CK;

      NCPC_LOCALIZATION() : its_boss(NULL)  {}
      virtual ~NCPC_LOCALIZATION() {}

     virtual bool read(ASCII_FILE&, NCPC*)=0;
     virtual void update_concentration_tensor(double time, const VECTOR& sig) {}
     virtual bool verify_info() { return(TRUE); }
   
};

class NCPC: public BASIC_SIMULATOR,  public BEHAVIOR 
{
   public : 

      bool strain_control;
      int ndir; // direction of normal to free surface
      int macro_int_size,macro_aux_size, total_int_size,total_aux_size;

      TENSOR2_VAUX         sig;
      TENSOR2_VINT         eto;
      AUTO_PTR<RUNGE>      m_intrk;
      TENSOR4   S, Cc;
      ROTATION* lrotation;
      BEHAVIOR*  local_behavior;
      TENSOR2_GRAD* local_eto;
      TENSOR2_FLUX* local_sig;
      TENSOR2 local_deel;
      TENSOR2_VINT* local_eel;
      SCALAR local_devcum;
      VECTOR   integration_vector,local_behavior_vints, local_behavior_dvints;
      double keep_theta; 

      TENSOR2_VAUX   local_evi;
      AUTO_PTR<NCPC_LOCALIZATION> localization_method;
      TENSOR2_VINT         neto;
      TENSOR2_FLUX         zfbehavior_sig;
      TENSOR2_GRAD         zfbehavior_eto;
      TENSOR2 deto;
      TENSOR2 dsig, local_dsig;
      VECTOR  dgrad_save; 

      NCPC() : BASIC_SIMULATOR(), BEHAVIOR(), ndir(0) { behavior=this; }
      virtual ~NCPC();
      virtual void initialize(ASCII_FILE& file, LOCAL_INTEGRATION*, SIMULATOR_TEST* tst);
      virtual void initialize(ASCII_FILE&, int, LOCAL_INTEGRATION*);
      virtual bool simul_integrate(VECTOR& dgl, ARRAY<STRING>& ctl, double dtime);
      virtual void derivative(double tau, const VECTOR& var_int, VECTOR& dvar);
      virtual void init();
      virtual void setup(int& fp, int& gp, int& vip, int& vap);
      virtual void init_material_data(MAT_DATA& mdat);
      virtual VECTOR get_all_variables();
      virtual void results(VECTOR& res, ARRAY<STRING>& wht);
      virtual void rotate_to_material(TENSOR2&);
      virtual void rotate_from_material(TENSOR2&);
      virtual void rotate_to_material(TENSOR4&);
      virtual void rotate_from_material(TENSOR4&);
      virtual void rotate_to_material(VECTOR&);
      virtual void rotate_from_material(VECTOR&);
      virtual bool if_constant_coefs()const;

      RTTI_INFO;
};

Z_END_NAMESPACE;
