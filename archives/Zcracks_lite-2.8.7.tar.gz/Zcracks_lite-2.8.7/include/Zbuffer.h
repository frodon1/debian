#ifndef __Z_FILE_BUFFER__
#define __Z_FILE_BUFFER__

#include <Ziostream.h>
#include <Zstreambuf.h>
#include <Zios.h>

#include <Defines.h>

Z_START_NAMESPACE;

ZCLASS ZFILEBUFFER : public ZSTREAMBUF {
  protected :

     int _state; 
     void setstate(ZIOSTATE flag); 
     void set(ZIOSTATE flag); 

  public :
    int indent;

    ZFILEBUFFER(); 
    virtual ~ZFILEBUFFER(); 

    virtual ZFILEBUFFER* open(const char*,IOS_OPENMODE,int);    
    virtual ZFILEBUFFER* close();
    virtual int is_open() const;
};
Z_END_NAMESPACE;

#endif
