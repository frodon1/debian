#ifndef __Jacobian_mpc__
#define __Jacobian_mpc__

#include <Array.h>
#include <Matrix.h>
#include <Vector.h>

Z_START_NAMESPACE;

ZCLASS JACOBIAN_MPC {

 public :

   double rhs, bc_factor;
   ARRAY<int> rks;
   ARRAY<double> coefs;

   JACOBIAN_MPC() : rhs(0.0), bc_factor(1.e19) {}
   ~JACOBIAN_MPC() {}

   void apply(SMATRIX& K, VECTOR& b);
   void restore(VECTOR& u);
};
Z_END_NAMESPACE;

#endif
