#ifndef __ZP_DAO_LINE_DOMAIN__
#define __ZP_DAO_LINE_DOMAIN__

#include <Geometry_parts.h>
#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_dao_domain.h>
#include <Dao_domains.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_DAO_LINE_DOMAIN : public ZP_DAO_DOMAIN 
{
  protected :
    ZP_FATAL_ERROR* reset(ZP_STACK &s,int n) { return(ZP_DAO_DOMAIN::reset(s,n)); }
    ZP_FATAL_ERROR* mesh(ZP_STACK &s,int);
    ZP_FATAL_ERROR* add(ZP_STACK &s,int);
    ZP_FATAL_ERROR* set_spring(ZP_STACK &s,int);
    virtual ZP_FATAL_ERROR* print(ZP_STACK &s,int n) {  return(ZP_DAO_DOMAIN::print(s,n)); }

    virtual void type_init(char*) { _CHECK_DGLP_ type="LINE_DOMAIN"; }

  public :
    ZP_DAO_LINE_DOMAIN() : ZP_DAO_DOMAIN(NULL) { 
      type_init(NULL); 
      dont_delete=0; 
      contens=new DAO_DOMAIN_SPR(dao_geom_link_program); 
      dao_delete_add();
    }
    ZP_DAO_LINE_DOMAIN(DAO_DOMAIN_SPR *d) : ZP_DAO_DOMAIN(d) {
      type_init(NULL);
      dont_delete=1;
      contens=d;
      _dao_delete();
    }

    virtual DAO_DOMAIN_SPR& get() { return(*((DAO_DOMAIN_SPR*)contens)); }

    METHOD_DECLARATION_START
      METHOD("add",add,1)
      METHOD("dump",dump,0)
      METHOD("remesh",mesh,0)
    METHOD_DECLARATION_ANCESTOR(ZP_DAO_DOMAIN)

    virtual ZP_FATAL_ERROR* acess(STRING &s,ZP_STACK &st,bool resolv=FALSE);
    ZPO_RTTI_INFO(DAO_DOMAIN_SPR)
};
Z_END_NAMESPACE;

#endif
