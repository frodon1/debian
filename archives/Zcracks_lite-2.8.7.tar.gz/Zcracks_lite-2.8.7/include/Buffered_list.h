#ifndef __Buffered_list__
#define __Buffered_list__

#include <Array.h>
#include <List.h>
#include <Defines.h>

Z_START_NAMESPACE;

/// A buffered list. 
/// Use this object for intensively used lists, when its size is not known
/// in advance. 
/// To be efficient, it allocates an internal buffer for storage,
/// with approximately 15% extra space reserved in advance. 

template<class T> ZCLASSt BUFF_LIST : public CARRAY<T> {
     protected :
       int tot_sz;                                    ///< size of the internal allocated buffer
       int estimate_buffer_size(int n);
       void copy_from_ptr(const T* xx, int s);        // not virtual, because used in constructors

     public :                                     
       BUFF_LIST(): CARRAY<T>(), tot_sz(0)  {}
       BUFF_LIST(int bsz) DEPRECATED : CARRAY<T>(bsz), tot_sz(bsz) { this->sz=0; assert(bsz>0); } ///< this constructor is deprecated; the buffer size is now automatically adjusted
       BUFF_LIST( const ARRAY<T>& a);
       BUFF_LIST( const BUFF_LIST<T>& a);
       virtual ~BUFF_LIST() {}

       virtual BUFF_LIST<T>& operator=(const BUFF_LIST<T>&);
       virtual BUFF_LIST<T>& operator=(const LIST<T>&);
       virtual operator LIST<T>()const;               ///< automatic conversion to a LIST object

       virtual T&   add(const T& xx);                 ///< append the given element; reallocate buffer if required
       virtual T&   add_at(int rank, const T& xx);    ///< insert element at given rank; reallocate buffer if required
       virtual void add_to(const ARRAY< T >& xx);     ///< append the given elements
       virtual T&   add();                            ///< create space for 1 more element and return it

       virtual void add_if_not_in(const T& xx);                 ///< append the given element if not already in the list; reallocate buffer if required
       virtual void add_if_not_in(const ARRAY<T>& xx);          ///< append the given elements if not already in the list; reallocate buffer if required

       virtual bool suppress();                                 ///< remove last element
       virtual bool suppress_item(const T& xx);                 ///< remove first occurence of item
       virtual bool suppress_all(const T& xx);                  ///< remove all occurences of item
       virtual int  suppress_items(const BUFF_LIST<T>& items);  ///< remove all occurences of items; returns the number of removed items
       virtual bool suppress(int rk);                           ///< remove element at rank rk

       virtual void resize(int);                                ///< resize list to the given size; resize buffer if required, in which case data is lost
       virtual void resize_and_keep(int);                       ///< resize list to the given size; resize buffer if required; data is copied if buffer changes
       virtual void reserve(int n);                             ///< allocate a buffer large enough to hold at least n items; data is copied if buffer changes
       virtual void pre_resize(int);                            ///< allocate a buffer of exactly the given size; data is lost if buffer changes.

       virtual void set_ptr_and_size(T *xx, int s) { CARRAY<T>::set_ptr_and_size(xx,s) ; this->tot_sz=s; }

       virtual void clear();                          ///< set size to zero, and delete the internal buffer 
};                                                 

template <class T> INLINE BUFF_LIST<T>::BUFF_LIST(const ARRAY<T>& a) : 
  CARRAY<T>(a.size()), tot_sz(a.size())
{
  this->copy_from_ptr(a.ptr(), a.size());
} 

template <class T> INLINE BUFF_LIST<T>::BUFF_LIST(const BUFF_LIST<T>& a) :
  CARRAY<T>(a.size()),  tot_sz(a.size())
{
  this->copy_from_ptr(a.ptr(), a.size());   
}


template <class T> INLINE BUFF_LIST<T>::operator LIST<T>()const
{
  LIST<T> ret; ret.resize(this->sz); 
  for (int i=0;i<this->sz;i++) ret[i] = this->x[i]; 
  return ret; 
}


/// Internal use: compute the buffer size required to store n items
/// Currently adds an extra ~15% extra space if too small
template <class T> INLINE int BUFF_LIST<T>::estimate_buffer_size(int n) 
{
  if ( n < tot_sz ) return tot_sz;
  else {
    return n + (n/8) + (n < 9 ? 3 : 6);
  }
}

// Using memcpy for simple types (int, double) gains 50% perf (memcpy wouldn't work with classes that require a complex copy operator)
template<> INLINE void BUFF_LIST<int>::copy_from_ptr(const int* xx, int s)
{
  resize(s);
  if (s>0) 
    memcpy(this->x, xx , this->sz * sizeof(int)) ;
}
template<> INLINE void BUFF_LIST<double>::copy_from_ptr(const double* xx, int s)
{
  resize(s);
  if(s>0) 
    memcpy(this->x, xx , this->sz * sizeof(double)) ;
}
template <class T> INLINE void BUFF_LIST<T>::copy_from_ptr(const T* xx, int s)
{
  resize(s);
  for(int i=0;i<this->sz;i++) this->x[i]=xx[i];
}


template <class T> INLINE BUFF_LIST<T>& BUFF_LIST<T>::operator=(const BUFF_LIST<T>& la)
{
  this->copy_from_ptr(la.ptr(), la.size());
  return *this;   
}

template <class T> INLINE BUFF_LIST<T>& BUFF_LIST<T>::operator=(const LIST<T>& la)
{
  resize(la.size());
  for(int i=0;i<this->sz;i++) this->x[i]=la[i];
  return *this;
}

template <class T> INLINE T& BUFF_LIST<T>::add()
{ 
  reserve(this->sz + 1); 
  this->sz++; 
  return this->last(); 
}

template <class T> INLINE T& BUFF_LIST<T>::add(const T& xx)
{ 
  if ( this->tot_sz > this->sz) {
    this->x[this->sz++] = xx; 
  }
  else {
    // I'd like to call reserve(sz+1);
    // but if xx is a member of me, I'll call its destructor before copying it
    // So I must delay the delete until after it is copied
    T *tt = this->x;
    this->tot_sz = estimate_buffer_size(this->sz+1);
    this->x=new T [this->tot_sz];
    copy_from_ptr(tt, this->sz);
    this->x[this->sz++] = xx; 
    if (!this->no_delete) delete[] tt;
  }
  return this->last(); 
}

template <class T> INLINE void BUFF_LIST<T>::add_if_not_in(const T& xx)
{
  if(!this->is_in(xx)) add(xx);
}

template <class T> INLINE void BUFF_LIST<T>::add_if_not_in(const ARRAY<T>& xx)
{
  for(int i=0;i<xx.size();i++) if(!this->is_in(xx[i])) add(xx[i]);
}

template <class T> INLINE T& BUFF_LIST<T>::add_at(int rank, const T& xx)
{ 
  int end = this->sz;
  if (end==0) {
      rank = 0; 
      add(xx); 
  }
  else { 
      add(this->x[end-1]); 
      if (end>1) { 
          for (int i=end-1;i>rank;i--) { 
               this->x[i] = this->x[i-1]; 
          } 
      } 
      this->x[rank] = xx; 
  } 

  return this->x[rank]; 
}

template <class T> INLINE void BUFF_LIST<T>::add_to(const ARRAY<T>& xx)
{ 
  int sz_before=this->size(); 
  this->resize_and_keep(sz_before + xx.size());
  for (int i=0;i<xx.size();i++) {
    this->x[sz_before+i] = xx[i]; 
  }
}

template <class T> INLINE bool BUFF_LIST<T>::suppress()
{ 
  assert(this->sz!=0);
  this->sz--;
  return TRUE;
} 

template <class T> INLINE bool BUFF_LIST<T>::suppress_item(const T& xx)
{ 
  if (this->sz==0) return FALSE; 
  int rank;
  bool ans=this->is_in(xx,rank);
  if(ans) suppress(rank);

  return ans;
}

template <class T> INLINE int BUFF_LIST<T>::suppress_items(const BUFF_LIST<T>& items)
// The idea is to do the is_in on the items list, generally much smaller than current "this".
// Using a hash_list, or a sorted & uniqued list for items could still accelerate this function
// Returns the number of suppressed items
{
  int nshift=0; 
  for (int i=0; i<this->size(); i++) {
    if ( items.is_in(this->x[i]) ) {
      nshift++ ; 
    }
    else {
      this->x[i-nshift] = this->x[i]; 
    }
  }
  this->sz -= nshift; 
  return nshift;
}


template <class T> INLINE bool BUFF_LIST<T>::suppress_all(const T& xx)
{
  if (this->sz==0) return FALSE;
  int rk=0;
  for(int i=0;i<this->sz;i++) {
    if (this->x[i] == xx) continue;
    this->x[rk] = this->x[i];
    rk++;
  }
  this->sz = rk;
  return TRUE;
}

template <class T> INLINE bool BUFF_LIST<T>::suppress(int rk)
{ 
  if (rk==this->sz-1) { suppress(); return(TRUE); }
  assert(rk>=0 && rk<this->sz);
  for(int i=rk+1;i<this->sz;i++) this->x[i-1]=this->x[i];
  this->sz--;
  return TRUE;
}

template <class T> INLINE void BUFF_LIST<T>::resize(int n)
{ 
  assert(n>=0);
  if(n>this->tot_sz) { 
    if(!this->no_delete) delete[] this->x;
    tot_sz=n;
    this->x=new T [tot_sz]; 
  }
  this->sz=n;
}

template <class T> INLINE void BUFF_LIST<T>::resize_and_keep(int n)
{ 
  this->reserve(n);
  this->sz=n;
}

template <class T> INLINE void BUFF_LIST<T>::reserve(int n)
{ 
  assert(n>=0);
  if ( tot_sz < n) {
    T *tt = this->x;
    this->tot_sz = estimate_buffer_size(n);
    this->x=new T [this->tot_sz];
    copy_from_ptr(tt, this->sz);
    if(!this->no_delete) delete[] tt;
  }
}

template <class T> INLINE void BUFF_LIST<T>::pre_resize(int n)
{ 
  assert(n>=0);
  if(n != this->tot_sz) {
    if(this->x && !this->no_delete) delete[] this->x;
    tot_sz=n;
    this->x=new T [tot_sz];
  }
}

template <class T> INLINE void BUFF_LIST<T>::clear()
{
   if(this->tot_sz && this->x && !this->no_delete){
      delete []this->x;
      this->x=NULL;
      this->tot_sz=this->sz=0;
   }
}

template<class T>
void sort(BUFF_LIST<T>&l);

Z_END_NAMESPACE;

#endif
