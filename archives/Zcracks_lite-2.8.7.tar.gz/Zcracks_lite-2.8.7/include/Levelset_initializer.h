#ifndef __LEVELSET_INITIALIZER__
#define __LEVELSET_INITIALIZER__

#include <Grid_3d.h>
#include <File.h>
#include <Xfem_levelset.h>

Z_START_NAMESPACE;

class MESH;
class XFEM_3D_LEVELSET;

class LEVELSET_INITIALIZER
{
public :
  XFEM_3D_LEVELSET *boss;
  
  LEVELSET_INITIALIZER() { boss=NULL; }
  virtual ~LEVELSET_INITIALIZER() { }
  
  virtual void initialize(ASCII_FILE&) { }
  virtual void initialize(XFEM_LEVELSET&) { }
  virtual void propagate() { }
  virtual void mesh_changed(MESH&,XFEM_LEVELSET*&) { }
  virtual GRID_3D<double>* get_grid() { return(NULL); }
  virtual void write_restart_grid() { }
  

};
Z_END_NAMESPACE;

#endif
