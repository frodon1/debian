#ifndef __RESULTS_CONTOUR_ACTOR__
#define __RESULTS_CONTOUR_ACTOR__

#include <Graphics_object.h>
#include <ZP_stack.h>
#include <Utility_set.h>
#include <Utility_results_database.h>

Z_START_NAMESPACE;

class ZP_CONTOUR_ACTOR;
class RESULTS_CONTOUR_ACTOR;
class CONTOUR_BAR;
class CONTOUR_EXTENSION_ACTOR;

ZCLASS2 RESULTS_ACTOR_2ND_DRAW : public GRAPHICS_OBJECT {
  public :
   RESULTS_CONTOUR_ACTOR* its_boss;
   RESULTS_ACTOR_2ND_DRAW(RESULTS_CONTOUR_ACTOR* boss) { its_boss = boss; priority=10; always_visible=TRUE; }

   virtual void local_draw(GRAPHICS_AREA* ga);
};

ZCLASS2 RESULTS_CONTOUR_ACTOR : public GRAPHICS_OBJECT {
  friend class ZP_CONTOUR_ACTOR;
  friend class RESULTS_ACTOR_2ND_DRAW;
  private :
    bool from_reload_mesh;

  protected :
    RESULTS_ACTOR_2ND_DRAW its_result_2nd_draw;
    CONTOUR_BAR *its_contour_bar;
    STRING contour_bar_type;
    bool inited,scale_inited;
    bool is_integ,is_node;
    LIST<CONTOUR_EXTENSION_ACTOR*> extensions;

    virtual bool do_a_post( UTILITY_RESULTS_DATABASE::LOCATIONS type, double when, STRING& comp);
    void reload_mesh_and_rerun(double when);
    void setup_new_values(double map, double tt, const STRING& comp);
    void paint_vectors_view(int check_vec);
    void paint_vectors_view_ctele(int check_vec);

    ZP_FATAL_ERROR* init_ctables(ZP_STACK&);

//    ZP_FATAL_ERROR* enable_element_cutoff(ZP_STACK&);
//    ZP_FATAL_ERROR* disable_element_cutoff(ZP_STACK&);
//    ZP_FATAL_ERROR* set_cutoff_parameters(ZP_STACK&, STRING *_name, double *_value, double *_factor);
    virtual ZP_FATAL_ERROR* enable(ZP_STACK&);
    virtual ZP_FATAL_ERROR* disable(ZP_STACK&);
    virtual ZP_FATAL_ERROR* set_ctable(ZP_STACK&,STRING *_c);
    virtual ZP_FATAL_ERROR* set_scale(ZP_STACK&, double *min, double *max, int *cbar, int *exact);
    ZP_FATAL_ERROR* set_node_component(ZP_STACK&, STRING *_name);
    ZP_FATAL_ERROR* set_integ_component(ZP_STACK&, STRING *_name);
    virtual ZP_FATAL_ERROR* start_anim_rec(ZP_STACK&, STRING *_p);
    virtual ZP_FATAL_ERROR* stop_anim_rec(ZP_STACK&);
    void set_ur_location();
    ZP_FATAL_ERROR* set_contour_bar_type(      ZP_STACK&,STRING*);
    ZP_FATAL_ERROR* set_contour_bar_background(ZP_STACK&,STRING*);
    ZP_FATAL_ERROR* set_contour_bar_border(    ZP_STACK&,STRING*);

    void check_contour_bar_change();

   ZP_FATAL_ERROR* enable_View_region_of_interest(ZP_STACK&);
   ZP_FATAL_ERROR* disable_View_region_of_interest(ZP_STACK&);
   ZP_FATAL_ERROR* set_View_region_of_interest_parameters(ZP_STACK&, STRING *_exp, double *_ROI_crit_rate);
   void Region_of_interest_by_function(double when);
   
 public :
   double magnification,last_mag;
   VECTOR vc_pos;
   STRING component,last_component;

   enum LOCATION { RENDERED=0,
                   CONTOUR=1,
                   CONTOUR_BY_ELEMENT=2,
                   CONTOUR_BY_MATERIAL=4,
                   GAUSS=8,
                   VVECTOR=16,
                   VELOCITY=32,
                   NVECTOR=64
   };

   enum OPTION { NONE=0,
                 WIREFRAME=1, 
                 DEFORMED=2,
                 INITIAL_MESH=4,
                 NO_MESH=8
   };

   enum MINMAX { MANUAL=0,
                 AUTOMATIC_BY_STRUCTURE=1,
                 AUTOMATIC_BY_VISIBLE=2
   };

   UTILITY_RESULTS_DATABASE::LOCATIONS ur_location;

   LOCATION location; 
   LOCATION last_location;
   int      option;
   int      minmax;

   UTILITY_NODE *last_click_node;
   double last_click_value;

   int was_deformed;
//   int elim_ele_over_cutoff;
//   STRING cutoff_var,last_cutoff_var;
//   double cutoff_value,last_cutoff_value;
//   double cutoff_factor,last_cutoff_factor;
//   int last_cutoff_state;
//   double last_cutoff_when;
   double last_when;
   int use_3d_velocity;
   double max_velocity;
   int custom_bar;
   double max_ival;
   double min_ival;
   MARRAY<VECTOR> ivecs;
   ARRAY< ARRAY<int> > ctele_start_index;
   double max_val, min_val;
   double results_factor;
   LIST<STRING>          ctables;
   int curr_ctable;

   RESULTS_CONTOUR_ACTOR();
   virtual ~RESULTS_CONTOUR_ACTOR(); 

   virtual ZP_FATAL_ERROR* put_results(ZP_STACK&,double*);

   virtual void local_draw(GRAPHICS_AREA* ga);

   virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);

   ZP_FATAL_ERROR* clicked(ZP_STACK&,double*,double*,double*);
   ZP_FATAL_ERROR* clicked(ZP_STACK&,int*);
   
   STRING expression, last_expression;
   int View_region_of_interest; 
   int last_View_ROI_state;
   double last_View_ROI_when;
   double ROI_crit_rate;
   
};
Z_END_NAMESPACE;

#endif
