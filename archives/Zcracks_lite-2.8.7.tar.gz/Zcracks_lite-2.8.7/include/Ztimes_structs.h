#ifndef __Ztimes_structs__
#define __Ztimes_structs__

#include <Ztimes.h> 

#ifdef _WIN32 
#include <windows.h> 
#include <Zerror.h>

struct timezone { int  tz_minuteswest; /* minutes west of Greenwich */
                  int  tz_dsttime;     /* type of dst correction */
                };

struct tms {
        clock_t tms_utime;              /* user time */
        clock_t tms_stime;              /* system time */
        clock_t tms_cutime;             /* user time, children */
        clock_t tms_cstime;             /* system time, children */
};

#endif 

#endif 
