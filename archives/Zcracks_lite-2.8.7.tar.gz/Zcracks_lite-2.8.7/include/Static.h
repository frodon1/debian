#ifndef __PROBLEM_STATIC_MECHANICAL__
#define __PROBLEM_STATIC_MECHANICAL__

#include <string.h>

#include <Object_factory.h>
#include <Calcul_timer.h>
#include <File.h>
#include <Stringpp.h>

#include <Contact.h>
#include <Element.h>
#include <Global_matrix.h>
#include <Mesh.h>
#include <Output.h>
#include <Problem.h>	
#include <Problem_mechanical.h>	
#include <Random_distribution.h>
#include <Sequence.h>

Z_START_NAMESPACE;

class INTEGRATION_RESULT;

ZCLASS2 PROBLEM_STATIC_MECHANICAL : public PROBLEM_MECHANICAL {
  public :
      PROBLEM_STATIC_MECHANICAL();
      virtual ~PROBLEM_STATIC_MECHANICAL();

      virtual bool Initialize();
      virtual bool verification();
      virtual bool Execute();

      // virtual bool end_problem();
      virtual bool make_increment(double);
      virtual void reinit();
      virtual GLOBAL_MATRIX* give_matrix();

      virtual void reset_global_matrix(); 

      RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
