#ifndef __Viscous_fluid_behavior__
#define __Viscous_fluid_behavior__

Z_START_NAMESPACE;

ZCLASS2 VISCOUS_FLUID_BEHAVIOR : public BEHAVIOR {
  protected : 
      TENSOR2_FLUX sig;
      TENSOR2_GRAD deto;
      SCALAR_VAUX  pval, vmag, divv;
  
      COEFF density;
      COEFF penalty;

      bool base_coef_read(STRING&, ASCII_FILE& file);
  
  public:
      VISCOUS_FLUID_BEHAVIOR(); 
      virtual ~VISCOUS_FLUID_BEHAVIOR(); 


      virtual void initialize(ASCII_FILE&,int,LOCAL_INTEGRATION*);
};      
Z_END_NAMESPACE;

#endif
