#include <stdio.h>
#include <math.h>

#include <meshgems/meshgems.h>
#include <meshgems/cadsurf.h>

#define PI 3.141592

double segments[16] = {
  -2.5,  2.5,  2.5, -2.5,
  -2.5, -2.5,  2.5,  2.5,
  2.5,  2.5, -2.5, -2.5,
  -2.5,  2.5,  2.5, -2.5,
};



status_t surf(real *uv, real *xyz,
	      real*du, real *dv,
	      real *duu, real *duv, real *dvv,
	      void *user_data )
{
  real sgn = *((real*)user_data);
  
  real u = uv[0];
  real v = uv[1];
  
  if(xyz){
    xyz[0] = u;
    xyz[1] = v;
    xyz[2] = sgn*(u*u + v*v) / 2;
  }
  
  if(du && dv) {
    du[0] = 1; du[1] = 0; du[2] = sgn*u;
    dv[0] = 0; dv[1] = 1; dv[2] = sgn*v;
  }
  
  if(duu && duv && dvv){
    duu[0] = 0; duu[1] = 0; duu[2] = sgn*1;
    duv[0] = 0; duv[1] = 0; duv[2] = 0;
    dvv[0] = 0; dvv[1] = 0; dvv[2] = sgn*1;
  }
  
  return STATUS_OK;
}


status_t curv(real t, real *uv,
	      real*dt, real *dtt,
	      void *user_data )
{
  integer ic = *((integer*)user_data);
	
  if(uv){
    if(ic >4){
      /* the internal curve */
      uv[0] = 2*cos(t);
      uv[1] = 2*sin(t);
    } else {
      uv[0] = segments[ic-1] +  t*(segments[ic+ 7] - segments[ic-1]);
      uv[1] = segments[ic+3] +  t*(segments[ic+11] - segments[ic+3]);
    }
  }
  
  if(dt){
    if(ic > 4){
      /* the internal curve */
      dt[0] = -2*sin(t);
      dt[1] = 2*cos(t);
    } else {
      dt[0] = segments[ic+ 7] - segments[ic-1];
      dt[1] = segments[ic+11] - segments[ic+3];
    }
  }
  
  if(dtt){
    if(ic > 4){
      /* the internal curve */
      dtt[0] = -2*cos(t);
      dtt[1] = -2*sin(t);
    } else {
      dtt[0] =  0;
      dtt[1] =  0;
    }
  }
  
  return STATUS_OK;
}
 

status_t my_message_cb(message_t *msg, void *user_data)
{
  FILE *f = (FILE*) user_data;
  char *desc;
  
  message_get_description(msg, &desc);
  fprintf(f, "cadsurf message : %s", desc);
  
  return STATUS_OK;
}

status_t size_on_curve(integer eid, real t, real *size, void *user_data)
{
  if(eid == 1){
    *size = 0.1;
  } else if(eid == 3){
    *size = 0.3;
  } else if(eid == 9){
    /* for the internal curve */
    *size = 0.1;
  } else {
    *size = 0.7;
  }

  return STATUS_OK;
}

status_t size_on_face(integer face_id, real *uv, real *size, void *user_data)
{
  if(face_id == 2){
    /* set size for face with id == 2 */
    *size = 0.4;
  } else {
    *size = 0.6;
  }
  
  return STATUS_OK;
}

int main(int argc, char **argv)
{
  context_t *ctx = NULL;
  cadsurf_session_t *css = NULL;
  cad_t *c = NULL;
  mesh_t *msh = NULL;
  integer i,j,i0,i1,i2,i3,i4;
  real s0,s1;
  real uv[2];
  cad_face_t *f;
  cad_edge_t *e;
  cad_point_t *p;
  sizemap_t *iso_sizemap_e, *iso_sizemap_f;

  ctx = context_new();
  context_set_message_callback(ctx, my_message_cb, stdout);
  
  css = cadsurf_session_new(ctx);
  c = cad_new(ctx);
  
  /* CAD descripion */
  s0 = 1;
  s1 = -1;
  i0=1;
  i1=2;
  i2=3;
  i3=4;
  i4=5;

  f = cad_face_new(c, 1, surf, &s0);
  cad_face_set_tag(f, 1);
  e = cad_edge_new(f, 1, 0, 1, curv, &i0);
  cad_edge_set_extremities(e, 1, 2);
  e = cad_edge_new(f, 2, 0, 1, curv, &i1);
  cad_edge_set_extremities(e, 2, 3);
  e = cad_edge_new(f, 3, 0, 1, curv, &i2);
  cad_edge_set_extremities(e, 3, 4);
  e = cad_edge_new(f, 4, 0, 1, curv, &i3);
  cad_edge_set_extremities(e, 4, 1);

  f = cad_face_new(c, 2, surf, &s1);  
  cad_face_set_tag(f, 2);
  e = cad_edge_new(f, 5, 0, 1, curv, &i0);
  cad_edge_set_extremities(e, 5, 6);
  e = cad_edge_new(f, 6, 0, 1, curv, &i1);
  cad_edge_set_extremities(e, 6, 7);
  e = cad_edge_new(f, 7, 0, 1, curv, &i2);
  cad_edge_set_extremities(e, 7, 8);
  e = cad_edge_new(f, 8, 0, 1, curv, &i3);
  cad_edge_set_extremities(e, 8, 5);
 
  /* Create some internal points */
  for(i=0;i<=4;i++){
    for(j=0;j<=3;j++){
      uv[0] = 0.0 + 0.1*i;
      uv[1] = 0.0 + 0.1*j;
      p = cad_point_new(f, (i+1)+10*(j+1), uv);
    }
  }
  
  e = cad_edge_new(f, 9, 0, 2*PI, curv, &i4);
  cad_edge_set_property(e, EDGE_PROPERTY_INTERNAL);
  
  /* Give everything to the session */
  cadsurf_set_cad(css, c);

  iso_sizemap_e = sizemap_new(c, meshgems_sizemap_type_iso_cad_edge, size_on_curve, NULL);
  iso_sizemap_f = sizemap_new(c, meshgems_sizemap_type_iso_cad_face, size_on_face, NULL);

  cadsurf_set_sizemap(css, iso_sizemap_e);
  cadsurf_set_sizemap(css, iso_sizemap_f);

  cadsurf_set_param(css, "verbose", "3");
  cadsurf_set_param(css, "geometric_size_mode", "none");
  cadsurf_set_param(css, "physical_size_mode", "local");
  cadsurf_set_param(css, "min_size", "0.05");
  cadsurf_set_param(css, "max_size", "2");
  cadsurf_set_param(css, "global_physical_size", "5");
  cadsurf_set_param(css, "gradation", "1.4");
  /* The topology is correct and complete : keep it as it is */
  cadsurf_set_param(css, "discard_input_topology", "no");
  cadsurf_set_param(css, "process_3d_topology", "no");

  /* mesh */
  cadsurf_compute_mesh(css);
  
  /* get the resulting mesh */
  cadsurf_get_mesh(css, &msh);
  if(msh){
    /* write it to a .mesh file (for medit visualisation tool) */
    mesh_write_mesh(msh, "aa.mesh");
  }	
  
  /* release it */
  cadsurf_regain_mesh(css, msh);
  
  /* clean up everything */
  sizemap_delete(iso_sizemap_e);
  sizemap_delete(iso_sizemap_f);
  cadsurf_session_delete(css);
  cad_delete(c);
  context_delete(ctx);

  return 0;
}
