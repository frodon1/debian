#ifndef __GP_interaction_matrix__
#define __GP_interaction_matrix__

#include <Defines.h> 
#include <Aaa_zmat_globals.h>

Z_START_NAMESPACE;

class BAND_MATRIX; class ELSET; class VECTOR;

WIN_THINGIE2 void GP_interaction_matrix(BAND_MATRIX& , double Lc, const ELSET& , 
                           double (*func)(const VECTOR&) ,
                           bool normalize=TRUE);
Z_END_NAMESPACE;

#endif
