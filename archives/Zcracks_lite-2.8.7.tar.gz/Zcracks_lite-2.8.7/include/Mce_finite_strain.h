#ifndef __Mce_finite_strain__
#define __Mce_finite_strain__

#include <ZMath.h>
#include <Error_messager.h>
#include <Integration_result.h>
#include <Mechanical_behavior.h>
#include <Mesh.h>
#include <Mechanical_volume_element.h>
#include <Rotation.h>
#include <Space.h>
#include <Utility.h>
#include <Verbose.h>
#include <Bool.h>
#include <ZMath.h>

Z_START_NAMESPACE;

ZCLASS2 MCE_FINITE_STRAIN : public MECHANICAL_VOLUME_ELEMENT {       
 public :
   enum FORMULATION_TYPE { UNDEFINED, UPDATED, TOTAL, FINAL };
 protected :
    bool Bbar, control_locking;
    ARRAY<MATRIX> BA,BB,BC,BD; // to control locking, if needed

//
// To reset reference configuration for remeshing
//
    ARRAY<TENSOR2_VAUX*> Fini,Fini0;

    bool time_for_pressure(APPLICATION_MESSAGE*);
    bool prepare_for_grad_ini(APPLICATION_MESSAGE*);
    bool set_grad_ini(APPLICATION_MESSAGE*);
    bool reset_for_grad_ini(APPLICATION_MESSAGE*);

    static FORMULATION_TYPE get_type(const char* ele_name);
    FORMULATION_TYPE lagrange_type;


    bool compute_B_external(APPLICATION_MESSAGE* msg);

    virtual void compute_BF(const MATRIX& dshape_dx, MATRIX& BF);
    virtual void compute_Be(const MATRIX& dshape_dx, MATRIX& Be);

    virtual void compute_BE(const VECTOR& Ut,const MATRIX& BF,const MATRIX& Be,MATRIX& BE);

    virtual void compute_F(const MATRIX& BF0,
                           const MATRIX& BF,
                           const VECTOR& dof, 
                           const VECTOR& ddof,
                           TENSOR2& F,
                           TENSOR2& dF,
                           TENSOR2& delta_F);

    virtual void compute_BEt_S(const MATRIX& BE,const TENSOR2& pk2, VECTOR& BEt_S);

    virtual void compute_BEt_D_BE(const MATRIX& BE,
                                  const MATRIX& D, 
                                  MATRIX&       BEt_D_BE);

    virtual void compute_NLSM(const MATRIX&,const TENSOR2&,MATRIX&);
    virtual bool if_periodic(int&)const;
    virtual bool modif_dV(double&,const VECTOR&,const VECTOR&);
    void move_coord(const VECTOR&, const VECTOR&, const MATRIX&, MATRIX&);
    TENSOR4 transport_D_PK_to_cauchy(const TENSOR4&,const TENSOR2&);
    TENSOR4 transport_D_cauchy_to_PK(const TENSOR4&,const TENSOR2&);
    TENSOR2 transport_cauchy_to_PK(const TENSOR2&,const TENSOR2&);
    TENSOR2 transport_PK_to_cauchy(const TENSOR2&,const TENSOR2&);

    bool enable_locking_control(APPLICATION_MESSAGE*);

    void update_for_unlocking(const int stage, const int what, const MATRIX &elem_coord, MATRIX &B);

    const int*  get_BE_idx(); 
    const int*  get_BEt_idx(); 

 public :

    MCE_FINITE_STRAIN(); 
    virtual ~MCE_FINITE_STRAIN();
    virtual INTEGRATION_RESULT* internal_reaction(bool, VECTOR& , SMATRIX& ,bool);
    virtual bool verification();
    ASK_INFO;
};

Z_END_NAMESPACE;
#endif

