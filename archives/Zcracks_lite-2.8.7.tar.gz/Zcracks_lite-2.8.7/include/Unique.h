#ifndef __SORT_UNIQUE__
#define __SORT_UNIQUE__

#define STACK_SIZE 2048

// this is a non-recursive qsort algo using an explicit stack
// templates and functor are used instead of classic function pointers and void*
template<class T, class COMP> void sort(T* V, int sz, COMP& cmp){
   struct _STACK {
      int stack[STACK_SIZE][2];
      int top;
   } stk;
   // initialize
   stk.top = 0;
   stk.stack[stk.top][0]=0;
   stk.stack[stk.top][1]=sz-1; 
   do {
      int left  = stk.stack[stk.top][0];
      int right = stk.stack[stk.top][1];
      stk.top--;
      // use a qsort algo for big arrays
      while ((right-left) > 6) {
         // choose pivot as a median of 3 elements, and let V[left] hold the median 
         int mid = ((left+right)/2);
         if (cmp.is_less(left,mid)) cmp.swap(left, mid);
         if (cmp.is_less(right,left)) {
            cmp.swap(right, left);
            if (cmp.is_less(left,mid)) cmp.swap(left, mid);
         }
         // scan for the final position of actual pivot (where _l and _r cross)
         int _l = left+1;
         int _r = right;
         do {
            while(cmp.is_less(_l,left)) _l++;
            while(cmp.is_less(left,_r)) _r--;
            if (_l < _r) {
               cmp.swap(_l, _r);
               _l++; _r--;
            } else break;
         } while(1); 
         // move pivot to its final position
         cmp.swap(left, _r);
         // set up for next iteration, push longest part on stack and reset for shortest
         stk.top++; 
         if((_r-left)<(right-_r)){
            stk.stack[stk.top][0]=_r+1;
            stk.stack[stk.top][1]=right;
            right = _r-1;
         } else {
            stk.stack[stk.top][0]=left;
            stk.stack[stk.top][1]=_r-1;
            left = _r+1;
         }
      }
      // use an insertion sort for smaller arrays
      for (int i = left+1; i< right+1; i++){
         for (int j = i; (j> left) && cmp.is_less(j,j-1); j--) cmp.swap(j, j-1);
      }
   } while(stk.top>-1);
}


// a unique function remove all duplicates in a sorted vector
template<class T, class COMP> void unique(T* V, int sz, int& u_sz, COMP& cmp){
   sort<T, COMP>(V, sz, cmp);
   // keep unique occurences
   u_sz = 0;
   for (int i=1; i<sz;i++) {
      if (cmp.is_eq(u_sz,i)) continue;
      u_sz++;
      cmp.assign(u_sz,i);
   }
   u_sz++;
}

// a template function that provide a generic comparison
// implement yours to :
// - compare data member of object if T is a complex class
// - performe advanced assignement (perhaps copy constructor of T not provided)
template<class T> class COMPARE {
   private :
      T* V;
   public : 
      COMPARE(T* in) : V(in) {}
      // comparison
      inline bool is_less(int a, int b) {return (V[a] < V[b]);}
      inline bool is_eq(int a, int b)  {return (V[a] == V[b]);}
      // assignement
      inline void assign(int a, int b) {V[a] = V[b];}
      inline void swap(int a, int b) { T _hold=V[a]; V[a]=V[b]; V[b]=_hold;}
};


#undef STACK_SIZE

#endif
