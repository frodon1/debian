This document gives some hints on how you can compile the mg-adapt_example.c

First, copy the corresponding dynamic libraries and the meshgems include directory in this directory.

Then, run 

      * ./compile.sh on a Linux platform
or 
      * compile.bat on a Windows platform

A mg-adapt_example.exe executable will be created in this
directory. It expects 3 command line arguments:
   * the input mesh to be adapted
   * the basename of the background mesh and size. For example, the
     basename "base" corresponds to "size.mesh" and "size.sol"
   * the output adapted mesh
