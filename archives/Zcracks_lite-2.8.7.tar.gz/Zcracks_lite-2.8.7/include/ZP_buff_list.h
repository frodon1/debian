#ifndef __ZP_Buffered_list__
#define __ZP_Buffered_list__

#include <string.h>
#include <List.h>
#include <Defines.h>
#include <Buffered_list.h>

Z_START_NAMESPACE;

// 
// RF removed ZCLASS 04/10/2006 for VC.NET
// JDG 2012/04/25 ZP_BUFF_LIST provides nothing more than the usual BUFF_LIST, 
// so I just say it's the same

#define ZP_BUFF_LIST BUFF_LIST 

Z_END_NAMESPACE;

#endif
