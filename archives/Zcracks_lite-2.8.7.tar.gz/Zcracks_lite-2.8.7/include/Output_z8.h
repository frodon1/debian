#ifndef __Output_z8__
#define __Output_z8__

// ============================================================================  
//  Z8.4 Output structure  RF June 2001.... Apr 2003 
// 
//  Classes : 
// 
//  UTILITY_FILE_DRIVER    abstract class which actually handles the writing 
//                         to file(s). There are 2 basic ones to be made.. 
//                         a directory structure one which is very open and 
//                         easy to manipulate, and a single file equivalent. 
//                         The idea is to re-use that for res db in writing posts 
// 
//                         this class should handle parallel mixing of the output!!
//                         
//                         ** THe class is INPUT/OUTPUT! ** shared with the utility 
//                         database. 
// 
//  OUTPUT_COMPONENT       See Output_component.h ...  used for each output chore 
//                         so normally this output class doesn't get touched to 
//                         add a new output type.. e.g. **contour
//                         **value_at_integration.. etc
// 
//  OUTPUT_Z8              a main manager of the output .. this interfaces with 
//                         the different output components. 
// 
// 
//  All output files are always placed in:
//       dir <prob>.zres for the open dir structure 
//       dir <prob>.zbres for single binary (filesystem like) equivalent 
//
//  ** nothing gets output by default ** 
//  
// ============================================================================  

#include <Output.h>
#include <Utility_file_driver.h>
#include <Output_component.h>

Z_START_NAMESPACE;

ZCLASS2 OUTPUT_Z8 : public OUTPUT {
 protected :
     int     nb_output; 
     STRING  dir_name; 
     STRING  def_mesh_form; 
     int     local_increment; 
     bool    parallel_master;
     LIST<int> parallel_friends;
     int     parallel_boss;

     LIST<MATERIAL_PIECE_VARIABLE_KEY*> output_keys;
 

     MESH*   curr_mesh;        // checks if the mesh has changed between outputs 
     int     curr_mesh_id;     // index for the mesh file 

     void write_geo(MESH& mesh); 
     void setup_records(); 

 public :
//
// List of components for output. An OUTPUT_COMPONENT is an abstract object able to store something
// in the result database. This class (see Output_component.h) supports reading *AND* writing in the database
// (it is used by the associated UTILITY_Z8_RESULTS_DATABASE).
//
     LIST<OUTPUT_COMPONENT*> components; 

     UTILITY_FILE_DRIVER* root_driver; 
     UTILITY_FILE_DRIVER* driver; 
     MESH* its_mesh; 

     OUTPUT_Z8(); 
     virtual ~OUTPUT_Z8();

     virtual void initialize(PROBLEM* pb, ASCII_FILE* inp);
     virtual bool base_read(STRING,ASCII_FILE&); 

     virtual void open_files(MODE m=OPEN);
     virtual void close_files();

     virtual void write_output(MESH& mesh,ARRAY<BEHAVIOR*>& behavior);
     virtual void setup(ARRAY<BEHAVIOR*>&,MESH& mesh,RESTARTER::MODE lrestart_mode,int io, bool rescan=FALSE); 

     virtual void increment_output(MESH& mesh,ARRAY<BEHAVIOR*>& behavior, bool skip_restart = FALSE); 

     virtual void read_restart_phase_1(RST_FSTREAM&);
     virtual void write_restart_phase_1(RST_FSTREAM&);

     RTTI_INFO;
};

Z_END_NAMESPACE;
#endif   

