//
// Gosselet 2004, Generic iterative solvers (mostly used with generic_dd)
// see P. Gosselet thesis (2003), nice paper soon
//
//  Krylov solvers with acceleration ability based on the storage of previous subspaces
//
#ifndef __DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER__
#define __DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER__

#include <DD_krylov_solver.h>

Z_START_NAMESPACE;


class DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER_PARAMETER : public DD_ITERATIVE_SOLVER_PARAMETER {
  public:
    DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER_PARAMETER(){type_of_base_solver="undefined";base_solver_parameter=NULL;eps_srks=1.e-11;selection_type="basic";}
    STRING type_of_base_solver;
    STRING selection_type;
    double eps_srks;
    DD_KRYLOV_ITERATIVE_SOLVER_PARAMETER *base_solver_parameter;
    virtual bool GetResponse(STRING&,ASCII_FILE&);
    RTTI_INFO;
};

class DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER : public DD_ITERATIVE_SOLVER {
  protected :
    DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER_PARAMETER *parameters;
    DD_KRYLOV_ITERATIVE_SOLVER *base_solver;
    BUFF_LIST<DD_KRYLOV_SUBSPACE*> subspaces;
    Zfstream inout;
    int nsyst;
    void import_mat();
    void export_mat();

  public :
    DD_MATRIX* Caugm;
    DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER() { base_solver=NULL; parameters=NULL;nsyst=0; Caugm=NULL;}
    virtual ~DD_ACCELERATED_KRYLOV_ITERATIVE_SOLVER() { if (base_solver) delete(base_solver); for (int i=0;i<subspaces.size();++i) delete(subspaces[i]);}
    virtual void set_parameter(SOLVER_PARAMETER *p);
    virtual void handle_augmentation(){DD_ITERATIVE_SOLVER::handle_augmentation();if(base_solver->parameters->selec){Caugm->set_to_zero(); base_solver->give_me_augmentation(Caugm);}};
    virtual void set_operator(DD_FULL_FETI *p);
    RTTI_INFO;

};
Z_END_NAMESPACE;

#endif
