#include <Remeshing_criterion.h>
#include <Stringpp.h>
#include <Discrete_timer.h>
#include <Print.h>

Z_START_NAMESPACE;

class REMESH_WHEN_ERROR : public REMESHING_CRITERION
{
  protected :
  double limit_error,min_size;
  int nb_dt, max_nb_elem;
  STRING filename,metric_file_name;
  bool reequilibrium, layer_extension,set_reduced;
  LIST<UTILITY_ELSET*> list_pli;
  
  public :
    REMESH_WHEN_ERROR() : REMESHING_CRITERION() { limit_error=0.;nb_dt=-1;max_nb_elem=-1; reequilibrium=FALSE;   filename="";layer_extension=FALSE; set_reduced=FALSE; list_pli.resize(0);metric_file_name=="";}
    virtual ~REMESH_WHEN_ERROR() { }
    virtual bool GetResponse(STRING &key, ASCII_FILE &inp);
    virtual bool time_for_remesh(const MESH&);
};

Z_END_NAMESPACE;
