#ifndef __BATCH_LEXER_ENTRY__
#define __BATCH_LEXER_ENTRY__

#include <Master_interactive_lexer_control.h>
#include <Stringpp.h>

Z_START_NAMESPACE;

class INTERACTIVE_LEXER_PB;
class ZP_PROGRAM_ITEM;

class BATCH_LEXER_ENTRY : public MASTER_INTERACTIVE_LEXER_CONTROL
{
  public :
    BATCH_LEXER_ENTRY();
    virtual ~BATCH_LEXER_ENTRY();
};
Z_END_NAMESPACE;

#endif
