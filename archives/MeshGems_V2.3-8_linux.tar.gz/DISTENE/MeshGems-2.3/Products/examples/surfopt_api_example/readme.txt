This document gives some hints on how to compile and run the MG-SurfOpt example

*** Preparation ***

First, copy the meshgems include directory in this directory.

Second, copy all the necessary dynamic libraries in this directory as well.
The necessary libraries are: mg-surfopt, mg-tetra, meshgems, meshgems_stubs

On a Linux platform, make sure LD_LIBRARY_PATH contains ., the current
directory, as it may be necessary to produce an executable and it is necessary
to run the example executable.

*** Compilation ***

Then, run:

      * ./compile.sh on a Linux platform
or 
      * compile.bat on a Windows platform

A mg-surfopt_example.exe executable will be created in this directory.

*** Execution ***

To run the MG-SurfOpt example, type:

	mg-surfopt_example.exe filein.mesh [fileout.mesh]

where filein.mesh is an input mesh and fileout.mesh is an optional name for the
output mesh.
