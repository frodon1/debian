1) Introduction

The MeshGems API provides an MPI stub system that allows the integrator to
use the MPI flavour of his choice.

2) How it works

All MPI functions are called by MeshGems libraries through a wrapper function
prefixed with "meshgems_". These functions are provided by a separate dynamic
library (libmeshgems_mpi.so on Linux platforms and meshgems_mpi.dll on
Windows platforms) for which we provide the source code, so that the
integrator can re-compile them.

3) How to use

The file stubs/meshgems_mpi.c defines the implementation of the MPI function
wrapper. The integrator should not modify them but only recompile this file
innto a dynamic MPI stubs implementation library :

   a) on Linux platforms : The command

      mpicc -m64 -fPIC -shared -I../include -DMESHGEMS_LINUX_BUILD meshgems_mpi.c  -o libmeshgems_mpi.so

    will produce the libmeshgems_mpi.so dynamic library for 64 bit
    architecture (replace -m64 by -m32 for 32bit)

   b) The Windows platforms are untested by Distene for MPI so we do not provide any instruction.

This dynamic library shall replace the existing one provided with MeshGems
dynamic libraries.
