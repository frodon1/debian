#ifndef __ANALYSE_BIFURCATION__
#define __ANALYSE_BIFURCATION__

#include <Utility.h>
#include <Simplex_tools.h>
#include <Tensor4.h>
#include <Print.h>

Z_START_NAMESPACE;

class ANALYSE_BIFURCATION : public SIMPLEX_TOOLS {
  protected :
     virtual double Fsimplex(const VECTOR&);
     int dim, tsz, utsz;
     TENSOR4 De;
     TENSOR2 lsig; bool if_nl, if_sym;
     void compute_n_rad(VECTOR&,double theta,double phi = M_PI/2.);
     SMATRIX nDn(const TENSOR4& L, const TENSOR1& n );
     SMATRIX nDn_1d(const TENSOR4& L, const TENSOR1& n );
     SMATRIX nDn_2d(const TENSOR4& L, const TENSOR1& n );
     SMATRIX nDn_3d(const TENSOR4& L, const TENSOR1& n );
     void compute_g(const SMATRIX& nLn, TENSOR1& g);
  public :
     ANALYSE_BIFURCATION() {}
     virtual ~ANALYSE_BIFURCATION() {}
     void analyse(const TENSOR4& D, const TENSOR2* sig, VECTOR& angle, TENSOR1& n, TENSOR1& g, double& det_min,bool symmetrize=FALSE);
};
Z_END_NAMESPACE;

#endif
