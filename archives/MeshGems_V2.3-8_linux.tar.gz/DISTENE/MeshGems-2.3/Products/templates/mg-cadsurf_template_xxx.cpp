/*
 * Integration template into a generic CAD engine.
 * This file describes how to import a geometry into the 
 * meshgems cad_t structure. The function generate_mesh defined in 
 * mg-cadsurf_template_common.cpp is then called to build a 
 * surface mesh using MG-CADSurf.
 */

#define CREATE_DCAD 0
#define IMPORT_WIRE 0
#define CREATE_PERIODICITY 0

#include <stdio.h>
#include <iostream>
#include <list>
#include <vector>
#include <map>
#include <assert.h>

extern "C" {                    // if c++
#include <meshgems/meshgems.h>
}

// if c++
status_t generate_mesh(context_t * ctx, cad_t * c, dcad_t * dc,
		       mesh_t * msh);

/* Surface definition function.
 * See cad_surf_t in file meshgems/cad.h for more information.
 * NOTE : if when your CAD systems evaluates second order derivatives it also
 * computes first order derivatives and function evaluation, you can optimize 
 * this example by making only one CAD call and filling the necessary xyz, du, dv, etc.. 
 * arrays.
 */
static status_t surf_function(real * uv, real * xyz, real * du, real * dv,
                              real * duu, real * duv, real * dvv,
                              void *user_data)
{
  /* uv[2] is given. It contains the u,v coordinates of the point
   * MG-CADSurf is querying on the surface */

  /* user_data identifies the face MG-CADSurf is querying (see
   * cad_face_new later in this example)*/

  your_cad_face_type *your_cad_face = (your_cad_face_type *) user_data;

  if (duu && duv && dvv) {
    /* query for the second order derivatives */
    your_buffer = your_cad_face->Deriv(uv, 2);

    duu[0] =...;
    duu[1] =...;
    duu[2] =...;
    duv[0] =...;
    duv[1] =...;
    duv[2] =...;
    dvv[0] =...;
    dvv[1] =...;
    dvv[2] =...;
  }

  if (du && dv) {
    /* query for the first order derivatives */
    your_buffer = your_cad_face->Deriv(uv, 1);
    du[0] =...;
    du[1] =...;
    du[2] =...;
    dv[0] =...;
    dv[1] =...;
    dv[2] =...;
  }

  if (xyz) {
    /* query for the function evaluation */
    your_buffer = your_cad_face->Eval(uv);
    xyz[0] =...;
    xyz[1] =...;
    xyz[2] =...;
  }

  if (a problem occured while querying you CAD system)
    return STATUS_ERROR;

  return STATUS_OK;
}

/* Curve definition function. See cad_curv_t in file meshgems/cad.h for
 * more information.
 * NOTE : if when your CAD systems evaluates second
 * order derivatives it also computes first order derivatives and
 * function evaluation, you can optimize this example by making only
 * one CAD call and filling the necessary uv, dt, dtt arrays.
 */
static status_t curv_function(real t, real * uv, real * dt, real * dtt,
                              void *user_data)
{
  /* t is given. It contains the t 1D parametric coordinates
   * of the point MG-CADSurf is querying on the curve */

  /* user_data identifies the edge MG-CADSurf is querying
   * (see cad_edge_new later in this example) */

  your_cad_edge_type *your_cad_edge = (your_cad_edge_type *) user_data;

  if (dtt) {
    /* query for the second order derivatives */
    your_buffer = your_cad_edge->Deriv(t, 2);
    dtt[0] =...;
    dtt[1] =...;
  }

  if (dt) {
    /* query for the first order derivatives */
    your_buffer = your_cad_edge->Deriv(t, 1);
    dt[0] =...;
    dt[1] =...;
  }

  if (uv) {
    /* cadsurf is querying the function evaluation */
    your_buffer = your_cad_edge->Eval(t);
    uv[0] =...;
    uv[1] =...;
  }

  if (a problem occured while querying you CAD system)
    return STATUS_ERROR;

  return STATUS_OK;
}

/* Curve definition function without derivatives. This one is used when the
 * internal curve representation does not provide derivatives. For
 * example for curves defined with reverse projection from XYZ space
 * to UV space.
 */
static status_t curv0_function(real t, real * uv, real * dt, real * dtt,
                               void *user_data)
{
  /* t is given. It contains the t (time) 1D parametric coordinates
     of the point MG-CADSurf is querying on the curve */

  /* user_data identifies the edge MG-CADSurf is querying
   * (see cad_edge_new later in this example)
   */

  your_cad_edge_type *your_cad_edge = (your_cad_edge_type *) user_data;

  /* MG-CADSurf will not ask for the first or second order
   * derivatives as long as the cad_edge_t is created with
   * cad_edge_new0()
   */

  if (uv) {
    /* MG-CADSurf is querying the function evaluation */
    your_buffer = your_cad_edge->Eval(t);
    uv[0] =...;
    uv[1] =...;
  }

  if (a problem occured while querying you CAD system)
    return STATUS_ERROR;

  return STATUS_OK;
}

/* Wire curve definition function. See cad_curv3d2_t in file meshgems/cad.h for
 * more information.
 * NOTE : if when your CAD systems evaluates second
 * order derivatives it also computes first order derivatives and
 * function evaluation, you can optimize this example by making only
 * one CAD call and filling the necessary xyz, dt, dtt arrays.
 */
static status_t curv3d2_function(real t, real * xyz, real * dt, real * dtt,
                                 void *user_data)
{
  /* t is given. It contains the t 1D parametric coordinates
   * of the point MG-CADSurf is querying on the wire */

  /* user_data identifies the wire MG-CADSurf is querying
   * (see cad_wire_new later in this example) */

  your_cad_wire_type *your_cad_wire = (your_cad_wire_type *) user_data;

  if (dtt) {
    /* query for the second order derivatives */
    your_buffer = your_cad_wire->Deriv(t, 2);
    dtt[0] =...;
    dtt[1] =...;
  }

  if (dt) {
    /* query for the first order derivatives */
    your_buffer = your_cad_wire->Deriv(t, 1);
    dt[0] =...;
    dt[1] =...;
  }

  if (xyz) {
    /* query for the function evaluation */
    your_buffer = your_cad_wire->Eval(t);
    xyz[0] =...;
    xyz[1] =...;
    xyz[2] =...;
  }

  if (a problem occured while querying you CAD system)
    return STATUS_ERROR;

  return STATUS_OK;
}

/*
 * This function specifies a transformation between two sets of face you
 * want to make periodic.  xyz contains the coordinates of a point.
 * The coordinates of the image are stored in xyz_image.  See
 * meshgems_cad_periodicity_transformation_t in meshgems/cad.h for
 * information about the function parameters
 */
static status_t periodicity_transformation(real * xyz, real * xyz_image,
                                           void *user_data)
{
  real *r = (real *) user_data;
  for (i = 0; i < 3; i++)
    xyz_image[i] = xyz[i] + (*r);

  return STATUS_OK;
}

/* This function generates the mesh of a geometry */
static status_t import_xxx_geometry(your_cad_body, context_t * ctx,
                                    cad_t ** pc, dcad_t ** pdc)
{
  status_t ret;
  cad_t *c = 0;
  dcad_t *dc = 0;
  cad_vertex_t *v = 0;

  assert(ctx);

  /* create the CAD object we will work on. It is associated to the context ctx. */
  c = cad_new(ctx);
  if (!c)
    return STATUS_NOMEM;

  if (CREATE_DCAD) {
    dc = dcad_new(c);
    if (!dc)
      return STATUS_NOMEM;
  }

  /* Now fill the CAD object with data from your CAD
   * environment. This is the most complex part of a successfull
   * integration.
   * See the documented meshgems/cad.h file for more information.
   */

  for each
    face your_face in your CAD body {
    /* create an object representing the face for cadsurf */
    cad_face_t *f =
        cad_face_new(c, face_id, surf_function, your_face_object_ptr);
    if (!f)
      return STATUS_NOMEM;
    /* where face_id is an integer identifying the face.
     * surf_function is the function that defines the surface (For
     * this face, it will be called by cadsurf with
     * your_face_object_ptr as last parameter.
     */

    /* by default a face has no tag (or attribute). The following call
     * sets it : */
    ret = cad_face_set_tag(f, your_face_tag);
    if (ret != STATUS_OK)
      return ret;

    /* The uid (unique identifier) will help you identify each cad
     * entity if you want to query the generated mesh vertices for
     * their location on the cad entities (faces or edges) by default
     * a face has no uid. The following call sets it : */
    ret = cad_face_set_uid(f, your_face_uid);
    if (ret != STATUS_OK)
      return ret;

    /* Set the face orientation for correct triangle normals
     * orientation in the generated mesh.
     * The "forward" orientation corresponds to the same orientation as 
     * "direct in UV space and projected to XYZ space by the cad face 
     * parameterization".
     */
    if (...) {
      ret = cad_face_set_orientation(f, CAD_ORIENTATION_REVERSED);
      if (ret != STATUS_OK)
        return ret;
    } else {
      ret = cad_face_set_orientation(f, CAD_ORIENTATION_FORWARD);
      if (ret != STATUS_OK)
        return ret;
    }

    /* set surface parametric range and periodicity properties of the
     * surface on which the face lies. For example if the face is a
     * portion of a cylinder, these 2 properties will be given for the
     * whole cylinder surface.
     *
     * The surface parametric range is the principal intervalle U and
     * V belong to in the UV space domain.
     *
     * The periodicity is given in both U and V direction. The period
     * pu in U is defined as the smallest real such that
     * surf(u,v) = surf(u+pu,v)
     * Please also note that if a face is periodic in a
     * direction, its surf function must be defined for any real value
     * in this direction.
     *
     *
     * NOTE : these properties are only usefull for MG-CADSurf if you want
     * it to treat and close the CAD patches which are not closed in
     * the UV domain space (mainly periodic faces or faces build on a
     * periodic surface, like a cylinder piece). If all your CAD faces
     * are already closed in UV domain, you do not need to set these
     * properties.
     *
     */

    real ru[2], rv[2];
    ru[0] = -REAL_INFINITY;
    ru[1] = REAL_INFINITY;
    if (surface param range in U is bounded below) {
      ru[0] =...;
    }
    if (surface param range in U is bounded above()) {
      ru[1] =...;
    }
    rv[0] = -REAL_INFINITY;
    rv[1] = REAL_INFINITY;
    if (surface param range in V is bounded below) {
      rv[0] =...;
    }
    if (surface param range in V is bounded above()) {
      rv[1] =...;
    }
    ret = cad_face_set_surface_parametric_range(f, ru, rv);
    if (ret != STATUS_OK)
      return ret;

    integer periodic_u, periodic_v;
    real period_u, period_v;
    if (the surface is periodic in U direction) {
      periodic_u = 1;
      period_u = (surface period in U direction);
    } else {
      periodic_u = 0;
      period_u = 0;
    }
    if (the surface is periodic in V direction) {
      periodic_v = 1;
      period_v = (surface period in V direction);
    } else {
      periodic_v = 0;
      period_v = 0;
    }
    ret =
        cad_face_set_surface_periodicity(f, periodic_u, periodic_v,
                                         period_u, period_v);
    if (ret != STATUS_OK)
      return ret;

    /* now create the edges associated to this face */
    for each
      boundary edge your_edge on your_face {
      /* attach the edge to the current cadsurf face */

      cad_edge_t *e = 0;
      if (this edge is defined by reverse projection
          or if we don 't know it' s derivatives
          or if queries on it are too expensive) {
        e = cad_edge_new0(f, edge_id, tmin, tmax,
                          curv0_function, your_edge_object_ptr);
        if (!e)
          return STATUS_NOMEM;
      } else {
        e = cad_edge_new(f, edge_id, tmin, tmax,
                         curv_function, your_edge_object_ptr);
        if (!e)
          return STATUS_NOMEM;
      }
      /* where edge_id is an integer identifying the edge
       * tmin is a lower bound of the parametric intervalle where the curve is defined
       * tmax is a upper bound of the parametric intervalle where the curve is defined
       * curv_function or curv0_function is the function that defines the curve 
       * (for this edge, it will be called by cadsurf with your_edge_object_ptr as
       * last parameter).
       *
       * NOTE : the creation of an edge with cad_edge_new0 instead of
       * the regular cad_edge_new will trigger some internal mecanism
       * in MG-CADSurf that will optimize it's use. It can
       * result in large speed-up in some circumstances.
       * 
       */

      /* by default an edge is a boundary edge */
      if (this edge is internal) {
        ret = cad_edge_set_property(e, EDGE_PROPERTY_INTERNAL);
        if (ret != STATUS_OK)
          return ret;
      }

      /* by default an edge has no tag (attribute). The following call sets it */
      ret = cad_edge_set_tag(e, your_edge_tag);
      if (ret != STATUS_OK)
        return ret;

      /* The uid (unique identifier) will help you identify each cad
       * entity if you want to query the generated mesh vertices for
       * their location on the cad entities (faces or edges) by
       * default an edge has no uid. The following call sets it :
       */
      ret = cad_edge_set_uid(f, your_edge_uid);
      if (ret != STATUS_OK)
        return ret;

      /* If you are able to identify the extremities of all the curves
       * (for example, the first extremiy of curve #2 is also the
       * second extremity of curve #5, ...) you can give their id with
       * the following function.  (pid1 is the id of the first
       * extremity (for t=tmin) and pid2 is the id of the second one
       * (for t=tmax)).
       * 
       * See the file meshgems/cad.h for more details.
       */
      ret = cad_edge_set_extremities(e, pid1, pid2);
      if (ret != STATUS_OK)
        return ret;

      /* Now, it can help to give the coordinates of the edge extremities */

      /* xyz should contain the coordinates of the first edge extremity */
      //xyz[0] = ...;
      //xyz[1] = ...;
      //xyz[2] = ...;
      v = cad_vertex_new(c, pid1, xyz);
      if (!v)
        return STATUS_NOMEM;

      /* Then xyz should contain the coordinates of the second edge extremity */
      //xyz[0] = ...;
      //xyz[1] = ...;
      //xyz[2] = ...;
      v = cad_vertex_new(c, pid2, xyz);
      if (!v)
        return STATUS_NOMEM;

      /* by default an edge is not oriented. The orientation should be
       * set accordingly to the following rule :
       * CAD_ORIENTATION_FORWARD :
       *     the patch lies on the left of the curve in UV space
       * CAD_ORIENTATION_REVERSED :
       *     the patch lies on the right of the curve in UV space
       * 
       * NOTE : the orientation property is only usefull for MG-CADSurf if
       * you want it to treat and close the CAD patches which are not
       * closed in the UV domain space (mainly periodic faces or faces
       * build on a periodic surface, like a cylinder piece). If all
       * your CAD faces are already closed in UV domain, you do not
       * need to set this property.
       *
       */
      if (...) {
        ret = cad_edge_set_orientation(e, CAD_ORIENTATION_REVERSED);
        if (ret != STATUS_OK)
          return ret;
      } else {
        ret = cad_edge_set_orientation(e, CAD_ORIENTATION_FORWARD);
        if (ret != STATUS_OK)
          return ret;
      }

      /*
       * If you want to set a required discretization on this edge, the dcad_t *dc object  
       * must have been created earlier and you need to do the following:
       */
      if (CREATE_DCAD) {
        dcad_edge_discretization_t *de = 0;
        real tt, uv[2], xyz[3];

        assert(dc);             // This object must have been created earlier

        /* Get the edge discretization associated to the current edge */
        ret = dcad_get_edge_discretization(dc, e, &de);
        if (ret != STATUS_OK)
          return ret;

        /* Set its vertex count (extremities included) */
        //n_required_vertices = ...;
        ret =
            dcad_edge_discretization_set_vertex_count(de,
                                                      n_required_vertices);
        if (ret != STATUS_OK)
          return ret;

        /* Set coordinates (t,uv,xyz) of each vertex (extremities included) */
        for (i = 1; i <= n_required_vertices; i++) {
          //tt = ...;
          //uv[0] = ...;
          //uv[1] = ...;
          //xyz[0] = ...;
          //xyz[1] = ...;
          //xyz[2] = ...;
          ret =
              dcad_edge_discretization_set_vertex_coordinates(de, i, tt,
                                                              uv, xyz);
          if (ret != STATUS_OK)
            return ret;
        }
        /* Mark this discretization as required */
        ret =
            dcad_edge_discretization_set_property(de,
                                                  DCAD_PROPERTY_REQUIRED);
        if (ret != STATUS_OK)
          return ret;
      }
      }
    }
  for each
    wire your_wire on your_cad_body {

    cad_wire_t *w = 0;

    w = cad_wire_new(c, wire_id, tmin, tmax, curv3d2_function,
                     your_wire_object_ptr);
    if (!w)
      return STATUS_NOMEM;

    /* where wire_id is an integer identifying the wire
     * tmin is a lower bound of the parametric interval where the curve is defined
     * tmax is a upper bound of the parametric interval where the curve is defined
     * curv_wire_function is the function that defines the curve 
     * (for this wire, it will be called by cadsurf with your_wire_object_ptr as
     * last parameter).
     */

    /* by default a wire has no tag (attribute). The following call sets it */
    ret = cad_wire_set_tag(w, your_wire_tag);
    if (ret != STATUS_OK)
      return ret;

    /* The uid (unique identifier) will help you identify each cad
     * entity if you want to query the generated mesh vertices for
     * their location on the cad entities (faces, edges or wires) by
     * default a wire has no uid. The following call sets it :
     */
    ret = cad_wire_set_uid(w, your_wire_uid);
    if (ret != STATUS_OK)
      return ret;

    /* If you are able to identify the extremities of all the curves
     * (for example, the first extremiy of curve #2 is also the
     * second extremity of curve #5, ...) you can give their id with
     * the following function.  (pid1 is the id of the first
     * extremity (for t=tmin) and pid2 is the id of the second one
     * (for t=tmax)).
     * 
     * See the file meshgems/cad.h for more details.
     */
    ret = cad_wire_set_extremities(w, pid1, pid2);
    if (ret != STATUS_OK)
      return ret;

    /* Now, it can help to give the coordinates of the wire extremities */

    /* xyz should contain the coordinates of the first wire extremity */
    //xyz[0] = ...;
    //xyz[1] = ...;
    //xyz[2] = ...;
    v = cad_vertex_new(c, pid1, xyz);
    if (!v)
      return STATUS_NOMEM;

    /* Then xyz should contain the coordinates of the second wire extremity */
    //xyz[0] = ...;
    //xyz[1] = ...;
    //xyz[2] = ...;
    v = cad_vertex_new(c, pid2, xyz);
    if (!v)
      return STATUS_NOMEM;
    }

  /*
   * If you want to set a periodicity meshing constraint (mesh
   * matching) between two sets of cad faces.  See the file
   * meshgems/cad.h for more details
   * (meshgems_cad_add_face_multiple_periodicity_with_transformation_function),
   * and the documentation.
   */
  if (CREATE_PERIODICITY) {
    integer fid1[2], fid2[2];
    integer eid1[2], eid2[2];
    integer size1, size2;
    integer nb_pt1, nb_pt2;
    real p[9], p_im[9], periodic_transformation_user_data;

    /* Example of a translation of vector (1,1,1) : 
     * fill fid1, fid2, eid1, eid2, size1, size2 with your data 
     * (See file meshgems/cad.h)
     */

    assert(size1 == size2);
    /* Set the face periodicities */
    if (1) {
      /* Define the periodic tranformation with points coordinates */
      nb_pt1 = 3;
      nb_pt2 = 3;
      assert(nb_pt1 == nb_pt2);

      /* p contains nb_pt1 points on the first set of face you want to set periodic */
      p[0] = 0;
      p[1] = 0;
      p[2] = 0;

      p[3] = 0;
      p[4] = 1;
      p[5] = 0;

      p[6] = 0;
      p[7] = 0;
      p[8] = 1;

      /* while p_im contains their images on the second set of face */
      p_im[0] = 1;
      p_im[1] = 1;
      p_im[2] = 1;

      p_im[3] = 1;
      p_im[4] = 2;
      p_im[5] = 1;

      p_im[6] = 1;
      p_im[7] = 1;
      p_im[8] = 2;

      /*
       * Set a periodicity between the size1 cad faces of fid1 array and
       * the size2 faces of fid2 array using a transformation defined by
       * the coordinates of nb_pt1 points contained in p and their
       * images contained in p_im See the file meshgems/cad.h for more
       * details on the parameters of this function
       */
      ret =
          cad_add_face_multiple_periodicity_with_transformation_function_by_points
          (c, fid1, size1, fid2, size2, p, nb_pt1, p_im, nb_pt2);
      if (ret != STATUS_OK)
        return ret;
    } else {
      /* Define the periodic tranformation with a callback */

      /*
       * Set a periodicity between the size1 cad faces of fid1 array and
       * the size2 faces of fid2 array using a transformation defined by
       * the periodicity_transformation function See the file
       * meshgems/cad.h for more details on the parameters of this
       * function
       */

      periodic_transformation_user_data = 1;

      ret = cad_add_face_multiple_periodicity_with_transformation_function
          (c, fid1, size1, fid2, size2, periodicity_transformation,
           &periodic_transformation_user_data);
      if (ret != STATUS_OK)
        return ret;
      /* Please note that in case of a translation, you can set
       * periodicity_transformation = 0 and periodic_transformation_user_data = 0.
       * In this case, the CAD preprocessor of MG-CADSurf will compute a simple translation 
       */
    }

    /* Set the edge periodicities (ie periodicity between edges while
       the associated cad faces are not required to be periodic) */
    if (1) {
      /* Define the periodic tranformation with points coordinates */
      nb_pt1 = 3;
      nb_pt2 = 3;
      assert(nb_pt1 == nb_pt2);

      /* p contains nb_pt1 points on the first set of edge you want to set periodic */
      p[0] = 0;
      p[1] = 0;
      p[2] = 0;

      p[3] = 0;
      p[4] = 1;
      p[5] = 0;

      p[6] = 0;
      p[7] = 0;
      p[8] = 1;

      /* while p_im contains their images on the second set of edge */
      p_im[0] = 1;
      p_im[1] = 1;
      p_im[2] = 1;

      p_im[3] = 1;
      p_im[4] = 2;
      p_im[5] = 1;

      p_im[6] = 1;
      p_im[7] = 1;
      p_im[8] = 2;

      /*
       * Set a periodicity between the size1 cad edges of eid1 array and
       * the size2 faces of eid2 array using a transformation defined by
       * the coordinates of nb_pt1 points contained in p and their
       * images contained in p_im See the file meshgems/cad.h for more
       * details on the parameters of this function
       */
      ret =
          cad_add_edge_multiple_periodicity_with_transformation_function_by_points
          (c, eid1, size1, eid2, size2, p, nb_pt1, p_im, nb_pt2);
      if (ret != STATUS_OK)
        return ret;
    } else {
      /* Define the periodic tranformation with a callback */

      /*
       * Set a periodicity between the size1 cad edges of eid1 array and
       * the size2 faces of eid2 array using a transformation defined by
       * the periodicity_transformation function See the file
       * meshgems/cad.h for more details on the parameters of this
       * function
       */
      periodic_transformation_user_data = 1;
      ret = cad_add_edge_multiple_periodicity_with_transformation_function
          (c, eid1, size1, eid2, size2, periodicity_transformation,
           &periodic_transformation_user_data);
      if (ret != STATUS_OK)
        return ret;
      /* Please note that in case of a translation, you can set
       * periodicity_transformation = 0 and periodic_transformation_user_data = 0.
       * In this case, the CAD preprocessor of MG-CADSurf will compute a simple translation 
       */
    }
  }

  *pc = c;
  if (dc)
    *pdc = dc;

  return ret;
}

status_t generate_mesh_for_xxx(your_cad)
{
  status_t ret;
  cad_t *c = 0;
  dcad_t *dc = 0;
  context_t *ctx = 0;

  assert(parts);
  ret = STATUS_OK;

  /* create a meshgems context (generic object) */
  ctx = context_new();
  if (!ctx)
    return STATUS_NOMEM;

  ret = import_xxx_geometry(your_cad, ctx, &c, &dc);
  if (ret != STATUS_OK) {
    context_delete(ctx);
    return ret;
  }

  ret = generate_mesh(ctx, c, dc, 0);

  cad_delete(c);
  if (dc)
    dcad_delete(dc);

  context_delete(ctx);

  return ret;
}
