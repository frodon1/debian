#ifndef __Sim_opt_exp__
#define __Sim_opt_exp__

#include <Sim_opt.h>
#include <Function.h>
#include <Sorted_list.h>

Z_START_NAMESPACE;

class LOESS;

class EXPERIMENTS_GUI : public GRAPHICS_COMMAND {
 
  protected :
    bool grabbing;
    BUFF_LIST<VECTOR> grabbed_points;

    void create_add_base_exp_dialog();
    void create_derived_exp_dialog(const STRING&);
    void create_composite_exp_dialog(int ncol, int plot_col);
    void create_grab_dialog();
    void create_edit_exp_dialog(STRING dialog, STRING file);
    bool update_derived_exp(EXP_ITEM*);
    bool update_composite_exp(COMP_EXP_ITEM*);
    bool update_from_function(EXP_ITEM*);
    bool update_from_program(EXP_ITEM*);
    bool update_from_filter(EXP_ITEM*);
    bool update_from_filter_max_min(EXP_ITEM*);
    void update_lists();
    void update_from_grabbing();
    STRING sort_out_selection(const SORTED_LIST<double>& xsel,const CARRAY<double>& xvals);
    void write_default_prog(const STRING& name);
    double interpolate(double ref,const MATRIX& mat);

  public :

    SIM_OPT_GUI* its_sim_opt;
    GRAPHICS_DATA_DIALOG* its_dialog;
    GRAPHICS_DATA_DIALOG* add_base_exp_dialog;
    GRAPHICS_DATA_DIALOG* derived_exp_dialog;
    GRAPHICS_DATA_DIALOG* composite_exp_dialog;
    GRAPHICS_DATA_DIALOG* edit_base_exp_dialog;
    GRAPHICS_DATA_DIALOG* edit_exp_dialog;
    GRAPHICS_DATA_DIALOG* edit_treatement_dialog;
    GRAPHICS_DATA_DIALOG* edit_prog_dialog;
    GRAPHICS_DATA_DIALOG* grab_dialog;
    STRING current_program;
    LOESS* current_filter;
    FILTER_MAX_MIN* current_filter_max_min;

    int    cur_composite_col;
    EXP_ITEM* cur_base_exp;
    EXP_ITEM* cur_derived_exp;
    COMP_EXP_ITEM* cur_comp_exp;
    TREE_FIELD_ITEM *root_base_exp,*root_derived_exp,*root_composite_exp;

    EXPERIMENTS_GUI();
    virtual ~EXPERIMENTS_GUI();
    virtual void initialize(GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app);
 
    virtual bool do_command(STRING);
    virtual bool do_click(int, GRAPHICS_POINT& clk, GRAPHICS_OBJECT*);
    virtual void read(ASCII_FILE&);
    virtual bool write(Zofstream& out);
 
};

class SIM_OPT_EXP : public GRAPHICS_COMMAND {
  protected :
    EXPERIMENTS_GUI* its_experiments_gui;
 
  public :

    SIM_OPT_GUI* its_sim_opt;

    SIM_OPT_EXP();
    virtual ~SIM_OPT_EXP();
    virtual void initialize(GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app);

    virtual bool do_command(STRING);
    virtual bool do_click(int,GRAPHICS_POINT& clk,GRAPHICS_OBJECT*);

};
Z_END_NAMESPACE;

#endif
