#ifndef __ZP_DAO_ARC__
#define __ZP_DAO_ARC__

#include <Geometry_parts.h>
#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_dao_edge.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_DAO_ARC : public ZP_DAO_EDGE 
{
  protected :
    virtual ZP_FATAL_ERROR* print(ZP_STACK&,int);
    ZP_FATAL_ERROR* set_nodes(ZP_STACK&,int);
    ZP_FATAL_ERROR* set_parameters(ZP_STACK&,int);
    ZP_FATAL_ERROR* set_arc(ZP_STACK&,int);
    ZP_FATAL_ERROR* set_arc_by_points(ZP_STACK&,int);
    ZP_FATAL_ERROR* set_center(ZP_STACK&,int);
    ZP_FATAL_ERROR* divide_into_n(ZP_STACK&,int);
    ZP_FATAL_ERROR* circle(ZP_STACK&,int);
    ZP_FATAL_ERROR* assign(ZP_STACK&,int);
    ZP_FATAL_ERROR* set_element_size(ZP_STACK &stack,int);
    ZP_FATAL_ERROR* set_even_element_size(ZP_STACK &stack,int);

    virtual void type_init(char*) { _CHECK_DGLP_ type="ARC"; }
    virtual void dao_add() { dao_geom_link_program->arc.add(&get()); }
    virtual void dao_delete() { if(dao_linked==0) dao_geom_link_program->arc.suppress_item(&get()); }
    void _dao_delete() { dao_geom_link_program->arc.suppress_item(&get()); }

  public :
    ZP_DAO_ARC() : ZP_DAO_EDGE(NULL) { type_init(NULL); contens=new DAO_ARC(dao_geom_link_program); dont_delete=0; dao_add(); get().p1=NULL; get().p2=NULL; }
    ZP_DAO_ARC(DAO_ARC *d) : ZP_DAO_EDGE(d) { type_init(NULL); }
   
    DESTRUCTORS_DAO(ZP_DAO_ARC);

    virtual DAO_ARC& get() { return(*((DAO_ARC*)contens)); }

    METHOD_DECLARATION_START
      METHOD("set_parameters",set_parameters,6)
      METHOD("set_arc",set_arc,4)
      METHOD("set_arc_by_points",set_arc_by_points,3)
      METHOD("set_center",set_center,1)
      METHOD("circle",circle,2)
      METHOD("divide_into_n",divide_into_n,2)
      METHOD("=",assign,2)
      METHOD("set_nodes",set_nodes,0)
      METHOD("set_element_size",set_element_size,2)
      METHOD("set_even_element_size",set_even_element_size,2)
    METHOD_DECLARATION_ANCESTOR(ZP_DAO_EDGE)

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
    ZPO_RTTI_INFO(DAO_ARC)
};
Z_END_NAMESPACE;

#endif
