#include <Remeshing_criterion.h>
#include <Stringpp.h>
#include <Discrete_timer.h>
#include <Print.h>

Z_START_NAMESPACE;

class REMESH_WITH_LIMIT_VALUE : public REMESHING_CRITERION
{
  protected :
  LIST<double> limit_error;
  LIST<STRING> files;
  int nb_dt;
  
  public :
    REMESH_WITH_LIMIT_VALUE() : REMESHING_CRITERION() { limit_error=NULL; files=NULL; nb_dt=-1;}
    virtual ~REMESH_WITH_LIMIT_VALUE() { }
    virtual bool GetResponse(STRING &key, ASCII_FILE &inp);
    virtual bool time_for_remesh(const MESH&);
};
Z_END_NAMESPACE;

