#ifndef __Post_simple__
#define __Post_simple__

// 
//  Used to handle basic options common to many of the simple 
//  little calculations 
// 
//  Defines 
//     *var  <name>  % variable name 
//     *automatic|scalar|tensor
// 
#include <Utility.h>
#include <Local_post_computation.h>

Z_START_NAMESPACE;

ZCLASS2 POST_SIMPLE :public LOCAL_POST_COMPUTATION {
 protected :
  int   scalar_check;

 public :
  STRING class_name;
  STRING var_name;

  POST_SIMPLE();
  virtual ~POST_SIMPLE();

  virtual MODIFY_INFO_RECORD* get_modify_info_record();
  virtual void add_base(MODIFY_INFO_RECORD* modif);
  
  virtual bool verify_info();

  void set_post_simple(STRING, bool, bool);
  virtual void set_input_data(const STRING&,void*);

};
Z_END_NAMESPACE;
  
#endif
