#ifndef __T_OBJECT_FACTORY__
#define __T_OBJECT_FACTORY__

#include <Stringpp.h>
#include <List.h>

Z_START_NAMESPACE;

//
// FF, july 31st 2005 : an object factory for template base classes
//

typedef void* (*T_OBJECT_FACTORY_FUNC)();

class T_OBJECT_FACTORY_CREATOR {
  public :
    STRING base,der,key,tmpl;
    T_OBJECT_FACTORY_FUNC create;

    T_OBJECT_FACTORY_CREATOR(char *b , char *d , char *k , char *t , T_OBJECT_FACTORY_FUNC f);
};

class T_OBJECT_FACTORY_REGISTAR {
  public :
    T_OBJECT_FACTORY_REGISTAR(char *base , char *deri , char *key , char *file, int nb_tmpl);
};

class T_OBJECT_FACTORY {
  friend class T_OBJECT_FACTORY_REGISTAR;
  friend class T_OBJECT_FACTORY_CREATOR;
  public :

    class T_OBJECT_FACTORY_DECLARATORS_DER {
      public :
        STRING derived,key,file;
        int nb_tmpl;
        LIST<T_OBJECT_FACTORY_CREATOR*> creators;

        T_OBJECT_FACTORY_DECLARATORS_DER(char *d, char *k, char *f, int n) { derived=d; key=k; file=f; nb_tmpl=n; }
    };

    class T_OBJECT_FACTORY_DECLARATORS_BASE {
      public :
        STRING base;
        LIST<T_OBJECT_FACTORY_DECLARATORS_DER*> derived;

        T_OBJECT_FACTORY_DECLARATORS_BASE(char *b) { base=b; }
        void register_type(char *key, char *der, char *file, int nb_tmpl);
    };

  protected :
    static T_OBJECT_FACTORY *instance;
    LIST<T_OBJECT_FACTORY_CREATOR*> creators;

    LIST<T_OBJECT_FACTORY_DECLARATORS_BASE*> declarations;

    void register_type(char *key, char *base, char *der, char *file, int nb_tmpl);

    void* _create(char *base, char *key, STRING &t);

  public :
    typedef void* (*T_OBJECT_FACTORY_FUNC)(void);

    T_OBJECT_FACTORY() { }
    ~T_OBJECT_FACTORY() { }

    static T_OBJECT_FACTORY& Instance();

    void register_creator(char *base, char *der, char *template_params,T_OBJECT_FACTORY_FUNC creator);
    void* create(char *base, char *key, char *t1);
    void* create(char *base, char *key, char *t1, char *t2);
    void* create(char *base, char *key, char *t1, char *t2, char *t3);
    void* create(char *base, char *key, char *t1, char *t2, char *t3, char *t4);
    void* create(char *base, char *key, char *t1, char *t2, char *t3, char *t4, char *t5);

    void dump_declarations();
    void resolve_creators();
};

#define T_DECLARE_OBJECT(base,deri,key,nb_tmpl) \
  static T_OBJECT_FACTORY_REGISTAR reg##base##deri( #base , #deri , #key , __FILE__ , nb_tmpl );

#define T_create_object1(base,key,t1) (base < t1 >*)(T_OBJECT_FACTORY::Instance().create(#base,key,#t1));

#define T_create_object2(base,key,t1,t2) (base < t1 , t2 >*)(T_OBJECT_FACTORY::Instance().create(#base,key,#t1,#t2));

#define T_create_object3(base,key,t1,t2,t3) (base < t1 , t2 , t3 >*)(T_OBJECT_FACTORY::Instance().create(#base,key,#t1,#t2,#t3));

#define T_create_object4(base,key,t1,t2,t3,t4) (base < t1 , t2 , t3 , t4 >*)(T_OBJECT_FACTORY::Instance().create(#base,key,#t1,#t2,#t3,#t4));

#define T_create_object5(base,key,t1,t2,t3,t4,t5) (base < t1 , t2 , t3 , t4 , t5>*)(T_OBJECT_FACTORY::Instance().create(#base,key,#t1,#t2,#t3,#t4,#t5));
Z_END_NAMESPACE;

#endif
