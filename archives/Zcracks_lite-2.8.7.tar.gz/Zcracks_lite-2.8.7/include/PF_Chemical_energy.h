#ifndef __Phasefield_phic_energy__
#define __Phasefield_phic_energy__

#include <Material_piece.h>
#include <Object_factory.h>
#include <Problem.h>
#include <Int_variable_holder.h>
#include <Elasticity.h>
#include <Integration_runge.h>
#include <Integration_theta.h>
#include <Behavior.h>
#include <PF_integration_info.h>
#include <PF_Chemical_behavior.h>

Z_START_NAMESPACE;

class MAT_DATA; class ASCII_FILE;

ZCLASS2 PHASEFIELD_PHIC_ENERGY {
   public :
     COEFF ENER,c1,c2,b1,b2,k1,k2,D1,D2,zeta,energy,Lamda;

     BEHAVIOR* boss;

     double w, dw,d2w;

     double f, df_dphi, df_dc, d2f_dphi2, d2f_dphidc, d3f_dphidc2, d3f_dphi2dc, d2f_dc2, alpha, kappa;

     PHASEFIELD_PHIC_ENERGY();
     virtual ~PHASEFIELD_PHIC_ENERGY();
     virtual void initialize(ASCII_FILE&,BEHAVIOR*);
     virtual VECTOR compute_a(double,double,double,double,double,double, double);
     virtual void compute_stuff(double, double, double, double, double)=0;
     virtual void compute_stuff(double) {};
     virtual void set_parameters();

};

Z_END_NAMESPACE;

#endif
