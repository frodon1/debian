#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/meshgems.h>
#include <meshgems/meshgems_short_names.h>
#include <meshgems/hybrid.h>

#define FREE_AND_STRDUP(_p_,_s_) if(_p_) free(_p_); _p_ = strdup(_s_)

/*
 Compute basename from file
 */
char *strstrfromend(char *MshNam, const char *base)
{
  char *InpFil;
  char *ptr = NULL, *pdeb = NULL;
  size_t longbase, longfil;

  InpFil = MshNam;
  longbase = strlen(base);
  longfil = strlen(InpFil);

  if (longbase > longfil)
    return (ptr);

  ptr = InpFil + longfil - longbase;
  ptr = strstr(ptr, base);
  if (ptr)
    return (ptr);

  if ((longfil - longbase) > 0) {
    ptr = InpFil + strlen(InpFil) - longbase - 1;
    ptr = strstr(ptr, base);
  }

  return (ptr);
}

/*
 * message callback function
 */
status_t my_message_cb(message_t * msg, void *user_data)
{
  char *desc;
  integer e, n, m;
  integer i, i_data[10];
  real r_data[10];
  n = m = 0;
  message_get_description(msg, &desc);
  message_get_number(msg, &e);

  if (e < 0) {
    printf("mg-hybrid ERROR %i : %s", MESHGEMS_ABS_CODE(e), desc);
    message_get_integer_data_count(msg, &n);
    message_get_real_data_count(msg, &m);
    printf("MGMESSAGE %i ", e);
    printf(" %i", n);
    if (n > 0) {
      message_get_integer_data(msg, 1, n, i_data);
      for (i = 0; i < n; i++)
        printf(" %i", i_data[i]);
    }
    printf(" %i", m);
    if (m > 0) {
      message_get_real_data(msg, 1, m, r_data);
      for (i = 0; i < m; i++)
        printf(" %f", r_data[i]);
    }
    printf(" \n");

  }
  if (e >= 0) {
    if (e == 0)
      printf("\rmg-hybrid info : %s", desc);
    else
      printf("mg-hybrid info %i : %s", MESHGEMS_CODE(e), desc);
  }

  return STATUS_OK;
}

/*
 * MAIN PROCEDURE
 */
int main(int argc, char *argv[])
{

  context_t *ctx;
  hybrid_session_t *myhybrid_session;
  mesh_t *surface;
  mesh_t *hexmesh;

  status_t ret;

  char *outfile;
  char *infile;

  int len;
  char *ptr;

  char chaine[512];

  ptr = NULL;
  outfile = NULL;
  infile = NULL;

  /* create the Meshgems working context */
  ctx = context_new();

  /* set the message callback for the context */
  context_set_message_callback(ctx, my_message_cb, NULL);


  /* create the Meshgems-Hexa session */
  myhybrid_session = meshgems_hybrid_session_new(ctx);

  surface = NULL;
  if (argc > 1) {
    /* check input and output files */
    if (argc > 1 && argv[1][0] != '-') {
      FREE_AND_STRDUP(infile, argv[1]);
      if (argc > 2) {
        FREE_AND_STRDUP(outfile, argv[2]);
      }
    }
  } else {
    printf("usage : hybrid_example.exe filein [fileout] \n");
    exit(-1);
  }

  if (infile) {
    /* create the Meshgems mesh and read it */
    surface = mesh_new_read_mesh(ctx, infile);
    if (!surface) {
      printf("\n %%%% Error, unable to read mesh file. \n");
      exit(-1);
    }
  }

  if (!outfile) {
    int i;
    char *basename;
    char *add = (char *) "_hybrid";
    ptr = strstrfromend(infile, ".mesh");
    len = strlen(ptr);
    basename = (char *) calloc(strlen(infile) - len + 1, sizeof(char));
    for (i = 0; i < strlen(infile) - len; i++)
      basename[i] = infile[i];
    len = strlen(ptr) + strlen(add) + strlen(basename);
    outfile = (char *) calloc(len + 1, sizeof(char));
    sprintf(outfile, "%s%s%s", basename, add, ptr);

  }

  /* set the session input surface mesh */
  ret = hybrid_set_surface_mesh(myhybrid_session, surface);
  if (ret != STATUS_OK) {
    printf("\n %%%% Internal error, unable to set surface mesh. \n");
    exit(-1);
  }

  printf("\n");
  printf("\nrunning hybrid mesher with element_generation set to hexa_dominant  ... \n");

  ret = hybrid_set_param(myhybrid_session, "element_generation", "hexa_dominant");
  if (ret != STATUS_OK) {
     printf("\n %%%% mesh unable to set element_generation parameter \n");
     exit(-1);
   }

  /* compute the volume mesh */
  ret = hybrid_compute_mesh(myhybrid_session);

  if (ret != STATUS_OK) {
    printf("\n %%%% mesh processing failed, no saving operation \n");
    exit(-1);
  }

  hexmesh = NULL;
  /* get the generated volume mesh */
  ret = hybrid_get_mesh(myhybrid_session, &hexmesh);
  if (ret != STATUS_OK) {
    printf("\n %%%% Internal error, unable to set surface mesh. \n");
    exit(-1);
  } else {
    printf(" %%%% writing the resulting mesh : %s\n", outfile);
    meshgems_mesh_write_mesh(hexmesh, outfile);
  }

  hybrid_regain_mesh(myhybrid_session, hexmesh);

  if (outfile)
    free(outfile);
  if (infile)
    free(infile);

  hybrid_session_delete(myhybrid_session);
  mesh_delete(surface);
  context_delete(ctx);

  return 0;
}
