#ifndef __ZP_GENERIC_POINTER__
#define __ZP_GENERIC_POINTER__

#include <ZP_basic_type.h>

Z_START_NAMESPACE;

template <typename T>
struct G_POINTER {
    T **ptr;  
    AUTO_PTR< ZP_OBJECT > object;
};

template <typename TT>
ZCLASSt ZP_GENERIC_POINTER : public ZP_BASIC_TYPE < G_POINTER <TT> >
{
  protected :
    ZP_FATAL_ERROR* assignment(ZP_STACK&);
    ZP_FATAL_ERROR* anchor(ZP_STACK&);

  public :
    BASIC_CONSTRUCTORS(ZP_GENERIC_POINTER,G_POINTER<TT>)

    virtual void type_init(char*); // { this->type="GENERIC_POINTER"; }
    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
    virtual ZP_FATAL_ERROR* method(STRING &_name, int nbp, ZP_STACK &stack,bool resolv=FALSE);

    ZPO_RTTI_INFO( G_POINTER<TT> )
};

Z_END_NAMESPACE;

#ifdef Z_HAS_NAMESPACE

#define IMPL_G_POINTER(ty) \
namespace ZSET { using namespace ZSET; \
  template<> void ZP_GENERIC_POINTER< ty >::type_init(char*) { \
    this->type="GENERIC_POINTER<"; this->type+=#ty; this->type+=">"; \
  } \
  template<> G_POINTER<ty>& ZP_GENERIC_POINTER< ty >::cast(AUTO_PTR<ZP_OBJECT> &zpo) { \
    static char ret[1024]=""; if(strcmp(ret,"")==0) sprintf(ret,"ZP_GENERIC_POINTER<%s*>",#ty); \
    if(!zpo->__are_you_a(ret)) ERROR("Internal error : Bas Cast"); \
    return(( (ZP_GENERIC_POINTER<ty>*)(zpo()) )->get()); \
  } \
  template<> ZP_FATAL_ERROR* ZP_GENERIC_POINTER< ty >::method(STRING &_name, int nbp, ZP_STACK &stack,bool resolv) { \
    if(_name=="=") { \
      if(this->type == stack.last()->type) { \
        *get().ptr=*ZP_GENERIC_POINTER::cast(stack.last()).ptr; \
        get().object->contens=*get().ptr; \
        return(NULL); \
      } else TYPE_MISMATCH_ERROR_1("="); \
    } else return(get().object->method(_name,nbp,stack,resolv)); \
    return(NULL); \
  } \
  template<> ZP_FATAL_ERROR* ZP_GENERIC_POINTER< ty >::acess(STRING &member, ZP_STACK &stack, bool resolv) { \
    return(get().object->acess(member,stack,resolv)); \
  } \
  \
  template<> const char* ZP_GENERIC_POINTER< ty >::__type()const { \
    static char ret[1024]=""; \
    if(strcmp(ret,"")==0) sprintf(ret,"ZP_GENERIC_POINTER<%s*>",#ty); \
    return(ret); \
  } \
  \
  template<> const char* ZP_GENERIC_POINTER< ty >::isA()const { return(__type()); } \
  template<> bool  ZP_GENERIC_POINTER< ty >::__are_you_a(const char* str)const \
  { static char ret[1024]=""; if(strcmp(ret,"")==0) sprintf(ret,"ZP_GENERIC_POINTER<%s*>",#ty); \
    if(strcmp(str,ret)==0) return TRUE; \
    else return ZP_BASIC_TYPE< G_POINTER< ty > >::__are_you_a(str); \
  } \
  template<> bool ZP_GENERIC_POINTER< ty >::areYouA(const char* str)const \
  { return(this->__are_you_a(str)); } \
  template<> bool  ZP_GENERIC_POINTER< ty >::CheckType(const char* str) const \
  { \
    static char ret[1024]=""; \
    if(strcmp(ret,"")==0) sprintf(ret,"ZP_GENERIC_POINTER<%s*>",#ty); \
    if(strcmp(str,ret)==0) return TRUE; \
    else return FALSE; \
  } \
}

#else

#define IMPL_G_POINTER(ty) \
  template<> void ZP_GENERIC_POINTER< ty >::type_init(char*) { \
    this->type="GENERIC_POINTER<"; this->type+=#ty; this->type+=">"; \
  } \
  template<> G_POINTER<ty>& ZP_GENERIC_POINTER< ty >::cast(AUTO_PTR<ZP_OBJECT> &zpo) { \
    static char ret[1024]=""; if(strcmp(ret,"")==0) sprintf(ret,"ZP_GENERIC_POINTER<%s*>",#ty); \
    if(!zpo->__are_you_a(ret)) ERROR("Internal error : Bas Cast"); \
    return(( (ZP_GENERIC_POINTER<ty>*)(zpo()) )->get()); \
  } \
  template<> ZP_FATAL_ERROR* ZP_GENERIC_POINTER< ty >::method(STRING &_name, int nbp, ZP_STACK &stack,bool resolv) { \
    if(_name=="=") { \
      if(this->type == stack.last()->type) { \
        *get().ptr=*ZP_GENERIC_POINTER::cast(stack.last()).ptr; \
        get().object->contens=*get().ptr; \
        return(NULL); \
      } else TYPE_MISMATCH_ERROR_1("="); \
    } else return(get().object->method(_name,nbp,stack,resolv)); \
    return(NULL); \
  } \
  template<> ZP_FATAL_ERROR* ZP_GENERIC_POINTER< ty >::acess(STRING &member, ZP_STACK &stack, bool resolv) { \
    return(get().object->acess(member,stack,resolv)); \
  } \
  \
  template<> const char* ZP_GENERIC_POINTER< ty >::__type()const { \
    static char ret[1024]=""; \
    if(strcmp(ret,"")==0) sprintf(ret,"ZP_GENERIC_POINTER<%s*>",#ty); \
    return(ret); \
  } \
  \
  template<> const char* ZP_GENERIC_POINTER< ty >::isA()const { return(__type()); } \
  template<> bool  ZP_GENERIC_POINTER< ty >::__are_you_a(const char* str)const \
  { static char ret[1024]=""; if(strcmp(ret,"")==0) sprintf(ret,"ZP_GENERIC_POINTER<%s*>",#ty); \
    if(strcmp(str,ret)==0) return TRUE; \
    else return ZP_BASIC_TYPE< G_POINTER< ty > >::__are_you_a(str); \
  } \
  template<> bool ZP_GENERIC_POINTER< ty >::areYouA(const char* str)const \
  { return(this->__are_you_a(str)); } \
  template<> bool  ZP_GENERIC_POINTER< ty >::CheckType(const char* str) const \
  { \
    static char ret[1024]=""; \
    if(strcmp(ret,"")==0) sprintf(ret,"ZP_GENERIC_POINTER<%s*>",#ty); \
    if(strcmp(str,ret)==0) return TRUE; \
    else return FALSE; \
  }

#endif

#endif
