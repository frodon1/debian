#ifndef __SVD_solver__  
#define __SVD_solver__  

#include <Defines.h>
#include <Matrix.h>

Z_START_NAMESPACE;

ZCLASS SVD_SOLVER {
  public:
    virtual void pseudo_inverse(const MATRIX &M, MATRIX &Mpinv, double tol=1.e-12) const=0;
    virtual void pseudo_inverse(MATRIX &M, double tol=1.e-12) const=0; 
    virtual void svd(const MATRIX &M, MATRIX &U, DMATRIX &S, MATRIX &V) const=0;
};

Z_END_NAMESPACE;
#endif
