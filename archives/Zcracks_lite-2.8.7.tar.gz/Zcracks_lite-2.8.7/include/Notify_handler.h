#ifndef __NOTIFY_HANDLER__
#define __NOTIFY_HANDLER__

#include <Bool.h>
#include <Handler_mp.h>
#include <Server.h>

Z_START_NAMESPACE;

ZCLASS NOTIFY_HANDLER : public HANDLER_MP
{
  public :
    NOTIFY_HANDLER();
    virtual ~NOTIFY_HANDLER();

    DECLARE_HANDLER;
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
