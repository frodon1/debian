#ifndef __Direct_kinematic__ 
#define __Direct_kinematic__ 

// ============================================================================ 
//   A kinematic hardening based on X = fn1(evcum,evi)evi   RF Jun 16 2000 
// 
//   For gen_evp use, there needs to be a variable for alpha because otherwise
//   we need evi = evi_ini + dvcum norm but norm depends on X which depends on 
//   evi... this way we can have some recovery too, which is maybe not usefull 
//   for the Asaro model but which is for the Boyce lengevin model (polymer 
//   chains relax their alignment big time)
// 
//   In addition, gen_evp (in Chaboche2.c) treats the evolution of this class like 
//   a parameter.. i.e. no state coupling, so there can be in fact more or less
//   than a full tensor.  
// 
//   ** Need to add var_aux capability as well. 
//   ** No attempt has been made at this point to plan out the interface. Its 
//      designed only by the needs of the current implementations
// ============================================================================ 

#include <Bool.h>
#include <Hierarchy.h>
#include <List.h>
#include <ZMath.h>
#include <Zminmax.h>
#include <Material_piece.h>

Z_START_NAMESPACE;

ZCLASS DIRECT_KINEMATIC_DATA { 
 public : 
   int     rec_only; 
   // 
   // Data for the kinematic to be set 
   // 
   VECTOR  devol_dp; 
   MATRIX  devol_dalpha; 
   MATRIX  devol_dsig;
   MATRIX  dX_da;

   // 
   // possible extra things if calc_extra>0 
   // 
   MATRIX  devol_dnorm;

   // 
   // pointers on data which should be calculated 
   // ahead of time 
   // 
   int    calc_extra; 
   double tdv; 
   double tdt; 
   const SMATRIX* dnorm_dsig; 
   const SMATRIX* dnorm_dbs; 
   const TENSOR2* norm; 

   DIRECT_KINEMATIC_DATA() {
       rec_only = 0; 
       calc_extra = 0; 
       dnorm_dsig = NULL; 
       dnorm_dbs  = NULL; 
   } 
}; 

ZCLASS DIRECT_KINEMATIC : public MATERIAL_PIECE {
protected:
   const  TENSOR2*  keep_sig; 
   VECTOR    dvar; 
   VECTOR    rec_dvar; 
   TENSOR2   X; 
   int       recovery_flag; 
public:   
          DIRECT_KINEMATIC();
          DIRECT_KINEMATIC(MATERIAL_PIECE* boss); 
          DIRECT_KINEMATIC(const DIRECT_KINEMATIC& kin, MATERIAL_PIECE* boss);

   virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
   virtual MATERIAL_PIECE*  copy_self(MATERIAL_PIECE*);
   virtual            ~DIRECT_KINEMATIC();

   int     has_recovery() { return recovery_flag; } 

   // 
   // This is the chance to see the current iterations values of 
   // its vars and increment of vars. you probably want to put a 
   // sub on these vectors.. they are the total integ vectors so 
   // the position is at int_pos() with size int_sz()
   // 
   virtual void      look(VECTOR& var, VECTOR& dvar, int is_theta_method); 
   virtual void      look_at_sig(const TENSOR2* stress); // must show sig before calculate_x
   
   // 
   // Calculate X ... renamed to emphasize the difference from the 
   // "other" kinematics 
   // 
   virtual const TENSOR2&    calculate_x();
   virtual const TENSOR2&    last_x() { return X; } 
   
   //
   // Evolution and recovery.. quite generic... anything you need to 
   // get X calculated! 
   //
   virtual const VECTOR& evolution(double devcum, 
                                   const TENSOR2& stress, 
                                   const TENSOR2& norm);

   // 
   // Watch sign with this. the basic equation is dh = dlam m - dt omega
   // and this function should return dt omega .. note NOT with (-) sign 
   // 
   virtual const VECTOR& recovery( const TENSOR2& stress); 

   // 
   // Theta method functions... all members of the DIRECT_KINEMATIC_DATA
   // should be resized and set to something in this function. 
   // 
   virtual void compute_theta_stuff(DIRECT_KINEMATIC_DATA& dat); 
   RTTI_INFO;
};

// ------------------------------------------------------------ 
//  RECOVERY_DIRECT_KINEMATIC  A base class to handle "classic" 
//  norton-like recovery for direct kinematics (with only alpha
//  as integrated variable)
// 
//  RF 10/06/2006 added viscoelastic relaxtion of back stress 
//  any model can ask for it, but you'll have to call the right 
//  functions from calculate_x() etc in order to have it work 
// ------------------------------------------------------------ 
ZCLASS RECOVERY_DIRECT_KINEMATIC : public DIRECT_KINEMATIC {
protected:
    COEFF         M,m,Xpp;
    double        equ_xx;
    double        rterm;

    VECTOR              ve_gamma_use; 
    COEFF               ve_gamma_inf;
    BUFF_LIST<COEFF>    ve_gamma;
    BUFF_LIST<COEFF>    ve_tau;
    TENSOR2             ve_keep_X_0; 
    ARRAY<TENSOR2_VAUX> ve_h;

    virtual void set_X_0(TENSOR2& X); 
    virtual void add_viscoelasticity(TENSOR2& X, TENSOR4& dX_da); 

public:   
    RECOVERY_DIRECT_KINEMATIC();
    RECOVERY_DIRECT_KINEMATIC(MATERIAL_PIECE* boss); 
    RECOVERY_DIRECT_KINEMATIC(const RECOVERY_DIRECT_KINEMATIC& kin, 
                              MATERIAL_PIECE* boss);

   virtual  ~RECOVERY_DIRECT_KINEMATIC();


   virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
   virtual bool  base_read(STRING& str, ASCII_FILE& file); 

   virtual void setup(int& flux_pos, int& grad_pos, int& vi_pos, int& va_pos);

   virtual const VECTOR& recovery( const TENSOR2& stress ); 

   // 
   // Adds in terms for recovery... be carefull about having the 
   // same storage here. basically its for only alpha integrated
   // kinematics 
   // 
   virtual void compute_theta_stuff(DIRECT_KINEMATIC_DATA& dat); 
   RTTI_INFO;
};

// ------------------------------------------------------------ 
// X = C/D tanh (D J(evi)) evi/J(evi)
// 
// *kinematic asaro 
// ------------------------------------------------------------ 

ZCLASS ASARO_KINEMATIC : public RECOVERY_DIRECT_KINEMATIC {
  public : 
    COEFF         C,D; 
    COEFF         Q,b;  // alternate D=b, C=Q*b
    double        C_D; 
    double        tt; 
    double        alpha_eq; 
    double        fact; 
    TENSOR2_VINT  alpha;
    double        term2; 
    TENSOR2       dJ_dalpha; 

    ASARO_KINEMATIC();
    ASARO_KINEMATIC(MATERIAL_PIECE* boss);
    ASARO_KINEMATIC(const ASARO_KINEMATIC& kin, MATERIAL_PIECE* boss);

   virtual bool calc_coef();
   virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
   virtual MATERIAL_PIECE*  copy_self(MATERIAL_PIECE*);
   virtual ~ASARO_KINEMATIC();
   virtual void      look(VECTOR& var, VECTOR& dvar, int is_theta_method);
   virtual const TENSOR2&    calculate_x();

   virtual const VECTOR& evolution(double devcum,
                                   const TENSOR2& stress,
                                   const TENSOR2& norm);

   virtual void compute_theta_stuff(DIRECT_KINEMATIC_DATA& dat); 
   RTTI_INFO;
}; 


// ------------------------------------------------------------ 
// See Chaboche and Nouailhas J. Eng. Mat. Tech. V111 pp409-416 (1989)
// 
// This one uses the direct kinematic model because there is more than
// a single variable assocated to the kinematic.. not available except
// in the gen_evp2 potential 
// 
// X = 2/3 C alpha  Y = 2/3 C y 
// 
// dalpha = dv (n - D / C (X - Y))
// dy     = 1/K (alpha-y) J(dy)     J(dy) = sqrt(1.5 dy:dy)
//
// *kinematic rousselier
// ------------------------------------------------------------ 

ZCLASS ROUSSELIER_KINEMATIC : public DIRECT_KINEMATIC {
  public :
    COEFF         C,D,K;
    double        alpha_eq;
    double        fact;
    double        mod;
    TENSOR2_VINT  alpha;
    TENSOR2_VINT  y;
    TENSOR2       Y; 

    int           is_tm; 
    double        J_dx; 
    TENSOR2       dalpha; 
    TENSOR2       m1,m2; 

    ROUSSELIER_KINEMATIC();
    ROUSSELIER_KINEMATIC(MATERIAL_PIECE* boss);
    ROUSSELIER_KINEMATIC(const ROUSSELIER_KINEMATIC& kin, MATERIAL_PIECE* boss);

    virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
    virtual MATERIAL_PIECE*  copy_self(MATERIAL_PIECE*);
    virtual ~ROUSSELIER_KINEMATIC();
    virtual void      look(VECTOR& var, VECTOR& dvar, int is_theta_method);
    virtual const TENSOR2&    calculate_x();

    virtual const VECTOR& evolution(double devcum,
                                   const TENSOR2& stress,
                                   const TENSOR2& norm);

   virtual void compute_theta_stuff(DIRECT_KINEMATIC_DATA& dat); 
   RTTI_INFO;
};

// ------------------------------------------------------------ 
// See Arruda and Boyce Int. J. Plasticity Vol 9 pp 697-720 (1993)
// equation 20 in the paper. 
// 
// A stiffening model for polymer chains... static recovery term
// under development... This is an adaptation from the original 
// paper.. some dramatically different results could be had depending 
// on the strain measures in the model. 
// 
// *kinematic eight_chain_polymer 
// 
// Also programmed in the ZebFront files Boyce_polymer.z and 
// Boyce_polymer_mod.z 
// ------------------------------------------------------------ 

ZCLASS EIGHT_CHAIN_POLYMER_KINEMATIC : public RECOVERY_DIRECT_KINEMATIC {
  public : 
    COEFF         N, CR; 
    TENSOR2_VINT  alpha;
    TENSOR2_VAUX  XX;
    TENSOR2_VAUX  lam;

    double        eps; 
    TENSOR2       Rlam; 

    EIGHT_CHAIN_POLYMER_KINEMATIC();
    EIGHT_CHAIN_POLYMER_KINEMATIC(MATERIAL_PIECE* boss);
    EIGHT_CHAIN_POLYMER_KINEMATIC(const EIGHT_CHAIN_POLYMER_KINEMATIC& kin, 
                                  MATERIAL_PIECE* boss);

   virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
   virtual MATERIAL_PIECE*  copy_self(MATERIAL_PIECE*);
   virtual ~EIGHT_CHAIN_POLYMER_KINEMATIC();
   virtual void  look(VECTOR& var, VECTOR& dvar, int is_theta_method);
   virtual const TENSOR2&    calculate_x();

   virtual const VECTOR& evolution(double devcum,
                                   const TENSOR2& stress,
                                   const TENSOR2& norm);

   virtual void compute_theta_stuff(DIRECT_KINEMATIC_DATA& dat); 
   RTTI_INFO;
}; 

// ------------------------------------------------------------
//  Tensile/Compressive kinematic...   foerch@nwnumerics.com 06/20/2000 
//  for cast iron behavior, following: 
//  Josetson, Stigh and Hjelm J. Eng. Mat. Tech. V117 145-150 (1995)
//
//  It is a classical Armstrong-Frederick model, and not a piecewise 
//  linear as they did in the paper. 
// ------------------------------------------------------------
ZCLASS NON_SYM_NL_KINEMATIC : public RECOVERY_DIRECT_KINEMATIC {
  public :
    COEFF         I1_trans; 
    COEFF         Ct,Dt;
    COEFF         Cc,Dc;

    int           use_x; 
    int           msz; 
    TENSOR2_VINT  alpha;
    SCALAR_VAUX   i1; 

    TENSOR2       mm;
    TENSOR2       zone;
    double        mod;

    NON_SYM_NL_KINEMATIC();

    virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
    virtual ~NON_SYM_NL_KINEMATIC() { }
    virtual const TENSOR2&    calculate_x();

    virtual const VECTOR& evolution(double devcum,
                                    const TENSOR2& stress,
                                    const TENSOR2& norm);

    virtual void compute_theta_stuff(DIRECT_KINEMATIC_DATA& dat);
   RTTI_INFO;
};
Z_END_NAMESPACE;
#endif

