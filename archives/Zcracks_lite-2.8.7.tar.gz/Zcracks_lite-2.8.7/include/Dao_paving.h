#ifndef __Dao_paving__
#define __Dao_paving__

// ============================================================================ 
//  The PAVER ... lots of copying from the delaunay routine which is probably 
//                a bad thing as the triangulation routine sucks. 
//
//                Total hack by RF July 1998 
// 
// ============================================================================ 

#include <Geometry_parts.h>
#include <Dao_domains.h>
#include <Dao_free_domain.h>
#include <Utility_connections.h>

Z_START_NAMESPACE;

class PAVING_QUAD; 
class PAVING_EDGE; 
class PAVING_BOUNDARY; 

// 
// modif is the approximate "age" of the vertex.. used to 
// eliminate smoothing "old" elements. 
// 
// 
ZCLASS2 PAVING_VERTEX : public GRAPHICS_POINT { 
  protected : 
  public : 
     int boundary_point; 
     int edge_point;             // 1 if its part of the original edges 
     int smoothed_as_boundary;   // 1 if it is on the curent mesh front (boundary)
     double   active_angle; 
     PAVING_BOUNDARY* curr_bndy; 
     int      index_in_boundary; 
     int      set_mid_side;      // utility thingie. 
     int      index;             // ditto
     int      modif;             

     PAVING_EDGE *left, *right; 
     BUFF_LIST<PAVING_EDGE*> connectors;
     PAVING_VERTEX*  gen_pt;
     double          desired_length; 

     PAVING_VERTEX(); 
     PAVING_VERTEX(const GRAPHICS_POINT& gp);
     PAVING_VERTEX(const PAVING_VERTEX& gp);
     PAVING_VERTEX(const VECTOR& v);
     virtual ~PAVING_VERTEX() {  }
     PAVING_VERTEX& operator=(const GRAPHICS_POINT& gp);
     PAVING_VERTEX& operator=(const PAVING_VERTEX& gp);
     PAVING_VERTEX& operator=(const VECTOR& v);
};

ZCLASS2 PAVING_EDGE { 
  public : 
    PAVING_EDGE(); 
    ~PAVING_EDGE(); 

    void setup_norm(PAVING_VERTEX* use_p1, PAVING_VERTEX* use_p2); 
  public : 
    LIST<PAVING_QUAD*> quads;

    PAVING_VERTEX *p1, *p2; 
    double         t1,   t2; 
    DAO_EDGE*      its_edge; 

    // 
    // To find the left side of the edge & proximity
    // 
    VECTOR         norm; 
    GRAPHICS_POINT edge_cent; 
    double         edge_rad; 
};

// 
// These are the closed loops of edges to be delt with.. 
// each one has it's vertices characterized by their 
// angle. 
// 
ZCLASS2 PAVING_BOUNDARY : public BUFF_LIST<PAVING_EDGE*> { 
  public : 
     PAVING_BOUNDARY(); 
     PAVING_BOUNDARY(const PAVING_BOUNDARY& in); 
     PAVING_BOUNDARY(const BUFF_LIST<PAVING_EDGE*>& in); 
     PAVING_BOUNDARY& operator=(const PAVING_BOUNDARY& bndy);
//     PAVING_BOUNDARY& operator=(const BUFF_LIST<PAVING_EDGE*>& bndy);
     virtual ~PAVING_BOUNDARY(); 
 
     PAVING_EDGE* idx(int i) { 
         if (i>=sz) return x[i-sz]; 
         if (i<0)   return x[i+sz]; 
         return x[i]; 
     } 
}; 

ZCLASS2 PAVING_QUAD { 
  public :
    int index; 
    BUFF_LIST<PAVING_VERTEX*> vert; 
    BUFF_LIST<PAVING_EDGE*>   edge; 
    
    PAVING_QUAD();
    PAVING_QUAD(PAVING_VERTEX* p1, PAVING_VERTEX* p2, 
                PAVING_VERTEX* p3, PAVING_VERTEX* p4);
    ~PAVING_QUAD();

    void set_neighbors_modified(); 
    PAVING_VERTEX* get_node_before(PAVING_VERTEX* vert); 
    PAVING_VERTEX* get_node_after(PAVING_VERTEX* vert); 
}; 


// ---------------------------------------------------------------------------- 
//  
// ---------------------------------------------------------------------------- 

ZCLASS2 DAO_PAVING_DOMAIN : public DAO_FREE_DOMAIN {
  public :
    UTILITY_CONNECTION mesh_connection;
    int    fail; 

    // 
    // Options set in $Z7PATH/lib/paving.conf 
    // 
    int     LOOK_TIME; 
    int     MAKE_MOVIE; 
    int     SIZE_FOR_PREDEFINED; 
    double  SIZE_FACTOR; 
    int     DO_TUCK; 
    int     NUM_FOR_AVE_CONNEC_SMOOTH; 
    double  CLOSE_FACTOR; 
    int     REMOVE_BOWTIE; 
    int     USE_BRUTE_AT_END; 
    double  SEAM_DEFAULT; 
    double  SIZE_DEFAULT; 
    int     ALLOW_SOME_TRIANGLES; 

    int     USE_SEAM_WEDGE; 
    int     DO_WEDGE; 
    int     WEDGE_AFTER_ITERATION; 

    int     DO_ELE_PAIR_SHARING; 
    int     CHECK_FOR_CLOSURE_EACH_PASS; 
    int     SMOOTH_AGE; 
    int     CHECK_FOR_CL_WITH_CLOSE; 
    int     VIEW_EDGE_NORMS; 
    void    load_defaults(); 

    double x_max, y_max, z_max; 
    double x_min, y_min, z_min; 

    double sigma1, sigma2, sigma3, sigma4; 
    int    iteration_number; 
    int    num_added; 
    int    num_closed_regions; 
    int    current_refine_boundary; 
    double fusion; 

    LIST<int>                    bnd_leave_alone; 
    BUFF_LIST<PAVING_EDGE*>      outer_edges; 
    BUFF_LIST<PAVING_VERTEX*>    outer_points; 
    BUFF_LIST<PAVING_EDGE*>      active_edges; 

    BUFF_LIST<PAVING_BOUNDARY*>  paving_boundaries; // #0 is the outer... 

    BUFF_LIST<PAVING_VERTEX*>    all_points; 
    BUFF_LIST<PAVING_QUAD*>      all_quads; 
    PAVING_VERTEX* look; 

    PAVING_EDGE* get_edge( PAVING_VERTEX* p1, PAVING_VERTEX* p2);

    virtual void do_smooth(); 
    virtual void interior_smooth(); 
    virtual void boundary_smooth(); 
    virtual void brute_force_smooth(); 

    virtual void pave_out_special_case(PAVING_BOUNDARY& closeit); 
    virtual int  refine_iteration();
    virtual void first_iteration();

            double make_angle(PAVING_EDGE& pe1, PAVING_EDGE& pe2); 
    virtual void setup_angles(); 
    virtual void configure_boundaries(); 
    virtual double calc_F(PAVING_EDGE& e1, PAVING_EDGE& e2); 
    virtual int  closure_check(); 
    virtual void close_it(PAVING_VERTEX& pt); 
    virtual int  proximity_check(); 

    int set_for_pairs( UTILITY_NODE* n1, UTILITY_NODE* n2,  
                                         UTILITY_NODE* node);
    virtual void create_the_mesh();
    virtual void ele_debug_output();

    int compress_element(int i, int st); 
    int clean_degen(); 
    int clean_degen_at_end(); 
    int row_adjustment(); 

    PAVING_VERTEX* get_extra_pt(PAVING_VERTEX* v); 
    void get_vert_list(ARRAY<PAVING_VERTEX*>& v, PAVING_BOUNDARY& bndy, 
                       int index, int inverse=0); 

    PAVING_QUAD* create_end_element(PAVING_VERTEX* nd);
    PAVING_QUAD* create_close_element(PAVING_VERTEX* nd);
    PAVING_QUAD* create_edge_element(PAVING_VERTEX* nd, int flag=0);
    PAVING_QUAD* create_corner_element(PAVING_VERTEX* nd);
    PAVING_QUAD* create_reversal_element(PAVING_VERTEX* nd);

    void get_attached_elements(BUFF_LIST<PAVING_QUAD*>& att,
                              PAVING_VERTEX* pt); 
    void get_attached_elements(BUFF_LIST<PAVING_QUAD*>& att,
                              PAVING_EDGE* edge); 
    void replace_everywhere(PAVING_VERTEX* orig, 
                            PAVING_VERTEX* replace); 

    void find_dup_index(BUFF_LIST<int>& index, const ARRAY<UTILITY_NODE*>& nds); 
    void check_for_degenerate_element(UTILITY_ELEMENT*& ele); 

  public :
    VECTOR plane_norm; 
    static DAO_PAVING_DOMAIN* active_domain;

    double fuse; 

    DAO_PAVING_DOMAIN(DAO_GEOMETRY* bin);
    DAO_PAVING_DOMAIN(ASCII_FILE& file, DAO_GEOMETRY* bin);

    virtual ~DAO_PAVING_DOMAIN(); 

    virtual void run_iteration();
    virtual void reset();

    virtual void remesh();
    virtual void local_draw(GRAPHICS_AREA* ga);

    virtual void write(Zofstream&);

    virtual MODIFY_INFO_RECORD* get_modify_info_record();
    virtual bool                set_from_modify_info_record(const MODIFY_INFO_RECORD*);
};
Z_END_NAMESPACE;

#endif
