#ifndef __CRACK_FV__
#define __CRACK_FV__

#include <Vector.h>
#include <Matrix.h>
#include <List.h>
#include <Element.h>
#include <Stringpp.h>
#include <Crack_FC.h>
#include <Crack_FE.h>
#include <GTH_element.h>

Z_START_NAMESPACE;

class CRACK_FC;
class GTH_ELEMENT;

class CRACK_FV : public BUFF_LIST<GTH_ELEMENT*>
{
  protected :
    CRACK_FC *its_boss;

  public :
    STRING elset_name,nset_name;
    int  kind_of_volume;
    bool initialize(double,GMESH*,int _kind=0,double rext=5.);
    bool initialize(ARRAY<ELEMENT*> elems,GMESH*,double);
    bool apply_theta(VECTOR&);

    // two VECTOR frame describing a plane, whose plane is the intersection between the cylinder and the structure edge
    LIST<VECTOR>  initialEdge; 
    LIST<VECTOR>  finalEdge;
    double radius;
    ARRAY<bool> node2_in,dof_in;
    ARRAY<int> node_in;

// Must set dof_in from somewhere where DOFs exist

    CRACK_FV(CRACK_FC * boss) { its_boss=boss; elset_name="ALL_ELEMENT"; nset_name="ALL_NODE";
    }
    CRACK_FV() { its_boss = NULL; elset_name="ALL_ELEMENT"; radius=0.;
    }
    ~CRACK_FV();

    MATRIX Compute_F_by_gth();

    bool is_in(ELEMENT*,int);
};
Z_END_NAMESPACE;

#endif
