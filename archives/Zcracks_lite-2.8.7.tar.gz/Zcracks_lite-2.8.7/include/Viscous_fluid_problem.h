#ifndef __Viscous_fluid_problem__
#define __Viscous_fluid_problem__

#include <Hierarchy.h> 
#include <Marray.h> 
#include <Vector.h> 

#include <Problem.h> 
#include <Global_matrix.h> 
#include <Mesh.h> 

Z_START_NAMESPACE;

ZCLASS2 VISCOUS_FLUID_MESH : public MESH {
  public :
      VISCOUS_FLUID_MESH() { } 
      RTTI_INFO;
};

class INTEGRATION_RESULT;

ZCLASS2 PROBLEM_VISCOUS_FLUID : public PROBLEM { 
   protected :
      int iter_max;
      int is_transient;
      AUTO_PTR<GLOBAL_MATRIX> K,M; 

      void create_mesh();
      virtual INTEGRATION_RESULT* newton_convergence(); 
      virtual void make_dof_stores(); 

  public :  
      int    max_nb_disp; 
      int    nb_veloc_dof; 
      MARRAY<VECTOR> d_store, v_store; 
      LIST<DOF_TYPE*> u_type; 
      LIST<DOF_TYPE*> v_type; 

      PROBLEM_VISCOUS_FLUID();
      virtual ~PROBLEM_VISCOUS_FLUID();

      virtual bool Initialize();
      virtual bool Execute();

      virtual bool make_increment(double);
      RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
