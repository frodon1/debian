#ifndef __Unshared_removed_middle_nodes__
#define __Unshared_removed_middle_nodes__

#include <Mesh.h>
#include <Relationship.h>

Z_START_NAMESPACE;

class UNSHARED_REMOVED_MIDDLE_NODES : public RELATIONSHIP {

   protected :

     MESH* its_mesh;
     UTILITY_CONNECTION   connec;

     virtual void _set_relationship(MESH&);
     bool is_quadratic(UTILITY_ELEMENT*);
     void get_free_middle_nodes(const UTILITY_BOUNDARY&, BUFF_LIST<UTILITY_NODE*>&,
       BUFF_LIST<UTILITY_NODE*>&);

   public :

     ARRAY<NODE*>          slave_nodes;
     ARRAY< ARRAY<NODE*> > master_nodes;

     UNSHARED_REMOVED_MIDDLE_NODES();
     ~UNSHARED_REMOVED_MIDDLE_NODES();
     
     void load(ASCII_FILE&) {}
     void set_relationship_definition(MESH&);

     RTTI_INFO;

};

Z_END_NAMESPACE;

#endif
