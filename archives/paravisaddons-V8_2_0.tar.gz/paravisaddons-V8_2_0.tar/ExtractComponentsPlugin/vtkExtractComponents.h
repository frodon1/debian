/*=========================================================================

  Program:   ParaView
  Module:    vtkExtractComponents.h

  Copyright (c) Kitware, Inc.
  All rights reserved.
  See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/**
 * @class   vtkExtractComponents
 * @brief   Extract a component of an attribute.
 *
 * vtkExtractComponents Extract a component of an attribute.
*/

#ifndef vtkExtractComponents_h
#define vtkExtractComponents_h

#include <set>

#include "vtkDataSetAlgorithm.h"

class vtkDataSet;

class vtkExtractComponents : public vtkDataSetAlgorithm
{
public:
  static vtkExtractComponents* New();
  vtkTypeMacro(vtkExtractComponents, vtkDataSetAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  void AddComponent(int);
  void ClearComponents();

  vtkSetStringMacro(OutputArrayName);
  vtkGetStringMacro(OutputArrayName);


protected:
  vtkExtractComponents();
  ~vtkExtractComponents();

  virtual int RequestData(vtkInformation*, vtkInformationVector**, vtkInformationVector*);

  virtual int FillInputPortInformation(int port, vtkInformation* info);

  std::set<int> InputArrayComponents;
  char* OutputArrayName;


private:
  vtkExtractComponents(const vtkExtractComponents&) VTK_DELETE_FUNCTION;
  void operator=(const vtkExtractComponents&) VTK_DELETE_FUNCTION;
};

#endif
