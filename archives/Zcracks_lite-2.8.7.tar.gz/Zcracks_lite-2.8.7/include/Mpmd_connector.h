#ifndef __MPMD_CONNECTOR__
#define __MPMD_CONNECTOR__

#include <Connector.h>

Z_START_NAMESPACE;

/**
 a class used in MPMD mode (ie when tasks are launched by ZeBuLoN itself, such as in PVM3)
 */
ZCLASS MPMD_CONNECTOR : public CONNECTOR
{
  public :
    /// default constructor
    MPMD_CONNECTOR() { }
   ~MPMD_CONNECTOR() { }

    /// method called just after main()
    virtual int connect(int& argc, char**& argv);
};
Z_END_NAMESPACE;

#endif
