#ifndef __Explicit_mechanical_pb__
#define __Explicit_mechanical_pb__

#include <Pointer.h>
#include <Problem_mechanical.h>
#include <Explicit_damping.h>
#include <Explicit_contact.h>

Z_START_NAMESPACE;

class EXPLICIT_MESH;
class MECHANICAL_EXPLICIT_ALGORITHM;
class ASCII_FILE;
class INTEGRATION_RESULT;
class EXPLICIT_INITIAL_CONDITION;


ZCLASS2 PROBLEM_EXPLICIT_MECHANICAL : public PROBLEM_MECHANICAL {
    friend class MECHANICAL_EXPLICIT_ALGORITHM;
  protected :
    int every_update,use_elem_props;

    virtual void create_mesh();
    virtual bool read_initial_condition(ASCII_FILE&);
    virtual bool read_explicit(ASCII_FILE&);
    virtual bool read_d_contact(ASCII_FILE&);
    virtual bool read_contact(ASCII_FILE&);

    virtual bool Initialize();

    virtual bool make_increment(double);
    virtual void end_increment(INTEGRATION_RESULT*&);

    PLIST<EXPLICIT_INITIAL_CONDITION> initial_conditions;

    PLIST<EXPLICIT_DAMPING>        damping; 
    //    PTR<CONTACT>                   contact;
    PTR<EXPLICIT_CONTACT>                   contact;

  public :
    EXPLICIT_DAMPING_CONSTANT*     constant_damping; 

    EXPLICIT_MESH*                 its_mesh;
    MECHANICAL_EXPLICIT_ALGORITHM* its_algo;

    PROBLEM_EXPLICIT_MECHANICAL();
    virtual ~PROBLEM_EXPLICIT_MECHANICAL();

    virtual bool GetResponse(const char* const keyword, ASCII_FILE& file);
    virtual bool Execute();


    int time_steps_total_number;

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
