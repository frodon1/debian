#define USE_LOCAL_BOUNDARY_LAYER_SIZE 0

#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/meshgems.h>
#include <meshgems/hybrid.h>

/* FOR OEM customers only, uncomment the following */
/*#include <meshgems_key_xxx.h>*/

/**
 * Let's assume that the following structure holds data that 
 * represents the input surface mesh on client side. 
 * It could be a database handle or
 * anything else containing surface mesh data. 
 * We will build the mesh_t object that accesses it.
 * See the file meshgems/mesh.h for more detailed information
 */

struct your_mesh_internal_data_t_ {
//_your_mesh_data;
};

typedef struct your_mesh_internal_data_t_ your_mesh_internal_data_t;

/**
 * Implementation of how the number of vertices in the mesh is obtained.
 * @param[out]	nbvtx	: the number of vertices
 * @param[in]     user_data	: a user pointer.
 * @return error code
 */

status_t mgtm_get_vertex_count(integer * nbvtx, void *user_data) {
	your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

	*nbvtx = 0;              //the_number_of_vertex_in_your_mesh;

	return STATUS_OK;
}

/**
 * Implementation of how the coordinates of a mesh vertex are obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	xyz	: real[3] array containing the coordinates of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */

status_t mgtm_get_vertex_coordinates(integer ivtx, real * xyz, void *user_data) {
	int j;
	your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

	for (j = 0; j < 3; j++)
		xyz[j] = 0;            //j_th_coordinate_of_the_ivtx_th_vertex;

	return STATUS_OK;
}

/**
 * Implementation of how the number of triangles in the mesh is obtained.
 * @param[out]	nbtri	: the number of triangles
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_count(integer * nbtri, void *user_data) {
	your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

	*nbtri = 0;                   // the_number_of_triangle_in_your_mesh;

	return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh triangle are obtained.
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]	vtri	: integer[3] array containing the vertices of the triangle
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_vertices(integer itri, integer * vtri,
		void *user_data) {
	int j;
	your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

	for (j = 0; j < 3; j++)
		vtri[j] = 0;            //j_th_vertex_index_of_the_itri_th_triangle;

	return STATUS_OK;
}

/**
 * Implementation of how the number of quadrangles in the mesh is obtained.
 * @param[out]	nbquad	: the number of quadrangles
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_quadrangle_count(integer * nbquad, void *user_data) {
	your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

	*nbquad = 0;             // the_number_of_quadrangle_in_your_mesh;

	return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh quadrangle are obtained.
 * @param[in]	iquad	: index of the desired quadrangle from 1 to nbtri
 * @param[out]	vquad	: integer[4] array containing the vertices of the quadrangle
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_quadrangle_vertices(integer iquad, integer * vquad,
		void *user_data) {
	int j;
	your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

	for (j = 0; j < 4; j++)
		vquad[j] = 0;      //j_th_vertex_index_of_the_itri_th_quadrangle;

	return STATUS_OK;
}

/**
 * This is the message callback function that Hybrid will call when
 * it wants to send a message to the caller
 * see meshgems/message.h for more details.
 *
 * @param[in] msg       : the message
 * @param[in] user_data : a user pointer.
 * @return an error code
 */
status_t my_message_cb(message_t * msg, void *user_data) {

	char *desc;
	integer e, ibuff[6];
	real r;
	status_t ret;

	/* Get the error number */
	ret = message_get_number(msg, &e);

	if (e < 0) {
		/* This is an error
		 */
		printf("MG-Hybrid ERROR %i : %s", MESHGEMS_ABS_CODE(e), desc);

	} else {
		ret = message_get_description(msg, &desc);
		if (ret != STATUS_OK)
			return ret;

		printf("MG-Hybrid message : %s", desc);
	}

	return STATUS_OK;

}

/* A macro we will call to cleanly return from the function in case of failure */
#define RETURN_WITH_MESSAGE(_ret, _msg) do{				\
    fprintf(stderr,"%s\n",_msg);					\
    if(hxs) hybrid_session_delete(hxs);				\
    if(msh) mesh_delete(msh);						\
    if(ctx) context_delete(ctx);					\
    return _ret;							\
  }while(0);

status_t hybrid_mesh(your_mesh_internal_data_t * your_mesh_internal_data) {
	status_t ret;
	context_t *ctx;
	mesh_t *msh, *vmsh;
	hybrid_session_t *hxs;
	integer i, ntm, nvm, nhm, ntrim, nprism, npyr;
	integer reqedg;
	integer nedg, nf;
	integer nsd;
	real q, qmin, qmax;

	ctx = NULL;
	msh = NULL;
	hxs = NULL;
	vmsh = NULL;

	/*
	 * Create the meshgems working context
	 */
	ctx = context_new();
	if (!ctx)
		RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new context");

	/*
	 * Set the message callback for our context and create the mesh accessor.
	 */
	ret = context_set_message_callback(ctx, my_message_cb, NULL);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "internal error");

	/*
	 * Create the mesh_t structure holding the callbacks giving acces 
	 * to your mesh data in your_mesh_internal_data
	 */
	msh = mesh_new(ctx);
	if (!msh)
		RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new mesh");

	/*
	 * Set the mesh_t callback functions that will interogate the mm_t struct :
	 * see meshgems/mesh.h for more details.
	 */

	mesh_set_get_vertex_count(msh, mgtm_get_vertex_count,
			your_mesh_internal_data);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "internal error");
	mesh_set_get_vertex_coordinates(msh, mgtm_get_vertex_coordinates,
			your_mesh_internal_data);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "internal error");

	mesh_set_get_triangle_count(msh, mgtm_get_triangle_count,
			your_mesh_internal_data);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "internal error");
	mesh_set_get_triangle_vertices(msh, mgtm_get_triangle_vertices,
			your_mesh_internal_data);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "internal error");

	mesh_set_get_quadrangle_count(msh, mgtm_get_quadrangle_count,
			your_mesh_internal_data);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "internal error");
	mesh_set_get_quadrangle_vertices(msh, mgtm_get_quadrangle_vertices,
			your_mesh_internal_data);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "internal error");

	if (0) {
		/*
		 * Display some statistics about the surface mesh.
		 * The data is sent formated to the context message callback
		 * For debugging purposes
		 */
		mesh_compute_statistics(msh);
	}
#ifdef __MESHGEMS_PRIVKEY_H__
	/* If you are an OEM customer for MG-HYBRID, sign this mesh object with
	 * your private key (else MG-HYBRID would reject it) */
	ret = meshgems_sign_mesh(msh);
	if (ret != STATUS_OK)
	return ret;
#endif

	/*
	 * Create an hybrid session
	 */

	hxs = hybrid_session_new(ctx);
	if (!hxs)
		RETURN_WITH_MESSAGE(STATUS_NOMEM,
				"unable to create a new hybrid session");

	/*
	 * Set the input working surface for this hybrid session
	 */

	/*
	 * Starting from a surface mesh.
	 */
	ret = hybrid_set_surface_mesh(hxs, msh);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "unable to set surface mesh");

	/* You can here specify the MG-HYBRID options, using the function
	 * hybrid_set_param(), see the documentation.
	 */
	if (0) {
		/* For example, here are some MG-HYBRID options.
		 * See the documentation for the complete list of options.
		 */

		/* This option changes the verbosity level of MG-HYBRID, between 1 and
		 * 10.  The higher it is, the more messages MG-HYBRID will send
		 * through the message callback. Default is 3.
		 */
		ret = hybrid_set_param(hxs, "verbose", "3");
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");

		/* This option sets the height of the first layer.
		 */
		ret = hybrid_set_param(hxs, "boundary_layer_global_initial_height",
				"0.0001");
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");

		/* This option sets the number of boundary layers.
		 */
		ret = hybrid_set_param(hxs, "number_of_boundary_layers", "2");
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");

		/* This option describes whether MG-HYBRID should  use 
		 * the surface normals or the opposite to the surface
		 * normals.
		 *    if <dir> is:
		 *       1 : this means the layers grow in the same 
		 *           direction as the normals to the surface
		 *      -1 : this means the layers grow in the opposite
		 *           direction to the normals to the surface
		 * Default: 1
		 */
		ret = hybrid_set_param(hxs, "normal_direction", "1");
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");

		/* This option sets the geometric progression for the boundary layer 
		 * growth (layer number i position is h * g^(i-1)).
		 *  Default: 1.0
		 */
		ret = hybrid_set_param(hxs, "boundary_layer_geometric_progression",
				"1.1");
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");

		/* This option changes the type of element generated inside the 
		 * domain,
		 * If this parameter is set to 
		 *      tetra_dominant: prismatic or hexahedral elements in the 
		 *        boundary layers, tetrahedra in the remaining volume
		 *      hexa_dominant:  prismatic or hexahedral elements in the 
		 *        boundary layers, mixture of hexahedra and tetrahedra 
		 *        in the remaining volume
		 *      cartesian_core : cartesian core with a mixture of tetrahedra and pyramids
		 *        in the remaining volume. The edge lenght of the generated hexahedra
		 *        is given by the parameter global_physical_size.
		 *      extrusion only : only prismatic or hexahedral elements 
		 *        near the boundary are generated. The remaining volume is 
		 *        not filled.
		 * Default: tetra_dominant
		 */
		ret = hybrid_set_param(hxs, "element_generation", "tetra_dominant");
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");

		/* 
		 * This option sets the desired maximum ratio between 2 adjacent tetrahedra edges.
		 * The closer it is to 1, the more uniform the mesh will be.
		 */
		ret = hybrid_set_param(hxs, "gradation", "2.0");
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");

		/*
		 * Set this option to yes to add multinormals at opening ridges and
		 * corners.
		 */
		ret = hybrid_set_param(hxs, "add_multinormals", "no");
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");

		/* This option sets the maximum angle between the multiple normals at 
		 * opening ridges.
		 * Default: 30
		 */
		ret = hybrid_set_param(hxs, "multinormal_angle_threshold", "30");
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");

		/* Set this option to yes to apply normal smoothing at closed ridges.
		 */
		ret = hybrid_set_param(hxs, "smooth_normals", "no");
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");

	}

	/* You can here specify the surface tags  to be used to grow layer,
	 * and the height of the first layer for the layer built on theses tags
	 *
	 */
	if (USE_LOCAL_BOUNDARY_LAYER_SIZE) {

		/* 
		 * Set this option to local to use local specifications for 
		 * the initial height of the boundary layers
		 */
		ret = hybrid_set_param(hxs, "boundary_layer_size_mode", "local");
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");

		integer surface_tag;
		real height_of_layer_on_tag;
		ret = meshgems_hybrid_set_initial_height_on_surface_tag(hxs,
				surface_tag, height_of_layer_on_tag);
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "internal error");
	}

	/* To compute volume mesh */
	ret = hybrid_compute_mesh(hxs);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "unable to compute a volume mesh");
	/*
	 * Mesh generation is completed.
	 * Get the generated volume mesh. This output mesh belongs to the
	 * hybrid_session. Thus the user does not have to destroy it
	 * afterwards.
	 */

	ret = hybrid_get_mesh(hxs, &vmsh);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "unable to get resulting mesh");

	/*
	 * Read the output mesh data. See meshgems/mesh.h for more details.
	 */

	/* First get all the vertices */
	ret = mesh_get_vertex_count(vmsh, &nvm);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex count");

	/*get the number of hexahedra*/
	ret = mesh_get_hexahedron_count(vmsh, &nhm);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "unable to get resulting hexahedron count");

	/*get the number of prisms*/
	ret = mesh_get_prism_count(vmsh, &nprism);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "unable to get resulting prism count");

	/*get the number of pyramids*/
	ret = mesh_get_pyramid_count(vmsh, &npyr);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "unable to get resulting pyramid count");

	/*get the number of tetrahedra*/
	ret = mesh_get_tetrahedron_count(vmsh, &ntm);
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedron count");

	for (i = 1; i <= nvm; i++) {
		real coo[3];
		ret = mesh_get_vertex_coordinates(vmsh, i, coo);
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "unable to get resulting vertices");
		if (0) {
			fprintf(stdout, "vertex %d is : %f %f %f \n", i, coo[0], coo[1],
					coo[2]);
		}
	}
	/* Then get all the tetrahedra */
	for (i = 1; i <= ntm; i++) {
		integer vtx[4], tag;
		ret = mesh_get_tetrahedron_vertices(vmsh, i, vtx);
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedra");
		if (0) {
			fprintf(stdout, "tetra %d vertices are : %d %d %d %d \n", i, vtx[0],
					vtx[1], vtx[2], vtx[3]);
		}
		ret = mesh_get_tetrahedron_tag(vmsh, i, &tag);
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedra tag");
	}

	/* Then get all the pyramids */
	for (i = 1; i <= npyr; i++) {
		integer vtx[5], tag;
		ret = mesh_get_pyramid_vertices(vmsh, i, vtx);
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "unable to get resulting pyramid");
		if (0) {
			fprintf(stdout, "pyramid %d vertices are : %d %d %d %d %d\n", i,
					vtx[0], vtx[1], vtx[2], vtx[3], vtx[4]);
		}
		ret = mesh_get_pyramid_tag(vmsh, i, &tag);
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "unable to get resulting pyramid tag");
	}

	/* Then get all the prisms */
	for (i = 1; i <= nprism; i++) {
		integer vtx[6], tag;
		ret = mesh_get_prism_vertices(vmsh, i, vtx);
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "unable to get resulting prism");
		if (0) {
			fprintf(stdout, "prism %d vertices are : %d %d %d %d %d %d\n", i,
					vtx[0], vtx[1], vtx[2], vtx[3], vtx[4], vtx[5]);
		}
		ret = mesh_get_prism_tag(vmsh, i, &tag);
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "unable to get resulting prism tag");
	}

	/* Then get all the hexahedra */
	for (i = 1; i <= nhm; i++) {
		integer vtx[8], tag;
		ret = mesh_get_hexahedron_vertices(vmsh, i, vtx);
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "unable to get resulting hexahedra");
		if (0) {
			fprintf(stdout, "hexa %d is : %d %d %d %d %d %d %d %d \n", i,
					vtx[0], vtx[1], vtx[2], vtx[3], vtx[4], vtx[5], vtx[6],
					vtx[7]);
		}
		ret = mesh_get_hexahedron_tag(vmsh, i, &tag);
		if (ret != STATUS_OK)
			RETURN_WITH_MESSAGE(ret, "unable to get resulting hexahedra tag");
	}

	fprintf(stdout,
			"\nGenerated %d vertices,%d tetrahedra, %d pyramids, %d prisms and %d hexahedra  \n",
			nvm, ntm, npyr, nprism, nhm);

	/*
	 * We can also directly write a .mesh formatted file :
	 */

	fprintf(stdout, "Writing volume mesh in output_hybrid.mesh file\n");
	ret = mesh_write_mesh(vmsh, "output_hybrid.mesh");
	if (ret != STATUS_OK)
		RETURN_WITH_MESSAGE(ret, "unable to write a .mesh file");

	if (1) {
		/*
		 * Display some statistics about the output mesh.
		 * The data is sent formated to the context message callback
		 * for debugging purposes.
		 */
		mesh_compute_statistics(vmsh);
	}

	/*
	 * We are done, give the volume mesh back to the session 
	 * and clean up everything.
	 */

	hybrid_regain_mesh(hxs, vmsh);
	hybrid_session_delete(hxs);
	mesh_delete(msh);

	context_delete(ctx);

	return STATUS_OK;
}
