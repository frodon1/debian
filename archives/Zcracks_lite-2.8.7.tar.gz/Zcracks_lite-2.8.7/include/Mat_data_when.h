#ifndef __Mat_data_when__
#define __Mat_data_when__

Z_START_NAMESPACE;
 
enum MDAT_WHEN { MDAT_0, MDAT_INI, MDAT_CURR };
 
Z_END_NAMESPACE;

#endif
