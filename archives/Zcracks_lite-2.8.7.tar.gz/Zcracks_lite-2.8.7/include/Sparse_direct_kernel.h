#ifndef __SPARSE_DIRECT_KERNEL__
#define __SPARSE_DIRECT_KERNEL__

#include <Global_matrix_kernel.h>

Z_START_NAMESPACE;

ZCLASS2 SPARSE_DIRECT_KERNEL : public GLOBAL_MATRIX_KERNEL {

  public :
    SPARSE_DIRECT_KERNEL(const DD_SUB_DOMAIN&,GLOBAL_MATRIX&);
    virtual ~SPARSE_DIRECT_KERNEL() {};

    virtual bool build_kernel(int,bool);
    virtual void fix_dof();
};
Z_END_NAMESPACE;

#endif
