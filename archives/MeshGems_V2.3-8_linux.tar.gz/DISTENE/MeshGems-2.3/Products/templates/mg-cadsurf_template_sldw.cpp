/* This file describes how to import a IModelDoc2 contained in a ISldWorks into the 
 * meshgems_cad_t structure. The function generate_mesh defined in 
 * mg-cadsurf_template_common.cpp is then called to build a 
 * surface mesh using MG-CADSurf.
 */

#define CREATE_DCAD 0
#define CREATE_PERIODICITY 0

extern "C" {
#include "meshgems/meshgems.h"
#include "meshgems/cadsurf.h"
} 

status_t generate_mesh(context_t * ctx, cad_t * c, dcad_t * dc,
                         mesh_t * msh);

class surf_data_t {
public:CComPtr < ISurface > surface;
};

class edge_data_t {
public:
  CComPtr < IFace2 > face;
  CComPtr < IEdge > edge;
};

void sd_delete_fun(void *arg)
{
  surf_data_t *sd = (surf_data_t *) arg;
  if (sd)
    delete[]sd;
}

void cd_delete_fun(void *arg)
{
  edge_data_t *cd = (edge_data_t *) arg;
  if (cd)
    delete[]cd;
}

/* Curve definition function for edges without derivatives. (defined
 * in UV by a reverse projetion 
 */
status_t curv0_function_sldw(real t, real * uv, real * dt, real * dtt,
                             void *user_data)
{
  edge_data_t *edge = (edge_data_t *) user_data;
  double coord[2];
  double xyz[3];
  HRESULT res = S_OK;
  long track_id[2];
  long status = 0;

  assert(edge);
  assert(edge->edge);
  assert(edge->face);

  if (uv) {
    res = edge->edge->IEvaluate2(t, 0, xyz);
    if (res != S_OK)
      return STATUS_ERROR;

    res = edge->face->IReverseEvaluate(xyz[0], xyz[1], xyz[2], coord);
    if (res != S_OK)
      return STATUS_ERROR;

    uv[0] = coord[0];
    uv[1] = coord[1];
  }

  return STATUS_OK;
}

status_t curv3d_function_sldw(real t, real * xyz, void *user_data)
{
  edge_data_t *edge = (edge_data_t *) user_data;
  HRESULT res = S_OK;

  assert(edge);
  assert(edge->edge);
  if (xyz) {
    double tmp[3];

    res = edge->edge->IEvaluate2(t, 0, tmp);
    if (res != S_OK)
      return STATUS_ERROR;

    xyz[0] = tmp[0];
    xyz[1] = tmp[1];
    xyz[2] = tmp[2];
  }

  return STATUS_OK;
}

/* Surface definition function.
 * See cad_surf_t in file meshgems/cad.h for more information.
 * NOTE : if when your CAD systems evaluates second order derivatives it also
 * computes first order derivatives and function evaluation, you can optimize 
 * this example by making only one CAD call and filling the necessary xyz, du, dv, etc.. 
 * arrays.
 */
status_t surf_function_sldw(real * uv, real * xyz, real * du, real * dv,
                            real * duu, real * duv, real * dvv,
                            void *user_data)
{
  /* uv[2] is given. It contains the u,v coordinates of the point
   * MG-CADSurf is querying on the surface */

  /* user_data identifies the face MG-CADSurf is querying (see
   * cad_face_new later in this example)*/

  HRESULT res = S_OK;
  long n_derivs = 0;
  surf_data_t *surf = (surf_data_t *) user_data;
  double value[30];
  double u, v;

  assert(uv);
  u = uv[0];
  v = uv[1];

  if (du || dv)
    n_derivs = 1;
  if (duu || duv || dvv)
    n_derivs = 2;

  assert(surf);
  res = surf->surface->IEvaluate(u, v, n_derivs, n_derivs, value);
  if (res != S_OK)
    return STATUS_ERROR;

  if (xyz) {
    /* query for the function evaluation */
    xyz[0] = value[0];
    xyz[1] = value[1];
    xyz[2] = value[2];
  }

  if (n_derivs == 1) {
    /* query for the first order derivatives only */
    if (du) {
      du[0] = value[3];
      du[1] = value[4];
      du[2] = value[5];
    }

    if (dv) {
      dv[0] = value[6];
      dv[1] = value[7];
      dv[2] = value[8];
    }
  } else if (n_derivs == 2) {
    /* query for the second order derivatives */
    if (du) {
      du[0] = value[3];
      du[1] = value[4];
      du[2] = value[5];
    }

    if (dv) {
      dv[0] = value[9];
      dv[1] = value[10];
      dv[2] = value[11];
    }

    if (duu) {
      duu[0] = value[6];
      duu[1] = value[7];
      duu[2] = value[8];
    }

    if (duv) {
      duv[0] = value[12];
      duv[1] = value[13];
      duv[2] = value[14];
    }

    if (dvv) {
      dvv[0] = value[18];
      dvv[1] = value[19];
      dvv[2] = value[20];
    }
  }

  return STATUS_OK;
}

/*
 * This function specifies a transformation between two sets of face you
 * want to make periodic.  xyz contains the coordinates of a point.
 * The coordinates of the image are stored in xyz_image.  See
 * meshgems_cad_periodicity_transformation_t in meshgems/cad.h for
 * information about the function parameters
 */
static status_t periodicity_transformation(real * xyz, real * xyz_image,
                                           void *user_data)
{
  real *r = (real *) user_data;
  integer i;

  for (i = 0; i < 3; i++)
    xyz_image[i] = xyz[i] + (*r);

  return STATUS_OK;
}


status_t count_sldw_entity(CComPtr < IEnumBodies2 > ebody, int *nsurf,
                           int *ncurv)
{
  status_t ret;
  HRESULT res = S_OK;
  long n_rbody;
  CComPtr < IEnumFaces2 > eface;
  CComPtr < IBody2 > body;

  assert(ebody);
  assert(nsurf);
  assert(ncurv);
  ret = STATUS_OK;

  *nsurf = *ncurv = 0;
  n_rbody = 0;
  res = ebody->Reset();
  res = ebody->Next(1, &body, &n_rbody);
  while (n_rbody > 0) {
    long n_rface;
    CComPtr < IFace2 > face;

    eface = 0;
    res = body->EnumFaces(&eface);
    assert(eface);
    n_rface = 0;
    face = 0;
    res = eface->Reset();
    res = eface->Next(1, &face, &n_rface);
    while (n_rface > 0) {
      long n_rloop;
      CComPtr < ISurface > surface;
      CComPtr < ILoop2 > loop;
      CComPtr < IEnumLoops2 > eloop;

      assert(face);

      surface = 0;
      face->IGetSurface(&surface);
      assert(surface);
      (*nsurf)++;

      eloop = 0;
      face->EnumLoops(&eloop);
      assert(eloop);

      loop = 0;
      n_rloop = 0;
      eloop->Reset();
      res = eloop->Next(1, &loop, &n_rloop);
      while (n_rloop > 0) {
        CComPtr < IEnumCoEdges > ecoedge = 0;
        CComPtr < ICoEdge > coedge = 0;
        long n_rcoedge;

        assert(loop);
        loop->EnumCoEdges(&ecoedge);
        assert(ecoedge);

        n_rcoedge = 0;
        ecoedge->Reset();
        res = ecoedge->Next(1, &coedge, &n_rcoedge);
        while (n_rcoedge > 0) {
          assert(coedge);
          (*ncurv)++;
          coedge = 0;
          res = ecoedge->Next(1, &coedge, &n_rcoedge);
        }
        loop = 0;
        res = eloop->Next(1, &loop, &n_rloop);
      }
      face = 0;
      res = eface->Next(1, &face, &n_rface);
    }
    body = 0;
    res = ebody->Next(1, &body, &n_rbody);
  }
  return ret;
}


status_t import_sldw_geometry(CComPtr < ISldWorks > swApp, context_t * ctx,
                              cad_t ** pc, dcad_t ** pdc)
{
  CComQIPtr < IPartDoc > part;
  CComQIPtr < IAssemblyDoc > apart;
  CComPtr < IModelDoc2 > model;
  long nDocType;
  long meshgems_id;
  HRESULT res = S_OK;
  CComPtr < IComponent2 > *comp;
  CComPtr < IEnumBodies2 > ebody;
  CComPtr < IEnumFaces2 > eface;
  CComPtr < IBody2 > body;
  long n_rbody;
  long status = 0;
  long track_id[2];
  int cnt_v = 0;
  int cnt_e = 0;
  int cnt_f = 0;
  cad_t *c = 0;
  dcad_t *dc = 0;
  status_t ret;
  int nsurf, ncurv;
  int isurf, icurv;
  surf_data_t *sd_array;
  edge_data_t *cd_array;

  meshgems_id = swApp->RegisterTrackingDefinition(_T("MeshGems"), &status);
  swApp->get_IActiveDoc2(&model);

  assert(model);
  if (!model)
    return STATUS_ERROR;

  model->GetType(&nDocType);

  /* FIXME : We should here import also the swDocASSEMBLY */

  long end = 0;
  unsigned assembly = 0;
  if (nDocType == swDocPART) {
    end = 1;
    part = model;
  } else {
    return STATUS_ERROR;
  }

  ret = STATUS_OK;
  nsurf = ncurv = 0;
  if (part) {
    res = part.p->EnumBodies3(swAllBodies, VARIANT_TRUE, &ebody);
    assert(ebody);

    ret = count_sldw_entity(ebody, &nsurf, &ncurv);
    if (ret != STATUS_OK)
      return ret;

  }

  sd_array = new surf_data_t[nsurf];
  if (!sd_array)
    return STATUS_NOMEM;

  /* We attach this array to the working context : it will be deleted 
   * at the same time as the context 
   */
  ret = context_attach_object(ctx, sd_array, sd_delete_fun);
  if (ret != STATUS_OK)
    return ret;

  cd_array = new edge_data_t[ncurv];
  if (!cd_array)
    return STATUS_NOMEM;

  /* We attach this array to the working context : it will be deleted 
   * at the same time as the context 
   */
  ret = context_attach_object(ctx, cd_array, cd_delete_fun);
  if (ret != STATUS_OK)
    return ret;

  c = cad_new(ctx);
  if (!c) {
    ret = STATUS_NOMEM;
    return ret;
  }

  if (CREATE_DCAD) {
    dc = dcad_new(c);
    if (!dc) {
      ret = STATUS_NOMEM;
      return ret;
    }
  }

  integer icomp;
  isurf = icurv = 0;
  for (icomp = 1; icomp <= end; icomp++) {
    /* Prevision for assemblies */
    assert(ebody);
    assert(end == 1);
    n_rbody = 0;
    res = ebody->Reset();
    res = ebody->Next(1, &body, &n_rbody);
    while (n_rbody > 0) {
      long n_rface;
      CComPtr < IFace2 > face;
      CComPtr < IBody2 > xbody;

      /* Prevision for assemblies */
      xbody = body;

      eface = 0;
      res = xbody->EnumFaces(&eface);
      assert(eface);

      n_rface = 0;
      face = 0;
      res = eface->Reset();
      res = eface->Next(1, &face, &n_rface);
      while (n_rface > 0) {
        double u_value[2], v_value[2];
        double param[11];
        int periodic_u = 0;
        double period_u = 0;
        int periodic_v = 0;
        double period_v = 0;
        int n_uprop;
        int n_vprop;
        int utype[2];
        int vtype[2];
        int prop;
        long n_rloop;
        cad_face_t *f = 0;
        VARIANT_BOOL facesurfsense;
        CComPtr < ISurface > surface;
        CComPtr < ILoop2 > loop;
        CComPtr < IEnumLoops2 > eloop;
        int fid;

        assert(face);
        track_id[0] = track_id[1] = 0;
        face->IGetTrackingIDs(meshgems_id, 1, track_id, &status);
        fid = 0;
        if (track_id[0]) {
          fid = track_id[0];
        } else {
          fid = ++cnt_f;
          face->SetTrackingID(meshgems_id, fid, &status);
        }

        surface = 0;
        face->IGetSurface(&surface);
        assert(surface);
        assert(isurf < nsurf);
        sd_array[isurf].surface = surface;

        f = cad_face_new(c, fid, surf_function_sldw, &(sd_array[isurf]));
        if (!f) {
          ret = STATUS_NOMEM;
          return ret;
        }

        facesurfsense = true;
        face->FaceInSurfaceSense(&facesurfsense);
        if (facesurfsense) {
          ret = cad_face_set_orientation(f, CAD_ORIENTATION_REVERSED);
          if (ret != STATUS_OK)
            return ret;
        } else {
          ret = cad_face_set_orientation(f, CAD_ORIENTATION_FORWARD);
          if (ret != STATUS_OK)
            return ret;
        }

        surface->IParameterization(param);

        n_uprop = ((int *) (param + 10))[0];
        n_vprop = ((int *) (param + 10))[1];

        u_value[0] = param[0];
        u_value[1] = param[1];

        utype[0] = ((int *) (param + 4))[0];
        utype[1] = ((int *) (param + 4))[1];

        if (utype[0] == 13733)
          u_value[0] = -REAL_INFINITY;
        if (utype[1] == 13733)
          u_value[1] = REAL_INFINITY;

        periodic_u = 0;
        period_u = 0;
        for (int j = 0; j < n_uprop; j++) {
          prop = ((int *) (param + 6))[j];
          if (prop == 13701) {
            periodic_u = 1;
            period_u = u_value[1] - u_value[0];
            break;
          }
        }
        v_value[0] = param[2];
        v_value[1] = param[3];

        vtype[0] = ((int *) (param + 5))[0];
        vtype[1] = ((int *) (param + 5))[1];

        if (vtype[0] == 13733)
          v_value[0] = -REAL_INFINITY;
        if (vtype[1] == 13733)
          v_value[1] = REAL_INFINITY;

        periodic_v = 0;
        period_v = 0;
        for (int j = 0; j < n_vprop; j++) {
          prop = ((int *) (param + 8))[j];
          if (prop == 13701) {
            periodic_v = 1;
            period_v = v_value[1] - v_value[0];
            break;
          }
        }

        ret = cad_face_set_surface_parametric_range(f, u_value, v_value);
        if (ret != STATUS_OK)
          return ret;

        /* The following call sets the face tag (color) to id */
        ret = cad_face_set_tag(f, fid);
        if (ret != STATUS_OK)
          return ret;

        /* NOTE : these properties are only usefull for MG-CADSurf if you want
         * it to treat and close the CAD patches which are not closed in
         * the UV domain space (mainly periodic faces or faces build on a
         * periodic surface, like a cylinder piece). If all your CAD faces
         * are already closed in UV domain, you do not need to set these
         * properties.
         */
        ret =
            cad_face_set_surface_periodicity(f, periodic_u, periodic_v,
                                             period_u, period_v);
        if (ret != STATUS_OK)
          return ret;

        eloop = 0;
        face->EnumLoops(&eloop);
        assert(eloop);

        loop = 0;
        n_rloop = 0;
        eloop->Reset();
        res = eloop->Next(1, &loop, &n_rloop);
        while (n_rloop > 0) {
          CComPtr < IEnumCoEdges > ecoedge = 0;
          CComPtr < ICoEdge > coedge = 0;
          long n_rcoedge;

          assert(loop);
          loop->EnumCoEdges(&ecoedge);
          assert(ecoedge);

          n_rcoedge = 0;
          ecoedge->Reset();
          res = ecoedge->Next(1, &coedge, &n_rcoedge);
          while (n_rcoedge > 0) {
            double tmin, tmax;
            CComPtr < IVertex > v1, v2;
            VARIANT_BOOL eorient = true;
            VARIANT_BOOL edgefacesense = true;
            VARIANT_BOOL curveedgesense = true;
            cad_edge_t *e = 0;
            cad_vertex_t *v = 0;
            CComPtr < IEdge > edge;
            CComPtr < ICurve > curve;
            int eid = 0;
            int pid1 = 0;
            int pid2 = 0;

            assert(coedge);
            edge = 0;
            coedge->IGetEdge(&edge);
            assert(edge);

            assert(icurv < ncurv);
            cd_array[icurv].edge = edge;
            cd_array[icurv].face = face;

            track_id[0] = track_id[1] = 0;
            edge->IGetTrackingIDs(meshgems_id, 1, track_id, &status);
            eid = 0;
            if (track_id[0]) {
              eid = track_id[0];
            } else {
              eid = ++cnt_e;
              edge->SetTrackingID(meshgems_id, eid, &status);
            }

            edge->IEdgeInFaceSense2(face, &edgefacesense);

            curve = 0;
            edge->IGetCurve(&curve);
            assert(curve);

            for (int j = 0; j < 11; j++)
              param[j] = 0;

            edge->IGetCurveParams2(param);
            tmin = param[6];
            tmax = param[7];

            curveedgesense = ((int *) (param + 10))[1];
            if (!curveedgesense) {
              double tmp;

              tmin = -tmin;
              tmax = -tmax;
              tmp = tmin;
              tmin = tmax;
              tmax = tmp;
            }

            e = cad_edge_new0(f, eid, tmin, tmax, curv0_function_sldw,
                              &(cd_array[icurv]));
            if (!e) {
              ret = STATUS_NOMEM;
              return ret;
            }
            ret =
                cad_edge_set_curve3d(e, curv3d_function_sldw,
                                     &(cd_array[icurv]));
            if (ret != STATUS_OK)
              return ret;

            /* Set edge_tag (color) to the same value as its id */
            ret = cad_edge_set_tag(e, eid);
            if (ret != STATUS_OK)
              return ret;

            /* by default an edge is not oriented. The orientation should be
             * set accordingly to the following rule :
             * CAD_ORIENTATION_FORWARD : the patch lies on the left of the curve in UV space
             * CAD_ORIENTATION_REVERSED : the patch lies on the right of the curve in UV space
             * 
             * NOTE : the orientation property is only usefull for MG-CADSurf if
             * you want it to treat and close the CAD patches which are not
             * closed in the UV domain space (mainly periodic faces or faces
             * build on a periodic surface, like a cylinder piece). If all
             * your CAD faces are already closed in UV domain, you do not
             * need to set this property.
             */

            if (facesurfsense)
              eorient = !eorient;
            if (!edgefacesense)
              eorient = !eorient;
            if (!curveedgesense)
              eorient = !eorient;

            if (eorient) {
              ret = cad_edge_set_orientation(e, CAD_ORIENTATION_FORWARD);
              if (ret != STATUS_OK)
                return ret;
            } else {
              ret = cad_edge_set_orientation(e, CAD_ORIENTATION_REVERSED);
              if (ret != STATUS_OK)
                return ret;
            }

            v1 = v2 = 0;
            edge->IGetStartVertex(&v1);
            edge->IGetEndVertex(&v2);

            int periodic = 0;
            if (v1) {
              track_id[0] = track_id[1] = 0;
              v1->IGetTrackingIDs(meshgems_id, 1, track_id, &status);
              pid1 = 0;
              if (track_id[0]) {
                pid1 = track_id[0];
              } else {
                pid1 = ++cnt_v;
                v1->SetTrackingID(meshgems_id, pid1, &status);
              }
            } else {
              assert(!v2);
              periodic = 1;
            }

            if (v2) {
              track_id[0] = track_id[1] = 0;
              v2->IGetTrackingIDs(meshgems_id, 1, track_id, &status);
              pid2 = 0;
              if (track_id[0]) {
                pid2 = track_id[0];
              } else {
                pid2 = ++cnt_v;
                v2->SetTrackingID(meshgems_id, pid2, &status);
              }
            } else {
              assert(!v1);
              periodic = 1;
            }

            if (!periodic) {
              if (curveedgesense) {
                ret = cad_edge_set_extremities(e, pid1, pid2);
                if (ret != STATUS_OK)
                  return ret;
                ret = cad_edge_set_extremities_tag(e, pid1, pid2);
                if (ret != STATUS_OK)
                  return ret;

              } else {
                ret = cad_edge_set_extremities(e, pid2, pid1);
                if (ret != STATUS_OK)
                  return ret;

                ret = cad_edge_set_extremities_tag(e, pid2, pid1);
                if (ret != STATUS_OK)
                  return ret;
              }
            } else {
              ret = cad_edge_set_property(e, EDGE_PROPERTY_PERIODIC);
              if (ret != STATUS_OK)
                return ret;
            }

            /* 

               FIXME : Now, it can help to give the coordinates of the edge extremities, 
               and fill the following structure :

               xyz should contain the coordinates of the first edge extremity
               xyz[0] = ...;
               xyz[1] = ...;
               xyz[2] = ...;
               v = cad_vertex_new(c, id_of_first_extremity, xyz);
               if(!v)
               return STATUS_NOMEM;

               Then xyz should contain the coordinates of the second edge extremity
               xyz[0] = ...;
               xyz[1] = ...;
               xyz[2] = ...;
               v = cad_vertex_new(c, id_of_second_extremity, xyz);
               if(!v)
               return STATUS_NOMEM;

             */

            if (CREATE_DCAD) {
              dcad_edge_discretization_t *de = 0;
              real tt, uv[2], xyz[3];
              integer n_required_vertices, i;
              status_t ret;

              assert(dc != 0);  /* This object must have been created earlier */

              /* Get the edge discretization associated to the current edge */
              ret = dcad_get_edge_discretization(dc, e, &de);
              if (ret != STATUS_OK)
                return ret;

              /* Set its vertex count (extremities included) */
              //n_required_vertices = ...;
              ret =
                  dcad_edge_discretization_set_vertex_count(de,
                                                            n_required_vertices);
              if (ret != STATUS_OK)
                return ret;

              /* Set coordinates (t,uv,xyz) of each vertex (extremities included) */
              for (i = 1; i <= n_required_vertices; i++) {
                //tt = ...;
                //uv[0] = ...;
                //uv[1] = ...;
                //xyz[0] = ...;
                //xyz[1] = ...;
                //xyz[2] = ...;
                ret =
                    dcad_edge_discretization_set_vertex_coordinates(de, i,
                                                                    tt, uv,
                                                                    xyz);
                if (ret != STATUS_OK)
                  return ret;
              }
              /* Mark this discretization as required */
              ret =
                  dcad_edge_discretization_set_property(de,
                                                        DCAD_PROPERTY_REQUIRED);
              if (ret != STATUS_OK)
                return ret;
            }
            icurv++;
            coedge = 0;
            res = ecoedge->Next(1, &coedge, &n_rcoedge);
          }
          loop = 0;
          res = eloop->Next(1, &loop, &n_rloop);
        }
        isurf++;
        face = 0;
        res = eface->Next(1, &face, &n_rface);
      }
      body = 0;
      res = ebody->Next(1, &body, &n_rbody);
    }
  }

  /*
   * If you want to set a periodicity meshing constraint (mesh
   * matching) between two sets of cad faces.  See the file
   * meshgems/cad.h for more details
   * (meshgems_cad_add_face_multiple_periodicity_with_transformation_function),
   * and the documentation.
   */
  if (CREATE_PERIODICITY) {
    integer fid1[2], fid2[2];
    integer eid1[2], eid2[2];
    integer size1, size2;
    integer nb_pt1, nb_pt2;
    real p[9], p_im[9], periodic_transformation_user_data;

    /* Example of a translation of vector (1,1,1) : 
     * fill fid1, fid2, eid1, eid2, size1, size2 with your data 
     * (See file meshgems/cad.h)
     */

    assert(size1 == size2);
    /* Set the face periodicities */
    if (1) {
      /* Define the periodic tranformation with points coordinates */
      nb_pt1 = 3;
      nb_pt2 = 3;
      assert(nb_pt1 == nb_pt2);

      /* p contains nb_pt1 points on the first set of face you want to set periodic */
      p[0] = 0;
      p[1] = 0;
      p[2] = 0;

      p[3] = 0;
      p[4] = 1;
      p[5] = 0;

      p[6] = 0;
      p[7] = 0;
      p[8] = 1;

      /* while p_im contains their images on the second set of face */
      p_im[0] = 1;
      p_im[1] = 1;
      p_im[2] = 1;

      p_im[3] = 1;
      p_im[4] = 2;
      p_im[5] = 1;

      p_im[6] = 1;
      p_im[7] = 1;
      p_im[8] = 2;

      /*
       * Set a periodicity between the size1 cad faces of fid1 array and
       * the size2 faces of fid2 array using a transformation defined by
       * the coordinates of nb_pt1 points contained in p and their
       * images contained in p_im See the file meshgems/cad.h for more
       * details on the parameters of this function
       */
      ret =
          cad_add_face_multiple_periodicity_with_transformation_function_by_points
          (c, fid1, size1, fid2, size2, p, nb_pt1, p_im, nb_pt2);
      if (ret != STATUS_OK)
        return ret;
    } else {
      /* Define the periodic tranformation with a callback */

      /*
       * Set a periodicity between the size1 cad faces of fid1 array and
       * the size2 faces of fid2 array using a transformation defined by
       * the periodicity_transformation function See the file
       * meshgems/cad.h for more details on the parameters of this
       * function
       */

      periodic_transformation_user_data = 1;

      ret = cad_add_face_multiple_periodicity_with_transformation_function
          (c, fid1, size1, fid2, size2, periodicity_transformation,
           &periodic_transformation_user_data);
      if (ret != STATUS_OK)
        return ret;
      /* Please note that in case of a translation, you can set
       * periodicity_transformation = 0 and periodic_transformation_user_data = 0.
       * In this case, the CAD preprocessor of MG-CADSurf will compute a simple translation 
       */
    }

    /* Set the edge periodicities (ie periodicity between edges while
       the associated cad faces are not required to be periodic) */
    if (1) {
      /* Define the periodic tranformation with points coordinates */
      nb_pt1 = 3;
      nb_pt2 = 3;
      assert(nb_pt1 == nb_pt2);

      /* p contains nb_pt1 points on the first set of edge you want to set periodic */
      p[0] = 0;
      p[1] = 0;
      p[2] = 0;

      p[3] = 0;
      p[4] = 1;
      p[5] = 0;

      p[6] = 0;
      p[7] = 0;
      p[8] = 1;

      /* while p_im contains their images on the second set of edge */
      p_im[0] = 1;
      p_im[1] = 1;
      p_im[2] = 1;

      p_im[3] = 1;
      p_im[4] = 2;
      p_im[5] = 1;

      p_im[6] = 1;
      p_im[7] = 1;
      p_im[8] = 2;

      /*
       * Set a periodicity between the size1 cad edges of eid1 array and
       * the size2 faces of eid2 array using a transformation defined by
       * the coordinates of nb_pt1 points contained in p and their
       * images contained in p_im See the file meshgems/cad.h for more
       * details on the parameters of this function
       */
      ret =
          cad_add_edge_multiple_periodicity_with_transformation_function_by_points
          (c, eid1, size1, eid2, size2, p, nb_pt1, p_im, nb_pt2);
      if (ret != STATUS_OK)
        return ret;
    } else {
      /* Define the periodic tranformation with a callback */

      /*
       * Set a periodicity between the size1 cad edges of eid1 array and
       * the size2 faces of eid2 array using a transformation defined by
       * the periodicity_transformation function See the file
       * meshgems/cad.h for more details on the parameters of this
       * function
       */
      periodic_transformation_user_data = 1;
      ret = cad_add_edge_multiple_periodicity_with_transformation_function
          (c, eid1, size1, eid2, size2, periodicity_transformation,
           &periodic_transformation_user_data);
      if (ret != STATUS_OK)
        return ret;
      /* Please note that in case of a translation, you can set
       * periodicity_transformation = 0 and periodic_transformation_user_data = 0.
       * In this case, the CAD preprocessor of MG-CADSurf will compute a simple translation 
       */
    }
  }

  *pc = c;
  if (dc)
    *pdc = dc;

  return ret;
}

status_t generate_mesh_for_sldw(CComPtr < ISldWorks > swApp)
{
  status_t ret;
  cad_t *c = 0;
  dcad_t *dc = 0;
  context_t *ctx = 0;

  assert(swApp);
  ret = STATUS_OK;

  ctx = context_new();
  if (!ctx)
    return STATUS_NOMEM;

  ret = import_sldw_geometry(swApp, ctx, &c, &dc);
  if (ret != STATUS_OK) {
    context_delete(ctx);
    return ret;
  }

  ret = generate_mesh(ctx, c, dc, 0);

  cad_delete(c);
  if (dc)
    dcad_delete(dc);
  context_delete(ctx);

  return ret;
}
