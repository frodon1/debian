#ifndef __ZP_TYPE_DAO__
#define __ZP_TYPE_DAO__

#include <Global_master_program.h>
#include <ZP_stack.h>
#include <ZP_object.h>
#include <Error_messager.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_BASE_DAO : public ZP_OBJECT
{
  protected :
    int dao_linked;
    void attach(ZP_BASE_DAO *d) { attachments.add(d); }
    void deattach(ZP_BASE_DAO *d) { attachments.suppress_item(d); }
    virtual int permanent_storage() { return(dao_linked>0); }

    void link_dao() 
    { 
      int i;

      dao_linked++; 
      for(i=0;i<!attachments;i++) attachments[i]->link_dao();
    }
    void unlink_dao() { 
      int i;

      dao_linked--; 
      for(i=0;i<!attachments;i++) attachments[i]->unlink_dao();
    }
    void force_unlink_dao() { 
      int i;

      dao_linked=0; 
      for(i=0;i<!attachments;i++) attachments[i]->force_unlink_dao();
    }
    virtual void release() { force_unlink_dao(); }

  public :
    LIST<ZP_BASE_DAO*> attachments;

    ZP_BASE_DAO() : ZP_OBJECT() { dao_linked=0; }
    virtual ~ZP_BASE_DAO() { }
   
    ZP_FATAL_ERROR* link(ZP_STACK&,int) { link_dao(); return(NULL); }
    ZP_FATAL_ERROR* unlink(ZP_STACK&,int) { unlink_dao(); return(NULL); }

    METHOD_DECLARATION_START
      METHOD("link",link,0)
      METHOD("unlink",unlink,0)
    METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)

    RTTI_INFO;
};

template <class T> ZCLASS2 ZP_TYPE_DAO : public ZP_BASE_DAO
{
  protected :
    virtual void type_init(char*)  {  
#ifdef ZCHECK
      cerr<<"warning : executing ZP_TYPE_DAO::type_init() for object ("<<type<<")"<<endl<<flush;
#endif
    }
    virtual void dao_add() {  
#ifdef ZCHECK
      cerr<<"warning : executing ZP_TYPE_DAO::dao_add() for object ("<<type<<")"<<endl<<flush;
#endif
    }
    virtual void dao_delete() {  
#ifdef ZCHECK
      cerr<<"warning : executing ZP_TYPE_DAO::dao_delete() for object ("<<type<<")"<<endl<<flush;
#endif
    }

    virtual ZP_FATAL_ERROR* cast(ZP_STACK &stack, STRING &tt)
    {
      AUTO_PTR< ZP_OBJECT > zpo;
      ZP_OBJECT *_zpo;

      T &obj=get();
      if(!obj.__are_you_a(tt())) ZP_ISSUE_FATAL_ERROR("Cannot cast an object of type "+type+" to type "+tt);
      _zpo=Create_object(ZP_OBJECT,tt());

      if (_zpo==NULL) ZP_ISSUE_FATAL_ERROR("Unknown data type: "+tt);

      delete((T*)(_zpo->contens));
      _zpo->contens=contens;
      _zpo->dont_delete=1;
      zpo=_zpo;
      stack.add(zpo);
      return(NULL);
    }

  public :
    ZP_TYPE_DAO() : ZP_BASE_DAO() { dont_delete=0; contens=new T(dao_geom_link_program); }
    ZP_TYPE_DAO(T *i) : ZP_BASE_DAO() { dont_delete=global_dao_dont_delete; contens=i; }
    virtual ~ZP_TYPE_DAO() 
    { 
#ifdef ZCHECK
      cerr<<endl<<endl;
      cerr<<"("<<type<<" : attachments "<<!attachments<<" dao_linked "<<dao_linked<<endl;
      if(dont_delete) cerr<<"will not delete object ("<<type<<") because it is forbidden (dont_delete=1)"<<endl<<flush;
      if(dao_linked>0) cerr<<"will not delete object ("<<type<<") because it is used by DAO_GEOM (dao_linked>0)"<<endl<<flush;
#endif
      if(!dont_delete && dao_linked<=0) {
        delete((T*)contens); 
#ifdef ZCHECK
        cerr<<"("<<type<<") deleted"<<endl;
#endif
      }
    }

    T& get() { return(*((T*)contens)); }

    METHOD_DECLARATION_EMPTY_ANCESTOR(ZP_BASE_DAO)
};

#define CONSTRUCTORS_DAO(cname,type) cname() : ZP_TYPE_DAO<type>() { type_init(NULL); dao_add(); } \
    cname(type *d) : ZP_TYPE_DAO<type>(d) { type_init(NULL); }
#define DESTRUCTORS_DAO(cname) virtual ~cname() { dao_delete();  }
Z_END_NAMESPACE;

#endif
