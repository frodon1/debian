#ifndef __Utility__
#define __Utility__

#include <Defines.h>
#include <Stringpp.h>
#include <List.h>
#include <Aaa_zmat_globals.h>

Z_START_NAMESPACE;

WIN_THINGIE bool if_tens_component(STRING str, bool& diag);

WIN_THINGIE void tens_name(ARRAY<STRING>& str, int st, int len, const STRING& s);

WIN_THINGIE void tens_name_no_us(ARRAY<STRING>& str, int st, int len, const STRING& s);

WIN_THINGIE void vector_name(ARRAY<STRING>& str, int st, int len, const STRING& s);

WIN_THINGIE void output_names(const ARRAY<STRING>& str);
WIN_THINGIE void output_names(const ARRAY<STRING>& str, int& zebaba_index);

WIN_THINGIE void Get_dir_content(const char* na, LIST<STRING>& fi);

WIN_THINGIE void Select_extension(const ARRAY<STRING>&, LIST<STRING>&, const char*);
WIN_THINGIE STRING Remove_extension_from_string(const STRING& fname); 

//
// see more find files funcs in Unix_tools.h
//
Z_END_NAMESPACE;

#endif
