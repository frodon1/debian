// ============================================================================ 
//  Apply displacement on an nset
// 
//  VC august 2009
//
//  Do not apply displacement on point that are too far from given displacement
//  Apply a brute force ordering method (could be improved) 
//
//  Also used for opened cracks
//
// ============================================================================ 

#ifndef __FRONT_DISPLACEMENT__
#define __FRONT_DISPLACEMENT__

#include <Marray.h>
#include <Vector.h>
#include <Utility_mesh.h>
#include <Transform_geometry.h>
#include <Base_problem.h>
#include <Message.h>

#include <Object_factory.h>
#include <Utility_set.h>
#include <Utility_results_database.h>

#include <Mesher_union.h>
#include <Mesher_translate.h>
#include <Problem.h>

#include <Verbose.h>

#include <Crack_FC.h>
Z_START_NAMESPACE;

class FRONT_DISPLACEMENT : public TRANSFORMERS {
    
    STRING liset_name,nset_name,elset_name;
    BUFF_LIST<STRING> ask_speed_to;
    double hmax,max_dist;
    bool if_dclose;
  public :
     FRONT_DISPLACEMENT() : TRANSFORMERS() {
       liset_name="";
       nset_name="";
       elset_name="";
       hmax=1.e99;
       max_dist=1.e99;
       if_dclose=FALSE;
     }
     virtual ~FRONT_DISPLACEMENT() { } 
     MODIFY_INFO_RECORD* get_modify_info_record(); 

     virtual void apply(UTILITY_MESH& mesh);
};

Z_END_NAMESPACE;

#endif
