#ifndef __Problem_mechanical__
#define __Problem_mechanical__

#include <Problem.h>
#include <Contact.h>
#include <Sequence.h>
#include <Contact.h>
#include <Zset_callback.h>

Z_START_NAMESPACE;

class PROBLEM_MECHANICAL_CALLBACK;


ZCLASS2 PROBLEM_MECHANICAL : public PROBLEM {
    friend class PROBLEM_MECHANICAL_CALLBACK;
    protected :
      bool new_debound;
      STRING elset_name_d_contact;
      PTR<ZSET_CALLBACK> zset_callback;

      void compute_internal_reactions();

    public :
       bool nul_veloc_accel_for_fixed_dof;

       AUTO_PTR<GLOBAL_MATRIX> K;
       AUTO_PTR<CONTACT> contact;
 
       PROBLEM_MECHANICAL();
       virtual ~PROBLEM_MECHANICAL();

       virtual int parallelized() { return(1); }
       virtual void read_restart(RST_FSTREAM&);
       virtual void write_restart(RST_FSTREAM&);
       virtual void init_mesh();

       virtual bool GetResponse(const char* const, ASCII_FILE&);
       virtual bool read_d_contact(ASCII_FILE&);
       virtual void initialize_d_contact();
       virtual bool read_contact(ASCII_FILE&);
       virtual bool nul_va_fixed(ASCII_FILE&);

       virtual bool Initialize();
       virtual void create_mesh();

       void manage_new_broken();
 
       // friend class MECHANICAL_QUASI_NEWTON_ALGORITHM;
       // friend class APHR_ALGORITHM;
       // friend class ACC_APHR_ALGORITHM;
       bool has_debound() { return(new_debound); }

       RTTI_INFO;

       double Wint;  //work of internal forces
       double Wext;  //work of external forces
       double Wkin;  //kinetic energy
       double Wkin0; //initial kinetic energy
       double Wdmp;  //work of damping forces
};

ZCLASS2 PROBLEM_MECHANICAL_CALLBACK : public ZSET_CALLBACK
{
  public :
    PROBLEM_MECHANICAL *boss;

    PROBLEM_MECHANICAL_CALLBACK(PROBLEM_MECHANICAL *b) : ZSET_CALLBACK() { boss=b; }
    virtual void compute_internal_reactions() { boss->compute_internal_reactions(); }
};


Z_END_NAMESPACE;
#endif

