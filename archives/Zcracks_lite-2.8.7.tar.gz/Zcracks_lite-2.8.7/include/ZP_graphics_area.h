#ifndef __ZP_GRAPHICS_AREA__
#define __ZP_GRAPHICS_AREA__

#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>
#include <Graphics_area.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_GA : public ZP_BASIC_TYPE< GRAPHICS_AREA >
{
  protected :
    ZP_FATAL_ERROR* do_command(ZP_STACK&,int);

    virtual void type_init(char*) { type="GRAPHICS_AREA"; }

  public :
    BASIC_CONSTRUCTORS(ZP_GA,GRAPHICS_AREA)

    METHOD_DECLARATION_START
      METHOD("do_command",do_command,1)
    METHOD_DECLARATION_ANCESTOR(ZP_BASIC_TYPE< GRAPHICS_AREA >)

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
   
    ZPO_RTTI_INFO(GRAPHICS_AREA)
};
Z_END_NAMESPACE;

#endif
