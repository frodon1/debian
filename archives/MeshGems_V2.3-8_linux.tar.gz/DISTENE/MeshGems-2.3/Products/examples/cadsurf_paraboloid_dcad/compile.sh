gcc -I. -L. cadsurf_paraboloid_dcad.c -lmg-cadsurf -lmeshgems -lmeshgems_stubs -lmg-tetra -lm -lc  -o paraboloid_dcad.exe

