#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/cleaner.h>
#include <meshgems/meshgems.h>


#define FREE_AND_STRDUP(_p_,_s_) if(_p_) free(_p_); _p_=NULL; _p_ = strdup(_s_)

/*
 * message callback function
 */
meshgems_status_t my_message_cb(message_t * msg, void *user_data)
{
  char *desc;
  integer e;
  status_t ret;

  ret = message_get_description(msg, &desc);
  if (ret != STATUS_OK) {
    printf("internal error");
    return ret;
  }
  ret = message_get_number(msg, &e);
  if (ret != STATUS_OK) {
    printf("internal error");
    return ret;
  }
  if (e >= 0) {                 /* this is an information */
    printf("%s\n", desc);
  } else if (e < 0) {           /* this is an error */
    printf("ERROR : %s\n", desc);
  }
  fflush(stdout);
 
  return STATUS_OK;
}

/* 
 * A macro we will call to cleanly return from the function in case of failure 
 */
#define RETURN_WITH_MESSAGE(_ret, _msg) do{		\
    fprintf(stderr,"%s\n",_msg);			\
    if(mcs) meshgems_cleaner_session_delete(mcs);	\
    if(msh) meshgems_mesh_delete(msh);			\
    if(ctx) meshgems_context_delete(ctx);		\
    return _ret;					\
  }while(0);


#ifndef MAX
#define MAX(a,b)  ((a)>(b)?(a):(b))
#endif /* !MAX */

/*
 * MAIN PROCEDURE
 */
int main(int argc, char *argv[])
{
  char *fileIn = NULL;
  char *fileOut = NULL;
  mesh_t *msh;
  mesh_t *msh_output = NULL;
  meshgems_status_t ret;

  context_t *ctx;
  meshgems_cleaner_session_t *mcs;

  ctx = 0;
  msh = 0;
  mcs = 0;
  msh_output = 0;

  /* Create the Meshgems working context */
  ctx = meshgems_context_new();
  if (!ctx) {
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new context");
  }

  /* Set the message callback for our context */
  ret = context_set_message_callback(ctx, my_message_cb, 0);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");



  /* Check input and output files */
  if (argc > 1 && argv[1][0] != '-') {
    FREE_AND_STRDUP(fileIn, argv[1]);
    if (argc > 2) {
      FREE_AND_STRDUP(fileOut, argv[2]);
    }
  }

  if (!fileIn) {
    fprintf(stdout, "ERROR: Missing input file.\n");
    return -1;
  }
  if (!fileOut) {
    int fileInLen = strlen(fileIn);
    char *pchar;
    fileOut = (char *) calloc(fileInLen + 20, sizeof(char));
    if (fileOut) {
      strncpy(fileOut, fileIn, fileInLen + 20);
      pchar = strstr(fileOut + MAX(0,fileInLen-7), ".mesh");
      if (pchar)
        pchar[0] = 0;

      if (fileIn[fileInLen - 1] == 'b') {
        strncat(fileOut, "_cleaner.meshb", fileInLen + 20);
      } else {
        strncat(fileOut, "_cleaner.mesh", fileInLen + 20);
      }
    } else {
      fprintf(stdout, "ERROR: Unable to create output file name.\n");
      return -1;
    }
  }


  /* Read the input file fileIn */
  {
    /* Create the Meshgems mesh and read it */
    if (fileIn) {
      msh = meshgems_mesh_new_read_mesh(ctx, fileIn);
    } else {
      fprintf(stdout, "ERROR: No input file...\n");
      return -1;
    }
    if (!msh) {
      printf("Mesh creation or reading failed \n");
      meshgems_cleaner_session_delete(mcs);
      meshgems_context_delete(ctx);
      return -1;
    }
  }


  /* Create the Meshgems Cleaner session */
  mcs = meshgems_cleaner_session_new(ctx);
  if (!mcs) {
    RETURN_WITH_MESSAGE(STATUS_ERROR,
                        "unable to create a new MeshGems-Cleaner session \n");
  }


  /* Set the parameters to run MeshGems-Cleaner */

  /* 
   * Set the verbose level to 4 
   */
  meshgems_cleaner_set_param(mcs, "verbose", "4");
  /*
   * Set the surface size threshold below which holes are filled to 100.
   */
  meshgems_cleaner_set_param(mcs, "min_hole_size", "100");

  /* This option sets the number of passes for the fix mode, between
   * 1 and 4.
   * 1 : analyses and fixes mesh with only the first stage of the
   *     cleaning procedure
   * 2 or more : analyses and fixes mesh with the two, three or four
   *     stage cleaning procedures (default value)
   */
  meshgems_cleaner_set_param(mcs, "number_of_passes", "2");



  ret = STATUS_ERROR;
  ret = meshgems_cleaner_set_surface_mesh(mcs, msh);
  if (ret != STATUS_OK) {
    RETURN_WITH_MESSAGE(ret,
                        "internal error : unable to set surface mesh.");
  }

  /* 
   * Analyses and fixes mesh with a cleaning procedure.
   * Does not write diagnostics into the output file.
   */

  ret = meshgems_cleaner_fix(mcs);

  switch(ret) {
  case STATUS_OK:		/* everything is ok */
  case STATUS_WARNING:		/* some warnings occurred but mesh is usable */
    break;
  default:			/* STATUS_ERROR, STATUS_NOMEM, ... */
    RETURN_WITH_MESSAGE(ret, "internal error : mesh processing failed");
    break;
  }

  /*
   * Mesh generation is completed.
   * Get the generated mesh. This output mesh belongs to the
   * cleaner_session. Thus the user does not have to destroy it
   * afterwards.
   */
  ret = meshgems_cleaner_get_mesh(mcs, &msh_output);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret,
                        "internal error : unable to set surface mesh.");


  /* We directly write a .mesh formatted file : */

  if (fileOut) {
    ret = meshgems_mesh_write_mesh(msh_output, fileOut);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to write a .mesh file");
  }


endsession:
  if (fileIn)
    free(fileIn);
  if (fileOut)
    free(fileOut);

  meshgems_cleaner_regain_mesh(mcs, msh_output);
  meshgems_cleaner_session_delete(mcs);

  if (msh) {
    meshgems_mesh_delete(msh);
  }

  meshgems_context_delete(ctx);

  return 0;
}
