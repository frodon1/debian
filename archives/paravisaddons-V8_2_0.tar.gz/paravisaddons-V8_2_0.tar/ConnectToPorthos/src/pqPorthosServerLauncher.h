/*=========================================================================
 Developed for EDF by Kitware SAS.
 Copyright (c) Kitware SAS 2015
 All rights reserved.
 More information http://www.kitware.fr
=========================================================================*/
#ifndef _pqPorthosServerLauncher_h
#define _pqPorthosServerLauncher_h

#include <QDialog>
#include <QProcess>
#include <QScopedPointer>

#include "pqServerConfiguration.h"
#include "pqServerLauncher.h"

/// This is a dialog that implements the user interface for the
/// Slurm cluster connexion plugin
class pqPorthosServerLauncher : public pqServerLauncher
{
  Q_OBJECT
  typedef pqServerLauncher Superclass;
public:
  Q_INVOKABLE pqPorthosServerLauncher(const pqServerConfiguration& config, QObject* parentObject = NULL);
  virtual ~pqPorthosServerLauncher();

protected:
  virtual void prepareDialogForPromptOptions(QDialog& dialog);
  virtual bool launchServer(bool show_status_dialog);
  virtual void handleProcessStandardOutput(const QByteArray& data);
  virtual void handleProcessErrorOutput(const QByteArray& data);
  virtual void clearProcessOutputs();
  virtual bool connectToPrelaunchedServer();

  bool processCommand(QString command, double timeout = 2, double delay = 2);
  static bool parseUpdateString(QString updateString, int& availableNodes, int& totalNodes);
  static bool parseEDFSlurmOutput(QString edfSlurmOutput, QString& computeNodeHost);
  bool parseSrunCommandOutput(QString specialCommandOutput, QString& computeNodeHost);
  bool waitForOutputString(int msTime);
  QString sshCommandString();

protected slots:
  void updateAvailableNodes();

private:
  class pqInternals;
  QScopedPointer<pqInternals> Internals;

  static pqServerConfiguration clean(const pqServerConfiguration& config);
  bool ConfigIsSlurm;
  bool CaptureProcessStreams;
  QString LastStdOut;
  QString LastStdErr;
  static const char PARAVISADDONS_ROOT_DIR[];
  static const char ASK_PATH_EXE[];
};

#endif
