#ifndef __LEAST_SQUARE_TRANSFER__
#define __LEAST_SQUARE_TRANSFER__

#include <Least_square.h>
#include <Utility_mesh.h>
#include <GMesh.h>
#include <Vector_to_element_locator.h>

Z_START_NAMESPACE;

class IP_LOCATE 
{ 
  public :
    int iel,iip,itot; 
    VECTOR *position;
    VECTOR pos;

    IP_LOCATE() { itot=iel=iip=-1; }
    IP_LOCATE(int i, int j, int ii) { itot=ii; iel=i; iip=j; }

    bool operator==(const IP_LOCATE &ipl) { return((iel==ipl.iel)&&(iip==ipl.iip)); }
    void set_position(VECTOR &pos0)
    {
    pos.resize(pos0.size());
    pos=pos0; 
    position=&pos;
    }
};

class GRID // a grid structure to pack IPs according to a distance criterion
{
  protected :
    LIST<IP_LOCATE*> *all_ips;
    ARRAY< ARRAY< ARRAY< LIST<IP_LOCATE*> > > > grid;
    VECTOR pmin,pmax;
    ARRAY<int> cuts;
    double distance;
    int dim;

  public :
    GRID();
    ~GRID();

    void initialize(double,LIST<IP_LOCATE*>&);
    void neighboors(VECTOR&,LIST<IP_LOCATE*>&);
};

class LEAST_SQUARE_TRANSFER 
{
  protected :
    LIST<IP_LOCATE*> old_ips;
    GRID grid;
    int new_tot_gp,old_tot_gp;

    ARRAY< LIST<IP_LOCATE* > > neigh;
    ARRAY< LIST<IP_LOCATE*> > potential_ip;
    ARRAY< ARRAY<double> > distance_ip;
    LEAST_SQUARE *ls;
    STRING lstype;
    double distance;
    int nb_sample_points;
    UTILITY_MESH *old_mesh, *new_u_mesh;
    GMESH *new_mesh;
    ARRAY<double> nrjls;

  public :
    bool is_mls,except_if_identical,reduce_volumetric_locking;
    STRING loc_type;
    ARRAY<STRING> variable_name;
    LEAST_SQUARE_TRANSFER();
    ~LEAST_SQUARE_TRANSFER();

    void set_old_mesh(UTILITY_MESH &um) { old_mesh=&um; }
    void set_new_mesh(GMESH &gm) { new_mesh=&gm; }
    void set_new_mesh(UTILITY_MESH &um) { new_u_mesh=&um; }
    void set_locator_type(const STRING& t) { loc_type=t; }

    void initialize(ASCII_FILE&);

    void reset(ELSET* newelset0,UTILITY_ELSET* oldelset0);
    void find_ip_near();
    void transfer(const ARRAY< ARRAY<double> >&, ARRAY< ARRAY<double> >&, ELSET*,ARRAY<int>& );
    void clean();

    void energy(ARRAY<double> nrj0);

};

Z_END_NAMESPACE;

#endif
