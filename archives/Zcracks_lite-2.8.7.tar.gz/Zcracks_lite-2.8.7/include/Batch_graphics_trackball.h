#ifndef __Batch_graphics_trackball__
#define __Batch_graphics_trackball__

#include <Stringpp.h>
#include <List.h>
#include <Vector.h>
#include <Matrix.h>

#include <Graphics_trackball.h>

Z_START_NAMESPACE;

class GRAPHICS_APPLICATION;
/* class BATCH_TRACKBALL_TOOL; */

class ZP_STACK;
class ZP_FATAL_ERROR;

ZCLASS2 BATCH_TRACKBALL_TOOL : public GRAPHICS_TRACKBALL_TOOL {
   protected :
    int offset;
    int xoffset;

    virtual void draw() ;
    virtual bool is_in_box(int x, int y);

  public :
    BATCH_TRACKBALL_TOOL(GRAPHICS_APPLICATION* app);
    virtual ~BATCH_TRACKBALL_TOOL();

    virtual bool do_command(STRING cmd);
    virtual ZP_FATAL_ERROR* post_reset_window(ZP_STACK&, double* umin, double* vmin,
                                                         double* umax, double* vmax,
                                                         double* rx,   double* ry   );
 
    RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
