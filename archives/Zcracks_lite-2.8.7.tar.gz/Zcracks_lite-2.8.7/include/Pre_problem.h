#ifndef __PRE_PROBLEM__
#define __PRE_PROBLEM__

#include <Base_problem.h>
#include <Vector.h>

Z_START_NAMESPACE;

class ASCII_FILE; class BASE_PROBLEM; class PROBLEM;
class NODE; class P_ELEMENT; class Zfstream;
class ELSET;

ZCLASS2 PRE_PROBLEM_TREATMENT : Z_OBJECT {

   protected :
      PROBLEM* its_problem;

   public :
      PRE_PROBLEM_TREATMENT();
      virtual void initialize(ASCII_FILE&,PROBLEM*);
      virtual ~PRE_PROBLEM_TREATMENT();
      virtual void read_restart(RST_FSTREAM&);
      virtual void write_restart(RST_FSTREAM&);
      virtual void apply();

   RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
