#ifndef __Mcesd__
#define __Mcesd__

#include <Behavior.h>
#include <Bool.h>
#include <Coefficient.h>
#include <Clock.h>
#include <Discrete_timer.h>
#include <Global_matrix.h>
#include <Integration_result.h>
#include <ZMath.h>
#include <Marray.h>
#include <Mechanical_behavior.h>
#include <Mechanical_volume_element.h>
#include <Message.h>
#include <Mce.h>
#include <Node.h>
#include <Rotation.h>
#include <Utility.h>

Z_START_NAMESPACE;

ZCLASS2 MCESD : public MECHANICAL_VOLUME_ELEMENT {
 public :

   struct MCESD_ELEMENT_CALLBACK_GRAD_OPERATOR
     : public ELEMENT::ELEMENT_CALLBACK_GRAD_OPERATOR
   {
     MCESD_ELEMENT_CALLBACK_GRAD_OPERATOR() {}
     virtual ~MCESD_ELEMENT_CALLBACK_GRAD_OPERATOR() {}
     virtual void compute_B(MATRIX&);
     virtual void compute_Bu(TENSOR2& eps, const MATRIX& B,const VECTOR& u,bool);
     virtual void compute_Btu(VECTOR& Ret, const MATRIX& B,const TENSOR2& sig); 
     virtual void compute_BtDB(MATRIX& Ret, const MATRIX& B, const MATRIX& D);
 
     RTTI_INFO;
   };

    enum FLAGS { NONE=0, UPDATED=1, USES_LOCAL=2 }; 

 protected :
    MCESD_ELEMENT_CALLBACK_GRAD_OPERATOR *mcesd_elem_cb;
    int  mcesd_flags; 
    bool control_locking;
    MATRIX BA,BB,BC,BD, B1,B2,B3,B4,B5,BRA,BRB, C1,C2,C3,C4,C5,CSA,CSB, E1,E2,E3,E4,E5,E6,E7,E8; // to control locking, if needed

    int  tsz;
    bool enable_locking_control(APPLICATION_MESSAGE*);
    bool time_for_pressure(APPLICATION_MESSAGE*);
    bool compute_elastic_energy(APPLICATION_MESSAGE*);
    bool compute_geometric_stiffness(APPLICATION_MESSAGE* msg);
    void calculate_local_to_global(MATRIX& local_to_global, MATRIX& coord);

    void update_B_for_unlocking(const int stage, const MATRIX &elem_coord, MATRIX &B);

 public :
    MCESD();
    virtual ~MCESD();

    bool compute_B_external(APPLICATION_MESSAGE*);
    FLAGS get_flags() { return((FLAGS)mcesd_flags); }

    void install_callback(MCESD_ELEMENT_CALLBACK_GRAD_OPERATOR *_callback) { mcesd_elem_cb=_callback; }

    // 
    // This just calls MECHANICAL_VOLUME_ELEMENT and then sets the 
    // tsz variable 
    // 
    virtual void initialize_element(const ARRAY<GNODE*>& element_nodes,
                              GMESH* the_mesh_it_belongs_to,
                              GEOMETRY* element_geometry,
                              char *the_im,
                              int element_id,
                              const char* ele_type);

    virtual INTEGRATION_RESULT* internal_reaction(bool,VECTOR&,SMATRIX&,
                                  bool get_only_tg_matrix=FALSE);

    virtual bool single_pass_mat_integ_enable() { return(true); }
    virtual INTEGRATION_RESULT* internal_reaction_stage1(ARRAY<VECTOR> &dgrads, ARRAY<VECTOR> &grads);
    virtual INTEGRATION_RESULT* internal_reaction_stage2(ARRAY<MATRIX> &tangent, bool,VECTOR&,SMATRIX&, bool only_get_tg_matrix=FALSE);


    virtual void update();
    virtual void compute_B(MATRIX&);


     virtual void end_compute_B(MATRIX&);
     virtual void end_compute_Bu(TENSOR2& eps, const MATRIX& B,const VECTOR& u,bool);
     virtual void end_compute_Btu(VECTOR& Ret, const MATRIX& B,const TENSOR2& sig);
     virtual int get_tsz() { return tsz; }


 
//  SQ: added "grad" argument for special temperature treatment in MCESDDIL
    virtual void compute_Bu(TENSOR2& Ret, const MATRIX& B,const VECTOR& u,bool grad=FALSE);
    virtual void compute_Btu(VECTOR& Ret, const MATRIX& B,const TENSOR2& sig);
    virtual void compute_BtDB(MATRIX &tmp, MATRIX& Ret, const MATRIX& B, const MATRIX& D);
    virtual bool modif_dV(double&,const VECTOR&, const VECTOR&);
    virtual bool verification();
    virtual bool set_local_grad0() { local_grad0=TRUE; return(TRUE); }
    DECLARE_ASK;
    RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
