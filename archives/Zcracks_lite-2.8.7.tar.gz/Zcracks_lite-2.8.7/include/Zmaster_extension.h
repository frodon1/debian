#ifndef __Zmaster_extension__
#define __Zmaster_extension__

#include <Zstream.h> 

#include <Graphics_command.h> 
#include <Graphics_area.h> 
#include <Graphics_application.h> 

Z_START_NAMESPACE;

class DAO_GEOMETRY; 

// 
// This is for extensions which use a button. like 
// the simulation plug-in 
// 
ZCLASS2 ZMASTER_EXTENSION : public GRAPHICS_COMMAND {
  public :
    DAO_GEOMETRY*         its_dao;
    GRAPHICS_APPLICATION_LOADER *its_loader;

  public :
    bool want_base_commands;

    ZMASTER_EXTENSION(); 
    virtual ~ZMASTER_EXTENSION(); 

    virtual void initialize( GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app); 
    virtual void end_of_initialization() { }

    STRING mast_file_keyword; 
    virtual void read(ASCII_FILE& mast); 
    virtual bool write(Zofstream& mast); 
    virtual bool allow(GRAPHICS_APPLICATION*) { return(TRUE); } // allow derived classes to denied registration in Zmaster
    virtual bool do_base_command(STRING /* cmd */) { return(FALSE); }

    void set_loader(GRAPHICS_APPLICATION_LOADER *l) { its_loader=l; }
};

// 
// This is for "transparent extensions" which can interface 
// essentially new extensions to the Dao_geom.c code 
// 
ZCLASS2 ZMASTER_CMD_EXTENSION : public GRAPHICS_COMMAND {
  public :
    DAO_GEOMETRY*         its_dao;
    GRAPHICS_APPLICATION_LOADER *its_loader;

  public :
    bool want_base_commands;
    STRING mast_file_keyword;
    LIST<STRING> file_extensions; 

    ZMASTER_CMD_EXTENSION();
    virtual ~ZMASTER_CMD_EXTENSION();

    virtual void initialize( GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app);
    virtual void end_of_initialization() { }

    virtual bool do_command(STRING cmd);

    virtual void read(STRING extension, STRING fname); 
    virtual void read(ASCII_FILE& mast);
    virtual void write(STRING extension, STRING fname); 
    virtual void write(Zofstream&); 
    virtual bool allow(GRAPHICS_APPLICATION*) { return(TRUE); } // allow derived classes to denied registration in Zmaster
    virtual bool do_base_command(STRING /* cmd */) { return(FALSE); }

    void set_loader(GRAPHICS_APPLICATION_LOADER *l) { its_loader=l; }
};

Z_END_NAMESPACE;

#endif
