#ifndef __FLUID_BEHAVIOR_NEWTONIAN__
#define __FLUID_BEHAVIOR_NEWTONIAN__

#include <Defines.h>
#include <File.h>
#include <ZMath.h>
#include <Print.h>

#include <Behavior.h>
#include <Mat_data.h>
#include <Coefficient.h>
#include <Int_variable_holder.h>
#include <Utility.h>

#include <Fluid_behavior.h>


Z_START_NAMESPACE;

ZCLASS2 FLUID_BEHAVIOR_NEWTONIAN : public FLUID_BEHAVIOR {
 protected : 
  COEFF viscosity;
  SMATRIX m_tg_matrix;
  
 public:
  FLUID_BEHAVIOR_NEWTONIAN();
  virtual ~FLUID_BEHAVIOR_NEWTONIAN(); 
  
  virtual void initialize(ASCII_FILE&,int,LOCAL_INTEGRATION*);
  virtual bool calc_coef(); 			
  INTEGRATION_RESULT* integrate(MAT_DATA&        mdat,
                                const VECTOR&    /*delta_grad*/,
                                MATRIX*&         tg_matrix,
                                int              flags        );
};      

Z_END_NAMESPACE;

#endif
