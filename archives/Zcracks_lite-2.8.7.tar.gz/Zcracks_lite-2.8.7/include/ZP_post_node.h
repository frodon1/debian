#ifndef __ZP_POST_NODE__
#define __ZP_POST_NODE__

#include <ZP_stack.h>
#include <Post_node.h>
#include <ZP_object.h>
#include <ZP_type.h>
#include <ZP_gnode.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_POST_NODE : public ZP_GNODE 
{
  protected :
    virtual void type_init(char*) { type="POST_NODE"; }
    ZP_FATAL_ERROR* get_data(ZP_STACK&,int);
    ZP_FATAL_ERROR* size(ZP_STACK&,int);

  public :
    ZP_POST_NODE() : ZP_GNODE(NULL)  { 
      dont_delete=0; type_init(NULL); contens=new POST_NODE(); 
    }
    ZP_POST_NODE(POST_NODE *p) : ZP_GNODE(p) { type_init(NULL); }

    virtual ~ZP_POST_NODE() { 
      if(!dont_delete) { 
        dont_delete=1; 
        delete((POST_NODE*)contens); 
      }
    }

    virtual POST_NODE& get() { return(*((POST_NODE*)contens)); }

    METHOD_DECLARATION_START
      METHOD("data",get_data,1)
      METHOD("!",size,0)
    METHOD_DECLARATION_ANCESTOR(ZP_GNODE)

    ZPO_RTTI_INFO(POST_NODE)
};
Z_END_NAMESPACE;

#endif
