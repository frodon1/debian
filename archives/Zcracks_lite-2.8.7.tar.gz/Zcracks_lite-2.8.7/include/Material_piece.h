#ifndef __Material_Piece__
#define __Material_Piece__

// ============================================================================ 
//   MATERIAL_PIECE        - calc_material just calls the sub_pieces...
//                         - coefficients in sub_pieces should only have 
//                           access to variables in its super MATERIAL_PIECE
//                         - put mamagement for calc_coef optimization into 
//                           this class?
// 
//  stub            name prefix for int vars...
//  tsz             tensor size
//  int_sz, etc...  obvious
//                  each time the vars change
//  calc_coef       calls calc_coef in sub_pieces by def. 
//  local_vars      a list automatically installed by 
//                  STORED_VARIABLE_SPEC.. 
//  attach_all      hooks on EVERYTHING
//  attach          links all local_vint to a temp vint vector.
//  init_name       these functions serve to line up the variables among
//                  a hierarchy of material bricks... start pos goes in, 
//                  end pos is returned
//  default_output_variables searches through the sub_pieces and then 
//                  does the local_vars.  Re-define for extra output
//                  somewhere (e.g. gen_evp potential)
//  get_var         needs to be optimized sometime.. 
//  get_vint_var, get_flux_var, etc .. versions which don't need to be cast. 
//                  they have an optional flag to specify if an error message is 
//                  given if not found (default TRUE!)
// 
//  flags           to be used for flagging variable coefs etc.
//
//  static read     ** all derived class static read functions should be 
//                  defined as read(ASCII_FILE&, MATERIAL_PIECE*, int tens_size)
//                  COEFFICIENT_MATRIX has an extra char* which wil be treated 
//                  by ZebFront
// curr_ext_param   interpolated value... 
//
// setup_name       adds a name-class pair to the piece's name list.. should be 
//                  done in the creator of a MATERIAL_PIECE holding sub-pieces
//                     its_kinematic.resize(4); 
//                     setup_name("KINEMATIC","alpha"); 
// 
// get_next_name_for should be called by a sub-piece to its boss, giving a string 
//                  name for the sub-type.. for example, a class holding 
//                  a number of kinematics.. each kinematic will find its
//                  variable name stub by calling its_boss: 
//                     alpha.initialize(its_boss->get_next_name_for("KINEMATIC"), 
//                                      tsz(), 0);
//                  the name passed should be the name of the base class... 
// 
// get_next_index_for Similar to above but used if you want to name in the 
//                  sub-mat piece.. ie. 
//                      STRING nm = ("X"+itoa(its_boss->get_next_index_for("KIN.."); 
//                      X.initialize(nm, tsz(), 0); 
//
// Adding an ASK option for special outputs.. they're recursive through all 
//     the sub-pieces, so please pay attention to the CPU effect of using 
//     that excessively.
// ============================================================================ 

#include <Error_messager.h>
#include <Z_object.h>
#include <Ask.h>
#include <Stringpp.h> 
#include <List.h> 
#include <Auto_readable.h>
#include <Auto_input_data_part.h>
#include <Buffered_list.h> 
#include <Hierarchy.h> 
#include <Mat_data_when.h>
#include <Material_integration_info.h>
#include <Int_variable_holder.h>
#include <Aaa_zmat_globals.h>

#include <Special_vector.h> 
#include <Aaa_zmat_globals.h>

Z_START_NAMESPACE;

class BEHAVIOR;
class MATERIAL_PIECE_NAMER;
class MATERIAL_PIECE_VARIABLE_KEY;
class STORED_FLUX;
class STORED_GRAD;
class MAT_DATA;
class VECTOR;
class MATRIX;
class MATERIAL_PIECE_VARIABLE_KEY;

ZCLASS MATERIAL_PIECE : public AUTO_READABLE {
    friend class COEFF;
    friend class COEFFICIENT;
    friend class STORED_VARIABLE_SPEC;
    friend class STORED_VINT;
    friend class STORED_VAUX;
    friend class STORED_MAT_BLACK_BOX;
  protected :
    // 
    // Internals for skipping attach work 
    // 
    int                         attach_skip_flags; 
    LIST<MATERIAL_PIECE*>       sub_pieces_required_attach;
    double*                     current_chi_vec_ptr;


    int                         flags;
    STRING                      its_name; 
    LIST<COEFF*>                coefficients;
    LIST<MATERIAL_PIECE*>       sub_pieces;
    LIST<STORED_VINT*>          local_vint;

    LIST<STORED_MAT_BLACK_BOX*>     local_black_box;
    int                         bb_var_sz;
    LIST<MATERIAL_PIECE_NAMER*> namer; 
    void tsz_utsz();
    void _initialize(MATERIAL_PIECE*,int);
    void _initialize(MATERIAL_PIECE*);
  public : 
    int                         int_var_sz,  aux_var_sz;
    int                         int_var_pos, aux_var_pos;
    int                         vint_index, vaux_index, flux_index, grad_index; 
    int                         _dim,_tsz, _utsz;       
    MATERIAL_PIECE*             its_boss;
    EXTERNAL_PARAMETER_VECTOR   curr_ext_param;
    MAT_DATA*                   curr_mat_data;

  public : 
    LIST<STORED_VARIABLE_SPEC*> local_vars;

    MATERIAL_PIECE();
    virtual ~MATERIAL_PIECE();

    MATERIAL_PIECE(MATERIAL_PIECE*);
    MATERIAL_PIECE(MATERIAL_PIECE*,int);
    bool declare_data(AUTO_PTR<AID_PART>&);
    void initialize(MATERIAL_PIECE* boss);         // connect
    void initialize(MATERIAL_PIECE* boss,int dim); // connect
    MATERIAL_PIECE(const MATERIAL_PIECE& svs_in, MATERIAL_PIECE* boss); // copy

    // 
    // This should be const.. assume it pretty much is... there's 
    // just frequent problems trying to get at all the data needed
    // when const is imposed by the compiler
    // 
    virtual MATERIAL_PIECE* copy_self(MATERIAL_PIECE*); 

    MATERIAL_PIECE& operator=(const MATERIAL_PIECE& svs_in);
    void            make_curr_ext_param_recursive(int size); 

    bool depends_on(const STRING&)const;

    void add_piece(MATERIAL_PIECE *p) { sub_pieces.add(p); }

    virtual void add_name_prefix_recursive(const STRING& sin);
    virtual void set_name(const STRING& sin);
    virtual const STRING& name();
            void  full_name(STRING&);
    void    rename_vars(const STRING&);

    virtual void attach_all( MAT_DATA&);
    virtual void attach( VECTOR& chi); 
    virtual void attach( VECTOR& chi, VECTOR& d_chi );
    virtual void update_var_aux(); 

    virtual void set_var_int_to_var_int_ini(); 
    virtual void set_var_aux_to_var_aux_ini(); 

    virtual bool if_constant_coefs()const; 
    virtual bool calc_coef();
    virtual int  calc_material(double);

    // 
    // New interfaces 
    // 
    void set_parameter(double theta); 
    void set_parameter(double theta,MATERIAL_INTEGRATION_INFO& /* mii */) {
         set_parameter(theta); 
      // set_mi_info(&mii); // Need to add this 
    }
//   To activate theta and rung flags back and forth
    virtual void switch_to_integration(int);

    virtual void setup(int& flux_pos, int& grad_pos, int& vi_pos, int& va_pos);
    virtual void output_var_names(int flags)const;
    virtual int  default_output_variables( BUFF_LIST<STRING>& names,
                                           LIST<STRING>& options);
    virtual int  rank_of_variable(const STRING&) const;

    // 
    // Find variable, with optimization now (12/22/98) the key classes 
    // are all destroyed in this class 
    // 
    LIST<MATERIAL_PIECE_VARIABLE_KEY*> variable_keys; 
    LIST<MATERIAL_PIECE_VARIABLE_KEY*> flux_var_keys; 
    LIST<MATERIAL_PIECE_VARIABLE_KEY*> grad_var_keys; 
    LIST<MATERIAL_PIECE_VARIABLE_KEY*> vint_var_keys; 
    LIST<MATERIAL_PIECE_VARIABLE_KEY*> vaux_var_keys; 

    // 
    // find it or create & add it to the list... NO_TYPE is match any 
    // 
    MATERIAL_PIECE_VARIABLE_KEY* find_key(const char* what, MP_TYPE type, 
                         LIST<MATERIAL_PIECE_VARIABLE_KEY*>& where_to_search); 
    
    // 
    // These are actually mutable const.. with the keys being mutable 
    // 
    void get_all_vars(BUFF_LIST<STORED_VARIABLE_SPEC*>&)const;
    STORED_VARIABLE_SPEC* get_var(const char*  what)const; 
    STORED_FLUX* get_flux_var(const char* what, bool give_err=TRUE)const;
    STORED_GRAD* get_grad_var(const char* what, bool give_err=TRUE)const;
    STORED_VINT* get_vint_var(const char* what, bool give_err=TRUE)const;
    STORED_VAUX* get_vaux_var(const char* what, bool give_err=TRUE)const;

    void add(TENSOR2_VAUX *vv);

    virtual STORED_VARIABLE_SPEC* output_get_var(const STRING& what)const; 
    const double& get_param(const STRING& what, MDAT_WHEN when=MDAT_CURR)const; 

    int  int_sz()const     { return int_var_sz; } 
    int  aux_sz()const     { return aux_var_sz; } 
    int  int_pos()const    { return int_var_pos; } 
    int  aux_pos()const    { return aux_var_pos; } 
    int  bb_sz() const { return(bb_var_sz); }

    enum BEHAVIOR_LEVEL { FIRST, NEXT, TOP }; 
    virtual BEHAVIOR*   find_behavior(BEHAVIOR_LEVEL top_level=FIRST)const;
    MATERIAL_PIECE*     give_boss()const { return its_boss; } 
    void                impose_boss(MATERIAL_PIECE* bin);
    MATERIAL_PIECE*     give_boss(const STRING& type);

    LIST<MATERIAL_PIECE*>& get_sub_pieces() { return sub_pieces; }
    LIST<COEFF*>&          get_coefficients() { return coefficients; }

    int  tsz()const  { return _tsz; } 
    int  utsz()const { return _utsz; } 
    int dim()const   { return _dim; }

    // 
    // Auto naming for sub-parts
    // 
    virtual void    setup_name(STRING class_type, STRING stub); 
    virtual STRING  get_next_name_for(STRING class_type);
    virtual STRING  get_current_name_for(STRING class_type); 
    virtual int     get_next_index_for(STRING class_type); 

    // 
    // set the vector index for all variables of a given type 
    // to idx from here down... 
    // 
    virtual int  index_size(); 
    virtual void set_flux_index(int idx); 
    virtual void set_grad_index(int idx); 
    virtual void set_vint_index(int idx); 
    virtual void set_vaux_index(int idx); 

    int  get_flux_index()const { return flux_index; }
    int  get_grad_index()const { return grad_index; }
    int  get_vint_index()const { return vint_index; }
    int  get_vaux_index()const { return vaux_index; } 

    DECLARE_ASK;
    RTTI_INFO;

    friend WIN_THINGIE void add_var(BUFF_LIST<STORED_VARIABLE_SPEC*>& var, const MATERIAL_PIECE* mp); 

    virtual void debug_variable_positions(STRING space="   ");

    // callbacks

    virtual bool do_command(STRING msg); 
    // This method may be called each time a mesh objetc starts to compute its internal reactions
    virtual void compute_internal_reactions();

    // may be called by problem components (eg. contact) to fix the material state during incerements
    virtual void linearize_yourself();
    virtual void back_from_linearized();
    
    virtual void update_integration_controls();
};

#define MP_DEFAULT_ATTACH1(sup_class) \
   virtual void attach( VECTOR& chi) { sup_class ::attach(chi); } 

#define MP_DEFAULT_ATTACH2(sup_class) \
   virtual void attach( VECTOR& chi, VECTOR& d_chi ) { sup_class ::attach(chi,d_chi); }

#define MP_DEFAULT_SETUP(sup_class) \
   virtual void setup(int& flux_pos, int& grad_pos, int& vi_pos, int& va_pos) {\
       sup_class ::setup(flux_pos,grad_pos,vi_pos,va_pos); } 

Z_END_NAMESPACE;
#endif

