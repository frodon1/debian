#ifndef __ABAQUS_INP_WRITER__
#define __ABAQUS_INP_WRITER__

#include <Utility_connections.h>
#include <Utility_mesh.h>
#include <Abaqus_zebulon.h>

Z_START_NAMESPACE;

class ABAQUS_WRITER {
   private :
      // templat file to help export INP
      bool first_written_step;
      ASCII_FILE template_file;
      Zofstream outfile;
      UTILITY_MESH* mesh;
      UTILITY_RESULTS_DATABASE* therm_results;
      BUFF_LIST<STRING> model_boundary, membrane_elsets;
      UTILITY_CONNECTION mesh_connection;
      void skip_step();
   public :
      void skip_until(const char* delim);
      void write_until(const char* delim);
      void write_nodes();
      void write_nsets();
      void write_elements();
      void write_elsets();
      void write_surfaces();
      void write_mesh();
      void write_initial_condition();
      void write_model();
      void parse_model_for_boundary();
      void write_step();
      void parse_step_for_restart();
      void field_interpolation(STRING nset, STRING file);
      void write_contact_mpc();
      void write_dload(const STRING& code, double mag, B_UTILITY_SET* bset, bool is_nu=FALSE);
   public :
      bool contact_on_lip, re_equilibrium_step, restart;
      double preload;

      ABAQUS_WRITER();
      ~ABAQUS_WRITER();
      void initialize(STRING fname, UTILITY_MESH* _mesh);
      void write();
};

Z_END_NAMESPACE;

#endif

