#ifndef __RIGID_KERNEL__
#define __RIGID_KERNEL__

#include <Global_matrix_kernel.h>

Z_START_NAMESPACE;

ZCLASS2 RIGID_KERNEL : public GLOBAL_MATRIX_KERNEL 
{
  public :
    RIGID_KERNEL(GLOBAL_MATRIX&);
    RIGID_KERNEL(const DD_SUB_DOMAIN&,GLOBAL_MATRIX&);
    virtual ~RIGID_KERNEL();

    virtual bool build_kernel(int,bool);
    virtual void fix_dof();
};
Z_END_NAMESPACE;

#endif
