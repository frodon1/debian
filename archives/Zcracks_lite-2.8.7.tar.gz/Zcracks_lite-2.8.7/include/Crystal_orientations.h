#ifndef __Crystal_orientations__
#define __Crystal_orientations__

#include <Array.h>
#include <Hierarchy.h>
#include <Marray.h>
#include <ZMath.h>

#include <Material_piece.h>
#include <Coefficient.h>

Z_START_NAMESPACE;

class ROTATION;
class ASCII_FILE;
class TENSOR2_VINT;

ZCLASS CRYSTAL_ORIENTATION : public MATERIAL_PIECE {
   protected :
      enum ORIENTATION_FLAGS { ORIENT_HAS_INTER = 1 } ;
      int                   orientation_flags;

      LIST<const ROTATION*> rotation;
      double                c_over_a;
      int                   h_matrix_sz;

      ARRAY<COEFF>          h_matrix_coef;
      SMATRIX               h_matrix;

      int                   current_plane;
      MARRAY<VECTOR>        planes;
      MARRAY<TENSOR2>       orig_m_loc, orig_u_loc;
      MARRAY<TENSOR2>       m_loc, u_loc;

      void  size_tensors(int sz);
      void  make_muloc_tensor(TENSOR2& mm, TENSOR2& uu,
                        double n1, double n2, double n3,
                        double l1, double l2, double l3);
      void  from_3_to_2(double vi1, double vi2, double vi3,
                        double& vo1, double& vo2);
      void  plan_4_to_3(double c_over_a,
                        double vi1, double vi2, double vi3, double vi4,
                        double& vo1, double& vo2, double& vo3);
      void  direction_4_to_3(double c_over_a,
                        double vi1, double vi2, double vi3, double vi4,
                        double& vo1, double& vo2, double& vo3);

      virtual void make_mloc(ARRAY<TENSOR2>& m_loc, ARRAY<TENSOR2>& u_loc)=0;
      virtual void calc_h_matrix_coefs(SMATRIX& h);

   public :
      CRYSTAL_ORIENTATION();
      CRYSTAL_ORIENTATION(const CRYSTAL_ORIENTATION& in, MATERIAL_PIECE* boss);
      virtual ~CRYSTAL_ORIENTATION();
      virtual MATERIAL_PIECE* copy_self(MATERIAL_PIECE*);
      virtual void            initialize(ASCII_FILE&, MATERIAL_PIECE* boss);
      static CRYSTAL_ORIENTATION* read(ASCII_FILE& file, MATERIAL_PIECE* b);

      bool base_read(STRING& str, ASCII_FILE& file);

      virtual void setup(int& flux_pos, int& grad_pos, int& vi_pos, int& va_pos);
      virtual bool calc_coef();

      void set_local_rotation(const TENSOR2* rot);
      const MARRAY<TENSOR2>& give_orig_m_loc()const { return( orig_m_loc ); }
      const MARRAY<TENSOR2>& give_orig_u_loc()const { return( orig_u_loc ); }
      const MARRAY<VECTOR>&  give_planes()const     { return( planes     ); }
            MARRAY<TENSOR2>& give_m_loc()           { return( m_loc      ); }
            MARRAY<TENSOR2>& give_u_loc()           { return( u_loc      ); }

      const SMATRIX&       give_h_matrix()const { return( h_matrix ); }
      void                 add_rotation(const ROTATION* rot) { rotation.add(rot); }
      int                  has_interaction()const { return( orientation_flags&ORIENT_HAS_INTER ); }

      int   num_systems() { return( m_loc.size() ); }

      virtual bool add_to_poly_map(APPLICATION_MESSAGE* msg);
      RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
