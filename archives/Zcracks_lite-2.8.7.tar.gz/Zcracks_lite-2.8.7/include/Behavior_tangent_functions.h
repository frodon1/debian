#ifndef __Behavior_tangent_functions__
#define __Behavior_tangent_functions__

// ============================================================================ 
//  These are functions for common behavior tangent functions. RF 04/26/2007
//
//  - many of the cases are going to be mechanical specific, but I put this in 
//    zBehavior because of useage coming from code which only knows behavior
//    (like simulation wrappers). 
//
//  * NEEDS TO BE COMPREHENSIVE 
// ============================================================================ 

#include <Behavior.h> 

Z_START_NAMESPACE;

ZCLASS BEHAVIOR_TANGENT_CALCULATOR { 
    int tsz; 
    int utsz; 

    TENSOR2 dJ_dF;

    void setup(int tsz_in); 

  public: 
    BEHAVIOR_TANGENT_CALCULATOR(); 
    virtual ~BEHAVIOR_TANGENT_CALCULATOR(); 

    virtual MATRIX jaumann_to_dsig_dF(const MATRIX& tg, 
                                        const TENSOR2& F, 
                                        const TENSOR2& cauchy);

    virtual MATRIX dsig_dF_to_jaumann(const MATRIX& tg,
                                        const TENSOR2& F, 
                                        const TENSOR2& cauchy);

    virtual MATRIX dsig_dF_to_truesdale(const MATRIX& tg,
                                        const TENSOR2& F, 
                                        const TENSOR2& cauchy);

    virtual MATRIX truesdale_to_dsig_dF(const MATRIX& tg,
                                        const TENSOR2& F, 
                                        const TENSOR2& cauchy);

    virtual MATRIX jaumann_to_truesdale(const MATRIX& tg,
                                        const TENSOR2& cauchy);
    virtual MATRIX truesdale_to_jaumann(const MATRIX& tg,
                                        const TENSOR2& cauchy);
};
Z_END_NAMESPACE;

#endif 
