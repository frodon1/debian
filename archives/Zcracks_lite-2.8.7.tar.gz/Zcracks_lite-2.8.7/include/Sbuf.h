#ifndef __Sbuf__ 
#define __Sbuf__ 

// ---------------------------------------------------------------------------- 
//  SBUF  is a STREAMBUF with a string as a buffer.          RF 09/29/2005 
//  
//  ** I have NOT made this to be an iostreams compatible thing... it is to 
//     satisfy an immediate need for the license manager. That's used with 
//     Z7LICENSEs specified like 192.168.2.19:3490 (So make sure and verify 
//     that if you're modifying this)
//  ** when you pass it a buffer pointer *this class will delete that* 
//     donno if that's the right behavior
// ---------------------------------------------------------------------------- 

#include <Defines.h>
#include <Stringpp.h>
#include <Zbuffer.h>

#include <stdio.h>

Z_START_NAMESPACE;

ZCLASS SBUF : public ZFILEBUFFER {
  private :
    char*  its_buffer; 
    int ext_size;

    void set_flags(IOS_OPENMODE);

  protected :
    ZSTREAMPOS seekoff_file(ZSTREAMOFF,_SEEK_DIR,int);

    virtual int is_open() const;
    void kill_buffers();

  public :
    SBUF(); 
    SBUF(char* buffer_in);
    SBUF(char* buffer_in, int sz);
    virtual ~SBUF();

    SBUF& operator=(char* buffer_in);

    virtual int underflow();
    virtual int overflow(int c = EOF);

    virtual int doallocate();
  
    virtual ZSTREAMPOS seekpos(ZSTREAMPOS pos,
                               int mode=DEF_IOS_IN_MODE|DEF_IOS_OUT_MODE);

    virtual ZSTREAMPOS seekoff(ZSTREAMOFF pos,
                               _SEEK_DIR dir, 
                               int mode=DEF_IOS_IN_MODE|DEF_IOS_OUT_MODE);

    virtual int sync();

    virtual ZFILEBUFFER* open(const char *filename, IOS_OPENMODE mode,int); // error 
    virtual SBUF* open_file(); // error
    virtual SBUF* close_file(); // error


};
Z_END_NAMESPACE;

#endif
