#ifndef NOCLIENT 

#ifndef __KERNEL_MATRIX__
#define __KERNEL_MATRIX__

#include <Array.h>
#include <Matrix.h>

Z_START_NAMESPACE;

ZCLASS KERNEL_MATRIX {
  protected :
    int total_dof;
    int schur_dof;
    int nbr;

    void print_matrix(MATRIX&);

  public :
    MATRIX schur;
    MATRIX ker;
    ARRAY<int> blocked;
    ARRAY<int> local_to_global;

    KERNEL_MATRIX(int n);
   ~KERNEL_MATRIX();

    void fix_ddl(MATRIX&,ARRAY<int>&,ARRAY<int>&);
    void find_ker_ddl(MATRIX&,int nb_rigid=-1);
    void fix_ker_ddl(MATRIX&,MATRIX&);

    void enforce_nb_rigid(int i) { nbr=i; }

    double& operator()(int i, int j);

    void    operator=(double d);

    double& getk(int i, int j) { return(ker(local_to_global[i],j)); }

    int& operator[](int i);

    void find_and_build_kernel(ARRAY<int>& fix, bool if_keep_rigid, ARRAY<int>*& rigid_body, int i_rigid=-1);

    void assign_local_to_global(ARRAY<int> &a) { local_to_global=a; }

    static void inverse(MATRIX& B, MATRIX& A,double *cond=NULL);
    int nb_fixed();
};

Z_END_NAMESPACE;
#endif
#endif
