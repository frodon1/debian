#ifndef __OUTPUT_COMPONENT_DYNAMIC_NODE__
#define __OUTPUT_COMPONENT_DYNAMIC_NODE__

//============================================================================ 
// Implementation of node data... classic **node option 
//============================================================================ 

#include <Utility_file_driver.h> 
#include <Utility_z8_results.h> 
#include <Output_component.h> 
#include <Print.h> 
#include <Problem.h> 
#include <Output_component_node.h> 

Z_START_NAMESPACE;

ZCLASS2 OUTPUT_COMPONENT_DYNAMIC_NODE : public OUTPUT_COMPONENT_NODE {
   public :


  OUTPUT_COMPONENT_DYNAMIC_NODE();
  virtual ~OUTPUT_COMPONENT_DYNAMIC_NODE();
  //      virtual void initialize(ASCII_FILE& file);
  
  virtual void look_at_params(UTILITY_FILE_DRIVER* drv,
                              MESH& mesh, 
                              ARRAY<BEHAVIOR*>& behavior);


  
  virtual void write_output(UTILITY_FILE_DRIVER* drv);
  //      virtual void get_results(double time, STRING comp); 
  void write_V_and_A(UTILITY_FILE_DRIVER* drv,NSET& nset, int current_var);
  
};
Z_END_NAMESPACE;

#endif
