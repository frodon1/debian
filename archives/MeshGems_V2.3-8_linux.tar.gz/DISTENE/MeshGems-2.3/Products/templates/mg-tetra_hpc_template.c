#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/meshgems.h>
#include <meshgems/tetra_hpc.h>

/* FOR OEM customers only, uncomment the following */
/* #include <meshgems_key_xxx.h> */

/**
 * Let's assume that the following structure holds data that
 * represents the input surface mesh on client side.  It could be a
 * database handle or anything else containing surface mesh data.  We
 * will build the mesh_t object that accesses it.  See the file
 * meshgems/mesh.h for more detailed information.
 */

struct your_internal_data_t_ {
/* _your_data; */
};

typedef struct your_internal_data_t_ your_internal_data_t;

/**
 * Implementation of how the number of vertices in the mesh is obtained.
 * @param[out]	nbvtx	: the number of vertices
 * @param[in]     user_data	: a user pointer.
 * @return error code
 */

status_t mgtm_get_vertex_count(integer * nbvtx, void *user_data) {
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *nbvtx = 0; /* the number of vertices in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the coordinates of a mesh vertex are obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	xyz	: real[3] array containing the coordinates of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_coordinates(integer ivtx, real * xyz, void *user_data) {
  int j;
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    xyz[j] = 0.0; /* j'th coordinate of the ivtx'th vertex */

  return STATUS_OK;
}

/**
 * Implementation of how the number of edges in the mesh is obtained.
 * @param[out]	nbedg	: the number of edges
 * @param[in]  user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_count(integer * nbedge, void *user_data) {
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *nbedge = 0; /* the number of edges in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh edge are obtained.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	vedge	: integer[2] array containing the vertices of the edge
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_vertices(integer iedge, integer * vedge, void *user_data) {
  int j;
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  for (j = 0; j < 2; j++)
    vedge[j] = 0; /* the j'th vertex index of the iedge'th edge */

  return STATUS_OK;
}

/**
 * Implementation of how the number of triangles in the mesh is obtained.
 * @param[out]	nbtri	: the number of triangles
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_count(integer * nbtri, void *user_data) {
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *nbtri = 0; /* the number of triangles in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh triangle are obtained.
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]	vtri	: integer[3] array containing the vertices of the triangle
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_vertices(integer itri, integer * vtri,
                                    void *user_data) {
  int j;
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    vtri[j] = 0; /* the j'th vertex index of the itri'th triangle */

  return STATUS_OK;
}

/**
 * Implementation of how the required status of a mesh vertex is obtained.
 * @param[in]	ivtx	: index of the desired vertex from 1 to nbvtx
 * @param[out]	rvtx	: integer[1] containing the required status (0 or 1)of the vertex 
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_required_property(integer ivtx, integer * rvtx,
                                           void *user_data) {
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *rvtx = 0; /* the ivtx'th vertex required property : 1 if the vertex is required or 0 if it is not */

  return STATUS_OK;
}

/**
 * This is the message callback function that Tetra_HPC will call when
 * it wants to send a message to the caller
 * see meshgems/message.h for more details.
 *
 * @param[in] msg       : the message
 * @param[in] user_data : a user pointer.
 * @return an error code
 */
status_t my_message_cb(message_t * msg, void *user_data) {
  char *desc;
  integer e, ibuff[6];
  real rbuff[3];

  message_get_description(msg, &desc);
  message_get_number(msg, &e);

  if (e == MESHGEMS_TETRA_HPC_CODE(-8411)) {
    /* This is the error 8411 related to unrecovered
     * required vertex.
     * Get the associated integer data
     */
    message_get_integer_data(msg, 1, 1, ibuff);
    printf("Missing required vertex : %i \n", ibuff[0]);
  } else if (e == MESHGEMS_TETRA_HPC_CODE(-8441)) {
    /* This is the error 8441 related to unrecovered edges.
     * Get the associated integer data [1..2]
     */
    message_get_integer_data(msg, 1, 2, ibuff);
    printf("Missing required edge : %i %i\n", ibuff[0], ibuff[1]);
  } else if (e == MESHGEMS_TETRA_HPC_CODE(-8423)) {
    /* This is the error 8423 related to unrecovered faces.
     * Get the associated integer data [1..3]
     */
    message_get_integer_data(msg, 1, 3, ibuff);
    printf("Missing required face : %i %i %i\n", ibuff[0], ibuff[1], ibuff[2]);
  } else {
    /* No specific handler for this message. Just print its description */
    printf("Message (%i) : %s", e, desc);
  }

  return STATUS_OK;
}

status_t set_tetra_hpc_parameters(tetra_hpc_session_t * ts) {
  status_t ret;

  /* You can here specify the Tetra_HPC options, using the API function
   * tetra_hpc_set_param().
   * For example : 
   */

  /* This option changes the verbosity level of Tetra_HPC, between 0 and
   * 10.  The higher it is, the more messages Tetra_HPC will send
   * through the message callback. Default is 3.
   */
  ret = tetra_hpc_set_param(ts, "verbose", "3");
  if (ret != STATUS_OK)
    return ret;

  /* Set the desired maximum ratio between 2 adjacent tetrahedra
   * edges. The closer it is to "1", the more uniform the mesh will be
   * Default value is "1.05"
   */
  ret = tetra_hpc_set_param(ts, "gradation", "1.05");
  if (ret != STATUS_OK)
    return ret;

  /* Number of computing thread to launch */
  ret = tetra_hpc_set_param(ts, "max_number_of_threads", "6");
  if (ret != STATUS_OK)
    return ret;

  return ret;
}

/* A macro we will call to cleanly return from the function in case of
 * failure.
 */
#define RETURN_WITH_MESSAGE(_ret, _msg) do{				\
    fprintf(stderr,"%s\n",_msg);					\
    if(input_mesh) mesh_delete(input_mesh);\
    if(ts) tetra_hpc_session_delete(ts);   \
    if(ctx) context_delete(ctx);					\
    return _ret;							\
  }while(0);

status_t generate_tetra_mesh(your_internal_data_t * your_internal_data) {
  status_t ret;
  context_t *ctx;
  mesh_t *input_mesh, *output_mesh;
  tetra_hpc_session_t *ts;

  integer i, nvm, ntm;
  integer nsd;
  real q, qmin, qmax;

  ctx = 0;
  input_mesh = 0;
  output_mesh = 0;
  ts = 0;

  /*
   * Create the meshgems working context
   */
  ctx = context_new();
  if (!ctx)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new context");

  /*
   * Set the message callback for our context.
   */
  ret = context_set_message_callback(ctx, my_message_cb, 0);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /*
   * Create the mesh_t structure holding the callbacks giving acces to your mesh data in
   * your_internal_data
   */
  input_mesh = mesh_new(ctx);
  if (!input_mesh)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new mesh");

  /*
   * Set the mesh_t callback functions that will query your_internal_data structure :
   * see meshgems/mesh.h for detailed function prototypes.
   */

  ret = mesh_set_get_vertex_count(input_mesh, mgtm_get_vertex_count,
                                  your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret = mesh_set_get_vertex_coordinates(input_mesh, mgtm_get_vertex_coordinates,
                                        your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret = mesh_set_get_vertex_required_property(input_mesh,
                                              mgtm_get_vertex_required_property,
                                              your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret = mesh_set_get_edge_count(input_mesh, mgtm_get_edge_count,
                                your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret = mesh_set_get_edge_vertices(input_mesh, mgtm_get_edge_vertices,
                                   your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret = mesh_set_get_triangle_count(input_mesh, mgtm_get_triangle_count,
                                    your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret = mesh_set_get_triangle_vertices(input_mesh, mgtm_get_triangle_vertices,
                                       your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  if (0) {
    /*
     * Display some statistics about the surface mesh.
     * The data is sent formated to the context message callback
     * For debugging purposes
     */
    mesh_compute_statistics(input_mesh);
  }
#ifdef __MESHGEMS_PRIVKEY_H__
  /* If you are an OEM customer for Tetra_HPC, this will sign the mesh object with
   * your private key (else Tetra_HPC would reject it) */
  ret = sign_mesh(input_mesh);
  if (ret != STATUS_OK)
  RETURN_WITH_MESSAGE(ret, "unable to sign input mesh");
#endif

  /*
   * Create a tetra_hpc session
   */
  ts = tetra_hpc_session_new(ctx);
  if (!ts)
    RETURN_WITH_MESSAGE(STATUS_NOMEM,
                        "unable to create a new tetra_hpc session");

  /*
   * Set the input working surface mesh for this tetra_hpc session
   */
  ret = tetra_hpc_set_input_mesh(ts, input_mesh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to set surface mesh");

  ret = set_tetra_hpc_parameters(ts);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to set tetra_hpc paramters");

  /* 
   * The mesh generation process. 
   * See the meshgems/tetra_hpc.h file for more details
   */
  ret = tetra_hpc_mesh(ts);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "Unable to generate volume mesh");

  /*
   * Mesh generation is completed. Get the generated volume
   * mesh. This output mesh belongs to the tetra_hpc_session. Thus the
   * user does not have to delete it afterwards.
   */
  ret = tetra_hpc_get_mesh(ts, &output_mesh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting mesh");

  /*
   * Read the output mesh data. See meshgems/mesh.h for more detailed
   * prototypes.
   */

  /* First get all the vertices */
  ret = mesh_get_vertex_count(output_mesh, &nvm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex count");

  ret = mesh_get_tetrahedron_count(output_mesh, &ntm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedron count");

  for (i = 1; i <= nvm; i++) {
    real coo[3];
    ret = mesh_get_vertex_coordinates(output_mesh, i, coo);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting vertices");
    if (0) {
      fprintf(stdout, "vertex %d coordinates are : %e %e %e \n", i, coo[0],
              coo[1], coo[2]);
    }
  }

  /* Then get all the tetrahedra and compute some statistics on their aspect ratio */

  qmin = REAL_INFINITY;
  qmax = -REAL_INFINITY;

  for (i = 1; i <= ntm; i++) {
    integer vtx[4], tag;
    ret = mesh_get_tetrahedron_vertices(output_mesh, i, vtx);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedra vertices");
    if (0) {
      fprintf(stdout, "tetra %d vertices are : %d %d %d %d \n", i, vtx[0],
              vtx[1], vtx[2], vtx[3]);
    }
    ret = mesh_get_tetrahedron_tag(output_mesh, i, &tag);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedra tags");
    if (0) {
      fprintf(stdout, "tetra %d is in subdomain %d\n", i, tag);
    }
    ret = mesh_get_tetrahedron_aspect_ratio(output_mesh, i, &q);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "internal error");
    if (q > qmax)
      qmax = q;
    if (q < qmin)
      qmin = q;
  }

  fprintf(stdout, "\nGenerated %d vertices and %d tetrahedra  \n", nvm, ntm);
  fprintf(stdout, "          with a quality within [%f,%f]\n", qmin, qmax);

  /*
   * Read the subdomain identification information.
   * See tetra_hpc documentation for more information.
   */
  ret = mesh_get_subdomain_count(output_mesh, &nsd);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting subdomain count");

  fprintf(stdout, "Identified subdomains : %d\n", nsd);
  if (nsd > 1) {
    for (i = 1; i <= nsd; i++) {
      integer subdomain_tag, seed_type, seed_idx, seed_orientation;
      char *seed_type_str;
      ret = mesh_get_subdomain_description(output_mesh, i, &subdomain_tag,
                                           &seed_type, &seed_idx,
                                           &seed_orientation);
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret, "unable to get a subdomain seed");

      if (seed_type == MESHGEMS_MESH_ELEMENT_TYPE_TRIA3) {
        seed_type_str = "triangle";
      } else {
        /* The only seed type generated by MeshGems-Tetra_HPC is the triangle */
        seed_type_str = "unknown error";
      }

      fprintf(
          stdout,
          "subdomain %d description is : tag=%d type=%s facet=%d orientation=%d \n",
          i, subdomain_tag, seed_type_str, seed_idx, seed_orientation);
    }
  }

  /*
   * We can also directly write a .mesh formated file and a .sol formated file for the sizemap : 
   */

  fprintf(stdout, "Writing volume mesh in tetra_hpc.mesh file\n");
  ret = mesh_write_mesh(output_mesh, "tetra_hpc.mesh");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a .mesh file");

  if (0) {
    /*
     * Display some statistics about the output mesh.
     * The data is sent formated to the context message callback
     * for debugging purposes.
     */
    mesh_compute_statistics(output_mesh);
  }

  /*
   * We are done, give the volume mesh and sizemap back to the session and clean up everything.
   */
  tetra_hpc_regain_mesh(ts, output_mesh);
  tetra_hpc_session_delete(ts);

  mesh_delete(input_mesh);

  context_delete(ctx);

  return STATUS_OK;
}
