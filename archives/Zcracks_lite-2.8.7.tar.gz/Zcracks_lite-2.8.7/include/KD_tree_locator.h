#ifndef __KD_TREE_LOC__
#define __KD_TREE_LOC__

#include<Buffered_list.h>
#include<Vector.h>
#include<Defines.h>
#include<Set.h>

Z_START_NAMESPACE;

struct ELEM{
    int id;
    VECTOR pos;
    VECTOR bbox;
};


class KDNODE {
    KDNODE* less; 
    KDNODE* more;
    ELEM* elem; 

  public : 
    VECTOR bbox;

    KDNODE();
    ~KDNODE();

    void partition(ELEM* V, int left, int right, int dir); 
    void search(VECTOR& position, BUFF_LIST<int>& candidate);
};

class KD_TREE_LOCATOR {
    ELEM* Vec;

  public :
    KDNODE* root;

    KD_TREE_LOCATOR();
    virtual ~KD_TREE_LOCATOR();
    void build_tree(BOUNDARYSET* target, double war_dist);
    void free_tree();
};


Z_END_NAMESPACE;


#endif



