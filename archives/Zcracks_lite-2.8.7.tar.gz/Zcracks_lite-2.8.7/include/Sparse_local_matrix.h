#ifndef __Sparse_local_matrix__
#define __Sparse_local_matrix__    // BS

#include <Defines.h>

#include <Sorted_list.h>
#include <Vector.h>

Z_START_NAMESPACE;

ZCLASS SPARSE_LOCAL_MATRIX 
{  
   private :
     void multv(const VECTOR&,VECTOR&)const;

   public :
     ARRAY<int> column_pointers;
     ARRAY<int> not_null; 
     VECTOR upper_triangle;
     VECTOR lower_triangle;

     SPARSE_LOCAL_MATRIX() {}
    ~SPARSE_LOCAL_MATRIX() {}

     void set_structure(const ARRAY< SORTED_LIST<int> >& terms);
     int nb_terms() { return(!not_null); }
     void set_size(bool sym=TRUE);
     int operator!() { return(!column_pointers-1); }
     double& operator()(int i, int j);
     VECTOR operator*(const VECTOR& v)const;

};
Z_END_NAMESPACE;

#endif
