#ifndef __Integration_method__
#define __Integration_method__

#include <ZMath.h>
#include <File.h>
#include <Zminmax.h>
#include <Marray.h>

#include <Integration_result.h>

Z_START_NAMESPACE;

class ASCII_FILE;
class RUNGE_INTEGRATOR;
class THETA_INTEGRATOR;

ZCLASS LOCAL_INTEGRATION {
  public :
      enum INTEGRATION_TYPE { THETA_ID=1, RUNGE_ID=2, PURTURBATION_ID=4 };
  protected :
      RUNGE_INTEGRATOR* rk_integrator;
      THETA_INTEGRATOR* th_integrator;
      int               thetype;
  
  public :
      // 
      // This is set to zero at the start of each call to the integrator 
      // (rk or theta method). The actual setting of the flag, and handling of 
      // it is done in each integration class, so it may or may not have an 
      // effect... if you set it to 1 in the calc_grad_f or derivative call however
      // then the integration should fail. 
      // 
      int               fail_step; 
      int               suppress_diverge_message;
      int               timer_idx;
      int               reinit;
      STRING            timer_name; 

      // 
      // General utility.. maybe set or not.. 
      // 
      int current_iteration;

      LOCAL_INTEGRATION();
      LOCAL_INTEGRATION(const LOCAL_INTEGRATION& cpy_in);
      virtual ~LOCAL_INTEGRATION();

      virtual LOCAL_INTEGRATION* copy_self()const; 

      virtual void initialize(ASCII_FILE&);

      static LOCAL_INTEGRATION* read(ASCII_FILE&,bool issue_error=TRUE);

      void set_integrator(RUNGE_INTEGRATOR*);
      void set_integrator(THETA_INTEGRATOR*);

      virtual INTEGRATION_RESULT* runge_kutta(double t1, double dt, VECTOR& y);
      virtual INTEGRATION_RESULT* runge_kutta(double t1, double dt, VECTOR& y, VECTOR& dy);

      virtual INTEGRATION_RESULT* theta_method(VECTOR& f_vec, SMATRIX& f_grad, VECTOR& chi_vec,
                               VECTOR& d_chi, const VECTOR& f_0, double t0, double dt);
      int  type()const { return thetype; }
};
Z_END_NAMESPACE;

#endif
