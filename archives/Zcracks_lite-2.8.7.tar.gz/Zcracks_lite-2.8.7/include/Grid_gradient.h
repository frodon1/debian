#ifndef __GRID_GRADIENT__
#define __GRID_GRADIENT__

#include <Grid_3d.h>

Z_START_NAMESPACE;

/*

  FF, sept 18th, 2008 : compute the gradient of a scalar field defined on a structured grid

*/

ZCLASS GRID_GRADIENT
{
  public :
    GRID_GRADIENT() { }
    virtual ~GRID_GRADIENT() { }

    void apply(const GRID_3D<double>&, GRID_3D< FINITE_SET<3,double> > &grad, int order=1);
    void apply(const GRID_3D<double>&, GRID_3D< double > &grad, int order=1);
};
Z_END_NAMESPACE;

#endif
