#ifndef __Polynomial_least_square__
#define __Polynomial_least_square__

#include <Vector.h>
#include <Matrix.h>

Z_START_NAMESPACE;

class POLY_LSQUARE
{
  private:
    int degree;
    VECTOR coefs;

  public :
    POLY_LSQUARE(int deg);
   ~POLY_LSQUARE();

    void set_degree(int deg);
    bool find_coefs(const VECTOR& x, const VECTOR& y, 
      const VECTOR& w,VECTOR& res);
    double calculate_value(double x);
    bool find_zero(double& val);
    
};
Z_END_NAMESPACE;

#endif
