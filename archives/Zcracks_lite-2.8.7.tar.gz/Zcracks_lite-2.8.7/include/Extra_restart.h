#ifndef __Extra_restart__
#define __Extra_restart__

#include <Bool.h> 
#include <List.h> 
#include <Stringpp.h> 

Z_START_NAMESPACE;
class ASCII_FILE; 
class EXTRA_RESTART; 

ZCLASS2 EXTRA_RESTART {
  private:
     enum { NEVER, ALWAYS, END_OF_SEQUENCE, END_OF_CYCLE, DTIME, TIMES } when;
     LIST<double> times;
     double dtime, last_time;

  public :
     STRING file_name; 

     EXTRA_RESTART(ASCII_FILE&);
     EXTRA_RESTART() : when(NEVER), last_time(0.) {}
     EXTRA_RESTART(const EXTRA_RESTART&);

     void do_restart(bool&);
};

Z_END_NAMESPACE;

#endif
