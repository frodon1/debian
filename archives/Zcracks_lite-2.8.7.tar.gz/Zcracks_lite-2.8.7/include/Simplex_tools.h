#ifndef __Simplex_tools__
#define __Simplex_tools__

#include <Array.h>
#include <Vector.h>
#include <Bool.h>

Z_START_NAMESPACE;

ZCLASS SIMPLEX_TOOLS {
  protected :
    double lambda, converge, abstol;
    int    num_iter, _iter ;
    bool   if_abstol, checked, _has_converged ;
    VECTOR Func_at_vertex;
    ARRAY<VECTOR> vertex;
    VECTOR init, dx0;
    int nb_var;
    void check();
    double amotry(VECTOR&,int,double);
  public :
	 const int &iter ;
	 const bool &has_converged ;
    SIMPLEX_TOOLS();
    void initialize(double converge,
                    double abstol,
                    int num_iter, 
                    bool if_abstol,
                    const VECTOR& init,
                    const VECTOR& dx0); 

    virtual ~SIMPLEX_TOOLS();
    VECTOR optimize();
    void set_init(const VECTOR&);
 
    virtual double Fsimplex(const VECTOR&)=0;
};
Z_END_NAMESPACE;

#endif
