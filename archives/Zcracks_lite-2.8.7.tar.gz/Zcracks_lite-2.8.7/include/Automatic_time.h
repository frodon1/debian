#ifndef __Automatic_time__
#define __Automatic_time__

#include <Defines.h> 
#include <Z_object.h>
#include <List.h>

Z_START_NAMESPACE;

class PROBLEM;
class ASCII_FILE; 
class MESH; 
class INTEGRATION_RESULT; 
class SEQUENCE; 

ZCLASS2 AUTOMATIC_TIME  : public Z_OBJECT {
 public  : 
     AUTOMATIC_TIME();
     virtual ~AUTOMATIC_TIME();
     virtual void initialize(ASCII_FILE&)=0;
     static AUTOMATIC_TIME* read(ASCII_FILE&);
     virtual double compute_dtime(PROBLEM*,SEQUENCE*)=0;
     virtual double compute_dtime(const INTEGRATION_RESULT*)=0;
     virtual INTEGRATION_RESULT* validate_increment(MESH*);
     virtual void mesh_changed() { }

     RTTI_INFO;
};

class STD_AUTOMATIC_TIME : public AUTOMATIC_TIME {
   protected :
             LIST<STRING> setup_variable; LIST<double> setup_value;
             LIST<bool>   mandatory; 
             bool if_first_time, force_min_dtime,use_actual_convergence_rate;
             LIST<double> first_dtime, min_dtime, max_dtime, te_toler;
             double security; double divide; int time;
             virtual bool base_read(STRING& tok, ASCII_FILE& inp);

   public  :
             int nb_divergence;
             int nb_global;

             STD_AUTOMATIC_TIME();
             virtual void initialize(ASCII_FILE& inp);
             virtual double compute_dtime(PROBLEM* prob,SEQUENCE* seq);
             virtual double compute_dtime(const INTEGRATION_RESULT* bad_result);
             virtual INTEGRATION_RESULT* validate_increment(MESH*);
             virtual void mesh_changed();

             RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
