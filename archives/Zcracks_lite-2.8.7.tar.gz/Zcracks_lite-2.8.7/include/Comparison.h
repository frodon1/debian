// COMPARISON modified for use in Levenberg ... now handling a vector 
// of linear differences between EVERY point of the simulation and 
// experiments. There is NO absolute value (important for correct 
// gradient calculation in LEVENBERG). Rodo, august 98.
#ifndef __Comparison__
#define __Comparison__

#include <Defines.h>
#include <Array.h>
#include <Function.h>
#include <Object_factory.h>
#include <Vector.h>

Z_START_NAMESPACE;

class ASCII_FILE; class OPTIMIZER;

ZCLASS COMPARISON {
  protected :
    static double Exponent;
    static int    nb_cmp;
    int           index;

    OPTIMIZER*                    its_optimizer;
    enum DATA_TYPE { XCONSTANT, XFUNCTION };
    ARRAY<STRING>                 input_files;
    ARRAY< ARRAY< int > >         types;
    ARRAY< PARRAY<FUNCTION> >     functions;
    ARRAY< ARRAY< ARRAY<int> > >  function_cols;
    ARRAY< ARRAY<int> >           cols;
    ARRAY< ARRAY<VECTOR> >        loaded;
    STRING datt_file;
    void make_datt_file();
    double lin_diff;

    void read_input(int,int,ASCII_FILE&);
    void load(const char *subdir);
    bool check_time_seq(VECTOR &, int& );
    void try_weight(ASCII_FILE&);
    bool no_time_check;
  public :
    bool          compare_log;
    double        weight;
    STRING        title;
    STRING        its_name;

    COMPARISON();
    virtual ~COMPARISON();
    virtual void initialize(ASCII_FILE&,OPTIMIZER*);

    virtual void write_comparison(char *subdir=NULL);
    virtual void write_trace(Zofstream&);
    virtual double compute_value(VECTOR &,VECTOR&,int,const char *subdir=NULL)=0;
    static void set_exponent(double n) { Exponent=n; }
};

ZCLASS FILE_FILE_COMPARISON : public COMPARISON {
  protected :
    FILE_FILE_COMPARISON();
    virtual ~FILE_FILE_COMPARISON();
    void gnu_head(Zofstream&);
};

ZCLASS I_FILE_FILE_COMPARISON : public FILE_FILE_COMPARISON {
  public :
      I_FILE_FILE_COMPARISON();
      virtual ~I_FILE_FILE_COMPARISON();
      virtual void write_trace(Zofstream&);
      virtual void initialize(ASCII_FILE&,OPTIMIZER*);
      virtual void write_comparison(char *subdir=NULL);
      virtual double compute_value(VECTOR &,VECTOR&,int,const char *subdir=NULL);
};

ZCLASS T_FILE_FILE_COMPARISON : public FILE_FILE_COMPARISON {
  public :
      T_FILE_FILE_COMPARISON();
      virtual ~T_FILE_FILE_COMPARISON();
      virtual void write_trace(Zofstream&);
      virtual void initialize(ASCII_FILE&,OPTIMIZER*);
      virtual void write_comparison(char *subdir=NULL);
      virtual double compute_value(VECTOR &,VECTOR&,int,const char *subdir=NULL);
};

ZCLASS FUNC_FILE_COMPARISON : public COMPARISON {
   protected :
      STRING func;
      VECTOR y, fy;
      void gnu_head(Zofstream&);
   public :
      FUNC_FILE_COMPARISON();
      virtual ~FUNC_FILE_COMPARISON();
      void load_y_fy(int,const char *subdir);
};

ZCLASS I_FUNC_FILE_COMPARISON : public FUNC_FILE_COMPARISON {
   public :
      I_FUNC_FILE_COMPARISON();
      virtual ~I_FUNC_FILE_COMPARISON();
      virtual void write_trace(Zofstream&);
      virtual void write_comparison(char *subdir=NULL);
      virtual void initialize(ASCII_FILE&,OPTIMIZER*);

      virtual double compute_value(VECTOR &,VECTOR&,int,const char *subdir=NULL);
};

ZCLASS T_FUNC_FILE_COMPARISON : public I_FUNC_FILE_COMPARISON {
   public :
      T_FUNC_FILE_COMPARISON();
      virtual ~T_FUNC_FILE_COMPARISON();
      virtual void write_trace(Zofstream&);
      virtual void write_comparison(char *subdir=NULL);
      virtual void initialize(ASCII_FILE&,OPTIMIZER*);

      virtual double compute_value(VECTOR &,VECTOR&,int,const char *subdir=NULL);
};

Z_END_NAMESPACE;
#endif

