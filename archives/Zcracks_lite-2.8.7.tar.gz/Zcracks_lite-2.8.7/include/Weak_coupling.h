#ifndef __WEAK_COUPLING__
#define __WEAK_COUPLING__

#include <Zunistd.h>

#include <Algorithm.h>
#include <Calcul_timer.h>
#include <Coupled_data_transfer.h>
#include <Error_messager.h>
#include <Object_factory.h>
#include <Out_message.h>
#include <Problem.h>
#include <Sequence.h>
#include <Sub_problem.h>
#include <Problem_includes.h>
#include <Weak_coupling_criterion.h>
#include <Z_object.h>
#include <Verbose.h>
#include <Print.h>

Z_START_NAMESPACE;

#ifdef _WIN32
  #define OUT_MODE ios::out|ios::binary|ios::trunc
  #define IN_MODE ios::in|ios::binary
  #define Rflag "wb"
#else
  #define OUT_MODE ios::out|ios::trunc
  #define IN_MODE ios::in
  #define Rflag "r"
#endif

ZCLASS2 WEAK_COUPLING : public PROBLEM {
  protected : 
    int iter, do_restart; 
    bool read_coupled(ASCII_FILE&) ; 
    bool set_auto_restart(ASCII_FILE&);
    bool read_sub_problem(ASCII_FILE&);
    bool read_initialize_with_transfer(ASCII_FILE&);

    LIST<WEAK_COUPLING_CONVERGENCE_CRITERION*> convergence_criterions;
    bool check_criterions();
    virtual bool may_have_output() { return(false); }

  public :
    PLIST<SUB_PROBLEM> problems;

    bool time_zero;

    WEAK_COUPLING();
    virtual ~WEAK_COUPLING();

    virtual bool Execute();
    virtual bool Initialize();
    virtual bool make_increment(double);
    virtual void write_restart(RST_FSTREAM&);
    virtual void read_restart(RST_FSTREAM&);
    virtual void output_data(bool forced=FALSE);
    virtual bool needs_a_mesh();
    virtual void create_mesh();
    virtual bool verification();
    virtual int parallelized(void) { return(1); }
    virtual bool GetResponse(const char* const,ASCII_FILE&);
    void mesh_setup(ASCII_FILE&) { }
//    virtual void read_all(const STRING&, ASCII_FILE&);

    int nb_sub_problems() { return(problems.size()); }
    const SUB_PROBLEM& sub_problem(int i) { return(*problems[i]); }

    LIST<PROBLEM*> get_fem_problem(STRING);

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
