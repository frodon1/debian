#ifndef __READ_WRITE_FINDER__
#define __READ_WRITE_FINDER__

#include <Defines.h>
#include <Zstream.h>

Z_START_NAMESPACE;

ZCLASS READ_WRITE_FINDER {
  public :
    READ_WRITE_FINDER() { }
   ~READ_WRITE_FINDER() { }

    void find();
};
Z_END_NAMESPACE;

#endif
