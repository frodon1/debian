#ifndef __Xfem_discontinuity__
#define __Xfem_discontinuity__

// ============================================================================
//  XFEM_DISCONTINUITY                                 RF 11/14/2003
// 
//  Some geometrical model of a discontinuity w/info about "side" given a 
//  coord, and endpoints. derived classes are for 2d 3d, level set, etc 
// ============================================================================

#include <Buffered_list.h> 
#include <File.h> 
#include <Grid_3d.h> 
#include <Sorted_list.h> 
#include <Vector.h> 

#include <Problem.h> 

#include <Behavior.h>

#include <Crack_growth_models.h> 
#include <Crack_behavior.h> 

Z_START_NAMESPACE;

class XFEM_PB_COMPONENT; 
class XFEM_ENHANCED_ELEMENT_WRAPPER; 

//
// needs to be hammered out some. used for passing back a boundary 
// for the x-integration to subdivide 
//
ZCLASS2 XFEM_2D_SEGMENT {
   public : 
      VECTOR p1; 
      VECTOR p2; 

      XFEM_2D_SEGMENT(); 
      XFEM_2D_SEGMENT(VECTOR& p1_in, VECTOR& p2_in); 
      XFEM_2D_SEGMENT(const XFEM_2D_SEGMENT& in); 
      XFEM_2D_SEGMENT& operator=(const XFEM_2D_SEGMENT& in); 
      bool operator==(const XFEM_2D_SEGMENT& in); 
};


ZCLASS2 XFEM_3D_SUBDIV {
   public : 
      BUFF_LIST<double>           values; // to store arbitrary values (for instance the psi levelset)
      BUFF_LIST<UTILITY_NODE*>    nd; 
      BUFF_LIST<UTILITY_BOUNDARY> bnd; 

      XFEM_3D_SUBDIV(); 
      ~XFEM_3D_SUBDIV(); 
      XFEM_3D_SUBDIV(const XFEM_3D_SUBDIV& in); 
      XFEM_3D_SUBDIV& operator=(const XFEM_3D_SUBDIV& in); 
      bool operator==(const XFEM_3D_SUBDIV& in); 

      void store(STRING&,STRING comment=STRING::EMPTY);
};

ZCLASS2 XFEM_DISCONTINUITY { 
  protected :
    XFEM_PB_COMPONENT* its_boss; 
    STRING elset_name;

  public :
    enum X_TYPE { 
        NONE=0, 
        FULLY_CUT=1, 
        ENDPOINT_WITHIN=2, 
        NODE_TANGENCY=4,
        EDGE_TANGENCY=8,
        FACE_TANGENCY=16,
        INSIDE_SPHERE=32,
        MAX_TYPE=64 
    };

    ARRAY<VECTOR> H_values; // current values of H,...,Hn at nodes

    ARRAY<int> nodes_on_discontinuity;
    LIST< ARRAY<int>* > faces_on_discontinuity;

    bool debug;
    bool reassign_behavior;
    BEHAVIOR *plus_behavior,*minus_behavior;
    STRING plus_behavior_fname,minus_behavior_fname;
    int    plus_behavior_rank,minus_behavior_rank;

    XFEM_DISCONTINUITY(); 
    virtual ~XFEM_DISCONTINUITY(); 
    virtual void initialize(ASCII_FILE& file, XFEM_PB_COMPONENT* boss); 
    virtual bool GetResponse(STRING&,ASCII_FILE&);

    virtual double Heaviside(XFEM_ENHANCED_ELEMENT_WRAPPER* elem, VECTOR& coord); 

    // used only for crack discontinuity: locate the point versus the second levelset
    virtual double Heaviside2(XFEM_ENHANCED_ELEMENT_WRAPPER* elem, VECTOR& coord);

    virtual void compute_distances(const int,ARRAY<double>&) { }


    // fills the H_values Array
    virtual void compute_H_values();

//  virtual double tip_distance(XFEM_ENHANCED_ELEMENT_WRAPPER* elem, VECTOR& coord); 
    virtual int    tip_coord(XFEM_ENHANCED_ELEMENT_WRAPPER* elem , const VECTOR& pos, VECTOR& tip_position, VECTOR& growth_dir, VECTOR& g_norm);

    // 
    // Each discontinuity is expected to keep some good internal 
    // tracking data on the x-section based on the element pointer 
    // 
    virtual X_TYPE compute_intersection(XFEM_ENHANCED_ELEMENT_WRAPPER* elem,
                BUFF_LIST<XFEM_2D_SEGMENT>& approx_segments_left,
                BUFF_LIST<XFEM_2D_SEGMENT>& approx_segments_right,
                LIST<VECTOR>& intersections); 
    virtual X_TYPE compute_intersection(MESH& mesh,
                XFEM_ENHANCED_ELEMENT_WRAPPER* elem,
                XFEM_3D_SUBDIV& subdiv_left,
                XFEM_3D_SUBDIV& subdiv_right,
                XFEM_3D_SUBDIV& middle);

    virtual void get_edges_on_discontinuity(LIST< LIST<int> >&,XFEM_ENHANCED_ELEMENT_WRAPPER*);
    virtual void get_nodes_on_discontinuity(SORTED_LIST<int>&,XFEM_ENHANCED_ELEMENT_WRAPPER*);
    virtual void get_face_on_discontinuity(LIST<int>&, int&, XFEM_ENHANCED_ELEMENT_WRAPPER*);
    // to identify sub_faces on discontinuity in xele_maps file
    virtual void get_sub_faces_ranks_on_discontinuity(BUFF_LIST<int>&,XFEM_ENHANCED_ELEMENT_WRAPPER*);


    // 
    // Don't really need to pass in prob because of its_boss, but 
    // i'm doing it for clarity/convenience 
    // 
    virtual void propagate(PROBLEM* prob); 

    // called after the mesh has been enhanced, if derived classes need to take some control over
    virtual void end_of_enhancement() { }
    virtual void dump_extras(Zofstream& /* file */) { }
    virtual void after_material();

    virtual void debug_cuts() { } 
    virtual void propagate() { }
    virtual void mesh_changed() { }
    virtual void get_levelset_grids(GRID_3D<double>*& gphi, GRID_3D<double>*& gpsi) { gphi=gpsi=NULL; }
    virtual void update_for_added_mpc_nodes(ARRAY<NODE*> duplicated_nodes) { }

    void set_elset(STRING &s) { elset_name=s; }

    virtual void read_restart(RST_FSTREAM& obin) {}
    virtual void write_restart(RST_FSTREAM& rep) {}
}; 

//  
//  2d piecewise linear discontinuity 
//  
//  **currently pre-defined also 
//  
ZCLASS2 XFEM_TIP_GROWTH_DEFINITION { 
  public: 
    enum MODE { 
        NONE, 
        EXTENSION,
        ADDITION
    };
    MODE   mode; 
    STRING crack_file; 
    int    file_idx; 
    CRACK_GROWTH_BEHAVIOR* growth;

    XFEM_TIP_GROWTH_DEFINITION(); 
    ~XFEM_TIP_GROWTH_DEFINITION(); 

    void initialize(ASCII_FILE& file);
};

ZCLASS2 XFEM_2D_PIECEWISE_LINEAR : public XFEM_DISCONTINUITY {
  protected: 
    BUFF_LIST<XFEM_ENHANCED_ELEMENT_WRAPPER*> x_section_elem;
    BUFF_LIST<VECTOR>   st_pt; 
    BUFF_LIST<VECTOR>   end_pt; 
    BUFF_LIST<VECTOR>   dx; 
    BUFF_LIST<VECTOR>   dxn; 
    BUFF_LIST<double>   len; 

    BUFF_LIST<VECTOR> pts;

    int    got_hack_y; 
    double hack_y; 
    double extend_factor; 
    int    skip_endpoint; 

    XFEM_TIP_GROWTH_DEFINITION growth1; 
    XFEM_TIP_GROWTH_DEFINITION growth2; 

  public:

    XFEM_2D_PIECEWISE_LINEAR();
    virtual ~XFEM_2D_PIECEWISE_LINEAR();
    virtual void initialize(ASCII_FILE& file, XFEM_PB_COMPONENT* boss); 

    virtual double Heaviside(XFEM_ENHANCED_ELEMENT_WRAPPER* elem, VECTOR& coord);
//  virtual double tip_distance(XFEM_ENHANCED_ELEMENT_WRAPPER* elem, VECTOR& coord);
    virtual X_TYPE compute_intersection(XFEM_ENHANCED_ELEMENT_WRAPPER* elem,
                BUFF_LIST<XFEM_2D_SEGMENT>& approx_segments_left,
                BUFF_LIST<XFEM_2D_SEGMENT>& approx_segments_right,
                LIST<VECTOR> &intersections);

    virtual void get_nodes_on_discontinuity(SORTED_LIST<int>&,XFEM_ENHANCED_ELEMENT_WRAPPER*);
    virtual void compute_H_values();

    virtual void propagate(PROBLEM* prob); 
    virtual void dump_extras(Zofstream& file);
    virtual bool GetResponse(STRING &ctl, ASCII_FILE &file);
};

// 
// XFEM_2D_PREDEFINED_PIECEWISE_LINEAR  (break out from prototype) 
// XFEM_3D_PIECEWISE_MESHED
// XFEM_2D_LEVELSET 
// 

Z_END_NAMESPACE;

#endif 
