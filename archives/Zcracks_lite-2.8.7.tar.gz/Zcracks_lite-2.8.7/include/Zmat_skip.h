#ifndef __Zmat_skip__
#define __Zmat_skip__

#include <Std_cc_stream.h>

#include <Marray.h>
#include <Vector.h>
#include <File.h>

Z_START_NAMESPACE;

class ZEBABA_HANDLER;

class ZMAT_SKIP {
  private:

    bool first_write,open_check_out;

    int header_size;
    int _record_size,_nb_points;
    int pt_vint;

    int nb_before,max_skip,nsteps_preload,nsteps_cycle;
    double tpreload,tcycle;

//  Skip control parameters:
    double check_limit,range,min_variation,precision;

    bool update_sizes,flush_sdv;
    int  record_size,nb_points;
    int last_ele,last_pt;
    int previous_ele,previous_pt;
    double T0;

    LIST<STRING> components;
    MARRAY<VECTOR> check_var1;
    MARRAY<VECTOR> check_var2;
    MARRAY<VECTOR> check_var3;
    VECTOR       vint_1,vint_2,vint_3;

    void _read_(VECTOR&,Zfstream&);
    void rewind_sdv_file();
    void write_size_to_sdv();
    void calculate_skip();
    void read_sdv();

  public:

//  Public and needed for disp extrapolation
    STRING sdv_name;
    Zfstream sdv_file, check_file;
    Zfstream debug_file;

    ARRAY<int> use_cycle;

    int Nskipped;

    ZMAT_SKIP();
    virtual ~ZMAT_SKIP();

    void load(ASCII_FILE&);
    void do_skip(bool,bool,double,double);
    bool use_skip(double,double);
    bool dig_for_sdv(bool,double,double,VECTOR& vint, VECTOR& vaux);
    void write_sdv(bool,double,int,int,ZEBABA_HANDLER&, VECTOR& vint, VECTOR& vaux);

};

Z_END_NAMESPACE;
#endif

