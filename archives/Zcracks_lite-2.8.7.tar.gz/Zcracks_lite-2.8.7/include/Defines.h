#ifndef __Defines__
#define __Defines__


//
// choose the thread model for the code
//
#if defined Linux || defined Darwin || defined AIX
   #define __POSIX_THREADS__
#elif defined _WIN32 
   #ifdef WIN_PTHREADS           // use the pthread port to win 
     #define __POSIX_THREADS__
   #else                          // use native win thread
     #define __WIN_THREADS__
   #endif
#endif


// 
// Tag included after threaded version started in Z8.3.10 
//
#define Z8310_THREADED 


// #define USE_1996_TOOLS
#ifdef __NO_ZSET_NAMESPACE__
  #undef Z_HAS_NAMESPACE
#else
  #define Z_HAS_NAMESPACE
#endif

#ifdef Z_HAS_NAMESPACE

#define Z_START_NAMESPACE namespace ZSET { 
#define Z_END_NAMESPACE }
#define Z_USE_NAMESPACE using namespace ZSET

#else

#define Z_START_NAMESPACE
#define Z_END_NAMESPACE 
#define Z_USE_NAMESPACE 

#endif


// 
// BLAS and Fortran interface defines 
// 
//
#if defined __ibm__ || defined _WIN32 
#elif defined HPUX
#else
#define Z_NEEDS_UNDSC
#endif

#ifdef Z_NEEDS_UNDSC
#define fortran_call(a) a ## _
#else
#define fortran_call(a) a
#endif

#ifdef HPaCC
#define NEEDS_THIS_IN_TEMPLATE
#endif 

#ifdef HPaCC
#define NO_DETAILED_OPERATORS
#endif

#if defined HPUX
#else 
#define INCLUDE_TEMPLATE_C_FILE
#endif
 
#ifdef __GNUG__
  #define INLINE inline 
#elif defined __GNUC__
  #define INLINE
#elif defined HPPA
  #define INLINE
#elif defined SUNCC5
  #define INLINE inline
#elif defined OSF1_OLD
  #define INLINE inline
  #define DETAILED_OPERATORS_REQUIRED
#elif defined OSF1
  #define INLINE
#elif defined SUNCC
  #define INLINE
  #define DETAILED_OPERATORS_REQUIRED
#elif defined HPUX
  #define INLINE
#else
  #define INLINE inline
  #define DETAILED_OPERATORS_REQUIRED
#endif

#if defined ibm || defined _WIN32
#else
#define FCNTL_IN_SYS 
#endif

#ifdef AIX 
  #include <fcntl.h>
#endif 

// #ifndef HPUX 
// #define USE_MEM_MOVE
// #endif

// 
// Horrid windows dll stuff define just one DLL# 
// 
#ifdef _WIN32 
#define NO_DETAILED_OPERATORS

#if defined DLL1 
  #define WIN_THINGIE __declspec(dllexport)
  #define ZCLASS  class WIN_THINGIE 
  #define ZCLASSt class

#elif defined DLL2 
  #define WIN_THINGIE __declspec(dllimport)
  #define ZCLASS  class WIN_THINGIE 
  #define ZCLASSt class

  #define WIN_THINGIE2 __declspec(dllexport)
  #define ZCLASS2 class WIN_THINGIE2 
  #define ZCLASS2t class 

  #define WIN_THINGIE3 __declspec(dllexport)
  #define ZCLASS3 class WIN_THINGIE3

#elif defined DLL3
  #define WIN_THINGIE __declspec(dllimport)
  #define ZCLASS  class WIN_THINGIE
  #define ZCLASSt class 
  
  #define WIN_THINGIE2 __declspec(dllimport)
  #define ZCLASS2 class WIN_THINGIE2
  #define ZCLASS2t class
  
  #define WIN_THINGIE3 __declspec(dllimport)
  #define ZCLASS3 class WIN_THINGIE3
  
  #define WIN_THINGIE4 __declspec(dllexport)
  #define ZCLASS4 class WIN_THINGIE4

#endif 

#else 
#define WIN_THINGIE
#define WIN_THINGIE2
#define WIN_THINGIE3
#define WIN_THINGIE4
#define ZCLASS class 
#define ZCLASSt class 
#define ZCLASS2 class 
#define ZCLASS2t class 
#define ZCLASS3 class 
#define ZCLASS4 class 
#endif

// 
// These are to handle the Zstreams/fstream difference between windoze 
// and unix...  RF July 05 2000 
// 
/* SQ 09/06/06 not needed anymore (since quite a time by the way)
#ifdef _WIN32
#define DBL_CAST (char*)
#define CHA_CAST (char*)
#define INT_CAST (char*)
#define FLO_CAST (char*)
#else
*/
    #define DBL_CAST (double*)
    #define CHA_CAST (char*)
    #define INT_CAST (int*)
    #define FLO_CAST (float*)
//#endif


#if defined _WIN32 && defined ZCHECK
  #include <malloc.h> 
  #include <Assert.h> 
  // #define ARRAY_PRINTS
  // #define HEAP_CHECK assert(_heapchk() == _HEAPOK);
  #define HEAP_CHECK 
#else
  #define HEAP_CHECK 
#endif

#ifdef _WIN32
     #define finite(a) _finite(a)
#elif defined HPUX64
     #define finite(a) isfinite(a)
#elif defined SUNCC5 && !defined Icc
     #include <ieeefp.h>
#elif defined SOLARIS
     #include <ieeefp.h>
#endif


// Macro to declare deprecated functions
#ifdef __GNUC__
  #ifndef NO_DEPRECATED
    #define DEPRECATED  __attribute__ ((deprecated)) 
  #else
    #define DEPRECATED
  #endif
#else 
  #define DEPRECATED
#endif 


#endif
