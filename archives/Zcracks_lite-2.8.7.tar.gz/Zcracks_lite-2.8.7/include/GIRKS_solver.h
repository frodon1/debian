//
// Gosselet 2004, Generic iterative solvers (mostly used with generic_dd)
// see P. Gosselet thesis (2003), nice paper soon
//
// GIRKS acceleration method mostly working with (bi)cg
//
#ifndef __N_GIRKS_SOLVER__
#define __N_GIRKS_SOLVER__

#include <Accelerated_Krylov_iterative_solver.h>

Z_START_NAMESPACE;

class GIRKS_ALGEBRA_PROVIDER;
class N_GIRKS_SOLVER : public ACCELERATED_KRYLOV_ITERATIVE_SOLVER {
  protected:
    GIRKS_ALGEBRA_PROVIDER *girks;
    double s;//TODO parameter
  public:
    virtual void loop(); 
    N_GIRKS_SOLVER():ACCELERATED_KRYLOV_ITERATIVE_SOLVER(){girks=NULL;s=1.;}
    virtual ~N_GIRKS_SOLVER() { }
    RTTI_INFO;
     
        AUTO_PTR<VECTOR_LIKE> proj_irks1t(AUTO_PTR<VECTOR_LIKE>);
    AUTO_PTR<VECTOR_LIKE> proj_irks1(AUTO_PTR<VECTOR_LIKE>);
    AUTO_PTR<VECTOR_LIKE> proj_irks2(AUTO_PTR<VECTOR_LIKE>);
    AUTO_PTR<VECTOR_LIKE> prec_gkc(AUTO_PTR<VECTOR_LIKE>);
    AUTO_PTR<VECTOR_LIKE> prec_gkct(AUTO_PTR<VECTOR_LIKE>);
};

class IRKS_PREC;
class GKC_PREC;
class GIRKS_ALGEBRA_PROVIDER : public ITERATIVE_SOLVER_OPERATOR
{
  protected:
    ITERATIVE_SOLVER_OPERATOR *provider;
    N_GIRKS_SOLVER *solver;
    AUTO_PTR<IRKS_PREC> preco_irks; 
    AUTO_PTR<GKC_PREC> preco_gkc;
    AUTO_PTR<OPERATOR_LIKE> precirks,precgkc;
  public:
    bool is_irks;
    GIRKS_ALGEBRA_PROVIDER():ITERATIVE_SOLVER_OPERATOR(){provider=NULL;is_irks=TRUE;solver=NULL;}
    virtual ~GIRKS_ALGEBRA_PROVIDER(){};
    void initialize(ITERATIVE_SOLVER_OPERATOR*,N_GIRKS_SOLVER*);
    virtual AUTO_PTR<VECTOR_LIKE> give_vector(){return(provider->give_vector());}
    virtual AUTO_PTR<MATRIX_LIKE> give_matrix(STRING s="empty"){return(provider->give_matrix(s));}
    virtual AUTO_PTR<OPERATOR_LIKE> give_operator(STRING);
    virtual void inivec(VECTOR_LIKE &v)const{provider->inivec(v);}
    virtual void inimat(MATRIX_LIKE &m)const{provider->inimat(m);}
//
    virtual double compute_ratio(const VECTOR_LIKE &v){return(provider->compute_ratio(v));}
    virtual double compute_ratio_factor()const{return(provider->compute_ratio_factor());}
};

class IRKS_PREC : public OPERATOR_LIKE
{
  public:
    N_GIRKS_SOLVER *solver;
    ITERATIVE_SOLVER_OPERATOR *provider;
    IRKS_PREC():OPERATOR_LIKE(){identity=FALSE;} 
    virtual ~IRKS_PREC(){}
    void set_solver(N_GIRKS_SOLVER *s,ITERATIVE_SOLVER_OPERATOR *i){solver=s;provider=i;}
    virtual void product(VECTOR_LIKE&,const VECTOR_LIKE&,bool transpose=FALSE)const;
    virtual void product(MATRIX_LIKE&, const MATRIX_LIKE&,bool /* transpose */=FALSE)const{
         NOT_IMPLEMENTED_ERROR("GIRKS BLOCK");
    }
//
    virtual AUTO_PTR<VECTOR_LIKE> operator*(VECTOR_LIKE&)const;
    virtual AUTO_PTR<VECTOR_LIKE> operator|(VECTOR_LIKE&)const;
    virtual AUTO_PTR<MATRIX_LIKE> operator*(MATRIX_LIKE&)const {ERROR("");return(provider->give_matrix());}
    virtual AUTO_PTR<MATRIX_LIKE> operator|(MATRIX_LIKE&)const {ERROR("");return(provider->give_matrix());}
    RTTI_INFO;
};

class GKC_PREC : public OPERATOR_LIKE
{
    N_GIRKS_SOLVER *solver;
    ITERATIVE_SOLVER_OPERATOR *provider;
  public:
    GKC_PREC():OPERATOR_LIKE(){} 
    virtual ~GKC_PREC(){}
    void set_solver(N_GIRKS_SOLVER *s,ITERATIVE_SOLVER_OPERATOR *i){solver=s;provider=i;}
    virtual void product(VECTOR_LIKE&,const VECTOR_LIKE&,bool transpose=FALSE)const;
    virtual void product(MATRIX_LIKE&, const MATRIX_LIKE&,bool /* transpose */=FALSE)const{
         NOT_IMPLEMENTED_ERROR("GIRKS BLOCK");
    }
//
    virtual AUTO_PTR<VECTOR_LIKE> operator*(VECTOR_LIKE&)const; 
    virtual AUTO_PTR<VECTOR_LIKE> operator|(VECTOR_LIKE&)const;
    virtual AUTO_PTR<MATRIX_LIKE> operator*(MATRIX_LIKE&)const {ERROR("");return(provider->give_matrix());}
    virtual AUTO_PTR<MATRIX_LIKE> operator|(MATRIX_LIKE&)const {ERROR("");return(provider->give_matrix());}
    RTTI_INFO;
};

Z_END_NAMESPACE;
#endif

