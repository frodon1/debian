#ifndef __Axis__
#define __Axis__

#include <Vector.h>
#include <Matrix.h>
#include <Stringpp.h>

Z_START_NAMESPACE;

ZCLASS2 AXIS 
{
  public :
    int mode;

    STRING name;
    VECTOR center;
    SMATRIX rotation;

    AXIS();
    ~AXIS();
};
Z_END_NAMESPACE;

#endif
