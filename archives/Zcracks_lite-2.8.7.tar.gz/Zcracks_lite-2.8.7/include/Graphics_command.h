#ifndef __Graphics_command__
#define __Graphics_command__

// ============================================================================ 
//  GRAPHICS_COMMAND  is a class to make the command icons in the command
//  panel of the program.  Easy extension should be possible... 
//  the name passed top the creator will be used to load a bitmap for 
//  example... 
// 
//  the class is a two-part class..  dynamically simulating multiple inheritance.
//  the problem is one needs to derive to create the do_command options 
//  for each class, but we don't want to duplicate the device specific junk. 
// 
//  fabricate is implemented in the device directory.. e.g. in Motif_command.c
//  this way the device knows what type to create for the commandor.. 
// ============================================================================ 

#include <Object_factory.h> 
#include <Defines.h> 
#include <Stringpp.h> 
#include <Commander.h>
#include <Graphics_application.h> 

Z_START_NAMESPACE;

class GRAPHICS_COMMANDOR; 
class GRAPHICS_APPLICATION_LOADER;
class GRAPHICS_COMMAND; 
class GRAPHICS_OBJECT; 
class GRAPHICS_POINT; 

ZCLASS GRAPHICS_COMMANDOR {
  protected : 
    int keep; 
    STRING its_name; 

  public : 
    GRAPHICS_COMMAND*     its_boss; 
    GRAPHICS_APPLICATION* its_app; 

    GRAPHICS_COMMANDOR(STRING name, GRAPHICS_COMMAND* boss,
           GRAPHICS_APPLICATION* app);
    virtual ~GRAPHICS_COMMANDOR();
    virtual bool do_command(STRING cmd);
    void set_keep() { keep=1; }
    void unset_keep() { keep=0; }

    virtual void help(STRING topic); 
    virtual void help_popup(STRING& msg); 
}; 

ZCLASS GRAPHICS_COMMAND : public COMMANDER { 
  public : 
    static GRAPHICS_COMMAND* last_active; 

    STRING its_name; 
    LIST<GRAPHICS_COMMAND*> sub_commands; 
    GRAPHICS_COMMAND*       its_boss; 
    GRAPHICS_COMMANDOR*     commandor; 
    GRAPHICS_APPLICATION* its_app; 
    GRAPHICS_APPLICATION_LOADER* its_loader;

    // 
    // Help system... 
    // 
    STRING       help_file; 
    LIST<STRING> issued_hints; 
    void         help_hint(STRING hint_name); 
    void         set_help_base(STRING file_base); 
    void         clear_hints(); 
    void         help(STRING topic); 
    
    GRAPHICS_COMMAND(); 
    virtual void base_initialize(STRING name , GRAPHICS_APPLICATION* app);
    virtual void initialize(GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app); 
    virtual ~GRAPHICS_COMMAND(); 

    static GRAPHICS_COMMAND* fabricate(int x, int y, STRING name, GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app); 
    static void fabricate(int x, int y, GRAPHICS_COMMAND *cmd, GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app); 

    virtual bool do_command(STRING cmd);

    // Depending on the real rendering device, either one of theses two methods will be called
    // The first one (eg native Zmaster) is called passing the clicked point, and it's up to the command to find which entity has been selected
    virtual bool do_click(int track, GRAPHICS_POINT& click, GRAPHICS_OBJECT* target);
    // The second one (eg OpenGL) is called when the device provides directly the clicked entity. The command must then check the graphics area object to know
    // what has been selected
    virtual bool do_click();

    virtual bool get_graphics_dialogs_for_save_view(LIST<GRAPHICS_DATA_DIALOG*>& fill_in); 

    void check_unique_object_name(const STRING radix, STRING &name, int &rk);
};

#define MAKE_GRAPHICS_COMMAND_LOADER(a,b) DECLARE_OBJECT(GRAPHICS_COMMAND, a, b) 

Z_END_NAMESPACE;
#endif 

