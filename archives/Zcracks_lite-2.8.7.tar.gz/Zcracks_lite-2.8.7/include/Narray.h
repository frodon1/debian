#ifndef __Narray__
#define __Narray__

#include <Array.h>

Z_START_NAMESPACE;

/// numeric array class : hould work with int double float long etc...
template <class T> ZCLASSt NARRAY : public CARRAY<T> {
   public :
     /// default constructor
     NARRAY() : CARRAY<T>() {}
     /// initialize size
     NARRAY(int n) : CARRAY<T>(n) {}
     /// copy constructor
     NARRAY(const NARRAY<T>& na) : CARRAY<T>(na) {}

     /// set all components of the array equal to t
     void set(const T&);

     /// +=
     NARRAY<T>& operator+=(const NARRAY<T>&);
     /// -=
     NARRAY<T>& operator-=(const NARRAY<T>&);
     /// /=
     NARRAY<T>& operator/=(const NARRAY<T>&);
     /// /=
     NARRAY<T>& operator/=(T);
     /// *=
     NARRAY<T>& operator*=(const NARRAY<T>&); 
     /// *=
     NARRAY<T>& operator*=(T);
};

template <class T> void NARRAY<T>::set(const T& t)
{ for(int i=0;i<sz;i++) x[i]=t; }

template <class T> NARRAY<T>& NARRAY<T>::operator+=(const NARRAY<T>& n)
{ assert(sz==!n); for(int i=0;i<sz;i++) x[i]+=n[i]; return *this; }

template <class T> NARRAY<T>& NARRAY<T>::operator-=(const NARRAY<T>& n)  
{ assert(sz==!n); for(int i=0;i<sz;i++) x[i]-=n[i]; return *this; }

template <class T> NARRAY<T>& NARRAY<T>::operator/=(const NARRAY<T>& n)   
{ assert(sz==!n); for(int i=0;i<sz;i++) x[i]/=n[i]; return *this; }

template <class T> NARRAY<T>& NARRAY<T>::operator*=(const NARRAY<T>& n)   
{ assert(sz==!n); for(int i=0;i<sz;i++) x[i]*=n[i]; return *this; }

template <class T> NARRAY<T>& NARRAY<T>::operator/=(T t)
{ for(int i=0;i<sz;i++) x[i]/=t; return *this; }

template <class T> NARRAY<T>& NARRAY<T>::operator*=(T t)
{ for(int i=0;i<sz;i++) x[i]*=t; return *this; }

template <class T> NARRAY<T> operator+(const NARRAY<T>& n1,const NARRAY<T>& n2)
        { NARRAY<T> r(n1); r+=n2; return r; }
template <class T> NARRAY<T> operator-(const NARRAY<T>& n1,const NARRAY<T>& n2)
        { NARRAY<T> r(n1); r-=n2; return r; }
template <class T> NARRAY<T> operator*(const NARRAY<T>& n1,const NARRAY<T>& n2)
        { NARRAY<T> r(n1); r*=n2; return r; }
template <class T> NARRAY<T> operator/(const NARRAY<T>& n1,const NARRAY<T>& n2)
        { NARRAY<T> r(n1); r/=n2; return r; }
template <class T> NARRAY<T> operator*(const NARRAY<T>& n1,T t)
        { NARRAY<T> r(n1); r*=t; return r; }
template <class T> NARRAY<T> operator*(T t,const NARRAY<T>& n1)
        { NARRAY<T> r(n1); r*=t; return r; }
template <class T> NARRAY<T> operator/(const NARRAY<T>& n1, T t)
        { NARRAY<T> r(n1); r/=t; return r; }
Z_END_NAMESPACE;

#endif
