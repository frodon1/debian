#ifndef __SPLIT_SEQ_PROBLEM__
#define __SPLIT_SEQ_PROBLEM__

#include <Dao_geom.h>

Z_START_NAMESPACE;
  
ZCLASS2 SPLIT_SEQ_PROBLEM : public GRAPHICS_COMMAND, public GRAPHICS_OBJECT
  {
     LIST<STRING> files;
     LIST<STRING> dirs;
     STRING work_dir;
     ARRAY<int> tasks;

     public:
	GRAPHICS_DATA_DIALOG* its_dialog;
	DAO_GEOMETRY*         its_dao;
	CONFIG_VM_DIALOG*     its_vm_dialog;
	
	SPLIT_SEQ_PROBLEM();
	virtual ~SPLIT_SEQ_PROBLEM();
	virtual void setup_dialog();
	bool do_command(STRING cmd);
	void Get_Dir_info(STRING);
	void read_and_split_geof(STRING input_name, STRING format, ARRAY<int> tasks);
	void send_mesh(UTILITY_MESH* mesh,  int PGA_tid, ARRAY<int>& nodes_local_to_global, ARRAY<int>& elements_local_to_global, ARRAY<int>& num_vals, ARRAY<int>& num_gp, int global_mesh_nodes_size, int sum_gp, STRING pb_name );
	
  };
Z_END_NAMESPACE;

#endif

