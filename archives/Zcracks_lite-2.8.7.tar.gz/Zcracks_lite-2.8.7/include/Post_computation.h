#ifndef __Post_computation__
#define __Post_computation__

#include <Bool.h>
#include <Special_vector.h>
#include <Modify_record.h>

#include <Post_coefficient.h>

Z_START_NAMESPACE;

class GAUGE;

ZCLASS2 POST_COMPUTATION : public Z_OBJECT {
     STRING class_name_for_coef_part; // hack set in ::write  
  protected :

     void size_coefficient(int i); 
     void size_coefficient(); 

     // 
     // this is used for the data entries of the type 
     //  was:   inp.optional("*scale", "log", "lin", is_log);
     //  now:   key_cmd(ret, "scale", "log", "lin", is_log); // is_log changed to int
     //  
     void key_cmd(MODIFY_INFO_RECORD* modif, 
                  STRING keyword, STRING true_key, STRING false_key, 
                  int& value); 

     ASCII_FILE* current_file; 
     ASCII_FILE* current_mat_file; 

     //
     // Used by the default read method.
     //
     virtual bool read_data_fields(ASCII_FILE& file, MODIFY_INFO_RECORD* modif);

   public :
     STRING                     processor_name; 
     STRING                     material_file_name;
     GAUGE *gauge;

     int         		section;
     void        		set_section(int);
     int         		get_section();

     POST_COMPUTATION*          parent;
     void                       set_parent(POST_COMPUTATION*);
     POST_COMPUTATION*          get_parent();

     LIST<POST_COEFF*>          coefficient; 
     LIST<STRING>               parameters_of_coefficient;

     enum PC_TYPE {LOCAL, GLOBAL};
     POST_COMPUTATION();
     virtual ~POST_COMPUTATION();

     //
     // These are now the method of choice for creating a post
     // calculation .. the modif record is in zTools/Modify_record.h
     // For posts, the default method actually assigns the data recieved
     // to the pointer kept in the modif record.. so be carefull !!!!
     //
     virtual void read_process(ASCII_FILE&, ASCII_FILE&, MODIFY_INFO_RECORD* m=NULL);
     virtual MODIFY_INFO_RECORD* get_modify_info_record();
     virtual bool                set_from_modify_info_record(const MODIFY_INFO_RECORD*);
     virtual bool                set_data_fields(const MODIFY_INFO_RECORD* modif);
             void                add_parameter_name_to_input_i_need(ARRAY<STRING>&);
             void                compute_coefficient(const VECTOR&);
             bool                read_coeffs(ASCII_FILE& mat_file); 

     //
     // The default load now uses the MODIFY_INFO_RECORD for
     // the post computation.. only re-define if you have some complex reading..
     // and you'll still probably only need to do set_from_modify_info_record
     //
     virtual void load(ASCII_FILE&,ASCII_FILE&,bool verify=TRUE);

     //
     // These INCLUDE the **process keyword... defaults work
     // from the MODIFY_INFO_RECORD again.
     //
     virtual void write_inp(Zofstream& file);
     virtual void write_mat(Zofstream& file);

     //
     // Check if it's good to go !
     //
     virtual bool verify_info();

     virtual void input_i_need(int dimension,         ARRAY<STRING>& data_names)=0;
     virtual void output_i_give(bool& out_every_map,  ARRAY<STRING>& data_names)=0;

     // function to overload for processes that need to rebuild stuff when the
     // mesh changes (Z8 format)
     virtual void mesh_changed() { }

     virtual PC_TYPE type()const =0;
     virtual bool need_material_file()const { return FALSE; }
     virtual bool compute_on_ipsets()const { return FALSE; }

     //
     // Card packet is for local posts which don't need the whole
     // history loaded in.. this will be much more mem efficient for
     // imported/exported results modes (e.g odb copy to cng SDV to real names)
     //
     virtual int card_packet()const { return 0; }
};

Z_END_NAMESPACE;

#endif
