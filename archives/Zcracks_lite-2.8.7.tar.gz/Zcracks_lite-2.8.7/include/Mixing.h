#ifndef __Mixing_parameter__
#define __Mixing_parameter__

#include <File.h>
#include <Object_factory.h>
#include <Zstream.h>
#include <Base_problem.h>
#include <Problem.h>
#include <Viscous_fluid_problem_EMSE.h>
#include <External_parameter.h>

Z_START_NAMESPACE;

ZCLASS2 MIXING : public EXTERNAL_PARAM
{
 public : 

  MIXING();
  ~MIXING();

  virtual void initialize(ASCII_FILE&,int ipc=0);  
  virtual void start_computing();
  virtual void end_computing();
    
  virtual void compute_next(int id,  const VECTOR& coord0,  double& vi,   double& vf,  double& v0, int ip_number=-1);      
                          
  int rank;
		                            
 protected :
	
  double param1; 
  double param2;
  double width;

};
Z_END_NAMESPACE;

#endif
