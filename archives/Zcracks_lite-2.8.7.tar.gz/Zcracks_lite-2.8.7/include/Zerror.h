//
// See my comments in zTools/Thread_specific_data.h
// This file is necessary for windows
//
#ifdef ERROR
  #undef ERROR
#endif
#define ERROR(a)                ERROR_MESSAGER::static_err_message(STRING::EMPTY+a,__FILE__, __LINE__)
#define ZERROR(a)               ERROR_MESSAGER::static_err_message(STRING::EMPTY+a,__FILE__, __LINE__)
