#ifndef __Post_fatigue__
#define __Post_fatigue__

#include <Dichotomy.h>
#include <Newton_raphson.h>

#include <Local_post_computation.h>
#include <Post_simple.h>
#include <Post_trace.h>
#include <Post_mises.h>
#include <Post_eigen.h>
#include <Post_range.h>

Z_START_NAMESPACE;


#define EPSILON 1.E-08

class POST_LCF;

ZCLASS2 BASE_POST_FATIGUE : public POST_SIMPLE {
  protected :
    double infinity;

    AUTO_PTR<POST_TRACE> lp_trace;
    AUTO_PTR<POST_MISES> lp_mises;
    AUTO_PTR<POST_RANGE> lp_range;
    AUTO_PTR<POST_EIGEN2> lp_eigen;
    AUTO_PTR<BASE_POST_FATIGUE> lp_fatigue;
    int tsz; 

    int is_log, for_cumulation, normalized_coeff;
    int  min_fat;
    bool use_eigen;

    friend class POST_LCF;
    POST_COEFF a, M, sigma_l, sigma_u, b1, b2;
    POST_COEFF A, alpha, B, beta;

  public :

    BASE_POST_FATIGUE(); 
    virtual ~BASE_POST_FATIGUE() {}
    virtual void init_coefs();

    void set_for_cumulation(int);
    void set_infinity(double);

    virtual MODIFY_INFO_RECORD* get_modify_info_record();
    virtual bool verify_info();

    virtual void input_i_need(int,ARRAY<STRING>&); 
    virtual void output_i_give(bool&,ARRAY<STRING>&); 
    virtual bool need_material_file()const { return TRUE; }
    virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&); 
    virtual void computation(const ARRAY<VECTOR>&,double&,double&,double&,double&);  
};

// Keyword : fatigue_S

ZCLASS2 POST_FATIGUE_STRESS : public BASE_POST_FATIGUE {
 protected :
  friend class POST_LCF;
  int with_a;

 public :
  POST_FATIGUE_STRESS();
  virtual ~POST_FATIGUE_STRESS();

  virtual void init_coefs(); 

  virtual MODIFY_INFO_RECORD* get_modify_info_record();
  virtual bool verify_info();

//  virtual void input_i_need(int,ARRAY<STRING>&);
  virtual void output_i_give(bool&,ARRAY<STRING>&);
  virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
//  virtual void computation(const ARRAY<VECTOR>&,double&,double&,double&,double&);
};
  
// Keyword : fatigue_E

ZCLASS2 POST_FATIGUE_PLASTIC_STRAIN : public BASE_POST_FATIGUE {
 protected :
 public :
  POST_FATIGUE_PLASTIC_STRAIN();
  virtual ~POST_FATIGUE_PLASTIC_STRAIN();

  virtual void init_coefs(); 
  virtual MODIFY_INFO_RECORD* get_modify_info_record();

//  virtual void input_i_need(int,ARRAY<STRING>&);
  virtual void output_i_give(bool&,ARRAY<STRING>&);
  virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
  virtual void computation(const ARRAY<VECTOR>&,double&,double&,double&,double&) {}
};
  
// Keyword : fatigue_EE

ZCLASS2 POST_FATIGUE_ELASTIC_PLASTIC_STRAIN : public BASE_POST_FATIGUE, public NEWTON_RAPHSON,
       public DICHOTOMY {
 protected :
  double deq;
 public :
  POST_FATIGUE_ELASTIC_PLASTIC_STRAIN();
  virtual ~POST_FATIGUE_ELASTIC_PLASTIC_STRAIN();

  virtual void init_coefs(); 
  virtual MODIFY_INFO_RECORD* get_modify_info_record();

//  virtual void input_i_need(int,ARRAY<STRING>&);
  virtual void output_i_give(bool&,ARRAY<STRING>&);
  virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
  virtual VECTOR f_newton_raphson(const VECTOR&);
  virtual double  f_dichotomy(double)const ;
  virtual SMATRIX df_newton_raphson(const VECTOR& x); 
  virtual void computation(const ARRAY<VECTOR>&,double&,double&,double&,double&) {}
};
Z_END_NAMESPACE;
  
#endif
