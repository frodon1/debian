#ifndef __Post_data_test__
#define __Post_data_test__

// ============================================================================ 
//  POST_DATA_TEST   a global post processor for making curve output as in the 
//                   zebulon **curve output option. used extensively for the 
//                   z-mat/abaqus validation cases 
// 
//  o ** NO GUI Interface ** 
//  o Can't mix node and integ values because that's set at a higher *** level 
//  o there's never any output_i_give, and out_every_map is always TRUE
// 
// 
//  ****post_processing
//   ***data_source fil 
//    **open uniaxial_145c_100.fil 
//   ***precision 3
//   ***global_post_processing
//    **file node
//    **output_number 1-999
//    **nset ALL_NODE
//    **process curve uniaxial_145c_100.test
//     *nset XSYM RU1 
//     *node 1223 U1 sig11 
// ****return
// 
// ============================================================================ 

#include <Modify_record.h>
#include <Error_messager.h>
#include <Global_post_computation.h>
#include <Post_processor.h>

Z_START_NAMESPACE;

class POST_DATA_TEST_COMPONENT; 

ZCLASS2 POST_DATA_TEST : public GLOBAL_POST_COMPUTATION {
   public :
      int          idx; 
      LIST<STRING> inputs;

      STRING           header_line; 
      STRING           output; 
      Zofstream        out_file; 
      int              precision; 
      double           _small; 
      int              do_time; 

      LIST<POST_DATA_TEST_COMPONENT*> parts; 

      POST_DATA_TEST();
      virtual ~POST_DATA_TEST();

      virtual void load(ASCII_FILE& file,ASCII_FILE& mat_file, bool verify);
      virtual bool base_read(STRING str, ASCII_FILE& file);

      virtual void input_i_need(int dimension,         ARRAY<STRING>& data_names);
      virtual void output_i_give(bool& out_every_map,  ARRAY<STRING>& data_names);
      virtual void compute(ARRAY<POST_ELEMENT*>&,ARRAY<POST_NODE*>&,const ARRAY<int>&);
      STRING     filter(double val); 
};

// ---------------------------------------------------------------------------- 
// Will add onto a curve output by adding new columns. it loads in 
// the cols of the existing (presumed closed) file into a vector buffer 
// and then runs the parts which then add on to the output
// 
// This is needed because each ***global_post_processing section can 
// have only one "location".  see Post_test/INP/disk6.inp 
// 
// **process continue_curve fname 
//  [ *existing_file  old_file ]   % default same as fname
// 
// NOTE: should interpolate these existing values if the time column 
//       (assumed 1st) doesn't match up totally..
// 
// ---------------------------------------------------------------------------- 
ZCLASS2 POST_CONTINUE_DATA_TEST : public POST_DATA_TEST {
   public :
      int               first_data_size; 
      STRING            existing_file; 
      LIST<STRING>      existing_headers; 
      BUFF_LIST< LIST<double> > existing_data; 

      POST_CONTINUE_DATA_TEST();
      virtual ~POST_CONTINUE_DATA_TEST();
      virtual bool base_read(STRING str, ASCII_FILE& file);
      virtual void compute(ARRAY<POST_ELEMENT*>&,ARRAY<POST_NODE*>&,const ARRAY<int>&);
};


// ---------------------------------------------------------------------------- 
//  Now follows the actual implementations 
// ---------------------------------------------------------------------------- 
ZCLASS2 POST_DATA_TEST_COMPONENT { 
  protected : 
     STRING fmt; 
     POST_DATA_TEST* its_boss; 
  public : 
      LIST<STRING>     var;
 
     // 
     // The POST_DATA_TEST sets these for us 
     // 
     LIST<int> indexes;           // index for my vars in look->data[0].data[indexes[i]]
     ARRAY<POST_ELEMENT*>*   p_eset;
     ARRAY<POST_NODE*>*      p_nset;

   
     POST_DATA_TEST_COMPONENT(); 
     virtual ~POST_DATA_TEST_COMPONENT(); 
     virtual void initialize(ASCII_FILE& file, POST_DATA_TEST* boss); 

     STRING     filter(double val) { return its_boss->filter(val); } 
     POST_NODE* findit(ARRAY<POST_NODE*>& p_nset, int id);

     virtual void add_data_names(LIST<STRING>& data_names)=0; 
     virtual void write_header_lines(Zofstream& of); 
     virtual void data_test_output(Zofstream& out_file, POST_MESH* mesh)=0;
}; 


ZCLASS2 PDT_AT_NODE : public POST_DATA_TEST_COMPONENT { 
  public : 
      int              look_node; 
      STRING           look_nset; 

      virtual void initialize(ASCII_FILE& file, POST_DATA_TEST* boss);
      virtual void add_data_names(LIST<STRING>& data_names);
      virtual void data_test_output(Zofstream& out_file, POST_MESH* mesh);
}; 

// ----------------------------------------------------------------------------
//  variables summed over a node set 
// ----------------------------------------------------------------------------
ZCLASS2 PDT_AT_NSET : public POST_DATA_TEST_COMPONENT { 
  public : 
      STRING           nset_name; 

      virtual void initialize(ASCII_FILE& file, POST_DATA_TEST* boss);
      virtual void add_data_names(LIST<STRING>& data_names);
      virtual void data_test_output(Zofstream& out_file, POST_MESH* mesh);
}; 

// ----------------------------------------------------------------------------
// PDT_NSET_LISTING ... like a liset but perhaps we don't have one (e.g. aba test)
//
//  You can ask for X Y and Z... not S however
// ----------------------------------------------------------------------------
ZCLASS2 PDT_NSET_LISTING : public POST_DATA_TEST_COMPONENT {
  public :
      LIST<int>        types;
      STRING           nset_name;

      virtual void initialize(ASCII_FILE& file, POST_DATA_TEST* boss);
      virtual void add_data_names(LIST<STRING>& data_names);
      virtual void data_test_output(Zofstream& out_file, POST_MESH* mesh);
};

// ----------------------------------------------------------------------------
//  PDT_AT_LISET... path output
// ----------------------------------------------------------------------------
ZCLASS2 PDT_AT_LISET : public POST_DATA_TEST_COMPONENT {
  public :
      LIST<int>        types;
      STRING           liset_name;

      virtual void initialize(ASCII_FILE& file, POST_DATA_TEST* boss);
      virtual void add_data_names(LIST<STRING>& data_names);
      virtual void data_test_output(Zofstream& out_file, POST_MESH* mesh);
};

// ----------------------------------------------------------------------------
//  
// ----------------------------------------------------------------------------
ZCLASS2 PDT_AT_GP : public POST_DATA_TEST_COMPONENT {
  public :
      int              look_element;
      int              look_gp;

      virtual void initialize(ASCII_FILE& file, POST_DATA_TEST* boss);
      virtual void add_data_names(LIST<STRING>& data_names);
      virtual void data_test_output(Zofstream& out_file, POST_MESH* mesh);
};

// ----------------------------------------------------------------------------
//  
// ----------------------------------------------------------------------------
ZCLASS2 PDT_NODE_TO_GP : public POST_DATA_TEST_COMPONENT {
  public :
      int              look_element;
      int              look_gp;

      virtual void initialize(ASCII_FILE& file, POST_DATA_TEST* boss);
      virtual void add_data_names(LIST<STRING>& data_names);
      virtual void data_test_output(Zofstream& out_file, POST_MESH* mesh);
};

ZCLASS2 PDT_TORQUE_LISTING : public POST_DATA_TEST_COMPONENT {
  public :
      STRING           nset_name;
      VECTOR           point; 
      VECTOR           direction; 

      virtual void initialize(ASCII_FILE& file, POST_DATA_TEST* boss);
      virtual void add_data_names(LIST<STRING>& data_names);
      virtual void data_test_output(Zofstream& out_file, POST_MESH* mesh);
};

// ----------------------------------------------------------------------------
//  PDT_BSET_INTEGRATION.  e.g. integ sig11 to get face load
// ----------------------------------------------------------------------------
ZCLASS2 PDT_BSET_INTEGRATION : public POST_DATA_TEST_COMPONENT {
  public :
      LIST<int>        types;
      STRING           liset_name;

      virtual void initialize(ASCII_FILE& file, POST_DATA_TEST* boss);
      virtual void add_data_names(LIST<STRING>& data_names);
      virtual void data_test_output(Zofstream& out_file, POST_MESH* mesh);
};

Z_END_NAMESPACE;

#endif 
