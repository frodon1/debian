#ifndef __Openmode__ 
#define __Openmode__

// 
// Everything now moved to Std_cc_stream.h
// 
#include <Std_cc_stream.h>

Z_START_NAMESPACE;
Z_END_NAMESPACE;

#endif
