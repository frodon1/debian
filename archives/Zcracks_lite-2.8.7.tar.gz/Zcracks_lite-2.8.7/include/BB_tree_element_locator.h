#ifndef __BB_TREE_ELEMENT_LOCATOR__
#define __BB_TREE_ELEMENT_LOCATOR__

//
//  VC 05/2006
//  Fast element locator using a bounding box tree (usefull for remeshing)
//

#include <List.h>
#include <Vector.h>
#include <Utility_mesh.h>
#include <Transfer_mapping_method.h>
#include <Vector_to_element_locator.h>
#include <BB_tree_utility_mesh.h>

Z_START_NAMESPACE;


class TRANSFER_MAPPING_METHOD;

class BB_TREE_ELEMENT_LOCATOR : public VECTOR_TO_ELEMENT_LOCATOR {
  public :
    BB_TREE_UTILITY_MESH  bb_tree;

    BB_TREE_ELEMENT_LOCATOR() { mesh=NULL; mapper=NULL; toler=1.e-7; iter=100; }
    virtual ~BB_TREE_ELEMENT_LOCATOR() { bb_tree.erase(); }

    virtual void locate();
};

Z_END_NAMESPACE;
#endif

