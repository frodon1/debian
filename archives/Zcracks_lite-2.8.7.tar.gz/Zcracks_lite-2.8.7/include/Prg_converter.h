#ifndef __PRG_CONVERTER__
#define __PRG_CONVERTER__

#include <Std_cc_stream.h>

#include <Zbool.h>
#include <Base_problem.h>
#include <ZP_piece.h>
#include <ZP_object.h>

Z_START_NAMESPACE;

class P_LEXER;

ZCLASS PRG_CONVERTER : public BASE_PROBLEM {
  protected :
    P_LEXER *p_lexer;

    virtual P_LEXER* build_lexer();

  public :
    STRING source_file,output_file,type,class_name;
    STRING keyword;

    PRG_CONVERTER();
    virtual  ~PRG_CONVERTER();

    virtual bool Execute();
    virtual void load();
    virtual void load(const STRING&, const STRING&); 

    void output_proc_proto(Zofstream &ofile, ZP_OBJECT *proc);
    void output_proc(Zofstream &ofile, ZP_OBJECT *proc);
    void output_post();

    void find_global_vars(LIST<STRING>&,LIST<STRING>&);
};
Z_END_NAMESPACE;

#endif
