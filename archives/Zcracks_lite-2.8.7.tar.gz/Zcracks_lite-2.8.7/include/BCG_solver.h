//
// Gosselet 2004, Generic iterative solvers (mostly used with generic_dd)
// see P. Gosselet thesis (2003), nice paper soon
//
// Block-conjugate gradient solver
// not yet garantied to function
//
#ifndef __B_CG_SOLVER__
#define __B_CG_SOLVER__

#include <Array.h>
#include <math.h>
#include <File.h>
#include <Krylov_iterative_solver.h>

Z_START_NAMESPACE;

class B_CG_SOLVER : public KRYLOV_ITERATIVE_SOLVER {
  protected :
    double last_ratio;
    virtual void loop();

  public :
    B_CG_SOLVER() :KRYLOV_ITERATIVE_SOLVER() { }
    virtual ~B_CG_SOLVER() { }

    virtual void set_parameter(SOLVER_PARAMETER *sp) {
      KRYLOV_ITERATIVE_SOLVER::set_parameter(sp);
      this->parameters->ortho_type="gram_schmidt";
    }

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
