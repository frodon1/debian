#ifndef __ZP_AXIS__
#define __ZP_AXIS__

#include <Axis.h>
#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_AXIS : public ZP_BASIC_TYPE< AXIS >
{
  protected :
    virtual void type_init(char*) { type="AXIS"; }

  public :
    BASIC_CONSTRUCTORS(ZP_AXIS,AXIS)

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
    ZPO_RTTI_INFO(AXIS)
};
Z_END_NAMESPACE;

#endif
