#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/meshgems.h>
#include <meshgems/meshgems_short_names.h>
#include <meshgems/hexa.h>

#define FREE_AND_STRDUP(_p_,_s_) if(_p_) free(_p_); _p_ = strdup(_s_)

/*
 Compute basename from file
 */
char *strstrfromend(char *MshNam, const char *base)
{
  char *InpFil;
  char *ptr = NULL, *pdeb = NULL;
  size_t longbase, longfil;

  InpFil = MshNam;
  longbase = strlen(base);
  longfil = strlen(InpFil);

  if (longbase > longfil)
    return (ptr);

  ptr = InpFil + longfil - longbase;
  ptr = strstr(ptr, base);
  if (ptr)
    return (ptr);

  if ((longfil - longbase) > 0) {
    ptr = InpFil + strlen(InpFil) - longbase - 1;
    ptr = strstr(ptr, base);
  }

  return (ptr);
}

/*
 * message callback function
 */
status_t my_message_cb(message_t * msg, void *user_data)
{
  char *desc;
  integer e, n, m;
  integer i, i_data[10];
  real r_data[10];
  n = m = 0;
  message_get_description(msg, &desc);
  message_get_number(msg, &e);

  if (e < 0) {
    printf("mg-hexa ERROR %i : %s", MESHGEMS_ABS_CODE(e), desc);
    message_get_integer_data_count(msg, &n);
    message_get_real_data_count(msg, &m);
    printf("MGMESSAGE %i ", e);
    printf(" %i", n);
    if (n > 0) {
      message_get_integer_data(msg, 1, n, i_data);
      for (i = 0; i < n; i++)
        printf(" %i", i_data[i]);
    }
    printf(" %i", m);
    if (m > 0) {
      message_get_real_data(msg, 1, m, r_data);
      for (i = 0; i < m; i++)
        printf(" %f", r_data[i]);
    }
    printf(" \n");

  }
  if (e >= 0) {
    if (e == 0)
      printf("mg-hexa info : %s", desc);
    else
      printf("mg-hexa info %i : %s", MESHGEMS_CODE(e), desc);
  }

  return STATUS_OK;
}

/*
 * MAIN PROCEDURE
 */
int main(int argc, char *argv[])
{

  context_t *ctx;
  hexa_session_t *myhex;
  mesh_t *surface;
  mesh_t *hexmesh;

  status_t ret;

  char *outfile;
  char *infile;

  int len;
  char *ptr;

  char chaine[512];

  ptr = NULL;
  outfile = NULL;
  infile = NULL;

  /* create the Meshgems working context */
  ctx = context_new();

  /* set the message callback for the context */
  context_set_message_callback(ctx, my_message_cb, NULL);


  /* create the Meshgems-Hexa session */
  myhex = meshgems_hexa_session_new(ctx);

  surface = NULL;
  if (argc > 1) {
    /* check input and output files */
    if (argc > 1 && argv[1][0] != '-') {
      FREE_AND_STRDUP(infile, argv[1]);
      if (argc > 2) {
        FREE_AND_STRDUP(outfile, argv[2]);
      }
    }
  } else {
    printf("usage : hexa_example.exe filein [fileout] \n");
    exit(-1);
  }

  if (infile) {
    /* create the Meshgems mesh and read it */
    surface = mesh_new_read_mesh(ctx, infile);
    if (!surface) {
      printf("\n %%%% Error, unable to read mesh file. \n");
      exit(-1);
    }
  }

  if (!outfile) {
    int i;
    char *basename;
    char *add = (char *) "_hexa";
    ptr = strstrfromend(infile, ".mesh");
    len = strlen(ptr);
    basename = (char *) calloc(strlen(infile) - len + 1, sizeof(char));
    for (i = 0; i < strlen(infile) - len; i++)
      basename[i] = infile[i];
    len = strlen(ptr) + strlen(add) + strlen(basename);
    outfile = (char *) calloc(len + 1, sizeof(char));
    sprintf(outfile, "%s%s%s", basename, add, ptr);

  }

  /* set the session input surface mesh */
  ret = hexa_set_surface_mesh(myhex, surface);
  if (ret != STATUS_OK) {
    printf("\n %%%% Internal error, unable to set surface mesh. \n");
    exit(-1);
  }

  printf("\n");
  printf("\nrunning hexahedral mesher  ... \n");

  /* compute the volume mesh */
  ret = hexa_compute_volume_mesh(myhex);

  if (ret != STATUS_OK) {
    printf("\n %%%% mesh processing failed, no saving operation \n");
    exit(-1);
  }

  hexmesh = NULL;
  /* get the generated volume mesh */
  ret = hexa_get_mesh(myhex, &hexmesh);
  if (ret != STATUS_OK) {
    printf("\n %%%% Internal error, unable to set surface mesh. \n");
    exit(-1);
  } else {
    printf(" %%%% writing the resulting mesh : %s\n", outfile);
    meshgems_mesh_write_mesh(hexmesh, outfile);
  }

  hexa_regain_mesh(myhex, hexmesh);

  if (outfile)
    free(outfile);
  if (infile)
    free(infile);

  hexa_session_delete(myhex);
  mesh_delete(surface);
  context_delete(ctx);

  return 0;
}
