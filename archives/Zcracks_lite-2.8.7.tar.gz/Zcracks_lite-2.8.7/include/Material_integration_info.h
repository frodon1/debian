#ifndef __Material_integration_info__
#define __Material_integration_info__

#include <Vector.h> 
#include <Matrix.h> 
#include <Z_object.h>

Z_START_NAMESPACE;

ZCLASS MATERIAL_INTEGRATION_INFO  : public Z_OBJECT {
   public :
      double     t0, dt;
      VECTOR     coord; 

      // 
      // This should go in mat data somehow.. still working on that 
      // 
      VECTOR     delta_grad; 

      SMATRIX    tg_matrix;
      int        flags;

      int        type_signature;

      MATERIAL_INTEGRATION_INFO() : t0(0.), dt(0.), flags(0), type_signature(0) { }
      MATERIAL_INTEGRATION_INFO(double _t0,double _dt) : t0(_t0), dt(_dt), flags(0) { }

      inline double tend() { return t0+dt; }
      RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
