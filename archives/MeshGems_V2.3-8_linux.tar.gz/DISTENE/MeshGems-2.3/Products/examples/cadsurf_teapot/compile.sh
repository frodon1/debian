gcc -I. -L. cadsurf_teapot.c -lmg-cadsurf -lmeshgems -lmeshgems_stubs -lmg-tetra -lm -lc  -o teapot.exe
