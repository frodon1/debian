#ifndef __Remesh_gth__ 
#define __Remesh_gth__ 

// ============================================================================  
//   REMESH_GTH    RF June 2003 
// 
//   Puts together the different transfer/remesh  elset functionality 
//   into a continous remeshing problem. 
// 
//   ** For the time being, Remember to use **save_all_variables in your output!
// 
//   ** RF 02/28/2004 took out remeshing engine, restored my syntax, advise 
//      always putting the remesh operation into a mesher transform, and 
//      allow derived classes from this one. There is a trivial example at the 
//      end of the .c file 
// 
// ============================================================================  

#include <Output_control.h> 
#include <Auto_ptr.h>
#include <Transfer_nodal_data.h> 
#include <Transform_geometry.h> 
#include <Initialize_with_transfer.h> 
#include <Remeshing_criterion.h>

Z_START_NAMESPACE;

class REMESH_GTH : public INITIALIZE_WITH_TRANSFER  {
  protected : 
    int       output_after_remesh; 
    STRING    format; 
    UTILITY_MESH *new_mesh;

    //
    // What to do when we re-mesh.. unfortunately fixed to doing just
    // one set of things every time.
    //
    bool remesh_now;
    PLIST<TRANSFORMERS> transf;

    OUTPUT_CONTROL*      remesh_frequency;
    REMESHING_CRITERION* remesh_criterion;    

  public  :
    REMESH_GTH(); 
    virtual ~REMESH_GTH(); 

    virtual bool base_read(STRING str, ASCII_FILE& file);
    virtual void load(ASCII_FILE& inp_file, PROBLEM* boss);

    virtual void post_manage_restart();
    virtual bool verification();
    virtual bool output_data();

    virtual void end_increment(INTEGRATION_RESULT*&);

    bool time_for_remeshing();
    void create_new_mesh(UTILITY_MESH*&);
    void load_new_mesh(UTILITY_MESH*&);
    void transfer();

    void set_new_mesh(UTILITY_MESH* &p) { new_mesh=p; }

//  virtual bool uses_sub_types() { return TRUE; }
//  virtual const char* sub_type_obj_factory() { return "REMESH_GTH"; }
}; 
Z_END_NAMESPACE;

#endif 
