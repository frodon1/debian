#ifndef __LEAST_SQUARE__
#define __LEAST_SQUARE__

#include <List.h>
#include <Vector.h>
#include <Matrix.h>

Z_START_NAMESPACE;

//
// FF, June 2003, a generic least square approximator
//
// See Numerical Recipies, chapter 15
//

//
// Just overload basis_function() and number_of_basis_function()
//   to define your own basis function

ZCLASS LEAST_SQUARE {
  protected :
    MATRIX A;
    SMATRIX AtA;
    VECTOR a;

  public :
    LEAST_SQUARE();
    virtual ~LEAST_SQUARE();

    virtual double basis_function(int,VECTOR&)=0;
    virtual int    number_of_basis_function()=0;

    void initialize(VECTOR &values, LIST<VECTOR> &positions);
    void initialize(VECTOR &values, LIST<VECTOR*> &positions);
    void initialize_mls(VECTOR values, LIST<VECTOR*> &positions, double hmax, const VECTOR& dist_ip);
    double interpolate(VECTOR&);
};
Z_END_NAMESPACE;

#endif
