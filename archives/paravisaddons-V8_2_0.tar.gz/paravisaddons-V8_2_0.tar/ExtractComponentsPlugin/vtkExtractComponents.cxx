/*=========================================================================

  Program:   ParaView
  Module:    vtkExtractComponents.cxx

  Copyright (c) Kitware, Inc.
  All rights reserved.
  See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
#include "vtkExtractComponents.h"

#include "vtkCellData.h"
#include "vtkDataArray.h"
#include "vtkDataSet.h"
#include "vtkFieldData.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkPointData.h"
#include "vtkSmartPointer.h"

vtkStandardNewMacro(vtkExtractComponents);

//----------------------------------------------------------------------------
vtkExtractComponents::vtkExtractComponents()
{
  this->OutputArrayName = 0;
}

//----------------------------------------------------------------------------
vtkExtractComponents::~vtkExtractComponents()
{
  this->SetOutputArrayName(0);
  this->ClearComponents();
}

//----------------------------------------------------------------------------
int vtkExtractComponents::FillInputPortInformation(int vtkNotUsed(port), vtkInformation* info)
{
  info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkDataSet");
  return 1;
}

//----------------------------------------------------------------------------
int vtkExtractComponents::RequestData(vtkInformation* vtkNotUsed(request),
  vtkInformationVector** inputVector, vtkInformationVector* outputVector)
{
  // get the output info object
  vtkInformation* outInfo = outputVector->GetInformationObject(0);
  vtkDataSet* output = vtkDataSet::SafeDownCast(outInfo->Get(vtkDataObject::DATA_OBJECT()));

  vtkInformation* inInfo = inputVector[0]->GetInformationObject(0);
  vtkDataSet* input = vtkDataSet::SafeDownCast(inInfo->Get(vtkDataObject::DATA_OBJECT()));

  output->ShallowCopy(input);

  vtkDataArray* inputArray = this->GetInputArrayToProcess(0, inputVector);
  vtkInformation* info = this->GetInputArrayInformation(0);
  int fieldAssociation = vtkDataObject::FIELD_ASSOCIATION_POINTS;
  if (info && info->Has(vtkDataObject::FIELD_ASSOCIATION()))
  {
    fieldAssociation = info->Get(vtkDataObject::FIELD_ASSOCIATION());
  }

  if (!inputArray)
  {
    vtkErrorMacro(<< "No data to extract");
    return 0;
  }

  if (this->InputArrayComponents.size() == 0)
  {
    return 1;
  }

  std::set<int>::const_iterator it = this->InputArrayComponents.begin();
  for (; it != this->InputArrayComponents.end(); ++it)
  {
    if (*it >= inputArray->GetNumberOfComponents() || *it < 0)
    {
      vtkErrorMacro(<< "Invalid component");
      return 0;
    }
  }

  if (!this->OutputArrayName)
  {
    vtkErrorMacro(<< "No output array name");
    return 0;
  }

  vtkSmartPointer<vtkDataArray> outputArray = inputArray->NewInstance();
  outputArray->SetName(this->OutputArrayName);
  outputArray->SetNumberOfComponents(this->InputArrayComponents.size());
  outputArray->SetNumberOfTuples(inputArray->GetNumberOfTuples());
  outputArray->CopyInformation(input->GetInformation());

  it = this->InputArrayComponents.begin();
  for (int i = 0; it != this->InputArrayComponents.end(); ++it, i++)
  {
    outputArray->CopyComponent(i, inputArray, *it);
    outputArray->SetComponentName(i, inputArray->GetComponentName(*it));
  }

  if (fieldAssociation == vtkDataObject::FIELD_ASSOCIATION_POINTS)
  {
    output->GetPointData()->AddArray(outputArray);
  }
  else if (fieldAssociation == vtkDataObject::FIELD_ASSOCIATION_CELLS)
  {
    output->GetCellData()->AddArray(outputArray);
  }
  else if (fieldAssociation == vtkDataObject::FIELD_ASSOCIATION_NONE)
  {
    output->GetFieldData()->AddArray(outputArray);
  }

  return 1;
}

//----------------------------------------------------------------------------
void vtkExtractComponents::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);

  os << indent << "InputArrayComponents: ";
  std::set<int>::iterator it;
  for (it = this->InputArrayComponents.begin(); it != this->InputArrayComponents.end(); ++it)
  {
    os << *it << " ";
  }
  os << std::endl;

  os << indent << "OutputArrayName: " << this->OutputArrayName << endl;
}

//----------------------------------------------------------------------------
void vtkExtractComponents::AddComponent(int component)
{
  this->InputArrayComponents.insert(component);
  this->Modified();
}

//----------------------------------------------------------------------------
void vtkExtractComponents::ClearComponents()
{
  this->InputArrayComponents.clear();
  this->Modified();
}
