#ifndef __Plot_command__
#define __Plot_command__

#include <File.h>
 
#include <Zmaster_extension.h>
#include <Graphics_object.h>
#include <Plot_xy.h>

Z_START_NAMESPACE;

class XY_PLOT;
class PLOT_XY_ACTOR;

ZCLASS2 PLOT_COMMAND : public ZMASTER_EXTENSION , public GRAPHICS_OBJECT 
{
  public :
    XY_PLOT* its_xy_plotter; 
    PLOT_XY_ACTOR *its_xy_actor;

    PLOT_COMMAND() : ZMASTER_EXTENSION() , GRAPHICS_OBJECT() { } 
    virtual void initialize(GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app);
    virtual ~PLOT_COMMAND(); 
    bool do_command(STRING);

    virtual void read(ASCII_FILE&);
    virtual bool write(Zofstream& out);
    virtual bool do_click(int track, GRAPHICS_POINT& click, GRAPHICS_OBJECT* target); 

    ZP_FATAL_ERROR* acess(STRING &name, ZP_STACK &stack, bool resolv);
};
Z_END_NAMESPACE;

#endif
