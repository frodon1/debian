//Norbert Germain
//Johann Rannou

// Implementation of  arc-length solvers (Lorentz, Crisfield, etc)
//

// Good references :

// On the arc-length and other quadratic control methods: Established, less known and new implementation procedure, 
// Ritto-Correa M. and Camotim, D. 
// Computers and Structures 2008

// A new path-following constraint for strain-softening finite element simulations,
// Lorentz, E. and Badel, P.
// International Journal for Numerical Methods in Engineering 2004

//
// The compute methods are the implementations of the constraint equations. The methods "compute" send back a "resu" ARRAY that contains possible values for the load increment lambda.
// Some of the methods have different constraint equation for prediction and correction. 
// Some have the same. For all type of solvers, there is however a compute_for_predictor and a compute_for_corrector methods that can call the same compute method.
//
// In this implementation, Um stands for the change in U  to correct the linearized error for a constant value of lambda
//                         Up stands for the variation of U with lambda, keeping the linearized error unchanged 
//                         U0 stands for the current displacement increment
// What is given to the compute methods is Up_tot and Um_tot. This corresponds to the global vectors. 
// Depending on the "choice" method selected, riks_choice->recuperation gives a projection of U_m U_p on a restricted set of nodes. 
//


#ifndef __NG_RIKS_CRITERION__
#define __NG_RIKS_CRITERION__

#include <Clock.h>
#include <Contact.h>
#include <Dimension.h>
#include <Error_messager.h>
#include <Function.h>
#include <Global_matrix.h>
#include <Integration_result.h>
#include <Mechanical_algorithm.h>
#include <Arc_length.h>
#include <Mesh.h>
#include <Zminmax.h>
#include <Node.h>
#include <Output.h>
#include <Problem.h>
#include <Random_distribution.h>
#include <Sequence.h>
#include <Dof_setter.h>
#include <Discrete_timer.h>
#include <Output.h>
#include <Random_distribution.h>
#include <Extra_restart.h>
#include <Behavior.h>
#include <Rotation.h>
#include <Boundary_condition.h>
#include <Relationship.h>
#include <Extra_restart.h>
#include <NNset.h>
#include <Array.h>

Z_START_NAMESPACE;

class RIKS_CHOICE;
class RIKS_TEST;
class RIKS_DECIDE;
class MECHANICAL_RIKS_V5;

// 
// NG - 01/2004 - Implementation of a general class for riks criterion
//

//
//General class
//
class RIKS_CRITERION
{
  protected :
    VECTOR U_pred_tot,U0_pred_tot;
    VECTOR prev_incr_tot;
    double lambda_pred;
    bool first_time_save;
    RIKS_CHOICE* riks_choice; 
    RIKS_TEST* riks_test;
    RIKS_DECIDE* riks_decide;

  public :
    bool Is_parallel;
    int _type;

  public :
    RIKS_CRITERION();
    virtual ~RIKS_CRITERION();

    virtual void read_data(ASCII_FILE&,PROBLEM*);
    virtual void init(MESH&,VECTOR&,double&,ARRAY<double>&) = 0;

    virtual bool compute_for_predictor(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&) = 0;
    virtual bool compute_for_corrector(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&) = 0;
    virtual bool compute(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&) = 0;

    virtual ARRAY<double> choose_lambda_compute(MESH&,VECTOR&,VECTOR&,VECTOR&,ARRAY<double>&);
    virtual ARRAY<double> choose_lambda_init(MESH&,VECTOR&,ARRAY<double>&);

    virtual void save_U0(VECTOR&,double&);
    virtual bool test_in(int&);
    virtual int can_parallel_computations();
    void info(RIKS_CHOICE*,RIKS_TEST*,RIKS_DECIDE*);
};

//
//A reimplementation of the  old version of riks
//

class RIKS_CRITERION_ABAQUS : public RIKS_CRITERION
{
  protected :
    double psi2,Dl;
    bool init_pos,met,psi2_give;
    double psi2_val;

  public :
    RIKS_CRITERION_ABAQUS();

    virtual void read_data(ASCII_FILE&,PROBLEM*);
    virtual void init(MESH&,VECTOR&,double&,ARRAY<double>&);

    virtual bool compute_for_predictor(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_corrector(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
};

//
//Cylindrical constraint equation such as proposed by Crisfield. psi is 0.
//

class RIKS_CYLINDRICAL_CONSTRAINT : public RIKS_CRITERION
{
  public :
    RIKS_CYLINDRICAL_CONSTRAINT();

    virtual void init(MESH&,VECTOR&,double&,ARRAY<double>&);

    virtual bool compute_for_predictor(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_corrector(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual int can_parallel_computations();
};

//
//Also Cylindrical constraint equation such as proposed by Crisfield. psi is 0.
//
                                                    
class RIKS_CRITERION_DPTDP : public RIKS_CRITERION
{
  public :
    RIKS_CRITERION_DPTDP();

    virtual void init(MESH&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_predictor(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_corrector(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual int can_parallel_computations();
};

//JR
//
//Crisfield method U_{c-1}.U_c=L^2
//Only one value of lambda is computed
//
                                                    
class RIKS_CRITERION_DPTDP0 : public RIKS_CRITERION
{
  public :
    RIKS_CRITERION_DPTDP0();

    virtual void init(MESH&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_predictor(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_corrector(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual int can_parallel_computations();
};

//
//Simplified Lorentz method (see ref Lorentz 2004)
//

class RIKS_CRITERION_DPTDP0_DEF : public RIKS_CRITERION
{
  public :
    bool first_time;
    double first_L;
    double dinf,dsup;
    ARRAY<bool> truc;
    int dim;
    STRING elset_name;
    LIST<STRING> grad_names;
    VECTOR user_eto00;

  public :
    RIKS_CRITERION_DPTDP0_DEF();

    virtual void read_data(ASCII_FILE&,PROBLEM*);
    virtual void init(MESH&,VECTOR&,double&,ARRAY<double>&);

    virtual bool compute_for_predictor(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_corrector(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute1(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual int can_parallel_computations();
};

//JR
//
//Simplified Lorentz method for large transformations
//                                            
class RIKS_CRITERION_DPTDP0_GD_DEF : public RIKS_CRITERION
{
  public :
    bool first_time;
    double first_L;
    double dinf,dsup;
    ARRAY<bool> truc;
    int dim;

  public :
    RIKS_CRITERION_DPTDP0_GD_DEF();

    virtual void read_data(ASCII_FILE&,PROBLEM*);
    virtual void init(MESH&,VECTOR&,double&,ARRAY<double>&);

    virtual bool compute_for_predictor(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_corrector(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute1(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual int can_parallel_computations();
};

//JR
//
//Riks method : epsilon_c=L^2
//
                                                     
class RIKS_CRITERION_DPTDP_DEF : public RIKS_CRITERION
{
  public :
    RIKS_CRITERION_DPTDP_DEF();

    virtual void init(MESH&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_predictor(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_corrector(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool test_in(int&);
    virtual int can_parallel_computations();
};

//
//Spherical constraint equation. The surface constraint is nt centred on the last equilibrium point. 
// The center position is parameterised with a parameter alpha (See ref. Ritto and Camotim 2008, par. 4.3) 
//
                                                     
class RIKS_CRITERION_SPHERICAL : public RIKS_CRITERION
{
  protected :
  double psi2,Dl,L_corrector;
  bool init_pos,met,psi2_give;
  double psi2_val;
  bool in_predictor_stage;
  double lambda_x;
  VECTOR Ux;
  double Lx;
  int iteration;
  double alpha;

  public :
    RIKS_CRITERION_SPHERICAL();

    virtual void read_data(ASCII_FILE&,PROBLEM*);
    virtual void init(MESH&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_predictor(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute_for_corrector(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
    virtual bool compute(MESH&,VECTOR&,VECTOR&,double&,ARRAY<double>&);
};

Z_END_NAMESPACE;

#endif
