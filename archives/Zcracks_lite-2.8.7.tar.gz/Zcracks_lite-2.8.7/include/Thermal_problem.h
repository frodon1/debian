#ifndef __PROBLEM_THERMAL__
#define __PROBLEM_THERMAL__

#include <Thermal_algorithm.h>
#include <Integration_result.h>

#include <Std_cc_stream.h>

#include <Error_messager.h>
#include <Table.h>
#include <Dof.h>

#include <Algorithm.h>
#include <Boundary_condition.h>
#include <Behavior.h>
#include <Clock.h>
#include <Discrete_timer.h>
#include <Front_matrix.h>
#include <Global_matrix_data.h>
#include <Output_thermal.h>
#include <Random_distribution.h>
#include <Sequence.h>
#include <Thermal_mesh.h>
#include <Print.h>
#include <Verbose.h>
#include <Feti_solver.h>
#include <Parallel_solver.h>
#include <Problem.h>
#include <Problem_includes.h>
#include <Problem_info.h>

Z_START_NAMESPACE;


ZCLASS2 PROBLEM_THERMAL : public PROBLEM { 
   protected :
      SEQUENCE *previous_seq;
      double dTmax;
      int iter_max;
      AUTO_PTR<GLOBAL_MATRIX> K; 
      
      void create_mesh();

   public :  
      VECTOR H_dot;
      double theta;
      PB_TIME_TYPE type;
      
      PROBLEM_THERMAL(PB_TIME_TYPE);
      virtual ~PROBLEM_THERMAL();

      virtual bool Initialize();
      virtual bool verification();
      virtual bool Execute();

      virtual void reset_global_matrix();
      virtual bool make_increment(double);
      virtual int parallelized(void) { return(1); }
      virtual GLOBAL_MATRIX* give_matrix() { return K() ; }
      RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
