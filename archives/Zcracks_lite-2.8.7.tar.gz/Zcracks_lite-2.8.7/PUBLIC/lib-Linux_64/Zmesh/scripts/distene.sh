#!/bin/sh

# D-Lim Shell control script	$Id: distene.sh,v 1.1 2006-09-14 15:04:19 feyel Exp $

DLIM_HOME=`dirname $0`
case "${DLIM_HOME}" in /*) ;; *)
    DLIM_HOME="`/bin/pwd`/${DLIM_HOME}"
;; esac

if [ -z "${DLIM_HOME}" -o ! -d "${DLIM_HOME}" ]
then
    echo "DLIM_HOME not found.  Exiting"
    exit 1
fi

DLIM_ARCH=`${DLIM_HOME}/dlim_arch`

if [ -z "${DLIM_ARCH}" ]
then
    echo "DLIM_ARCH not set.  Exiting"
    exit 1
fi

case "$1" in
    arch)
	echo "${DLIM_ARCH}"
	exit 0
	;;
esac

DLIM_EXE=${DLIM_HOME}/../sbin
#DLIM_EXE=${DLIM_HOME}/license8/machines/${DLIM_ARCH}

if [ ! -d "${DLIM_EXE}" ]
then
    echo "DLIM_ARCH '${DLIM_ARCH}' executable directory not found.  Exiting"
    exit 1
fi

optn="-n"
optc="\c"
case "`echo $optn \"x$optc\"`" in
    "$optn x") optn="";;
esac
case "`echo $optn \"x$optc\"`" in "x" ) ;; *)
	optc=""
;; esac

get_info() {
    ques="$1"
    case "$2" in "") ;; *)
	    ques="${ques} [default: $2]"
    ;; esac	
    echo>&2 $optn "$ques ? $optc"
    read answer
    echo "${answer:-$2}"
}

run_program() {
    PROGRAM=$1
    shift
    if [ ! -x "${DLIM_EXE}/${PROGRAM}" ]
    then
	echo "DLim executable '${PROGRAM}' not found.  Exiting"
	exit 1
    fi
    ${DLIM_EXE}/${PROGRAM} ${1:+"$@"}
}

case "$1" in
    arch)
	echo "${DLIM_ARCH}"
	;;
    info)
	run_program dlim8_get_info
	;;
    server-info)
	run_program dlim8_get_info | sed -e '/</ s/^/server:	/'
	echo "server port:	`get_info \"Server port\" 29029`"
	;;
    client-info)
	run_program dlim8_get_info | sed -e '/ID/d;/</ s/^/client:	/'
	;;
    build-info)
	echo>&2 "*** Warning: Must be run on machine that will be used as server ***" 
	echo "### DLim request file ###" > request
	echo "" >> request
	echo "	-company \"`get_info \"Company name\"`\"" >> request
	echo "	-customer \"`get_info \"Customer name\"`\"" >> request
	echo "" >> request
	run_program dlim8_get_info 2>&1 | sed -ne '/</ s/^/main server:	/p' >> request

	echo "=== If you do not know the answer to a question below, use the default answer ==="
	echo "main server port:	`get_info \"Server port\" 29029`" >> request

	# La plupart des Unix:
	IFCONFIG=`(ifconfig -a || /sbin/ifconfig -a || /usr/etc/ifconfig -a) 2>&1`
	case "${IFCONFIG}" in *cast*) ;; *)
		# HP:
		IFCONFIG=`/usr/sbin/ifconfig lan0 2>&1`
	;; esac
	case "${IFCONFIG}" in
	    "")	adddef="192.168.0.*"
		netdef="192.168.0.*"
		masdef="255.255.255.*"
		nbdef=0
		;;
	    *)	IFCONFIG="`echo \"${IFCONFIG}\" |
		sed -ne '
			: loop
			s/ff/255./g
			s/00/0./g
			t loop
			s/[.] / /g
			s/ 0x/ /g
			s/.*inet addr:\([0-9.]*\) * Bcast:\([0-9.]*\) * Mask:\([0-9.]*\).*/adddef="\1" netdef="\2" masdef="\3"/p
			s/.*inet \([0-9.]*\) * netmask \([0-9.a-f]*\) * broadcast \([0-9.]*\).*/adddef="\1" netdef="\3" masdef="\2"/p
			'`"
		echo "$IFCONFIG" | sed -e 's/"//g; s/adddef=/IP:/g; s/netdef=/net:/g; s/masdef=/mask:/g; s/^/ifconfig: /' >> request
		;;
	esac
	case "${IFCONFIG}" in
	    "")	nbdef=0 ;;
	    * ) nbdef="`echo \"${IFCONFIG}\" | wc -l`" ;;
	esac

	nb_nets="`get_info \"How many client subnets do you have (given by addr & mask)\" ${nbdef}`"
	if [ ${nb_nets} -gt 0 ]; then
	    echo "" >> request
	    i=0
	    while [ $i -lt ${nb_nets} ]; do
		i=`expr $i + 1`
		eval "`echo \"${IFCONFIG}\" | head -$i | tail -1`"
		addr="`get_info \"Net #$i address\" $netdef`"
		mask="`get_info \"Net #$i mask\" $masdef`"
		echo "	-net2 $addr $mask" >> request
	    done
	fi
	nb_clients="`get_info \"How many client machines do you have (given by addr only)\" ${nbdef}`"
	if [ ${nb_clients} -gt 0 ]; then
	    echo "" >> request
	    i=0
	    while [ $i -lt ${nb_clients} ]; do
		i=`expr $i + 1`
		addr="`get_info \"Client #$i address\" $adddef`"
		echo "	-net1 $addr" >> request
	    done
	fi
	echo "" >> request
	echo>&2 "To get a license key, send the file 'request' to support@distene.com"
	;;
    start)
	cd `dirname $0`
	run_program dlimd8
	sleep 1
	tail `ls -tr dlimd8-log-*.txt`
	;;
    stop)
	cd `dirname $0`
	for host in `grep dlimd dlim8.key | cut -d ' ' -f 3`
	do
	  run_program dlimd8_stop dlim8.key $host
	done
	;;
    status)
	cd `dirname $0`
	shift
	case "x$1x" in
	    xx) run_program dlimd8_status dlim8.key ;;
	    * ) run_program dlimd8_status "$@" ;;
	esac
	;;
    report)
	cd `dirname $0`
	shift
	case "x$1x" in
	    xx) run_program dlimd8_report `ls -t dlimd8-log-*.txt 2>/dev/null | head -1` ;;
	    * ) run_program dlimd8_report "$@" ;;
	esac
	;;
    *)
	echo "Usage: $0 [ arch | server-info | client-info | build-info | start | stop | status | report ]"
	echo "       $0 report dlimd8-log-xyz.txt [-users] [-plot]"
	;;
esac
