#ifndef __TERMINATE_HANDLER__
#define __TERMINATE_HANDLER__

#include <Bool.h>
#include <Handler_mp.h>
#include <Server.h>

Z_START_NAMESPACE;

#define Z_TERMINATE 1010

ZCLASS TERMINATE_HANDLER : public HANDLER_MP
{
  protected :
    int how_many;

  public :
    TERMINATE_HANDLER() : HANDLER_MP() { how_many=0; }
   ~TERMINATE_HANDLER(void) { }

    DECLARE_HANDLER;
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
