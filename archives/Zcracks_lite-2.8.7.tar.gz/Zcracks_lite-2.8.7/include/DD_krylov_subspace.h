//
// Gosselet 2004, Generic iterative solvers (mostly used with generic_dd)
// see P. Gosselet thesis (2003), nice paper soon
//
// A class to store a basis of Krylov subspace
// with incorporated orthogonalization methods (variations around Gramm-Schmidt)
//
#ifndef __DD_KRYLOV_SUBSPACE__
#define __DD_KRYLOV_SUBSPACE__

#include <Buffered_list.h>
#include <Z_object.h>
#include <Zstream.h>

Z_START_NAMESPACE;
class DD_VECTOR;
class DD_MATRIX;
class DD_SUB_DOMAIN;
class DD_KRYLOV_ITERATIVE_SOLVER_PARAMETER;
class DD_KRYLOV_SUBSPACE : public Z_OBJECT {
protected:
  DD_SUB_DOMAIN *domain;
public:
  bool is_euclid;
  DD_KRYLOV_ITERATIVE_SOLVER_PARAMETER *parameters;
  bool normalized;
  DD_KRYLOV_SUBSPACE() {
    normalized=TRUE;
    parameters=NULL;
    is_euclid=TRUE;
  }
  virtual ~DD_KRYLOV_SUBSPACE() { }

  virtual void initialize (bool , DD_SUB_DOMAIN *dd,DD_KRYLOV_ITERATIVE_SOLVER_PARAMETER* pa, bool norma=TRUE , bool extra_space=FALSE ) ;
  virtual int size() const=0;
  virtual int extra_size() const {
    return ( 0 );
  }
  virtual void compact ( int ) { }
//
  virtual DD_VECTOR operator[] ( int ) =0;
//
  virtual void addR ( DD_VECTOR& ) =0;
  virtual void add ( DD_VECTOR& ) =0;
  virtual void add ( DD_VECTOR &v, DD_VECTOR& /* Av */ ) ;
  virtual void add ( DD_VECTOR &v,DD_VECTOR& /* Av */,double ) ;
//
  virtual void orthogonalize ( DD_VECTOR&,VECTOR& ) const=0;
//  virtual void orthogonalize ( DD_VECTOR&,DD_VECTOR&,VECTOR& ) const=0;
//
  virtual DD_VECTOR operator* ( const VECTOR& ) const=0;
  virtual VECTOR operator| ( const DD_VECTOR& ) const=0;
  virtual VECTOR operator|| ( const DD_VECTOR & ) const=0;
//
  void copy ( const DD_KRYLOV_SUBSPACE* );
  RTTI_INFO;
};


//
//
//

class DD_GS_KSS : public DD_KRYLOV_SUBSPACE {
protected:
  DD_MATRIX subspace;
  DD_MATRIX* Asubspace;
  LIST<double> normsubspace;
  LIST<DD_VECTOR*> Rsubspace;
//

public:
  DD_GS_KSS() : DD_KRYLOV_SUBSPACE() { Asubspace=NULL; }
  virtual ~DD_GS_KSS() ;

  virtual void initialize (bool, DD_SUB_DOMAIN *dd,  DD_KRYLOV_ITERATIVE_SOLVER_PARAMETER* pa,  bool norma=TRUE ,  bool extra_space=FALSE );

  virtual void orthogonalize ( DD_VECTOR&,VECTOR& ) const;
//  virtual void orthogonalize ( DD_VECTOR&,DD_VECTOR&,VECTOR& ) const;

  virtual void addR ( DD_VECTOR  &v ) ;
  virtual void add ( DD_VECTOR &v ) ;
  virtual void add ( DD_VECTOR &v,DD_VECTOR &Av ) ;
  virtual void add ( DD_VECTOR &v,DD_VECTOR &Av, double  vAv  );

  virtual int size() const ;
  void copy ( const DD_GS_KSS* );
//
  virtual DD_VECTOR operator[] ( int /* i */ )  ;
  virtual DD_VECTOR operator* ( const VECTOR &in ) const ;
  virtual VECTOR operator| ( const DD_VECTOR&v ) const ;
  virtual VECTOR operator|| ( const DD_VECTOR&v ) const ;

  RTTI_INFO;
};

class DD_GS_KSS2 : public DD_KRYLOV_SUBSPACE {
protected:
  BUFF_LIST<DD_VECTOR* > subspace,*Asubspace,*Rsubspace;
  BUFF_LIST<double> normes;
public:
  DD_GS_KSS2() : DD_KRYLOV_SUBSPACE() {
    Rsubspace=Asubspace=NULL;
  }
  virtual ~DD_GS_KSS2() ;
  void copy ( const DD_GS_KSS2* );

  virtual void initialize (bool,  DD_SUB_DOMAIN *dd,  DD_KRYLOV_ITERATIVE_SOLVER_PARAMETER* pa,  bool norma=TRUE ,  bool extra_space=FALSE ) ;
  virtual int size() const ;
  virtual int extra_size() const ;

  virtual void orthogonalize ( DD_VECTOR&,VECTOR& ) const;
  virtual void addR ( DD_VECTOR &v ) ;
  virtual void add ( DD_VECTOR &v ) ;
  virtual void add ( DD_VECTOR &v,DD_VECTOR &w ) ;
  virtual void add ( DD_VECTOR &v,DD_VECTOR &w, double wAw ) ;
//
  virtual DD_VECTOR operator[] ( int i )  ;
  virtual DD_VECTOR operator* ( const VECTOR &in ) const ;
  virtual VECTOR operator| ( const DD_VECTOR& in ) const; 
  virtual VECTOR operator|| ( const DD_VECTOR& in ) const ;
  virtual void operator= ( const DD_GS_KSS2 toto ) ;
//
  RTTI_INFO;
};

class DD_MGS_KSS : public DD_KRYLOV_SUBSPACE {
protected:
  BUFF_LIST<DD_VECTOR* > subspace,*Asubspace,*Rsubspace;
  BUFF_LIST<double> normes;
public:
  DD_MGS_KSS() : DD_KRYLOV_SUBSPACE() {
    Rsubspace=Asubspace=NULL;
  }
  virtual ~DD_MGS_KSS() ;
  void copy ( const DD_MGS_KSS* );

  virtual void initialize (bool,  DD_SUB_DOMAIN *dd,  DD_KRYLOV_ITERATIVE_SOLVER_PARAMETER* pa,  bool norma=TRUE ,  bool extra_space=FALSE ) ;
  virtual int size() const ;
  virtual int extra_size() const ;

  virtual void compact ( int );
  virtual void orthogonalize ( DD_VECTOR&,VECTOR& ) const;
//  virtual void orthogonalize ( DD_VECTOR&,DD_VECTOR&,VECTOR& ) const;
  virtual void addR ( DD_VECTOR &v ) ;
  virtual void add ( DD_VECTOR &v ) ;
  virtual void add ( DD_VECTOR &v,DD_VECTOR &w ) ;
  virtual void add ( DD_VECTOR &v,DD_VECTOR &w, double wAw ) ;
//
  virtual DD_VECTOR operator[] ( int i )  ;
  virtual DD_VECTOR operator* ( const VECTOR &in ) const ;
  virtual VECTOR operator| ( const DD_VECTOR& in ) const; 
  virtual VECTOR operator|| ( const DD_VECTOR& in ) const ;
  virtual void operator= ( const DD_MGS_KSS toto ) ;
//
  RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
