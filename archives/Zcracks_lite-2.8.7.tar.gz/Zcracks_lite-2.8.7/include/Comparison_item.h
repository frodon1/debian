#ifndef __Comparison_item__
#define __Comparison_item__

#include <Stringpp.h>

Z_START_NAMESPACE;

class COMPARISON_ITEM {
  public :
    bool   active;
    double weight;
    STRING name,type;
    STRING xcol,ycol;
    STRING sim_name,exp_name;

    COMPARISON_ITEM();
   ~COMPARISON_ITEM();
   
    bool write(Zofstream& out);
    bool read(ASCII_FILE&);
};
Z_END_NAMESPACE;

#endif
