#ifndef __ZP_COEFFICIENT__
#define __ZP_COEFFICIENT__

#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>
#include <Coefficient.h>

Z_START_NAMESPACE;

ZCLASS ZP_COEFF : public ZP_BASIC_TYPE< COEFF >
{
  protected :
    ZP_FATAL_ERROR* par(ZP_STACK&,int);
    ZP_FATAL_ERROR* compute_value(ZP_STACK&,int);
    ZP_FATAL_ERROR* read(ZP_STACK&,int);
    ZP_FATAL_ERROR* get_parameter_tabular_definition(ZP_STACK&,int);
    ZP_FATAL_ERROR* get_name(ZP_STACK&,int);
    virtual void type_init(char*) { type="COEFF"; }

  public :
    BASIC_CONSTRUCTORS(ZP_COEFF,COEFF)

    METHOD_DECLARATION_START
      METHOD("()",par,0)
      METHOD("compute_value",compute_value,0)
      METHOD("read",read,2)
      METHOD("get_parameter_tabular_definition",get_parameter_tabular_definition,1)
      METHOD("get_name",get_name,0)
    METHOD_DECLARATION_ANCESTOR(ZP_BASIC_TYPE< COEFF >)

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);

    ZPO_RTTI_INFO(COEFF)
};

ZCLASS ZP_READ_COEFFICIENT : public ZP_OBJECT
{
  protected :
    ZP_FATAL_ERROR* par(ZP_STACK& stack,int);

    virtual void type_init(char*) { }

  public :
    ZP_READ_COEFFICIENT() : ZP_OBJECT() { type="read_coefficients"; }
    virtual ~ZP_READ_COEFFICIENT() { }

   METHOD_DECLARATION_START
     METHOD("()",par,2)
   METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)
};

Z_END_NAMESPACE;

#endif
