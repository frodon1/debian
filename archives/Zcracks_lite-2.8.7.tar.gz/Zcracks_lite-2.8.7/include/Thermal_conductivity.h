#ifndef __Thermal_conductivity__
#define __Thermal_conductivity__

#include <Coefficient.h>
#include <Material_piece.h>

Z_START_NAMESPACE;

class MAT_DATA; class ASCII_FILE;

ZCLASS2 THERMAL_CONDUCTIVITY : public MATERIAL_PIECE {
   public :
     THERMAL_CONDUCTIVITY();
     virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*); 
     virtual ~THERMAL_CONDUCTIVITY(); 
     virtual SMATRIX compute_k()=0;
     virtual SMATRIX compute_dk(const STRING&)=0;
     virtual void set_parameters()=0;
     static THERMAL_CONDUCTIVITY* read(ASCII_FILE&,MATERIAL_PIECE*);
     RTTI_INFO;
};

class ANISOTROPIC_THERMAL_CONDUCTIVITY : public THERMAL_CONDUCTIVITY { 
protected :
  COEFF K1, K2, K3; 
public : 
  ANISOTROPIC_THERMAL_CONDUCTIVITY();
  virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*); 
  virtual void set_parameters();
  SMATRIX compute_k(); 
  SMATRIX compute_dk(const STRING&);  
}; 

  Z_END_NAMESPACE;

#endif
