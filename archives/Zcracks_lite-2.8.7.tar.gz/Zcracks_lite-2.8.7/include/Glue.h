#ifndef __GLUE__
#define __GLUE__

#include <Bool.h>
#include <Base_problem.h>
#include <Stringpp.h>
#include <Task_result.h>
#include <Parallel_ut_info.h>
#include <Zstream.h>

Z_START_NAMESPACE;

ZCLASS2 GLUE : public BASE_PROBLEM {
  private :
    STRING    glue_name; 
    bool      post,ctnod;
    TASK_RESULT *tr;
    Zofstream node_file,integ_file;
    LIST<int> cards_id;
    STRING mesh_type;
    STRING matrix_storage;

    void build_global_ut_file(PARALLEL_UT_INFO&);

  public :
    GLUE(void);
    virtual  ~GLUE(void) { }
    virtual void load(const STRING&,const STRING&);
    virtual bool Execute(void);
    virtual int  parallelized(void) { return(1); }
};

Z_END_NAMESPACE;

#endif
