#ifndef __LINK_REQUEST__
#define __LINK_REQUEST__

#include <Defines.h>

Z_START_NAMESPACE;

ZCLASS LINK_REQUEST
{
  public :
    enum MODIFIERS { NONE=0, MANDATORY=1 };
    MODIFIERS flags;
    STRING name,name_space;
    LIST< AUTO_PTR<ZP_PIECE> > *procs;
    bool *b;

    LINK_REQUEST() { flags=NONE; b=NULL; }
    virtual ~LINK_REQUEST() { }
};

ZCLASS STATIC_LINK_REQUEST
{
  public :
    enum MODIFIERS { NONE=0, MANDATORY=1 };
    MODIFIERS flags;
    STRING name,name_space;
    AUTO_PTR<ZP_OBJECT> *target;
    bool *b;

    STATIC_LINK_REQUEST() { flags=NONE; target=NULL; }
    virtual ~STATIC_LINK_REQUEST() { }
};

Z_END_NAMESPACE;

#endif
