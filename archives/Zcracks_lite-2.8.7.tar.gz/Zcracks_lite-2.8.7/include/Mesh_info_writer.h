#ifndef __MESH_INFO__
#define __MESH_INFO__

#include <List.h>
#include <Stringpp.h>
#include <Mesh.h>

Z_START_NAMESPACE;

class GEOMETRY_INFO;

ZCLASS2 MESH_INFO_WRITER
{
  public :
    MESH_INFO_WRITER();
    virtual ~MESH_INFO_WRITER();
    void write(STRING &geof, LIST<STRING> &elset_name, LIST<STRING> &elset_type, LIST<GEOMETRY_INFO*> &gi, MESH &mesh, int ipc);

};
Z_END_NAMESPACE;

#endif
