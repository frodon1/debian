#ifndef __ZP_BOUNDARYSET__
#define __ZP_BOUNDARYSET__

#include <ZP_stack.h>
#include <Set.h>
#include <ZP_object.h>
#include <ZP_type.h>

#include <ZP_int.h>
#include <ZP_double.h>
#include <ZP_stack.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_BOUNDARYSET : public ZP_TYPE< BOUNDARYSET >
{
  protected :
    virtual ZP_FATAL_ERROR* print(ZP_STACK&) { return(NULL); }

    ZP_FATAL_ERROR* assign(ZP_STACK&,int);
    void type_init(char*) { type="BOUNDARYSET"; }

    ZP_FATAL_ERROR* bracket(ZP_STACK&,int);
    ZP_FATAL_ERROR* size(ZP_STACK&,int);

  public :
    CONSTRUCTORS(ZP_BOUNDARYSET,BOUNDARYSET);

    METHOD_DECLARATION_START
      METHOD("[]",bracket,1)
      METHOD("!",size,0)
      METHOD("size",size,0)
    METHOD_DECLARATION_ANCESTOR(ZP_TYPE< BOUNDARYSET >)

    ZPO_RTTI_INFO(BOUNDARYSET)
};
Z_END_NAMESPACE;

#endif
