//
// Gosselet 2004, Generic domain decomposition method
// see P. Gosselet, C. Rey "Non-overlapping domain decomposition methods in structural mechanics",
//     Archives of computational methods in engineering. Vol 13 (4). Pages 515-572. 2007.
//
// Key class of generic domain decomposition method, inherits from GLOBAL_MATRIX and redefines solve()
//

#ifndef __DD_FULL_FETI__
#define __DD_FULL_FETI__

#include <Global_matrix.h>
#include <Solver_parameter.h>
#include <DD_krylov_solver.h>

#include <DD_local_schur.h>
#include <DD_scaling.h>
#include <DD_projector.h>
#include <DD_augmentation.h>

#include <Zstream.h>
#include <File.h>
#include <Output.h>

Z_START_NAMESPACE;


class GLOBAL_MATRIX;
class VECTOR;
class OUTPUT;
class ASCII_FILE;
class DD_SUB_DOMAIN;
class MESH;
class PROBLEM;
class DD_VECTOR;
class DD_MATRIX;

ZCLASS2 DD_FULL_FETI_PARAMETER :
public SOLVER_PARAMETER {
public :
  STRING precond_type;
  STRING scaling_type;
  STRING natural_projector_schur_type;
  STRING natural_projector_scaling_type;
  STRING force_splitting_type;
  STRING type_of_dd;
  STRING solver_config;
//
  bool detect_redundancy,precond_dsr;
  double eps_redund;

  STRING type_of_local_op;
  SOLVER_PARAMETER *local_op_parameter;

  STRING type_of_iterative_solver;
  SOLVER_PARAMETER *iterative_solver_parameter;

  DD_FULL_FETI_PARAMETER();
  virtual ~DD_FULL_FETI_PARAMETER() {
    if ( local_op_parameter ) delete ( local_op_parameter );
    if ( iterative_solver_parameter ) delete ( iterative_solver_parameter );
  }

  virtual bool GetResponse ( STRING&,ASCII_FILE& );
  RTTI_INFO;

};

ZCLASS2 DD_FULL_FETI :
public GLOBAL_MATRIX {
protected :
  GLOBAL_MATRIX *local_op;
  DD_FULL_FETI_PARAMETER *parameters;
  DD_ITERATIVE_SOLVER  *its_solver;
  DD_SUB_DOMAIN *domain;
  //
  DD_VECTOR last_criterion;
  double norm_fext;
  int dd_solver_timer;

  DD_LOCAL_SCHUR *schur_1,*schur_2,*natural_projector_schur;
  DD_OPERATOR_COMPOSITE *scaled_schur_2,*natural_projector_scaled_schur;
  DD_SCALING *scaling,*natural_projector_scaling;
  DD_MATRIX *G1,*Gaug;

  VECTOR *stored_force;
  DD_VECTOR *reaction, *equilibrated_reaction;

  virtual void initialize_defaults_parameters() {}
//    virtual double compute_ratio(const DD_VECTOR& a);
//    virtual double compute_ratio_factor() const{return(norm_fext);}
  virtual double compute_ratio ( const DD_VECTOR& a );
  virtual double compute_ratio_factor() const {
    return ( norm_fext );
  }
  virtual GLOBAL_MATRIX* copy_type ( MESH &mesh ) {
    DD_FULL_FETI *ret=new DD_FULL_FETI();
    ret->associated_mesh=&mesh;
    return ( ret );
  }

  void assign_dof_kind();
  void assign_constraint_block_dof();

  DD_OPERATOR_COMPOSITE *opera,*preco;

  double global_norm ( const VECTOR& ) const;

//    void compute_complement(DD_MATRIX&)const;

public :
  DD_PROJECTOR *natural_projector;
  bool do_output;
  DD_FULL_FETI() : GLOBAL_MATRIX() {
    Gaug=NULL;
    G1=NULL;
    schur_1=schur_2=natural_projector_schur=NULL;
   
    dd_solver_timer=-1;
    stored_force=NULL;
    reaction=NULL;
    opera=preco=scaled_schur_2=natural_projector_scaled_schur=NULL;
    do_output=FALSE;
  }
  virtual ~DD_FULL_FETI();

  DD_SUB_DOMAIN* give_domain ( ) {
    return domain;
  }
  virtual DD_OPERATOR* give_operator ( STRING what ) {
    if ( what=="operator" || what=="" ) return ( opera );
    else if ( what=="preconditioner" ) return ( preco );
    else if ( what=="projector" ) return ( natural_projector );
    else {
      INTERNAL_ERROR;
      return ( NULL );
    }
  }

  void do_product(DD_VECTOR&, const DD_VECTOR &);
  void do_precond(DD_VECTOR&, const DD_VECTOR &);

  virtual DD_MATRIX* give_augmentation( ) {
    if ( ! Gaug ) Gaug = new DD_MATRIX ( *domain );
    Gaug->assemble();
    return ( Gaug );
  }


  virtual void create ( MESH& mesh,char* name=NULL );
  virtual void set_parameter ( SOLVER_PARAMETER *p ) {
    parameters= ( DD_FULL_FETI_PARAMETER* ) p;
    initialize_defaults_parameters();
  }
  virtual bool solve ( VECTOR& displ,VECTOR& force,int if_compute_inverse, int if_compute_kernel=0 );



  bool is_all_primal();
  bool is_all_dual();
  void build_dof_type_info();

// todo
  virtual bool solve ( ARRAY<VECTOR>& /* displ */, ARRAY<VECTOR>& /* force */, int /* if_compute_inverse */ ) {
    NOT_IMPLEMENTED_ERROR ( "solve()" );
    return ( FALSE );
  }
  void compute_rhs ( VECTOR& /* vout */, const VECTOR& /* vin */ ) const {
    ERROR ( "" );
  }

  Zofstream output;

  friend class N_ITERATIVE_SOLVER_MODIFIER;

// my wrapper is beautiful
  virtual bool can_parallel_computations() const {
    return ( TRUE );
  }
  virtual bool is_symmetric() const {
    return ( local_op->is_symmetric() );
  }
  virtual int  set_flag ( STRING what ) {
    return ( local_op->set_flag ( what ) );
  }
  virtual void read_from ( USE_GM_FSTREAM_TYPE& fichier,int nb_matr=0 ) {
    local_op->read_from ( fichier,nb_matr );
  }
  virtual void write_in ( USE_GM_OFSTREAM_TYPE& fichier ) {
    local_op->write_in ( fichier );
  }
  virtual void store ( const D_ELEMENT& ele,const SMATRIX& mat ) {
    local_op->store ( ele,mat );
  }
  virtual VECTOR operator* ( const VECTOR& v ) const {
    return ( ( *local_op ) *v );
  }
  virtual void partial_times ( ARRAY<int>& index,const VECTOR& q, VECTOR& v ) {
    local_op->partial_times ( index,q,v );
  }
  virtual void addmult ( const GLOBAL_MATRIX& mat1,double d ) {
    local_op->addmult ( mat1,d );
  }
  virtual void assign ( const GLOBAL_MATRIX& mat1 ) {
    local_op->assign ( mat1 );
  }
  virtual void adddiag ( double f ) {
    local_op->adddiag ( f );
  }
  virtual void mult ( double f ) {
    local_op->mult ( f );
  }
  virtual SMATRIX& operator[] ( int i ) {
    return ( ( *local_op ) [i] );
  }
  virtual const SMATRIX& operator[] ( int i ) const {
    return ( ( *local_op ) [i] );
  }
  virtual double& operator() ( int i, int j ) {
    return ( ( *local_op ) ( i,j ) );
  }
  virtual void arvp ( const ARRAY<VECTOR>& vi,ARRAY<VECTOR>& vo ) const {
    local_op->arvp ( vi,vo );
  }
  virtual void normalize_vector ( VECTOR& v ) const {
    local_op->normalize_vector ( v );
  }
  virtual void global_matrix_structure_change ( UPDATE_FLAGS ident_flags ) {
    local_op->global_matrix_structure_change ( ident_flags );
  }
  virtual bool link_to ( GLOBAL_MATRIX *K ) {
    return ( local_op->link_to ( K ) );
  }
  virtual void compute_schur_complement ( ARRAY<DOF*>& /* dof */, MATRIX& ) {
    NOT_IMPLEMENTED_ERROR ( "compute_schur_complement" );
  }
  virtual void compute_flexibility_matrix ( ARRAY<DOF*>& /* dof */, MATRIX&, bool verbose_contact=FALSE ) {
    NOT_IMPLEMENTED_ERROR ( "compute_flexibility_matrix" );
  }
  virtual void zero_matrix() {
    local_op->zero_matrix();
  }
  virtual bool is_determinant_negative() const {
    return ( local_op->is_determinant_negative() );
  }
  virtual GLOBAL_MATRIX_KERNEL* initialize_kernel ( const DD_SUB_DOMAIN &f ) {
    return ( local_op->initialize_kernel ( f ) );
  }
  virtual void enable_keep_rigid() {
    local_op->enable_keep_rigid();
  }
  virtual void initialize_structure() {
    local_op->initialize_structure();
  }
  virtual double matrix_norm ( double order=2. ) const {
    return ( local_op->matrix_norm ( order ) );
  }
  virtual void   print() {
    local_op->print();
  }

  virtual void partial_times_hyper_rom ( int Nb_testing_dof, ARRAY<int>& index, ARRAY<int>& inv_selec, const MATRIX& v, ARRAY<bool>& if_bc, MATRIX& res ) {
    local_op -> partial_times_hyper_rom ( Nb_testing_dof, index, inv_selec, v, if_bc, res );
  }

};
Z_END_NAMESPACE;

#endif
