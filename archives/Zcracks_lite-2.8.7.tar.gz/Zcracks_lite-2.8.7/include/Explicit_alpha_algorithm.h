#ifndef __Explicit_alpha_algorithm__
#define __Explicit_alpha_algorithm__

#include <Mechanical_algorithm.h>
#include <Gauge.h>

#include <Explicit_mesh.h>
#include <Explicit_algorithm.h>
#include <Explicit_initial_conditions.h>

Z_START_NAMESPACE;

class INTEGRATION_RESULT;

ZCLASS2 MECHANICAL_EXPLICIT_ALPHA_ALGORITHM : public MECHANICAL_EXPLICIT_ALGORITHM {
  friend class PROBLEM_EXPLICIT_MECHANICAL;
  protected :

  
  VECTOR A_last,V_last;


  virtual INTEGRATION_RESULT* explicit_substeps(SEQUENCE& seq);


  public :
  MECHANICAL_EXPLICIT_ALPHA_ALGORITHM() ;
  virtual ~MECHANICAL_EXPLICIT_ALPHA_ALGORITHM(){}

};
Z_END_NAMESPACE;

#endif
