#ifndef __PAIR__
#define __PAIR__

Z_START_NAMESPACE;

// FF, oct. 14th 2005 : a pair of something, which defines operator ==

template <class T>
class PAIR : public ARRAY<T>
{
  public :
    PAIR() : ARRAY<T>(2) { }
    PAIR(const T &p1, const T &p2) : ARRAY<T>(2) { (*this)[0]=p1; (*this)[1]=p2; }

    bool operator==(const PAIR &p) const {
      return( ( ((*this)[0]==p[0]) && ((*this)[1]==p[1]) ) ||
              ( ((*this)[0]==p[1]) && ((*this)[1]==p[0]) ) );
    }

    bool same(const PAIR &p) const {
      return( ( ((*this)[0]==p[0]) && ((*this)[1]==p[1]) ));
    }

};
Z_END_NAMESPACE;

#endif
