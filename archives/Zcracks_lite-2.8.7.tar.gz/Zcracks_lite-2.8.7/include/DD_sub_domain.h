#ifndef __DD_SUB_DOMAIN__
#define __DD_SUB_DOMAIN__

#include <G_F_sub_domains.h>
#include <Global_client.h>
#include <Mesh.h>
#include <Utility_relations.h>
#include <Message_passing_exchange.h>
#include <Std_cc_stream.h>

#include <List.h>
#include <Array.h>

#include <DD_multidof.h>
#include <DD_interface.h>
#include <P_mpc.h>

Z_START_NAMESPACE;

#define Z_DOF_INFORMATION           3244
#define Z_INTERFACE_DOF_INFORMATION 6666

ZCLASS2 DD_SUB_DOMAIN : public G_F_SUB_DOMAINS {
  friend class DD_INTERFACE;
  protected :
    BUFF_LIST<DD_INTERFACE*> interfs;
    BUFF_LIST<DD_NODE*> my_dd_nodes;//
    BUFF_LIST<DD_DOF*> my_dd_dofs;//
    ARRAY<DD_DOF*> virtual_master_dofs;
    int interface_dofs_number;
    MESH *the_mesh;

    LIST<DOF*> dofs_to_add; 
    LIST<DOF*> dofs_to_remove; 

    // these two arrays will be deleted after interface creation
    ARRAY<bool> nodes_needed;
    ARRAY<bool> dofs_needed;

    // use in splitted mode for the automatic build of interfaces
    ARRAY<int> skin_ids;

    void assign_interfaces_rank();

  public :
    MP_EXCHANGE exchange;
    GLOBAL_CLIENT glc;
    int global_dof_nb;
    bool do_output;

    DD_DOF::KIND unique_kind;

    ARRAY< BUFF_LIST<int> > dofs; // global dof ranks for all domains
    BUFF_LIST<DD_MULTIDOF*> multi_dofs;
    int my_rank;
    ARRAY<int> rigid_body; // ranks of dofs

    DD_SUB_DOMAIN(UTILITY_MESH &fm, const STRING &pbn,int w,int rcf=1);
    virtual ~DD_SUB_DOMAIN();
    void build_nodes_and_dofs(MESH&);
    void build_interfaces();
    void build_nodal_interfaces(bool got_elset_dof);
    void build_rigid_body(MESH&);
    void take(LIST<P_MPC*>&);
    void update_interfaces_for_mpc();
    void clean_mpc();
    void clean_color(int);
    void clean_color(int c, BUFF_LIST<int>& other_domains);
//    BUFF_LIST<DD_NODE*> my_skin;//

    void dynamic_add_to_interface(int other_domain, NODE &node, int node_grank, ARRAY<int> dof_grank, ARRAY<int> &kind);
    void add_to_interface(int other_domain, NODE &node);
    void remove_from_interface(int other_domain, NODE &node);
    void dynamic_add_dof(DOF*);
    void remove_dof(DOF*);
    void remove_node(NODE*);
    void remove_dd_dof(DD_DOF *ddd){my_dd_dofs.suppress_item(ddd);}
    void remove_dd_node(DD_NODE *ddn){my_dd_nodes.suppress_item(ddn);}
   
    void update_dofs();
    void update_count();
    void prepare_dofs_to_add(LIST<DOF*>&);
    void prepare_dofs_to_remove(LIST<DOF*>&);
    void add_dd_dof(DD_DOF *dd) {my_dd_dofs.add(dd);}
    void add_dd_node(DD_NODE *dd){my_dd_nodes.add(dd);}
    void update_added_interface(LIST<DD_NODE*>,int);
    void update_removed_interface(LIST<DD_NODE*>,int);
 
    int nb_interfaces() const {return(!interfs);}
    int nb_interface_dofs()const {return(interface_dofs_number);}
    int nb_dd_dofs()const{return(!my_dd_dofs);}
    int nb_dd_nodes()const{return(!my_dd_nodes);}
    DD_INTERFACE* dd_interface(int i) const { return(interfs[i]);}
    DD_DOF* give_dd_dof(int i) {return(my_dd_dofs[i]);};
    const DD_DOF* give_dd_dof(int i)const {return(my_dd_dofs[i]);};
    DD_NODE* give_dd_node(int i) {return(my_dd_nodes[i]);}
    const MESH& associated_mesh() const { return(*the_mesh); }

    void fix_interface_dofs(VECTOR*);
    void restore_interface_dofs_bcs();
    void dof_mean(VECTOR&);
    void dof_sum(VECTOR &v,int pdiv=0)const;
    double dof_norm(VECTOR &v, int pdiv=0)const;

    void write_dom_file(STRING name=STRING::EMPTY);
    void write_out(ZOSTREAM&);

    // should be avoided somehow
    int global_gp_nb;
//    void build_skin();
    int n_primal,n_dual,n_mixed,n_recondensed,n_unknown;
};
Z_END_NAMESPACE;

#endif
