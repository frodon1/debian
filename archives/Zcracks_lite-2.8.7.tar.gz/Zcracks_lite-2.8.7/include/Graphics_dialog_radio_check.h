#ifndef GRAPHICS_DIALOG_RADIO_CHECK__
#define GRAPHICS_DIALOG_RADIO_CHECK__

#include <Graphics_dialog_piece.h>

Z_START_NAMESPACE;

// ---------------------------------------- 
//  Check groups 
// ---------------------------------------- 

ZCLASS CHECK_GROUP_APPLICATION_MESSAGE : public APPLICATION_MESSAGE {
  public :
    ARRAY<int> contens;

    CHECK_GROUP_APPLICATION_MESSAGE();
    virtual ~CHECK_GROUP_APPLICATION_MESSAGE() { }

    RTTI_INFO;
};

ZCLASS GRAPHICS_DIALOG_CHECK_GROUP : public GRAPHICS_DIALOG_PIECE {
  public :
    ARRAY<STRING> buttons;
    ARRAY<int> vals;

    GRAPHICS_DIALOG_CHECK_GROUP();
    virtual ~GRAPHICS_DIALOG_CHECK_GROUP() { }

    RTTI_INFO;
};

// ---------------------------------------- 
//  Radio groups 
// ---------------------------------------- 

ZCLASS RADIO_GROUP_APPLICATION_MESSAGE : public APPLICATION_MESSAGE {
  public :
    int contens;

    RADIO_GROUP_APPLICATION_MESSAGE();
    virtual ~RADIO_GROUP_APPLICATION_MESSAGE() { }

    RTTI_INFO;
};

ZCLASS GRAPHICS_DIALOG_RADIO_GROUP : public GRAPHICS_DIALOG_PIECE {
  public :
    ARRAY<STRING> buttons;
    int last_val,def_sel;

    GRAPHICS_DIALOG_RADIO_GROUP();
    virtual ~GRAPHICS_DIALOG_RADIO_GROUP() { }

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
