#ifndef __NG_RIKS_CHOICE__
#define __NG_RIKS_CHOICE__
                                                                                
#include <Object_factory.h>
#include <Clock.h>
#include <Contact.h>
#include <Dimension.h>
#include <Error_messager.h>
#include <Function.h>
#include <Global_matrix.h>
#include <Integration_result.h>
#include <Mechanical_algorithm.h>
#include <Mesh.h>
#include <Zminmax.h>
#include <Node.h>
#include <Output.h>
#include <Problem.h>
#include <Random_distribution.h>
#include <Sequence.h>
#include <Dof_setter.h>
#include <Discrete_timer.h>
#include <Output.h>
#include <NNset.h>

Z_START_NAMESPACE;

class RIKS_CRITERION;
class RIKS_TEST;
class RIKS_DECIDE;

//
// NG 03/2004
//

class RIKS_CHOICE
{
  public :
    bool make;
    VECTOR U_pred_tot,U0_pred_tot;
    bool first_time_save,initialized;
    double lambda_pred;
    LIST<int>  rank;
    RIKS_CRITERION* riks_criterion;
    RIKS_TEST* riks_test;
    RIKS_DECIDE* riks_decide;

    virtual void internal_initialize(MESH&) { }

  public :
    void info(RIKS_CRITERION*,RIKS_TEST*,RIKS_DECIDE*);
    virtual void read_data(ASCII_FILE&,PROBLEM*) =0;
    RIKS_CHOICE();
    virtual ~RIKS_CHOICE(){};
    virtual double coef(MESH&) =0;
    virtual VECTOR recuperation(MESH&,const VECTOR&,bool) =0;
    virtual void save_U0(VECTOR&,double);
};

class RIKS_CHOICE_CLASSICAL : public RIKS_CHOICE
{
  protected :
    bool make,nset_give,no_norm,var_bool;
    STRING nset_name,var;
    NNSET* nset;

    virtual void internal_initialize(MESH&);

  public :
    RIKS_CHOICE_CLASSICAL();
    void read_data(ASCII_FILE&,PROBLEM*);
    double coef(MESH&);
    virtual VECTOR recuperation(MESH&,const VECTOR&,bool);
};

class RIKS_CHOICE_NONLOCAL : public RIKS_CHOICE
{
  protected :
    bool make,var_give,nb_give;
    int nb_max;
    STRING nset_name,rate,var,type;
    NNSET* nset;
    LIST<NODE*> list;
    ARRAY<int> rank_pond,rank_pond_tot;
    ARRAY<double> coef_pond,coef_pond_tot;
    double max;

    virtual void internal_initialize(MESH&);

  public :
    RIKS_CHOICE_NONLOCAL();
    void read_data(ASCII_FILE&,PROBLEM*);
    double coef(MESH&);
    virtual VECTOR recuperation(MESH&,const VECTOR&,bool);
    virtual void ponderation(VECTOR);
    void rangement(ARRAY<double>&,ARRAY<int>&,ARRAY<double>&,ARRAY<int>&);
};

class RIKS_CHOICE_VARIABLE : public RIKS_CHOICE
{
  protected :
    bool var_give,nb_give,range;
    int nb_max;
    STRING nset_name,rate,var,type;
    NNSET* nset;
    LIST<NODE*> list;
    ARRAY<int> rank_pond,rank_pond_tot;
    ARRAY<double> coef_pond,coef_pond_tot;

    virtual void internal_initialize(MESH&);

  public :
    RIKS_CHOICE_VARIABLE();
    void read_data(ASCII_FILE&,PROBLEM*);
    double coef(MESH&);
    virtual VECTOR recuperation(MESH&,const VECTOR&,bool);
    virtual void ponderation(VECTOR);
    void rangement(ARRAY<double>&,ARRAY<int>&,ARRAY<double>&,ARRAY<int>&);
};

Z_END_NAMESPACE;

#endif
