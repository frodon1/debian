#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>




#include <meshgems/meshgems.h>
#include <meshgems/tetra.h>



/**
 * Struct holding data that represents the input surface mesh.  It
 * could be replaced by a database handle or anything else containing
 * surface mesh data.
 * For a simple example, let's just read a mesh file on disk and
 * store it in this struct Then we will build the mesh_t object
 * that accesses it.
 * See the file meshgems/mesh.h for more detailed information
 */

struct mm_t_ {
  int nv;
  int nt;
  int ne;
  int ntet;
  double *vtx;
  double *w;
  int *tag;
  int *tri;
  int *trip2;
  int *edg;
  int *tetra;
};

typedef struct mm_t_ mm_t;

/**
 * Implementation declaration of how the number of vertices in the mesh is obtained.
 * @param[out]	nbvtx	: the number of vertices
 * @param     user_data	: a user pointer.
 * @return error code
 */

status_t mgtm_get_vertex_count(integer * nbvtx, void *user_data)
{
  mm_t *mm = (mm_t *) user_data;

  *nbvtx = mm->nv;

  return STATUS_OK;
}

/**
 * Implementation of how the coordinates of a mesh vertex are obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	xyz	: real[3] array containing the coordinates of the vertex
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_coordinates(integer ivtx, real * xyz,
                                     void *user_data)
{
  int j;
  mm_t *mm = (mm_t *) user_data;

  for (j = 0; j < 3; j++)
    xyz[j] = mm->vtx[3 * (ivtx - 1) + j];

  return STATUS_OK;
}

/**
 * Implementation declaration of how the number of edges in the mesh is obtained.
 * @param[out]	nbedg	: the number of edges
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_count(integer * nbedge, void *user_data)
{
  mm_t *mm = (mm_t *) user_data;

  *nbedge = mm->ne;

  return STATUS_OK;
}

/**
 * Implementation declaration of how the vertices of a mesh edge are obtained.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	vedge	: integer[2] array containing the vertices of the edge
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_vertices(integer iedge, integer * vedge,
                                void *user_data)
{
  int j;
  mm_t *mm = (mm_t *) user_data;

  for (j = 0; j < 2; j++)
    vedge[j] = mm->edg[2 * (iedge - 1) + j];

  return STATUS_OK;
}


/**
 * Implementation declaration of how the number of triangles in the mesh is obtained.
 * @param[out]	nbtri	: the number of triangles
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_count(integer * nbtri, void *user_data)
{
  mm_t *mm = (mm_t *) user_data;

  *nbtri = mm->nt;

  return STATUS_OK;
}

/**
 * Implementation declaration of how the vertices of a mesh triangle are obtained.
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]	vtri	: integer[3] array containing the vertices of the triangle
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_vertices(integer itri, integer * vtri,
                                    void *user_data)
{
  int j;
  mm_t *mm = (mm_t *) user_data;

  for (j = 0; j < 3; j++)
    vtri[j] = mm->tri[3 * (itri - 1) + j];

  return STATUS_OK;
}

/**
 * Implementation declaration of how the vertices of a quadratic mesh triangle (P2) are obtained.
 * @param[in]	m	: the mesh
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]	typetri	: integer containing the type of the triangle
 * @param[out]	evtri	: integer[] array containing the extra vertices of the triangle
 * @return error code
 */
status_t mgtm_get_triangle_extra_vertices(integer itri, integer * typetri,
                                          integer * evtri, void *user_data)
{
  int j;
  mm_t *mm = (mm_t *) user_data;


  *typetri = 0;

  for (j = 0; j < 3; j++)
    evtri[j] = mm->trip2[3 * (itri - 1) + j];

  if ((evtri[0] == 0) && (evtri[1] == 0) && (evtri[2] == 0))
    *typetri = MESHGEMS_MESH_ELEMENT_TYPE_TRIA3;
  else if ((evtri[0] * evtri[1] * evtri[2] != 0))
    *typetri = MESHGEMS_MESH_ELEMENT_TYPE_TRIA6;
  else
    return STATUS_ERROR;

  return STATUS_OK;

}

/**
 * Implementation declaration of how the number of tetrahedron in the mesh is obtained.
 * @param[out]	nbtetra	: the number of tetrahedra
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_tetrahedron_count(integer * nbtetra, void *user_data)
{
  mm_t *mm = (mm_t *) user_data;


  *nbtetra = mm->ntet;

  return STATUS_OK;
}

/**
 * Implementation declaration of how the vertices of a mesh tetrahedra are obtained.
 * @param[in]	itetra	: index of the desired tetrahedra from 1 to nbtetra
 * @param[out]	vtetra	: integer[4] array containing the vertices of the tetrahedra
 * @param	user_data: a user pointer.
 * @return error code
 */

status_t mgtm_get_tetrahedron_vertices(integer itetra, integer * vtetra,
                                       void *user_data)
{
  int j;
  mm_t *mm = (mm_t *) user_data;

  for (j = 0; j < 4; j++)
    vtetra[j] = mm->tetra[4 * (itetra - 1) + j];

  return STATUS_OK;
}

mm_t *mm = NULL;

/**
 * Implementation declaration of how the weights of vertices of a mesh 
 * @param[in]	ivtx	: index of the desired vertex from 1 to nbvtx
 * @param[out]	wvtx	: real  containing the weight of the vertex
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_weight(integer ivtx, real * wvtx, void *user_data)
{
  mm_t *mm = (mm_t *) user_data;

  *wvtx = mm->w[ivtx - 1];

  return STATUS_OK;
}

status_t mgtm_get_vertex_required_status(integer ivtx, integer * wvtx,
                                         void *user_data)
{
  mm_t *mm = (mm_t *) user_data;

  *wvtx = mm->tag[ivtx - 1];

  return STATUS_OK;
}


status_t tetra_mgtm_free(tetra_session_t * tms)
{
  return STATUS_OK;
}

/**
 * This function will read a msh2
 * formated file into a mm_t structure and create a mesh_t interface
 * for it.
 * @param[in] ctx : the meshgems context we are working in
 * @param[in] name : the prefix name of the msh2 files to read
 * @return a mesh_t struct pointer to the created mesh_t object
 *
 */

status_t create_mesh_and_sizemap_from_file(context_t * ctx, char *name,
                                           mesh_t ** pmsh,
                                           sizemap_t ** psizemap)
{
  FILE *f;
  char *tmp, c;
  char *ptr = NULL;
  int t, i, j, k, nlen;
  int nff = 0;
  int nedg = 0;
  integer reqedg;
  integer req;
  integer npmax;

  integer nv, nf, ntet = 0, num, vert[8];
  integer nusom;
  real cooxyz[3];
  double *xyz = NULL, *weight = NULL;
  int *faces = NULL, *edges = NULL, *tetra = NULL, *tagvtx = NULL;

  meshgems_mesh_t *msh;
  meshgems_sizemap_t *sizemap;

  msh = NULL;
  sizemap = NULL;

  mm = (mm_t *) calloc(1, sizeof(mm_t));

  nlen = strlen(name);
  tmp = (char *) calloc(nlen + 21, sizeof(char));
  if (!tmp) {
    fprintf(stdout, "ERROR-1 : Unable to alloc tmp buffer\n");
    return STATUS_NOMEM;
  }
  strcat(tmp, name);
  strcpy(tmp, name);
  ptr = strstr(tmp, ".mesh");
  if (ptr != NULL)
    tmp[ptr - tmp] = '\0';
  strcat(tmp, ".mesh");
  fprintf(stdout, " Reading input mesh in %s\n", tmp);
  msh = meshgems_mesh_new_read_mesh(ctx, tmp);

  if (msh) {
    meshgems_mesh_get_edge_count(msh, &nedg);
    meshgems_mesh_get_triangle_count(msh, &nff);
    meshgems_mesh_get_tetrahedron_count(msh, &ntet);
    meshgems_mesh_get_vertex_count(msh, &nv);
    nf = nff + nedg;
#ifdef DEBUG
    fprintf(stdout, "%s %d ", __FILE__, __LINE__);
    fprintf(stdout, " nedg %d nff %d nf %d nv %d ntet %d\n", nedg, nff, nf,
            nv, ntet);
#endif


    if (ntet != 0) {
      strcpy(tmp, name);
      ptr = strstr(tmp, ".mesh");
      if (ptr != NULL)
        tmp[ptr - tmp] = '\0';
      strcat(tmp, ".sol");

      fprintf(stdout, " Reading input size map in %s\n", tmp);
      sizemap = meshgems_sizemap_new_read_sol(msh, tmp);
      if (!sizemap) {
        fprintf(stderr, "%s\n", "Sizemap creation failed");
        return STATUS_ERROR;
      }

    } else {
      weight = (double *) calloc(nv, sizeof(double));
      for (i = 0; i < nv; i++)
        weight[i] = 0;

      sizemap =
          meshgems_sizemap_new(msh, meshgems_sizemap_type_iso_mesh_vertex,
                               mgtm_get_vertex_weight, mm);
      if (!sizemap) {
        fprintf(stderr, "%s\n", "Sizemap creation failed");
        return STATUS_ERROR;
      }
      // Set the desired size around the enforced vertices
      for (i = 1; i <= nv; i++) {
        meshgems_mesh_get_vertex_required_status(msh, i, &req);
        if (req)
          weight[i - 1] = 1.5;
      }

      mm->w = weight;
#ifdef DEBUG
      for (i = 0; i < nv; i++)
        fprintf(stdout, " weight[%d]=%f\n", i + 1, weight[i]);
#endif
    }

  }

  if (!msh) {

    fprintf(stdout, " Status %d try to open msh2 \n", STATUS_ERROR);
    sprintf(tmp, "%s.points", name);
    f = fopen(tmp, "r");
    if (f == NULL) {
      fprintf(stdout, "ERROR0 : Unable to open %s.points file\n", name);
      return STATUS_ERROR;
    }

    t = fscanf(f, "%d", &nv);
    if (t != 1) {
      fprintf(stdout, "ERROR1 : Unable to read .points file\n");
      return STATUS_ERROR;
    }

    npmax = 1.5 * nv;
    //    xyz  = (double*) calloc(3*nv, sizeof(double));
    xyz = (double *) calloc(3 * npmax, sizeof(double));
    if (!xyz) {
      fprintf(stdout,
              "ERROR2 : Unable to allocate memory to read .points file\n");
      return STATUS_NOMEM;
    }

    for (i = 0; i < nv; i++) {
      double *r = xyz + 3 * i;
      t = fscanf(f, "%lf %lf %lf %*i", r, r + 1, r + 2);
      if (t != 3) {
        fprintf(stdout, "ERROR3 : Unable to read .points file\n");
        return STATUS_ERROR;
      }
    }

    weight = (double *) calloc(npmax, sizeof(double));
    if (!weight) {
      fprintf(stdout,
              "ERROR2 : Unable to allocate memory to read .points file\n");
      return STATUS_NOMEM;
    }

    for (i = 0; i < npmax; i++)
      weight[i] = 0;

    tagvtx = (int *) calloc(npmax, sizeof(int));
    if (!tagvtx) {
      fprintf(stdout,
              "ERROR12 : Unable to allocate memory to read .points file\n");
      return STATUS_NOMEM;
    }
    for (i = 0; i < npmax; i++)
      tagvtx[i] = 0;

    req = 0;
    t = 4;
    i = nv;
    while (t == 4) {
      double *r = xyz + 3 * nv;
      double *wtx = weight + nv;
      t = fscanf(f, "%lf %lf %lf %lf %*i", r, r + 1, r + 2, wtx);
      if (t != 4) {
        j = feof(f);
        if (j) {
          if (req != 0)
            fprintf(stdout, "INFO : End of enforced vertices\n");
        } else {
          fprintf(stdout, " %% ERROR reading %s file\n", tmp);
          return STATUS_ERROR;
        }
      } else {
        fprintf(stdout, " xyz %lf %lf %lf %lf \n", xyz[3 * nv],
                xyz[3 * nv + 1], xyz[3 * nv + 2], weight[nv]);
        nv++;
        req++;
        tagvtx[nv] = 1;
      }
    }
    if (req)
      fprintf(stdout, "INFO : There are %d enforced vertices\n", req);

    fclose(f);

    sprintf(tmp, "%s.faces", name);
    f = fopen(tmp, "r");
    if (f == NULL) {
      fprintf(stdout, "ERROR10 : Unable to open %s.faces file\n", name);
      return STATUS_ERROR;
    }

    t = fscanf(f, "%d", &nf);
    if (t != 1) {
      fprintf(stdout, "ERROR11 : Unable to read .faces file\n");
      return STATUS_ERROR;
    }
    // next line:
    while ((c = getc(f)) != EOF && c != '\n');

    faces = (int *) calloc(3 * nf, sizeof(int));
    if (!faces) {
      fprintf(stdout,
              "ERROR12 : Unable to allocate memory to read .faces file\n");
      return STATUS_NOMEM;
    }

    edges = (int *) calloc(2 * nf, sizeof(int));
    if (!edges) {
      fprintf(stdout,
              "ERROR12 : Unable to allocate memory to read .faces file\n");
      return STATUS_NOMEM;
    }

    for (i = 0; i < nf; i++) {

      t = fscanf(f, "%i ", &k);
      //    fprintf(stdout," type %d \n",k);
      if (k == 2) {
        int *r = edges + 2 * nedg;
        nedg++;
        t = fscanf(f, "%i %i %*i %*i %*i \n", r, r + 1);
        //      *(r+2)=0;

      } else {
        if (k == 3) {
          int *r = faces + 3 * nff;
          nff++;

          t = fscanf(f, "%i %i %i %*i %*i %*i %*i \n", r, r + 1, r + 2);
        } else {
          fprintf(stdout, "ERROR13 : Unable to read .faces file\n");
          return STATUS_ERROR;
        }
      }
    }
    fclose(f);

    /*
     * Create a mesh_t object that acceses the surface mesh data
     */
    msh = mesh_new(ctx);

    if (!msh) {
      fprintf(stdout, "unable to create a new mesh \n");
      return STATUS_ERROR;
    }
#ifdef DEBUGFULL
    fprintf(stdout, "READ %d  vertices and %d  faces %d edges %d tetra\n",
            nv, nff, nedg, ntet);
    num = 1;
    for (i = 0; i < nff; i++, num++)
      fprintf(stdout, " faces[%d] %d  %d %d\n", num, faces[3 * (num - 1)],
              faces[3 * (num - 1) + 1], faces[3 * (num - 1) + 2]);
    num = 1;
    for (i = 0; i < nedg; i++, num++)
      fprintf(stdout, " edges[%d] %d  %d \n", num, edges[2 * (num - 1)],
              edges[2 * (num - 1) + 1]);
    nusom = 1;
    for (i = 0; i < nv; i++, nusom++)
      fprintf(stdout, " nusom %d %f %f %f\n", nusom, xyz[3 * (nusom - 1)],
              xyz[3 * (nusom - 1) + 1], xyz[3 * (nusom - 1) + 2]),
#endif
          mm->nv = nv;
    mm->nt = nff;
    mm->ne = nedg;
    mm->ntet = ntet;
    mm->vtx = xyz;
    mm->w = weight;
    mm->tag = tagvtx;
    mm->tri = faces;
    mm->edg = edges;
    mm->tetra = tetra;

    /*
     * Set the mesh_t callback functions that will interogate the mm_t struct :
     * see meshgems/mesh.h for more details.
     */
    mesh_set_get_vertex_count(msh, mgtm_get_vertex_count, mm);
    mesh_set_get_triangle_count(msh, mgtm_get_triangle_count, mm);
    mesh_set_get_vertex_coordinates(msh, mgtm_get_vertex_coordinates, mm);
    mesh_set_get_vertex_required_status(msh,
                                        mgtm_get_vertex_required_status,
                                        mm);
    mesh_set_get_triangle_vertices(msh, mgtm_get_triangle_vertices, mm);
    mesh_set_get_edge_count(msh, mgtm_get_edge_count, mm);
    mesh_set_get_edge_vertices(msh, mgtm_get_edge_vertices, mm);
    mesh_set_get_tetrahedron_count(msh, mgtm_get_tetrahedron_count, mm);
    mesh_set_get_tetrahedron_vertices(msh, mgtm_get_tetrahedron_vertices,
                                      mm);


    sizemap =
        meshgems_sizemap_new(msh, meshgems_sizemap_type_iso_mesh_vertex,
                             mgtm_get_vertex_weight, mm);
    if (!sizemap) {
      fprintf(stderr, "%s\n", "Sizemap creation failed");
      return STATUS_ERROR;
    }

  }
  /* !msh */
  *pmsh = msh;
  *psizemap = sizemap;

  return STATUS_OK;
}


/*
 * This is the message callback function that Tetra will call when
 * he wants to send a message to the caller
 * see meshgems/message.h for more details.
 *
 * param msg [in] : the message
 * param user_data [in] : a user pointer.
 * return an error code
 */
status_t my_message_cb(message_t * msg, void *user_data)
{
  char *desc;
  integer e, n, m;
  integer i, p, edge[2], face[3];
  real r;

  message_get_description(msg, &desc);
  message_get_number(msg, &e);

  if ( (e == 0) || (MESHGEMS_ABS_CODE(e) == 9001) ) {
    /* this is an information */
    //    printf("INFO : \n%s", desc);
    printf("%s", desc);

  } else if (e >= 0) {
    /* this is a warning */
    if (e == MESHGEMS_ABS_CODE(e) == 5200) {
      message_get_integer_data_count(msg, &n);
      if (n >= 3) {             // just to make sure everything is as expected
        message_get_integer_data(msg, 1, 3, face);
        printf("Warning : Found duplicate face : %i %i %i \n", face[0],
               face[1], face[2]);
      }
    } else {
      /* No specific handler for this warning. Just print it */
      printf("WARNING (%i) : %s", e, desc);
    }
  } else {                      // e < 0
    /* this is an error. Find out what is going on */
    if (MESHGEMS_ABS_CODE(e) == 8421) {
      /* This is the error 8421 (from Tetra standard documentation :
         EDGE  3127 3139  IS MISSING
       */
      message_get_integer_data_count(msg, &n);
      if (n >= 2) {             // just to make sure everything is as expected
        message_get_integer_data(msg, 1, 2, edge);
        printf("Found missing edge (%i) : %i %i \n", n, edge[0], edge[1]);
      }
    } else if (MESHGEMS_ABS_CODE(e) == 8423) {
      /* This is the error 8423 (from Tetra standard documentation :
         FACE  3127 3129 3139  IS MISSING
       */
      message_get_integer_data_count(msg, &n);
      if (n >= 3) {             // just to make sure everything is as expected
        message_get_integer_data(msg, 1, 3, face);
        printf("Found missing face : %i %i %i \n", face[0], face[1],
               face[2]);
      }
    } else if (MESHGEMS_ABS_CODE(e) == 5150) {
      /* This is the error 5150 (from Tetra standard documentation :
         ERR  3105  :  2953  IN  912 2781 2860
       */
      message_get_integer_data_count(msg, &n);
      if (n >= 4) {             // just to make sure everything is as expected
        message_get_integer_data(msg, 1, 1, &p);
        message_get_integer_data(msg, 2, 4, face);
        printf("Found point/face intersection : %i in %i %i %i\n",
               p, face[0], face[1], face[2]);
      }
    } else if (MESHGEMS_ABS_CODE(e) == 5120) {
      /* This is the error 5120 (from Tetra standard documentation :
         ERR  3106  :  4826 4827  WITH  4742 4761 4762
       */
      message_get_integer_data_count(msg, &n);
      if (n >= 5) {             // just to make sure everything is as expected
        message_get_integer_data(msg, 1, 2, edge);
        message_get_integer_data(msg, 3, 5, face);
        printf("Found edge/face intersection : %i %i with %i %i %i\n",
               edge[0], edge[1], face[0], face[1], face[2]);
      }
    } else if (MESHGEMS_ABS_CODE(e) == 5110) {
      /* This is the error 5110 (from Tetra standard documentation :
         ERR  3103  :  362 10895  WITH  10280 364
       */
      message_get_integer_data_count(msg, &n);
      if (n >= 4) {             // just to make sure everything is as expected
        message_get_integer_data(msg, 1, 2, edge);
        message_get_integer_data(msg, 3, 4, face);
        printf("Found edge/edge intersection : %i %i with %i %i \n",
               edge[0], edge[1], face[0], face[1]);
      }
    } else if (MESHGEMS_ABS_CODE(e) == 5505) {
      /* This is the error 5505 (from Tetra standard documentation :
         FACE   942  WITH VERTICES :  32 25 764
         SMALL INRADIUS :  0.
       */
      message_get_integer_data_count(msg, &n);
      message_get_real_data_count(msg, &m);
      if (n >= 4 && m >= 1) {   // just to make sure everything is as expected
        message_get_integer_data(msg, 1, 1, &i);
        message_get_integer_data(msg, 2, 4, face);
        message_get_real_data(msg, 1, 1, &r);
        printf("Found face %i : (%i, %i, %i) with small inradius : %lf \n",
               i, face[0], face[1], face[2], r);
      }
    } else {
      /* No specific handler for this error. Just print it */
      printf("ERROR (%i) : %s", e, desc);
    }
  }

  return STATUS_OK;
}




/* A macro we will call to cleanly return from the function in case of failure */
#define RETURN_WITH_MESSAGE(_ret, _msg) do{				\
    fflush(stdout);	                                                \
    fflush(stderr);                                                     \
    fprintf(stderr,"%s\n",_msg);					\
    fflush(stderr);				                	\
    if(tms) tetra_session_delete(tms);				\
    if(msh) mesh_delete(msh);						\
    if(ctx) context_delete(ctx);					\
    return _ret;							\
  }while(0);

status_t run_tetra_mesh(char *name_in, const char *suffix_out,
                        integer internal_points,
                        const char *optim_level,
                        integer optimise_overconstrained,
                        integer optimise_sliver)
{
  status_t ret;
  context_t *ctx;
  mesh_t *msh;
  tetra_session_t *tms;
  mesh_t *vmsh;
  sizemap_t *sizemap, *vsizemap;
  char *tmp;

  integer i;
  integer nvm, ntm;
  integer reqedg;
  integer nedg, nf;
  integer nsd;
  int meshp2 = 0;
  real q, qmin, qmax;
  char param[256];


  ctx = NULL;
  msh = NULL;
  tms = NULL;
  vmsh = NULL;
  sizemap = NULL;
  vsizemap = NULL;
  mm = NULL;

  if (!name_in)
    return STATUS_ERROR;

  /*
   * Create the meshgems working context
   */
  ctx = context_new();
  if (!ctx)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new context");

  /*
   * Set the message callback for our context and create the mesh accessor.
   */
  context_set_message_callback(ctx, my_message_cb, NULL);

  ret = create_mesh_and_sizemap_from_file(ctx, name_in, &msh, &sizemap);
  if (ret != STATUS_OK || !msh)
    RETURN_WITH_MESSAGE(STATUS_ERROR, "Mesh creation failed");


  if (0) {
    /*
     * Display some statistics about the surface mesh.
     * The data is sent formated to the context message callback
     * For debugging purposes
     */
    mesh_compute_statistics(msh);
  }


  /*
   * Create a Tetra session
   */

  tms = tetra_session_new(ctx);
  if (!tms)
    RETURN_WITH_MESSAGE(STATUS_NOMEM,
                        "unable to create a new Tetra session");

  /*
   * On the Tetra session, set its working surface or volume  mesh
   */

  ret = mesh_get_tetrahedron_count(msh, &ntm);
  if (ntm) {
    /* 
       Starting from an existing volume mesh 
     */
    ret = tetra_set_volume_mesh(tms, msh);
    if (ret != STATUS_OK) {
      RETURN_WITH_MESSAGE(ret, "unable to set volume mesh");
    }
    ret = tetra_set_sizemap(tms, sizemap);
    if (ret != STATUS_OK) {
      RETURN_WITH_MESSAGE(ret, "unable to set volume sizemap");
    }
    meshgems_mesh_get_triangle_count(msh, &nf);
  } else {
    ret = mesh_get_triangle_count(msh, &nf);
    if (nf) {
      /* 
         Starting from a surface mesh 
       */
      ret = tetra_set_surface_mesh(tms, msh);
      if (ret != STATUS_OK) {
        RETURN_WITH_MESSAGE(ret, "unable to set surface mesh");
      }
      /*
       * Sizemap is optional for surface mesh.
       */
      if (sizemap) {
        ret = tetra_set_sizemap(tms, sizemap);
        if (ret != STATUS_OK) {
          RETURN_WITH_MESSAGE(ret, "unable to set surface sizemap");
        }
      }
    } else {
      RETURN_WITH_MESSAGE(ret, "unable to find triangles or tetrahedra in the input mesh");
    }
  }

#ifdef DEBUG
  fprintf(stdout, "%s %d\n", __FILE__, __LINE__);
#endif


  {
    /* Detects if input surface mesh is quadratic */
    /* Quadratic mesh
     */
    integer nbfp2, nbfp1, typetri, num, vert[8];

    nbfp2 = 0;
    nbfp1 = 0;
    for (i = 1; i <= nf; i++) {
      ret = mesh_get_triangle_extra_vertices(msh, i, &typetri, vert);

      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret, "problem when reading extra vertices");
      if (typetri == MESHGEMS_MESH_ELEMENT_TYPE_TRIA6)
        nbfp2++;
      if ((typetri == MESHGEMS_MESH_ELEMENT_TYPE_TRIA3) || (typetri == 0))
        nbfp1++;
    }

    if (nf == nbfp2) {
      if (ntm != 0) {
        ret = STATUS_ERROR;
        RETURN_WITH_MESSAGE(ret,
                            "ERROR : can not use quadratic option with an input volume mesh");
      }
      /*
         define quadratic input mesh
       */
      meshp2 = 1;
      sprintf(param, "%s", "quadratic");
      ret = tetra_set_param(tms, "element_order", param);

      /*
         define the parameter with permits to correct the input quadratic skin mesh
       */
      sprintf(param, "yes");
      ret = tetra_set_param(tms, "rectify_jacobian", param);

    } else {
      /*
         define linear input mesh
       */

      if (nf == nbfp1) {
        meshp2 = 0;
        sprintf(param, "%s", "linear");
        ret = tetra_set_param(tms, "element_order", param);
      } else {
        ret = STATUS_ERROR;
        sprintf(param,
                "Unable to read linear or quadratic elements \n\tnumber of triangles %d\n\tnumber of linear triangles %d\n\tnumber of quadratic triangles %d\n",
                nf, nbfp1, nbfp2);
        RETURN_WITH_MESSAGE(ret, param);
      }
    }
  }

  /* This option changes the verbosity level of Tetra, between 0 and
   * 10.  The higher it is, the more messages Tetra will send
   * through the message callback
   */
  ret = tetra_set_param(tms, "verbose", "3");

  /* This option sets the maximum number of error Tetra will
   * send to the message callback.
   */
  ret = tetra_set_param(tms, "max_error_count", "20");

  //   ret = tetra_set_param(tms, "components", "all");
  if (0) {
    /* Set this parameter to 0 if you want all connex component to be
     * meshed or to 1 if you only want the main one.
     * default is the main one
     */
    ret = tetra_set_param(tms, "components", "outside_components");
    ret = tetra_set_param(tms, "components", "all");

    /* The following parameter  drives the
     * point density inside the generated mesh. it  represents a goal
     * and cannot be guaranteed to be exactly respected, mainly
     * because of the input surface mesh constraints and of the
     * nature of the algorithms used.
     */

    /* Set the desired maximum ratio between 2 adjacent tetrahedra
     * edges. The closer it is to "1", the more uniform the mesh will be
     * Default value is "1.05"
     */
    ret = tetra_set_param(tms, "gradation", "1.05");



    /* Set this parameter to no to removes initial central point.
       Default: create initial central point to speed-up the mesh 
       generation process.
     */
    ret = tetra_set_param(tms, "centralpoint", "no");

  }

  /* 
   * The mesh generation order. You can also try with 
   * See the meshgems/tetra.h file for more details
   *
   */
  if ((meshp2 == 1)
      && (optimise_overconstrained || optimise_sliver
          || !internal_points)) {
    ret = STATUS_ERROR;
    RETURN_WITH_MESSAGE(ret, "Unable to generate volume tetrahedra");
  }

  ret = tetra_set_param(tms, "optimisation_level", optim_level);

  if (internal_points) {
    /*
     * Do a standard tetra run with the requested optimisation level
     */

    /*   
       // Run standard  meshgems_tetra_compute_mesh  makes the following steps :
       //   ret = meshgems_tetra_mesh_boundary(tms)
       //   ret = meshgems_tetra_insert_volume_vertices(tms)
       //   ret = meshgems_tetra_optimise_volume_regular(tms)
       //
     */

    if (strcmp(optim_level, "pthreads") == 0) {
      ret = tetra_set_param(tms, "pthreads_mode", "safe");
      ret = tetra_set_param(tms, "optimisation_level", "standard");
    }

    if (strcmp(optim_level, "pthreadsa") == 0) {
      ret = tetra_set_param(tms, "max_number_of_threads", "8");
      ret = tetra_set_param(tms, "pthreads_mode", "aggressive");
      ret = tetra_set_param(tms, "optimisation_level", "standard");
    }

    ret = tetra_compute_mesh(tms);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "Unable to generate internal vertices");

  } else {
    /*
     * We do not want internal points : do the work in two steps :
     * 1st create an empty mesh and then optimise it to the desired
     * optimisation level (it may create some internal points if
     * optimisation_level is greater than MESHGEMS_TETRA_LIGHT_OPTIMISATION)
     */
    ret = STATUS_ERROR;
    if (meshp2 != 1)
      ret = tetra_mesh_boundary(tms);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "Unable to generate empty mesh");

    if (strcmp(optim_level, "none") != 0)
      ret = tetra_optimise_volume_regular(tms);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "Unable to optimise empty volume");
  }

  if (optimise_overconstrained) {
    /*
     * Do a special post-treatment optimisation to remove over-constrained 
     * elements (ie with too many edges/faces on the input surface)
     */
    ret = STATUS_ERROR;
    if (meshp2 != 1)
      ret = tetra_optimise_volume_overconstrained(tms);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "Unable to optimise for FEM");
  }

  if (optimise_sliver) {
    /*
     * Do a special post-treatment optimisation to remove sliver
     * elements (without surface modification). Can be time consuming.
     */
    ret = STATUS_ERROR;
    if (meshp2 != 1)
      ret = tetra_optimise_volume_sliver(tms);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "Unable to optimise sliver");
  }

  /*
   * Get the generated volume mesh. This output mesh belongs to the
   * tetra_session. Thus the user does not have to destroy it
   * afterwards.
   */

  ret = tetra_get_mesh(tms, &vmsh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting mesh");

  ret = tetra_get_sizemap(tms, &vsizemap);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting sizemap");



  /*
   * Read the output mesh data. See meshgems/mesh.h for more details.
   */
  ret = mesh_get_vertex_count(vmsh, &nvm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex count");

  ret = mesh_get_tetrahedron_count(vmsh, &ntm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedron count");

  for (i = 1; i <= nvm; i++) {
    real coo[3];
    ret = mesh_get_vertex_coordinates(vmsh, i, coo);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting vertices");
    if (0) {
      fprintf(stdout, "vertex %d is : %f %f %f \n", i, coo[0], coo[1],
              coo[2]);
    }
  }

  {
    integer req, tag;
    for (i = 1; i <= nvm; i++) {
      ret = mesh_get_vertex_required_status(vmsh, i, &req);
#ifdef DEBUG
      if (req)
        fprintf(stdout, "vertex %d is required  %d \n", i, req);
#endif
    }
  }

  qmin = REAL_INFINITY;
  qmax = -REAL_INFINITY;


  {
    integer nbfp2, typetri;
    int ntri;
    nbfp2 = 0;
    ret = mesh_get_triangle_count(vmsh, &ntri);
    for (i = 1; i <= ntri; i++) {
      integer vtx[3], tag;
      ret = mesh_get_triangle_vertices(vmsh, i, vtx);
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret, "unable to get resulting triangles");
      if (0) {
        fprintf(stdout, "tria %d is : %d %d %d\n", i, vtx[0], vtx[1],
                vtx[2]);
      }

      ret = mesh_get_triangle_extra_vertices(vmsh, i, &typetri, vtx);
#ifdef DEBUG
      fprintf(stdout, " %d %d %d %d %d \n", ntri, i, typetri,
              MESHGEMS_MESH_ELEMENT_TYPE_TRIA3,
              MESHGEMS_MESH_ELEMENT_TYPE_TRIA6);
#endif

      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret,
                            "problem when reading triangle extra vertices");
      if (typetri == MESHGEMS_MESH_ELEMENT_TYPE_TRIA6) {
        nbfp2++;
        if (0)
          fprintf(stdout, "tria %d nodes : %d %d %d \n", i, vtx[0], vtx[1],
                  vtx[2]);
      } else {
        //LF 2012       if (typetri != MESHGEMS_MESH_ELEMENT_TYPE_TRIA3)
        if ((typetri != MESHGEMS_MESH_ELEMENT_TYPE_TRIA3)
            && (typetri != 0))
          RETURN_WITH_MESSAGE(ret, "invalid tria type");
      }
    }
  }

  {
    integer nbfp2, typetetra;
    nbfp2 = 0;

    for (i = 1; i <= ntm; i++) {
      integer vtx[6], tag;
      ret = mesh_get_tetrahedron_vertices(vmsh, i, vtx);
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedra");
      if (0) {
        fprintf(stdout, "tetra %d is : %d %d %d %d \n", i, vtx[0], vtx[1],
                vtx[2], vtx[3]);
      }
      ret = mesh_get_tetrahedron_tag(vmsh, i, &tag);
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedra tag");
      if (0) {
        fprintf(stdout, "tetra %d is in subdomain %d\n", i, tag);
      }
      mesh_get_tetrahedron_aspect_ratio(vmsh, i, &q);
      if (q > qmax)
        qmax = q;
      if (q < qmin)
        qmin = q;

      ret = mesh_get_tetrahedron_extra_vertices(vmsh, i, &typetetra, vtx);
#ifdef DEBUG
      fprintf(stdout, " %d %d %d \n", typetetra,
              MESHGEMS_MESH_ELEMENT_TYPE_TETRA4,
              MESHGEMS_MESH_ELEMENT_TYPE_TETRA10);
#endif
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret, "problem when reading extra vertices");
      if (typetetra == MESHGEMS_MESH_ELEMENT_TYPE_TETRA10) {
        nbfp2++;
        if (0)
          fprintf(stdout, "tetra %d nodes : %d %d %d %d %d %d \n", i,
                  vtx[0], vtx[1], vtx[2], vtx[3], vtx[4], vtx[5]);
      } else {
        if (typetetra != MESHGEMS_MESH_ELEMENT_TYPE_TETRA4)
          RETURN_WITH_MESSAGE(ret, "invalid tetrahedra type");
      }

    }

    if (nbfp2 == 0)
      fprintf(stdout, "\nGenerated %d vertices and %d tetrahedra   \n",
              nvm, ntm);
    if (nbfp2 != 0)
      fprintf(stdout, "\nGenerated %d vertices and %d tetrahedra10 \n",
              nvm, nbfp2);
    fprintf(stdout, "          with a quality within [%f,%f]\n", qmin,
            qmax);
  }

  /*
   * Read the subdomain identification information.
   * Available if you set the parameter "component" to "0"
   * See meshgems-tetra documentation for more information about them.
   */

  ret = mesh_get_subdomain_count(vmsh, &nsd);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting subdomain count");

  fprintf(stdout, "Identified subdomains : %d\n", nsd);
  if (nsd > 1) {
    for (i = 1; i <= nsd; i++) {
      integer subdomain_tag, seed_type, seed_idx, seed_orientation;
      ret = mesh_get_subdomain_description(vmsh, i,
                                           &subdomain_tag, &seed_type,
                                           &seed_idx, &seed_orientation);
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret, "unable to get a subdomain seed");
      if (seed_type == MESHGEMS_MESH_ELEMENT_TYPE_TRIA3)
        seed_type = 3;

      fprintf(stdout,
              "subdomain %d description is :  tag %d type %d facet %d orientation %d \n",
              i, subdomain_tag, seed_type, seed_idx, seed_orientation);
    }
  }
  /*
   * We can also directly write a .mesh formated file : 
   */

  tmp = (char *) calloc(strlen(name_in) + 100, sizeof(char));
  if (!tmp)
    RETURN_WITH_MESSAGE(ret, "unable to allocate output volume file");
  strcpy(tmp, name_in);
  if (suffix_out)
    strcat(tmp, suffix_out);
  strcat(tmp, ".mesh");
  fprintf(stdout, "Writing volume mesh  in %s\n", tmp);
  ret = mesh_write_mesh(vmsh, tmp);
  if (tmp)
    free(tmp);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a .mesh file");

  tmp = (char *) calloc(strlen(name_in) + 100, sizeof(char));
  if (!tmp)
    RETURN_WITH_MESSAGE(ret, "unable to allocate output sizemap file");
  strcpy(tmp, name_in);
  if (suffix_out)
    strcat(tmp, suffix_out);
  strcat(tmp, ".sol");
  fprintf(stdout, "Writing volume size map  in %s\n", tmp);
  ret = sizemap_write_sol(vsizemap, tmp);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a size map file");
  if (tmp)
    free(tmp);
  tmp = NULL;

  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a .mesh file");


  if (tmp)
    free(tmp);
  tmp = NULL;

  if (1) {
    /*
     * Display some statistics about the output mesh.
     * The data is sent formated to the context message callback
     * for debugging purposes.
     */
    fprintf(stdout, "\n");
    mesh_compute_statistics(vmsh);
  }

  /*
   * We are done, give the volume mesh and sizemap back to the session and clean up everything.
   */
  tetra_regain_mesh(tms, vmsh);
  tetra_regain_sizemap(tms, vsizemap);
  tetra_session_delete(tms);
  if (msh) {
    mesh_delete(msh);
  }
  if (sizemap)
    sizemap_delete(sizemap);

  context_delete(ctx);
  tetra_mgtm_free(tms);

  return STATUS_OK;
}

int main(int argc, char **argv)
{
  char *name, *linquad;
  status_t ret;

  if (argc != 2 && argc != 3) {
    //    cout << "USAGE : "<< argv[0] << " name \n";
    fprintf(stdout, "USAGE : %s name \n", argv[0]);
    return -1;
  }

  name = argv[1];

  if (argc == 3) {
    linquad = argv[2];
    if (strcmp(linquad, "quadratic") == 0) {
      /* Quadratic run only standard and postprocessing  */
      ret = run_tetra_mesh(name, "_quadratic", 1, "standard", 0, 0);
      if (ret != STATUS_OK)
        fprintf(stdout, "Quadratic meshing failed\n");
      goto fintetra;
    }
  }


  /*
   * Run a few examples of meshgems-tetra runs on this case
   *
   */

  /* Standard run */
  ret = run_tetra_mesh(name, "_std", 1, "standard", 0, 0);
  if (ret != STATUS_OK) {
    //    cout << "Meshing failed \n";
    fprintf(stdout, "Meshing failed\n");
    //exit(-1);    
  }
  //  goto fintetra;

  /* Standard but without optimisation */
  ret = run_tetra_mesh(name, "_std_no_optim", 1, "none", 0, 0);
  if (ret != STATUS_OK) {
    fprintf(stdout, "Meshing failed\n");
    //    exit(-1);    
  }

  /* Standard with overconstrained elements optimisation */
  ret = run_tetra_mesh(name, "_std_fem", 1, "standard", 1, 0);
  if (ret != STATUS_OK) {
    //    cout << "Meshing failed \n";
    fprintf(stdout, "Meshing failed\n");
    //    exit(-1);    
  }

  /* Standard with sliver elements optimisation */
  ret = run_tetra_mesh(name, "_std_sliver", 1, "standard", 0, 1);
  if (ret != STATUS_OK) {
    //    cout << "Meshing failed \n";
    fprintf(stdout, "Meshing failed\n");
    //  exit(-1);    
  }

  /* Standard with sliver and overconstrained elements optimisation */
  ret = run_tetra_mesh(name, "_std_fem_sliver", 1, "standard", 1, 1);
  if (ret != STATUS_OK) {
    //    cout << "Meshing failed \n";
    fprintf(stdout, "Meshing failed\n");
    //  exit(-1);    
  }

  /* Empty mesh generation (or almost) without optimisation */
  ret = run_tetra_mesh(name, "_empty_no_optim", 0, "none", 0, 0);
  if (ret != STATUS_OK) {
    //    cout << "Meshing failed \n";
    fprintf(stdout, "Meshing failed\n");
    //  exit(-1);    
  }

  /* Empty mesh generation (or almost) with light optimisation */
  ret = run_tetra_mesh(name, "_empty_light_optim", 0, "light", 0, 0);
  if (ret != STATUS_OK) {
    //    cout << "Meshing failed \n";
    fprintf(stdout, "Meshing failed\n");
    //  exit(-1);    
  }

  /* Empty mesh generation (or almost) with light optimisation */
  ret = run_tetra_mesh(name, "_empty_light_optim_fem", 0, "light", 1, 0);
  if (ret != STATUS_OK) {
    //    cout << "Meshing failed \n";
    fprintf(stdout, "Meshing failed\n");
    //  exit(-1);    
  }

  /* Empty mesh generation (or almost) with standard optimisation */
  ret = run_tetra_mesh(name, "_empty_std_optim", 0, "standard", 0, 0);
  if (ret != STATUS_OK) {
    //    cout << "Meshing failed \n";
    fprintf(stdout, "Meshing failed\n");
    //  exit(-1);    
  }

  /* Standard but with threads optimistaion */
  ret = run_tetra_mesh(name, "_std_threads_safe", 1, "pthreads", 0, 0);
  if (ret != STATUS_OK) {
    fprintf(stdout, "Meshing failed\n");
    //    exit(-1);    
  }

  ret =
      run_tetra_mesh(name, "_std_threads_aggressive", 1, "pthreadsa", 0,
                     0);
  if (ret != STATUS_OK) {
    fprintf(stdout, "Meshing failed\n");
    //    exit(-1);    
  }
fintetra:

  return 0;
}
