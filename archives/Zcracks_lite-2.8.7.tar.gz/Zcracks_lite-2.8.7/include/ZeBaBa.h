#ifndef __ZeBaBa__
#define __ZeBaBa__

#include <Defines.h> 

#include <Stringpp.h> 
#include <Behavior.h> 
#include <Mat_data.h> 
#include <Zmat_skip.h> 
#include <Zmat_storage.h> 
#include <Local_frame.h> 
#include <Zmat_class.h> 

Z_START_NAMESPACE;

// 
// This is used to compile Zpreload 
// 
extern "C" {
#if defined HPUX64
void zebaba_(
#elif defined HPUX 
void zebaba(
#elif defined AIX
void zebaba(
#elif defined _WIN32
#define STDCALL __stdcall
WIN_THINGIE void STDCALL ZEBABA(
#else 
void zebaba_(
#endif
      real_abq* stress,          // 1
      real_abq* statev,          // 2
      real_abq* ddsdde,          // 3
      		
      real_abq* /* sse */,       // 4
      real_abq* /* spd */,       // 5
      real_abq* /* scd */,       // 6
      real_abq* /* rpl */,       // 7
      real_abq* /* ddsddt[] */,	 // 8
      real_abq* /* drplde[] */,	 // 9
      real_abq* /*  drpldt */,	 // 0
      
      real_abq* stran,           // 1
      real_abq* dstran,          // 2
      
      real_abq* time,            // 3
      real_abq* dtime,           // 4
      real_abq* temp,            // 5
      real_abq* dtemp,           // 6
      real_abq* , // predef[], 	 // 7
      real_abq* , // dpred[], 	 // 8
      char* cmname,		 // 9
#if defined(_WIN32) && !defined(_WIN64)
      char* cmname_xxx,
#endif

      int* _ndi, // 0
      int* /* _nshr */,          // 1
      int* _ntens,               // 2
      int* _nstatv,              // 3
      
      real_abq*  /*props*/,      // 4
      int*   /*nprops*/,         // 5
      real_abq*  /*coords*/,     // 6
      real_abq*  /*drot*/,       // 7
      real_abq* pnewdt,          // 8
      real_abq* /*celent*/,      // 9

      real_abq* dfgrd0,          // 0
      real_abq* dfgrd1,          // 1

      int* /*_noel*/, int* /*_npt*/, 
      int* /*layer*/, int* /*kspt*/, 
      int* /*kstep*/, int* /*kinc*/, 
      int* /*kiter*/, 
      int* /*kitgen*/            // 9

);
}
Z_END_NAMESPACE;

#endif
