#ifndef __ERROR_HANDLER__
#define __ERROR_HANDLER__

#include <Bool.h>
#include <Handler_mp.h>
#include <Server.h>

Z_START_NAMESPACE;

#define Z_ERROR 1012

ZCLASS ERROR_HANDLER : public HANDLER_MP
{
  protected :
    LIST<int> who_wait;

  public :
    ERROR_HANDLER();
    virtual ~ERROR_HANDLER(void);

    DECLARE_HANDLER;
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
