// ============================================================================ 
//  
//  
//  
// ============================================================================ 
#ifndef __Dao_geom__
#define __Dao_geom__

#include <List.h> 
#include <Geometry_parts.h> 
#include <Base_problem.h> 
#include <Buffered_list.h>
#include <Graphics_application.h> 
#include <Graphics_data_dialog.h> 
#include <Zmaster_extension.h> 
#include <Axis.h>

#include <Master_interactive_lexer_control.h>

#include <Geometry_actor.h>
#include <Mesh_actor.h>
#include <Print_actor.h>
//#include <Transform_geometry.h> 

Z_START_NAMESPACE;

class ASCII_FILE; 

class PLOT_COMMAND; 
class MESH_COMMAND; 
class SELECT_COMMAND; 
class MESHER_MODULE; 
class DAO_GRID; 
class RESULTS_POST_RECORD; 
class RESULTS_MANAGER_COMMAND;
class UTILITY_NODE;
class TRANSFORMERS;
class DAO_EDGE_GROUP; 
class ZMASTER_EXTENSION; 
class SAVED_VIEW_UTILITY; 
class SAVED_VIEW_SPEC;
class LIGHT_COMMAND;
class HIGHLIGHT_MESH_OBJECTS_COMMAND;
class VIEW_OPTIONS_COMMAND;
class UNLOAD_MESH_DIALOG;
class SPLIT_SEQ_PROBLEM;
class CONFIG_VM_DIALOG;
class QUICK_PARALLEL_OPEN;
class SUB_DOMAIN;

extern WIN_THINGIE2 int    global_tried_to_set_view; 

ZCLASS2 DAO_GEOMETRY : public BASE_PROBLEM, 
                     public GRAPHICS_APPLICATION { 
   protected :
     LIST<STRING> all_commands_type;
     LIST<STRING> all_hidden_commands_type;
     LIST<ZMASTER_EXTENSION*> all_commands;
     LIST<ZMASTER_CMD_EXTENSION*> all_hidden_commands;

     friend class SAVED_VIEW_UTILITY;
     int version; // version of the last .mast file read
     GRAPHICS_DATA_DIALOG*           elset_option_dialog;
     SUB_DOMAIN *sub_domain;

     HIGHLIGHT_MESH_OBJECTS_COMMAND* highlight_mesh_objects_command;
     VIEW_OPTIONS_COMMAND*           view_options_command;
     UNLOAD_MESH_DIALOG*             unload_mesh_dialog;
     CONFIG_VM_DIALOG*               Config_VM_dialog;
     SPLIT_SEQ_PROBLEM*              Split_seq_problem;
     QUICK_PARALLEL_OPEN*            Quick_parallel_open;
     LIGHT_COMMAND*                  light_command;

     STRING unit; 

     int *_do_make_wrap;

     float Win1_xinf, Win1_xsup, Win1_yinf, Win1_ysup; 
     float Preci_fusion_points, Rayon_digit, Shrink_factor; 
     // vars 2 
     int  Degre_interpolation;   
     char Type_element[5]; // VC: To avoid buff overflow (STRING contains an end marker char)
     char Integration_reduite[5]; 

     // vars 3 
     int  Working_layer, Visu_point, Visu_fil1d; 
     int  Visu_domaine,  Visu_element, Visu_noeud; 
     int  Visu_decoupage, Visu_texte,  Visu_cotation; 

     // vars 4 
     int Propagation_taille; 
     int Nb_int_param, Nb_float_param; 
     int If_english; 
     int Auto_t3q4; 

     int num_texte, num_spring, num_noeud_quart; 

     virtual void delete_all(); 

     virtual void do_group();
     virtual void do_ungroup();

     virtual void add_objects_to_ga(); 
     virtual void set_defaults(); 
     virtual void clear_all_unused(); 

     virtual void read_iges(STRING name); 
     virtual void write_iges(STRING name);
     virtual void write_geof(STRING name);

     virtual void build_menu();
     virtual void build_commands();

     void consolidate_a_name(BUFF_LIST<STRING>&,DAO_GEOM_PIECE*,BUFF_LIST<DAO_GEOM_PIECE*>&);
     void consolidate_names();
     void propagate_names();

     void update_meshfusion();

   public : 
     int   arc_res; 
     int   bspline_res; 
     STRING display_elset;
     bool needs_unshared_faces , deformed;

     // used to update the rot_center in defromed mode
     int mesh_center;
     UTILITY_NODE* node_center;
   
     GEOMETRY_ACTOR *geometry_actor;
     MESH_ACTOR     *mesh_actor;
     PRINT_ACTOR    *print_actor;

     MASTER_INTERACTIVE_LEXER_CONTROL *engine;
     // Command bar.. 
     // 
     MESH_COMMAND*     its_mesh_cmd;
     PLOT_COMMAND*     its_plot_cmd;
//     GRAPHICS_COMMAND* its_light_cmd;
     SELECT_COMMAND* its_geom_cmd;
     RESULTS_MANAGER_COMMAND*  its_resu_cmd;
     GRAPHICS_COMMAND* its_run_cmd;

     DAO_GRID*          active_grid; 
     DAO_TRANSFORM*     active_xform; 
     BUFF_LIST<DAO_TRANSFORM*> xforms; 

     BUFF_LIST<DAO_POINT*>   fused_pts; BUFF_LIST<int> new_ids; 

     BUFF_LIST<DAO_POINT*>   point; 
     BUFF_LIST<DAO_LINE*>    line; 
     BUFF_LIST<DAO_ARC*>     arc; 
     BUFF_LIST<DAO_DOMAIN*>  domain; 
     BUFF_LIST<DAO_NSET*>    nset; 
     BUFF_LIST<DAO_ELSET*>   elset; 
     BUFF_LIST<DAO_LISET*>   liset; 
     BUFF_LIST<DAO_EDGE*>    other_entities; 
     BUFF_LIST<DAO_EDGE_GROUP*> groups; 
     BUFF_LIST<AXIS*>        axis;


     BUFF_LIST<GRAPHICS_EDGE*> liset_edges;
     BUFF_LIST<DAO_EDGE*>    get_all_edges();


     // 
     // Living with some older class hierarchies here.. 
     // it's a bit confused having two types here.. 
     // 
     LIST<STRING>         transformers_types; 
     LIST<STRING>         transformers_names; 
     LIST<TRANSFORMERS*>         transformers; 

     PLIST<RESULTS_POST_RECORD>  user_posts; 

     // 
     // List saved views 
     // 
     GRAPHICS_DATA_DIALOG* view_option_dialog;
     void view_option_command(STRING cmd); 
     
     // List saved views -> A_R: should move it to view_options_command?
     //
     SAVED_VIEW_UTILITY*   saved_view_util;
     LIST<SAVED_VIEW_SPEC*>   saved_views;

     //
     // These vars are adjustable on the view options dialog
     // 
     LIST< LIST<int> >                visible_elsets; 
     LIST< LIST<B_UTILITY_SET*> >     visible_bsets; 
     LIST< BUFF_LIST<UTILITY_NODE*> > visible_nodes; 
     int cull_face0;
     bool changed_hidden_fasets;
     LIST< LIST<int> >                hidden_fasets; 

     int display_axes; 
     int display_points; 
     int display_nodes; 
     int display_elements; 
     int display_domains; 
     double shrink;                  // element shrink factor for domains

     // 
     // These concern the "memory" of mesh dim/element
     // types, etc. 
     // 
     int  keep_mesh_flag; 
     int  keep_mesh_dimension; 
     int  keep_mesh_integration; 
     int  keep_mesh_interpolation; 
     int  keep_mesh_element; 
     void check_keep_mesh(); 

     DAO_GEOMETRY(); 
     virtual ~DAO_GEOMETRY(); 

     virtual bool Execute();
     virtual void end_of_initialization();
     virtual void initialize();
     virtual int parallelized(void) { return(1); }
     virtual DAO_GEOMETRY* get_dao_geom() { return(this); }
     virtual void load(const STRING&,const STRING&); 
     virtual void set_message_handling(const STRING&);
     virtual bool do_command(STRING cmd);
     virtual bool do_base_command(STRING cmd); 

     virtual void new_app(STRING); 
     virtual void quit();
     virtual void save(); 
     virtual void save_as(STRING format, STRING name); 
     virtual void open(STRING name);
     virtual void open_file(STRING name);
     virtual void append(STRING name);
     virtual void read_geof(STRING fname); 
     virtual void read_geof(STRING fname, STRING fmt); 
     virtual void write_master(STRING name);
     virtual void read_master(STRING name);

     virtual void set_autoscale(); 
     virtual void set_graphics_area(GRAPHICS_AREA* ga); 

     DAO_POINT*  get_select_point(GRAPHICS_OBJECT* targ); 
     VECTOR      get_click_point(GRAPHICS_POINT& pt); 
     DAO_POINT*  get_point_near(double x, double y, double z); 

     DAO_POINT*  point_with_name(STRING); 
     DAO_POINT*  point_with_id(int); 
     DAO_EDGE*   edge_with_name(STRING); 
     DAO_TRANSFORM* xform_with_name(STRING); 

     // 
     // Does a search for exisiting x-forms, or adds a new one. 
     // 
     DAO_TRANSFORM* get_xform(DAO_GRID* grd); 

     VECTOR get_active_plane_norm()const; 

     GRAPHICS_COMMAND* get_command_named(STRING name); 
     void extract_skin();
     void extract_liset_edges();
     void find_visible_bsets();
     

     
}; 
Z_END_NAMESPACE;

#endif 
