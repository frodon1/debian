#ifndef __REFINEMENT_DENSITY__
#define __REFINEMENT_DENSITY__

#include <Utility_mesh.h>
#include <Vector.h>

Z_START_NAMESPACE;

class REFINEMENT_DENSITY
{
  protected :
    double power, minsize, maxsize;
    double max_initial_density, max_distance_to_front;
    STRING front_name;
    
    ARRAY<VECTOR> front_nodes_pos;

    double get_length(UTILITY_BOUNDARY& edge);
    double distance_to_front(const VECTOR& pos);

  public :
    REFINEMENT_DENSITY();
    ~REFINEMENT_DENSITY();

    void initialize(UTILITY_MESH &mesh, STRING&, double, double, double);
    void surfacic_density(ARRAY<UTILITY_NODE*> &nodes, VECTOR &densities, bool vol=FALSE);
    void volumic_density(ARRAY<UTILITY_NODE*> &nodes, VECTOR &densities){ surfacic_density(nodes,densities); }
};

Z_END_NAMESPACE;
#endif
