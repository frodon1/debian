#ifndef __Utility_database_element__
#define __Utility_database_element__

#include <Post_element.h>
#include <Post_mesh.h>
#include <Utility_database_source.h> 
#include <Predefined_section_mesh.h> 

Z_START_NAMESPACE;

ZCLASS2 UTILITY_DATABASE_DS_ELEMENT : public POST_ELEMENT {
  public :
    STRING its_name;

    static AUTO_PTR<SINGLE_GP_UNIT_PREDEFINED_SECTION>  stat_def_section; 

    UTILITY_DATABASE_DS_ELEMENT(); 
    virtual ~UTILITY_DATABASE_DS_ELEMENT();

    virtual void size(int nb_card_in, int nb_in, int nb_out, bool every_card,PDT_GROUP grp);
    virtual void erase();

    virtual void check_for_section(GEOMETRY* geo,  
                                     GMESH* m,  
                                     BUFF_LIST<UTILITY_ELSET*>& esets);

    void initialize_element(const ARRAY<GNODE*>& element_nodes,
                              GMESH* m,
                              GEOMETRY* geo,
                              char *the_im,
                              int elem_id,
                              const char* ele_type);

    // 
    // Now data read/write methods 
    // 
    virtual void load(int ic, 
                      int card_id,
                      const ARRAY<int>& pos,
                      const ARRAY<POST_DATA_TYPE>& pdt,
                      PDT_GROUP grp,
                      const ARRAY<int>& rk_utp_card);

    virtual void read_native(int iv, int ic,
                        int card_id,
                        const ARRAY<int>& pos,
                        const ARRAY<POST_DATA_TYPE>& pdt,
                        PDT_GROUP grp,
                        const ARRAY<int>& rk_utp_card);

    virtual void write(int ic,int card_id, const ARRAY<int>& pos, POST_DATA_TYPE pdt);
    virtual void write(int ic,int card_id, const ARRAY<int>& pos, POST_DATA_TYPE pdt, int ip);

    UTILITY_DATABASE_DS_NODE* get_ds_node(int inode) {
       return (UTILITY_DATABASE_DS_NODE*)ELEMENT::get_node(inode);
    }
    const UTILITY_DATABASE_DS_NODE* get_ds_node(int inode)const {
      return (UTILITY_DATABASE_DS_NODE*)ELEMENT::get_node(inode); 
    }

};

Z_END_NAMESPACE;

#endif 
