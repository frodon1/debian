#ifndef __EXPLICIT_MESH__
#define __EXPLICIT_MESH__

#include <Pointer.h>
#include <Mechanical_mesh.h>
#include <Mechanical_element.h>
#include <Elastic_properties_perturbation.h>

Z_START_NAMESPACE;

class INTEGRATION_RESULT;
class PROBLEM_EXPLICIT_MECHANICAL;

ZCLASS2 EXPLICIT_MESH : public DYNAMIC_MESH {
  void dump_details();

 public :
  PROBLEM_EXPLICIT_MECHANICAL* its_boss; 

  int              every_update;
  int              count_update;
  unsigned int     time_for_update; 
  VECTOR           keep_fixed;
  ARRAY<DOF*>      U_dofs;
  ARRAY<double>      initial_coords;  //Associated to U_dofs
  VECTOR           diagonal_mass_matrix;
  double           delta_t_critical,alpha;
  int              delta_t_critical_element_rank;
  int              use_elem_props; 
  int              require_strain_rate; 

  LIST<ELSET*> penalty_elset;
  LIST<double> penalty;

  PTR<ELASTIC_PROPERTY_PERTURBATION> perturb_method;

  void calc_matl_stress_strain(MECHANICAL_ELEMENT& the_element,
                               ARRAY<VECTOR>& eto_1,
                               ARRAY<VECTOR>& sig_1);


  EXPLICIT_MESH();
  virtual ~EXPLICIT_MESH();

  INTEGRATION_RESULT* MT_get_force(VECTOR&,VECTOR&,VECTOR&);
  INTEGRATION_RESULT* get_force(VECTOR&,VECTOR&,VECTOR&);
  void compute_diagonal_mass_matrix();

  double get_penalty(D_ELEMENT*)const;

  void initialize();
  virtual void read_specials(ASCII_FILE&);

  virtual void update_dofs_ini(VECTOR& u);

  virtual void update_dofs(VECTOR& u, 
                           VECTOR& du);

  int dimension() { return node[0]->coord0.size(); }
  int nb_gp();

  virtual void apply_bc();
  virtual void update_V(VECTOR&);









  /// 
  /// Data & functions for special element calculations. We do want to use 
  /// all the std mechanical elements so an EXPLICIT_MECHANICAL_ELEMENT class  
  /// is not the good idea.
  /// 
  class EXPLICIT_ELE_DATA { 
  public:
    double        critical_dtime;  ///<Critical time step
    double        Le;              ///<chatacteristic length  
    bool          use_fake_rho;
    double        fake_rho;
    //  LIST<double>  lambda_0,mu_0;

    int           fs_type; 
    double        K_max; 
    double        mu_max; 

    bool          mass_scaling;
    double        mass_scaling_dt;
    double        mass_scaling_factor;
    EXPLICIT_ELE_DATA(); 

    ARRAY<VECTOR>  eto_1, eto_2; 
    ARRAY<VECTOR>  sig_1, sig_2; 
  }; 
  ARRAY<EXPLICIT_ELE_DATA> ele_data;

  double update_critical_dtime(MECHANICAL_ELEMENT& the_element,
                               ARRAY<VECTOR>& eto1,
                               ARRAY<VECTOR>& sig1,
                               ARRAY<VECTOR>& eto2,
                               ARRAY<VECTOR>& sig2);

  void ele_initialize(MECHANICAL_ELEMENT* ele);
     
  double ele_compute_size(MECHANICAL_ELEMENT* ele);

  void ele_compute_diagonal_mass_matrix(MECHANICAL_ELEMENT* ele, VECTOR& small_mass);


  // 
  // Hackery so we can create any mechanical element with this mesh object. 
  // 
  virtual const char*  __type()const {  return("MECHANICAL_MESH"); }
  virtual bool         __are_you_a(const char* t)const { 
    if (strcmp(t,"MECHANICAL_MESH")==0) return TRUE; 
    return MECHANICAL_MESH::__are_you_a(t); 
  } 
  virtual const char*  isA()const { return(__type()); }
  virtual bool         areYouA(const char* t)const { return(__are_you_a(t)); }
  virtual bool verification() { return MECHANICAL_MESH::verification(); } 

};
Z_END_NAMESPACE;

#endif
