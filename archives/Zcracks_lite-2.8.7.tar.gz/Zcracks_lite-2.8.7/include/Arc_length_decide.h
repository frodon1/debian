// Norbert Germain
// Johann Rannou

// Implementation of  root selectors.
// Constraint equations have indeed several roots. We need to choose the correct one. 
// The selection is made in the method "calcul"
//


//Good references :

// On the arc-length and other quadratic control methods: Established, less known and new implementation procedure, 
// Ritto-Correa M. and Camotim, D. 
// Computers and Structures 2008

// A new arc-length method for handling sharp snap-backs
// Hellweg, H.B. and Crisfield, MA
// Computers and Structures,  1998



#ifndef __NG_RIKS_DECIDE__
#define __NG_RIKS_DECIDE__
                                                                                
#include <Object_factory.h>
#include <Clock.h>
#include <Contact.h>
#include <Dimension.h>
#include <Error_messager.h>
#include <Function.h>
#include <Global_matrix.h>
#include <Integration_result.h>
#include <Mechanical_algorithm.h>
#include <Mesh.h>
#include <Zminmax.h>
#include <Mesh.h>
#include <Node.h>
#include <Output.h>
#include <Problem.h>
#include <Random_distribution.h>
#include <Sequence.h>
#include <Dof_setter.h>
#include <Discrete_timer.h>
#include <Output.h>
#include <NNset.h>

Z_START_NAMESPACE;

class RIKS_CHOICE;
class RIKS_TEST;
class RIKS_CRITERION;

//
// NG 03/2004
//

class RIKS_DECIDE
{
  protected :
    bool first_time;
    bool first_time_save;
    VECTOR U_pred_tot,U0_pred_tot;
    VECTOR prev_incr_tot;
    double lambda_pred;
    RIKS_CHOICE* riks_choice;
    RIKS_TEST* riks_test;
    RIKS_CRITERION* riks_criterion;

  public :
    void info(RIKS_CHOICE* ,RIKS_TEST* ,RIKS_CRITERION* );
    RIKS_DECIDE();
    virtual ~RIKS_DECIDE(){};
    virtual void read_data(ASCII_FILE&,PROBLEM*)=0;
    virtual ARRAY<double> calcul(ARRAY<double>,VECTOR,VECTOR,VECTOR,VECTOR)=0;
    virtual void save_U0(VECTOR&,double);
};
                                                                          
class RIKS_DECIDE_ANGLE : public  RIKS_DECIDE
{
  protected :
    STRING type;
  public :
    RIKS_DECIDE_ANGLE();
    virtual ~RIKS_DECIDE_ANGLE(){};
    virtual void read_data(ASCII_FILE&,PROBLEM*);
    virtual ARRAY<double> calcul(ARRAY<double>,VECTOR,VECTOR,VECTOR,VECTOR);
};
                                                                 
class RIKS_DECIDE_ARC : public  RIKS_DECIDE
{
  protected :
    STRING type;
  public :
    RIKS_DECIDE_ARC();
    virtual ~RIKS_DECIDE_ARC(){};
    virtual void read_data(ASCII_FILE&,PROBLEM*);
    virtual ARRAY<double> calcul(ARRAY<double>,VECTOR,VECTOR,VECTOR,VECTOR);
};

//
// ??
//

class RIKS_DECIDE_LAMBDA : public  RIKS_DECIDE
{
  protected :
    STRING type;
  public :
    RIKS_DECIDE_LAMBDA();
    virtual ~RIKS_DECIDE_LAMBDA(){};
    virtual void read_data(ASCII_FILE&,PROBLEM*);
    virtual ARRAY<double> calcul(ARRAY<double>,VECTOR,VECTOR,VECTOR,VECTOR);
};

//
// Outwards criterion from Ritto-Comotim  (see Ref, equation 20)
//
                                                                      
class RIKS_DECIDE_OUTWARDS : public  RIKS_DECIDE
{
  protected :
    STRING type;
    double psi2;
  public :
    RIKS_DECIDE_OUTWARDS();
    virtual ~RIKS_DECIDE_OUTWARDS(){};
    virtual void read_data(ASCII_FILE&,PROBLEM*);
    virtual ARRAY<double> calcul(ARRAY<double>,VECTOR,VECTOR,VECTOR,VECTOR);
};

//
//Minimum residual criterion
//
//See ref Hellweg/Crisfield 1998
//
// This method is special since it requires the computations of the solutions for all lambdas.  
// The selection of the right lambda is performed with the residual of the equilibrium equation
// The selection therefore can not be made here and calcul sends back all the roots.
// The implementation of the residual selector is void here
//
                                                                             
class RIKS_DECIDE_RESIDUAL : public  RIKS_DECIDE
{
  protected :
    STRING type;
  public :
    RIKS_DECIDE_RESIDUAL();
    virtual ~RIKS_DECIDE_RESIDUAL(){};
    virtual void read_data(ASCII_FILE&,PROBLEM*);
    virtual ARRAY<double> calcul(ARRAY<double>,VECTOR,VECTOR,VECTOR,VECTOR);
};

Z_END_NAMESPACE;

#endif
