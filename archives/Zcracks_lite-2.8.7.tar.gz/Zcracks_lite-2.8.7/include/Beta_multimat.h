//
// A material law for ferrite/austenite composites
//

#ifndef __Beta_multimat__
#define __Beta_multimat__

#include <ZMath.h>
#include <Beta_model.h>
#include <Clock.h>
#include <Defines.h>
#include <Dictionnary.h>
#include <Error_messager.h>
#include <File.h>
#include <Integration_result.h>
#include <Localization.h>
#include <Mecha_multi_mat_homo.h>
#include <Object_factory.h>
#include <Rotation.h>

Z_START_NAMESPACE;

ZCLASS BETA_MULTIMAT : public MECHA_MULTI_MAT_HOMO  {
   TENSOR2 dsig;
 protected :
   PLIST< BETA_VARIABLE >  _beta;
   PLIST< LOCALIZATION > _localiz;   
   LOCALIZATION* one_localization;
   BETA_VARIABLE*  one_beta;

   TENSOR4        Ccm1, Lc, Lcm1; 
   ARRAY<TENSOR4> x_L, _Cm1L;
   ARRAY<bool> _constant_L;
   TENSOR2 dBeta;

   TENSOR4& L()    { return x_L[iib]; }
   TENSOR4& Cm1L() { return _Cm1L[iib]; }
   bool& constant_L() { return _constant_L[iib]; }
   BETA_VARIABLE& beta()     { return *(_beta[iib]()); }
   LOCALIZATION& localiz() { return *(_localiz[iib]()); }

   bool Ls_computed, all_L_constant;
   void compute_Ls();
 public :
   BETA_MULTIMAT();
   virtual ~BETA_MULTIMAT();
   virtual int base_read(const STRING&,ASCII_FILE&,LOCAL_INTEGRATION*);
   virtual void initialize(ASCII_FILE&, int, LOCAL_INTEGRATION*);
   virtual void derivative(double, const VECTOR& chi_vec,VECTOR& dvar); 
   virtual void apply_localization();
         TENSOR2& get_dsig()      { return dsig; }
   const TENSOR2& get_dsig()const { return dsig; }
};
Z_END_NAMESPACE;

#endif 
