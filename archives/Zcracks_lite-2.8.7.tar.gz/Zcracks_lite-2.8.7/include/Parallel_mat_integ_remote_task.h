#ifndef __PARALLEL_MAT_INTEG_REMOTE_TASK__
#define __PARALLEL_MAT_INTEG_REMOTE_TASK__

#include <Base_problem.h>
#include <Object_factory.h>
#include <Unix_tools.h>
#include <Parallel_remote_task.h>
#include <Pmi_slave.h>
#include <Z_object.h>
#include <Zunistd.h>

Z_START_NAMESPACE;

class PARALLEL_MAT_INTEG_REMOTE_TASK : public PARALLEL_REMOTE_TASK
{
  protected :
    bool initialized;

    void put_mat_var();
    void put_decomposition();
    void internal_reaction();
    void init();
    void reinit();
    void reset();
    void send_mat_var();
    void end();

    STRING pb_name;
    PROBLEM *its_problem;
    PMI_SLAVE *its_pmi;

  public :
    enum TAGS { MAT_INTEG=200 , PUT_MAT_VAR=0 , PUT_DECOMPOSITION=1 , INTERNAL_REACTION=2 , REINIT=4 , SEND_MAT_VAR=8 , END=16 , INIT=32 , RESET=64 };

    PARALLEL_MAT_INTEG_REMOTE_TASK() : PARALLEL_REMOTE_TASK() { initialized=false; }
    virtual ~PARALLEL_MAT_INTEG_REMOTE_TASK() { }

    virtual int handle_message(int);
    virtual int get_tag() { return(MAT_INTEG); }
};

Z_END_NAMESPACE;

#endif
