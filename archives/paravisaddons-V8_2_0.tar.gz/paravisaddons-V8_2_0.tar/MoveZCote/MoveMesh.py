#### import the simple module from the paraview
from paraview.simple import *
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

# create a new 'MED Reader'
#f3d_gouttedomed = MEDReader(FileName='/home/H87074/TMP52/f3d_gouttedo.med')
#f3d_gouttedomed.AllArrays = ['TS0/MESH/ComSup0/COTE Z@@][@@P1', 'TS0/MESH/ComSup0/VITESSE U@@][@@P1', 'TS0/MESH/ComSup0/VITESSE V@@][@@P1', 'TS0/MESH/ComSup0/VITESSE W@@][@@P1']
#f3d_gouttedomed.AllTimeSteps = ['0000', '0001', '0002', '0003', '0004', '0005', '0006', '0007', '0008', '0009', '00010']

source = GetActiveSource()
renderView1 = GetActiveViewOrCreate('RenderView')
# get animation scene
animationScene1 = GetAnimationScene()

# update animation scene based on data timesteps
animationScene1.UpdateAnimationUsingDataTimeSteps()

# create a new 'Calculator'
calculator1 = Calculator(Input=source)

# Properties modified on calculator1
calculator1.ResultArrayName = 'DisplacementsZ'
calculator1.Function = 'COTE Z-coordsZ'

# get color transfer function/color map for 'DisplacementsZ'
displacementsZLUT = GetColorTransferFunction('DisplacementsZ')

# show data in view
#calculator1Display = Show(calculator1, renderView1)

# hide data in view
Hide(source, renderView1)

# show color bar/color legend
#calculator1Display.SetScalarBarVisibility(renderView1, True)

# get opacity transfer function/opacity map for 'DisplacementsZ'

# create a new 'Warp By Scalar'
warpByScalar1 = WarpByScalar(Input=calculator1)
warpByScalar1.Scalars = ['POINTS', 'DisplacementsZ']

