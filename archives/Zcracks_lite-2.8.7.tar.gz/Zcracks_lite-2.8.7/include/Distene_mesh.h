#ifndef __DISTENE_MESH_READER__
#define __DISTENE_MESH_READER__

#include <Zstream.h>

#include <Utility_mesh.h>
#include <Utility_mesh_reader.h>
#include <Utility_results_database.h>
#include <Error_messager.h>

Z_START_NAMESPACE;

//
// 2008-05-10 VAL: readers for various Distene mesh formats
//

class YAMS_MESH_READER : public UTILITY_MESH_READER
{
  public :

    YAMS_MESH_READER() : UTILITY_MESH_READER() { }
    virtual ~YAMS_MESH_READER() { }

    virtual STRING default_extension() { return(".mesh"); }
    virtual void initialize(ASCII_FILE& file, UTILITY_MESH* mesh);

};

class YAMS_MESH_DENSITY : public UTILITY_RESULTS_DATABASE 
{
  protected :
    STRING file_prefix;

  public :
    YAMS_MESH_DENSITY();
    virtual ~YAMS_MESH_DENSITY() {}

    virtual void initialize(const STRING& problem_name);

    virtual bool get_ctnod_results(int map, const STRING& comp);
    virtual void generate_location_list(int& all_location_flags);
    virtual void generate_node_variable_list(LIST<STRING>&);
};


class GHS3D_MESH_READER : public UTILITY_MESH_READER
{
  public :

    GHS3D_MESH_READER() : UTILITY_MESH_READER() { }
    virtual ~GHS3D_MESH_READER() { }

    virtual STRING default_extension() { return(".meshb"); }
    virtual void initialize(ASCII_FILE& file, UTILITY_MESH* mesh);
};

class GHS3D_ASCII_MESH_READER : public UTILITY_MESH_READER
{
  public :

    GHS3D_ASCII_MESH_READER() : UTILITY_MESH_READER() { }
    virtual ~GHS3D_ASCII_MESH_READER() { }

    virtual STRING default_extension() { return(".mesh"); }
    virtual void initialize(ASCII_FILE& file, UTILITY_MESH* mesh);
};
Z_END_NAMESPACE;

#endif
