#ifndef __Post_node__
#define __Post_node__

#include <GNode.h>
#include <Integ_data.h>
#include <Node_data.h>
#include <Post_data_type.h>

Z_START_NAMESPACE;

ZCLASS2 POST_NODE : public GNODE {
  protected :
    friend class POST_MESH; friend class LOCAL_POST_PROCESSING;
    friend class GLOBAL_POST_PROCESSING;

    long       off_node;
    long       off_ctnod;

  public :
    int        flags; 

    int ctnod_rank;

    // 
    // Sized to number of outputs (cards) we have. Each data has member "data"
    // which is the input I need, and "out" where the output goes for the 
    // current task at hand of a global post computation 
    // 
    ARRAY<NODE_DATA>  data;
    POST_NODE();
    POST_NODE(int,const VECTOR&);
    virtual ~POST_NODE();

    virtual void size(int nb_card,int nb_in, int nb_out,bool every_card);
    virtual void erase();
    virtual void load(int,int,int,const ARRAY<int>&,const ARRAY<POST_DATA_TYPE>&);
    virtual void write(int,int,const ARRAY<int>&, int output_to_node);
};

Z_END_NAMESPACE;
#endif

