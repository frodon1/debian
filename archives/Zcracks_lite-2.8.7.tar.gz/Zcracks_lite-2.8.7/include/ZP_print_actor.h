#ifndef __ZP_PRINT_ACTOR__
#define __ZP_PRINT_ACTOR__

#include <Print_actor.h>
#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>

Z_START_NAMESPACE;

ZCLASS ZP_PRINT_ACTOR : public ZP_BASIC_TYPE< PRINT_ACTOR >
{
  protected :
    virtual ZP_FATAL_ERROR* print(ZP_STACK&,int);
    virtual void type_init(char*) { type="PRINT_ACTOR"; }

  public :
    BASIC_CONSTRUCTORS(ZP_PRINT_ACTOR,PRINT_ACTOR)

    METHOD_DECLARATION_START
      METHOD("print",print,0)
    METHOD_DECLARATION_ANCESTOR(ZP_BASIC_TYPE< PRINT_ACTOR >)

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
    ZPO_RTTI_INFO(PRINT_ACTOR)
};
Z_END_NAMESPACE;

#endif
