#ifndef __Crack_behavior__ 
#define __Crack_behavior__ 

// ----------------------------------------------------------------------------
//  CRACK_GROWTH_BEHAVIOR                                         RF 07/04/2003
//
//  a container for crack growth behaviors... combining driving forces, growth 
//  rate models, and interactions.  a little modeled after gen_evp. 
//  
//  right now i'm implementing the "standard" behavior right in the base class 
//  in order to see how this grows... it is still an obj-factory item however. 
//  my problem is that i want the forces and rates to find each other based on 
//  this object. 
//
//  being bold making these things behavior/material pieces.. re-use away 
//  these are however obj-factor registered as CRACK_GROWTH_BEHAVIOR not BEHAVIOR 
//
//  ** the behavior is self contained for now.. so it stores its own mat data.. 
//  instead of the class owning the behavior to hold the mat data.. because a 
//  crack is a discrete item i figure this is the proper way to handle that..? 
//
//  ** verify w/auto step 
//  ** Need restart info 
//  ** Need connection to transfer somehow in order that the force get its 
//     global results data... connected now using a global variable for 
//     active_transfer!! 
// ----------------------------------------------------------------------------

#include <Crack_growth_models.h> 
#include <Crack_driving_force.h> 
#include <Behavior.h> 
#include <Utility_mesh.h> 
#include <Mesh.h> 

Z_START_NAMESPACE;

class CRACK_GROWTH_BEHAVIOR; 
class OUTPUT_CONTROL; 

ZCLASS2 CRACK_GROWTH_BEHAVIOR : public BEHAVIOR {
  protected :
    PLIST<CRACK_DRIVING_FORCE> force; 
    PLIST<CRACK_GROWTH_MODEL>  rate; 
//  PLIST<CRACK_GROWTH_INTERACTION> interaction;  // someday 

    double                     last_time_ini;     // used to determine when to fix mdat 
    OUTPUT_CONTROL*            growth_control;    // maybe multiple ones? 
 
    virtual void reinit(); 

  public :
    MAT_DATA     m_mdat;
    VECTOR_FLUX   crack_length;

    CRACK_GROWTH_BEHAVIOR(); 
    virtual ~CRACK_GROWTH_BEHAVIOR(); 
    virtual void initialize(ASCII_FILE& file); 

    static CRACK_GROWTH_BEHAVIOR* read_crack_behavior(int dim,
                         STRING mat_file,  
                         LOCAL_INTEGRATION* integr,
                         int material_pos);
 
    virtual void initialize(  ASCII_FILE& file,
                              int prob_size,
                              LOCAL_INTEGRATION* integ);

    virtual int  base_read(const STRING& tok, ASCII_FILE& file);

    virtual VECTOR growth_increment(UTILITY_MESH& mesh);
    virtual VECTOR growth_increment(MESH& mesh);
    RTTI_INFO;

};

Z_END_NAMESPACE;
#endif

