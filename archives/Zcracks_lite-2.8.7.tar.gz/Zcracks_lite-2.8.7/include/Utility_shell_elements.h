#ifndef __SHELL_ELEMENTS__
#define __SHELL_ELEMENTS__

#include <Object_factory.h>
#include <Defines.h>
#include <Error_messager.h>
#include <Help.h>
#include <Out_message.h>
#include <Stringpp.h>
#include <Verbose.h>
#include <Graphics_area.h>

#include <Utility_mesh.h>
#include <Print.h>

#include <Utility_boundary.h>
#include <Interpolation.h>

#include <Utility_relations.h>
#include <Std_utility_rel_face.h>

Z_START_NAMESPACE;

#define ELEMENT_LOADER(a,b) DECLARE_OBJECT(UTILITY_ELEMENT, a , b )
#define pt(rank) (nodes[rank]->position)

// ============================================================================
//  UTILITY_SHELL  base class with the special output stuff... 
// 
// ============================================================================

ZCLASS UTILITY_SHELL : public UTILITY_ELEMENT {
  protected :
    int view_layer; // 0 : view top, 1 : view bottom

  public : 
    UTILITY_SHELL() : UTILITY_ELEMENT() { view_layer=0; } 
    UTILITY_SHELL(const UTILITY_SHELL& e) : UTILITY_ELEMENT(e) { } 
    virtual ~UTILITY_SHELL() { }

    virtual int  num_contour_vals()const { return 2*nodes.size(); } 
    virtual void build_gp_position();
    virtual void build_gp_position_deformed( ARRAY<VECTOR> &disp );
    virtual bool if_in(VECTOR& xi, const VECTOR xp, double tol, double tol2, int max_iter,double *det=NULL);
    void set_view_layer(int);
    RTTI_INFO;
}; 


// ============================================================================
//  Derived Elements
// ============================================================================

ZCLASS S3D3_UTILITY_ELEMENT : public UTILITY_SHELL {
  public :
    S3D3_UTILITY_ELEMENT() { space_dim=3; }
    virtual void initialize(const STRING& t) { 
         UTILITY_SHELL::initialize(t);
         nodes.resize(3);
         num_gp=2;
         // SQ 04/04/10 : have to fix num_gp (2 layers assumed by default)
         //if (t=="s3d3r") num_gp=2; else num_gp=12;
    }    
    S3D3_UTILITY_ELEMENT(const S3D3_UTILITY_ELEMENT& in) : UTILITY_SHELL(in) { }
    virtual UTILITY_ELEMENT* element_copy_self() {  return new S3D3_UTILITY_ELEMENT(*this); }

    virtual void to_quadratic();
    virtual void add_bsets(B_UTILITY_SET&, BUFF_LIST<UTILITY_NODE*>&);
    virtual ARRAY<UTILITY_BOUNDARY>& get_faces();
    virtual ARRAY<UTILITY_BOUNDARY>& get_edges();

    virtual void get_element_axis(ARRAY<VECTOR>& axes);
    virtual void set_integ(VECTOR& /* values */, int& index);
    virtual void set_integ_skin(VECTOR& values, int& index);
};


// ============================================================================
// ============================================================================

ZCLASS S3D6_UTILITY_ELEMENT : public UTILITY_SHELL {
  public :
    S3D6_UTILITY_ELEMENT() { space_dim=3; }
    virtual void initialize(const STRING& t) {
         UTILITY_SHELL::initialize(t);
         nodes.resize(6);
         if (t=="s3d6r") num_gp=6; else num_gp=12;
    }
    S3D6_UTILITY_ELEMENT(const S3D6_UTILITY_ELEMENT& in) : UTILITY_SHELL(in) { }
    virtual UTILITY_ELEMENT* element_copy_self() {  return new S3D6_UTILITY_ELEMENT(*this); }
    virtual UTILITY_ELEMENT* copy_to_linear(ARRAY<UTILITY_NODE*>& rem);

    virtual void set_integ(VECTOR& /* values */, int& index);
    virtual void set_integ_skin(VECTOR& values, int& index);
    virtual void add_bsets(B_UTILITY_SET&, BUFF_LIST<UTILITY_NODE*>&);
    virtual ARRAY<UTILITY_BOUNDARY>& get_faces();
    virtual ARRAY<UTILITY_BOUNDARY>& get_edges();
};

// ============================================================================
// ============================================================================
ZCLASS S3D4_UTILITY_ELEMENT : public UTILITY_SHELL {
  public :
    S3D4_UTILITY_ELEMENT() { space_dim=3; }
    virtual void initialize(const STRING& t) {
         UTILITY_SHELL::initialize(t);
         nodes.resize(4); 
         if (t=="s3d4r") num_gp=2; else num_gp=8;
    }
    S3D4_UTILITY_ELEMENT(const S3D4_UTILITY_ELEMENT& in) : UTILITY_SHELL(in) { }

    virtual void to_quadratic();
    virtual UTILITY_ELEMENT* element_copy_self() { return new S3D4_UTILITY_ELEMENT(*this); }
    virtual void add_bsets(B_UTILITY_SET&, BUFF_LIST<UTILITY_NODE*>&);
    virtual ARRAY<UTILITY_BOUNDARY>& get_faces();
    virtual ARRAY<UTILITY_BOUNDARY>& get_edges();

    virtual void set_integ(VECTOR& /* values */, int& index);
    virtual void set_integ_skin(VECTOR& values, int& index);
    virtual void get_element_axis(ARRAY<VECTOR>& axes);
};
 
// ============================================================================ 
ZCLASS S3D8_UTILITY_ELEMENT : public UTILITY_SHELL { 
  public : 
    S3D8_UTILITY_ELEMENT() { space_dim=3; }
    virtual void initialize(const STRING& t) {
         UTILITY_SHELL::initialize(t);
         nodes.resize(8);
         if (t=="s3d8r") num_gp=8; else num_gp=18;
    }

    S3D8_UTILITY_ELEMENT(const S3D8_UTILITY_ELEMENT& in) : UTILITY_SHELL(in) { } 
    virtual UTILITY_ELEMENT* element_copy_self() { return new S3D8_UTILITY_ELEMENT(*this); } 
    virtual UTILITY_ELEMENT* copy_to_linear(ARRAY<UTILITY_NODE*>& rem);
    virtual void set_integ(VECTOR& /* values */, int& index);
    virtual void set_integ_skin(VECTOR& values, int& index);
    virtual void add_bsets(B_UTILITY_SET&, BUFF_LIST<UTILITY_NODE*>&);
    virtual ARRAY<UTILITY_BOUNDARY>& get_faces();
    virtual ARRAY<UTILITY_BOUNDARY>& get_edges();
}; 
 
//
// Associated UTLITY_REL_ELEMENTs
//

ZCLASS UR_S3D3 : public UTILITY_REL_ELEMENT
{
  public :
    UR_S3D3() : UTILITY_REL_ELEMENT() { }
    virtual ~UR_S3D3() { }
                                                                                        
    virtual void to_quadratic();
    virtual void build_faces(BUFF_LIST<UTILITY_REL_FACE *>&);
    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE *>&) { }
                                                                                        
    RTTI_INFO;
};
                                                                                        
                                                                                        
ZCLASS UR_S3D4 : public UTILITY_REL_ELEMENT
{
  public :
    UR_S3D4() : UTILITY_REL_ELEMENT() { }
    virtual ~UR_S3D4() { }

    virtual void to_quadratic();
    virtual void build_faces(BUFF_LIST<UTILITY_REL_FACE *>&);
    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE *>&) { }

    RTTI_INFO;
};

ZCLASS UR_S3D6 : public UTILITY_REL_ELEMENT
{
  public :
    UR_S3D6() : UTILITY_REL_ELEMENT() { }
    virtual ~UR_S3D6() { }

    virtual void build_faces(BUFF_LIST<UTILITY_REL_FACE *>&);
    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE *>&) { }
                                                                                        
    RTTI_INFO;
};
                                                                                
ZCLASS UR_S3D8 : public UTILITY_REL_ELEMENT
{
  public :
    UR_S3D8() : UTILITY_REL_ELEMENT() { }
    virtual ~UR_S3D8() { }
                                                                                                      
    virtual void build_faces(BUFF_LIST<UTILITY_REL_FACE *>&);
    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE *>&) { }
                                                                                                      
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
