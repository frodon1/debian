#ifndef __AUTO_INPUT_READER_ASCII_FILE__
#define __AUTO_INPUT_READER_ASCII_FILE__

#include <Auto_input_reader.h>
#include <File.h>
#include <Zstream.h>

Z_START_NAMESPACE;

class AUTO_INPUT_READER_ASCII_FILE : public AUTO_INPUT_READER
{
  protected :
    STRING fname;
    bool del_inp,del_out;

  public :
    int level;
    ASCII_FILE *inp;
    Zofstream *out;

    AUTO_INPUT_READER_ASCII_FILE(ASCII_FILE &f) : AUTO_INPUT_READER() { inp=&f; del_inp=FALSE; out=NULL; del_out=FALSE; level=0; }
    AUTO_INPUT_READER_ASCII_FILE(Zofstream &f) : AUTO_INPUT_READER() { out=&f; del_out=FALSE; inp=NULL; del_inp=FALSE; level=0; }

    AUTO_INPUT_READER_ASCII_FILE() : AUTO_INPUT_READER() { del_inp=del_out=TRUE; inp=NULL; out=NULL; level=0; }

    virtual ~AUTO_INPUT_READER_ASCII_FILE() { 
      if(del_inp && inp) { delete(inp); inp=NULL; }
      if(del_out && out) { delete(out); out=NULL; }
    }

    bool open_in(STRING);
    bool open_out(STRING);

    virtual bool read(AUTO_PTR<AID_PART>&);
    virtual bool write(AUTO_PTR<AID_PART>&);
};
Z_END_NAMESPACE;

#endif
