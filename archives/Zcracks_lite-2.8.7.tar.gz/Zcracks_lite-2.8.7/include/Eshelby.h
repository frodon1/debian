#ifndef __Eshelby__
#define __Eshelby__

#include <ZMath.h>
#include <Zbool.h>
#include <Matrix.h>
#include <Rotation.h>
#include <Tensor4.h>

Z_START_NAMESPACE;

class ASCII_FILE;

ZCLASS ESHELBY : public TENSOR4 {
  private :
    double ratio, poisson, gamma;
    double a1, a2;
    double Gamma();
    void set();
    void set_elliptic_cylinder();
    AUTO_PTR<ROTATION> rotation;

  public :
    ESHELBY() : TENSOR4() {}
    ESHELBY(int sz);
    ESHELBY(int sz,double ratio,double poisson);
    ESHELBY(int sz,double a1,double a2, double poisson);
    ESHELBY(int sz,ROTATION*);
    ESHELBY(int sz,double ratio,double poisson,ROTATION*);

    void set(double ratio,double poisson);
    void set(double ratio,double poisson,ROTATION*);
    void set_elliptic_cylinder(double a1,double a2, double poisson);
    void set_poisson(double poisson);

    void read(ASCII_FILE&,int);

    ESHELBY& operator=(const ESHELBY& esh) { return (ESHELBY&)SMATRIX::operator=((SMATRIX&)esh); }
    ESHELBY& operator=(const SMATRIX& esh) {  return (ESHELBY&)SMATRIX::operator=(esh); }
};
Z_END_NAMESPACE;

#endif
