#ifndef __HYPERBOLIC_FLOW_LAW__
#define __HYPERBOLIC_FLOW_LAW__

#include <Dimension.h>
#include <Error_messager.h>
#include <File.h>
#include <Object_factory.h>

#include <Coefficient.h>
#include <Flow.h>
#include <Integration_theta.h>
#include <Potential.h>

Z_START_NAMESPACE;

class HYPERBOLIC_FLOW : public FLOW {
  protected:
     bool   discrete, update_lambda, keep_edot, compute_Kinf;
     POTENTIAL* pot;

     double  _os, _dt; 
     double  term1, term2, term3, term4; 
     // for norton_fallback method
     double _max, _Kinf, _ninf;
     COEFF   eps0, K, n, m; 

     double calc_lambda(double stress);

  public:

    bool   use_norton_fallback, is_finite, skip_lambda, automatic_reinit;

     // those are not coeffcients intentionally
    double  Kinf, ninf, edotmax;
    int integration;

    SCALAR_VAUX lambda;
    THETA* theta_integ;
    double cur_edotmax; 

           HYPERBOLIC_FLOW();
   virtual void initialize(ASCII_FILE& file, MATERIAL_PIECE*);
           HYPERBOLIC_FLOW(const HYPERBOLIC_FLOW& in, MATERIAL_PIECE*);
   virtual MATERIAL_PIECE* copy_self(MATERIAL_PIECE*);
   void update_integration_controls();
   void attach_all(MAT_DATA& mdat);
   void switch_to_integration(int);

   double  flow_rate(double v, double stress);

   double  dflow_dv();
   double  dflow_dcrit();  

   DERIVED;
};

Z_END_NAMESPACE;

#endif
