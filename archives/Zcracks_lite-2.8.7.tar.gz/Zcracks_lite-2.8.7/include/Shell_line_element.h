#ifndef __Shell_line_element__
#define __Shell_line_element__

// ============================================================================
//   WORK IN PROGRESS... DOES NOT YET FUNCTION
// ============================================================================

// ============================================================================ 
//   SHELL_LINE_ELEMENT    a line element which is better for shells. You 
//                         can set this one using a predefined mesh... or maybe 
//                         some other way... 
//   
//   ** I started writing this before i thought to change the use of 
//      integration type in the declare geometries and make_integration 
//      items (rf 01/23/2001), but am continuing with this as an example 
//      of how to fudge totally the geometry/integration ... this should go 
//      into the user project directory eventually. 
// 
//   I had to make these new elements in order to use Gauss-Labbato integration 
//   c.f. Zienk Pt II 5th ed (2000)
// ============================================================================ 

#include <Element.h>
#include <Space.h>

Z_START_NAMESPACE;

// ------------------------------------------------------------ 
//  A new geometry needed to add the make_integration overload, 
//  which has a new GAUSS_LOBBATO_INTEGRATION in it. 
//
//  I guess i could make some use of the INTEGRATION_MODE passed in 
//  to the DECLARE_GEOMETRY(s3d4, 4,2,4,_3D,GAUSS_POINT_INTEGRATION,ST_SHELL)
//  type lines. 
// ------------------------------------------------------------ 
ZCLASS2 SHELL_LINE_GEOMETRY : public SPACE1D { 
  public : 
    SHELL_LINE_GEOMETRY() { } 
    virtual ~SHELL_LINE_GEOMETRY() {}

    virtual void make_integration(const char* key);
}; 

ZCLASS2 SHELL_LINE_ELEMENT : public ELEMENT {
  public :
     virtual GEOMETRY* make_geometry(GMESH* boss_mesh,
                        int elem_id,
                        int number_nodes,
                        int number_gauss_points,
                        GEOM_TYPE gt,
                        SPACE_TYPE st,
                        const ARRAY<double>& real_constants);
    
     SHELL_LINE_ELEMENT() : ELEMENT() { } 
     virtual ~SHELL_LINE_ELEMENT();
};
Z_END_NAMESPACE;
	
#endif
