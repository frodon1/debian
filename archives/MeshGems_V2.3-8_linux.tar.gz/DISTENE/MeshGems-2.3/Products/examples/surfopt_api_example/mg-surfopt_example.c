#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/meshgems.h>
#include <meshgems/surfopt.h>

#define FREE_AND_STRDUP(_p_,_s_) if(_p_) free(_p_); _p_=NULL; _p_ = strdup(_s_)

/*
 * message callback function
 */
status_t my_message_cb(message_t * msg, void *user_data)
{
  FILE *f = (FILE *) user_data;
  char *desc;
  integer e, n, m;
  integer i, i_data[10];
  real r_data[10];
  n = m = 0;

  message_get_description(msg, &desc);
  message_get_number(msg, &e);

  if (e == 0) {
    fprintf(f, "mg-surfopt info : %s\n", desc);
  } else {
    if (e < 0) {
      fprintf(f, "mg-surfopt ERROR %i : %s\n", MESHGEMS_ABS_CODE(e), desc);
    } else {
      fprintf(f, "mg-surfopt info %i : %s\n", MESHGEMS_CODE(e), desc);
    }
    message_get_integer_data_count(msg, &n);
    message_get_real_data_count(msg, &m);
    if (e < 0 || n > 0 || m > 0) {
      fprintf(f, "MGMESSAGE %i ", e);
      fprintf(f, " %i", n);
      if (n > 0) {
        message_get_integer_data(msg, 1, n, i_data);
        for (i = 0; i < n; i++)
          fprintf(f, " %i", i_data[i]);
      }
      fprintf(f, " %i", m);
      if (m > 0) {
        message_get_real_data(msg, 1, m, r_data);
        for (i = 0; i < m; i++)
          fprintf(f, " %f", r_data[i]);
      }
      fprintf(f, " \n");
    }
  }
  fflush(f);

  return STATUS_OK;
}



/* A macro we will call to cleanly return from the function in case of
 * failure. Deleting the context will delete all attached MeshGems
 * object (sessions, meshes, sizemaps, ...)
 */
#define RETURN_WITH_MESSAGE(_ret, _msg) do{				\
    fprintf(stderr,"%s\n",_msg);					\
    if(ctx) context_delete(ctx);					\
    /* Memory should be clean of MeshGems objects here */		\
    return _ret;							\
  }while(0);


/*
 * MAIN PROCEDURE
 */
int main(int argc, char *argv[])
{
  char *fileIn = NULL;
  char *fileOut = NULL;
  char *sizeOut = NULL;
  mesh_t *msh;
  mesh_t *msh_output = NULL;
  sizemap_t *sizemap_output = NULL;
  meshgems_status_t ret;

  context_t *ctx;
  meshgems_surfopt_session_t *prs;

  ctx = 0;
  msh = 0;
  prs = 0;
  msh_output = 0;


  /* Create the Meshgems working context */
  ctx = meshgems_context_new();
  if (!ctx) {
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new context");
  }

  /* Set the message callback for our context */
  ret = context_set_message_callback(ctx, my_message_cb, stdout);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /* Check input and output files */
  if (argc > 1 && argv[1][0] != '-') {
    FREE_AND_STRDUP(fileIn, argv[1]);
    if (argc > 2) {
      FREE_AND_STRDUP(fileOut, argv[2]);
    }
  }

  if (!fileIn) {
    RETURN_WITH_MESSAGE(-1,"ERROR: Missing input file.");
  }
  if (!fileOut) {
    int fileInLen = strlen(fileIn);
    int fileOutLen = fileInLen + 20;
    char *pchar;
    fileOut = (char *) calloc(fileOutLen+1, sizeof(char));
    if (fileOut) {
      strncpy(fileOut, fileIn, fileOutLen);
      pchar = strstr(fileOut + fileInLen - 7, ".mesh");
      if (pchar)
        pchar[0] = 0;

      if (fileIn[fileInLen - 1] == 'b') {
        strncat(fileOut, "_surfopt.meshb", fileOutLen);
      } else {
        strncat(fileOut, "_surfopt.mesh", fileOutLen);
      }
    } else {
      RETURN_WITH_MESSAGE(-1, "ERROR: Unable to create output mesh file name.");
    }
  }
  if (!sizeOut) {
    int sizeOutLen = strlen(fileOut);
    char *pchar;
    sizeOut = (char *) calloc(sizeOutLen+1, sizeof(char));
    if (sizeOut) {
      strncpy(sizeOut, fileOut, sizeOutLen);
      pchar = strstr(sizeOut + sizeOutLen - 7, ".mesh");
      if (pchar)
        pchar[0] = 0;

      if (fileOut[sizeOutLen - 1] == 'b') {
        strncat(sizeOut, ".solb", sizeOutLen);
      } else {
        strncat(sizeOut, ".sol", sizeOutLen);
      }
    } else {
      RETURN_WITH_MESSAGE(-1, "ERROR: Unable to create output sizemap file name.");
    }
  }


  /* Read the input file fileIn */
  {
    /* Create the Meshgems mesh and read it */
    if (fileIn) {
      msh = meshgems_mesh_new_read_mesh(ctx, fileIn);
    } else {
      RETURN_WITH_MESSAGE(-1, "ERROR: No input file...");
    }
    if (!msh) {
      RETURN_WITH_MESSAGE(-1, "Mesh creation or reading failed");
    }
  }

  /* Create the Meshgems Surfopt session */
  prs = meshgems_surfopt_session_new(ctx);
  if (!prs) {
    RETURN_WITH_MESSAGE(ret,
                        "unable to create a new MeshGems-Surfopt session \n");
  }


  /* Set the parameters to run MeshGems-Surfopt */

  ret = meshgems_surfopt_set_param(prs, "element_generation", "full_quad");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret = STATUS_ERROR;
  ret = meshgems_surfopt_set_surface_mesh(prs, msh);
  if (ret != STATUS_OK) {
    RETURN_WITH_MESSAGE(ret,
                        "internal error : unable to set surface mesh.");
  }

  /* 
   * The mesh generation process. 
   * See the meshgems/surfopt.h file for more details
   */

  ret = meshgems_surfopt_compute(prs);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error : mesh processing failed");

  /*
   * Mesh generation is completed.
   * Get the generated mesh.
   *
   * The user is now responsible of this output mesh.  That is, if control of
   * the mesh is not given back to the surfopt_session with:
   *
   *	    meshgems_surfopt_regain_mesh(prs, msh_output);
   *
   * the user will have to destroy the output mesh when it is no longer of use.
   */
  ret = meshgems_surfopt_get_mesh(prs, &msh_output);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret,
                        "internal error : unable to get output mesh.");

  /* Usually the mesh and size outputs are treated the same way.  We do not
     give back the output mesh to the session to illustrate the regain call and
     the memory management.  */

  /*
   * Get the generated sizemap.
   *
   * The user is now responsible of this output sizemap. That is, if control of
   * the sizemap is not given back to the surfopt_session with:
   *
   *	    meshgems_surfopt_regain_sizemap(prs, sizemap_output);
   *
   * the user will have to destroy the output sizemap when it is no longer of use.
   */
  ret = meshgems_surfopt_get_sizemap(prs, &sizemap_output);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret,
                        "internal error : unable to get output sizemap.");

  /* To illustrate this, we write the .sol file now :*/
  if (sizeOut) {
    ret = meshgems_sizemap_write_sol(sizemap_output, sizeOut);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to write a SOL file");
  }

  /* ... and we give back the sizemap to the session: */
  meshgems_surfopt_regain_sizemap(prs, sizemap_output);
  sizemap_output = NULL; // to make sure we cannot use or delete it afterwards

  /*
   * We are done with the session, delete it.
   */
  meshgems_surfopt_session_delete(prs);

  /* And now we write the .mesh file :*/
  if (fileOut) {
    ret = meshgems_mesh_write_mesh(msh_output, fileOut);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to write a MESH file");
  }

  /*
   * As the control of msh_output has not been given back to the SurfOpt
   * session (which is destroyed now), we have to free ourselves the object.
   */
  if (msh_output) {
    meshgems_mesh_delete(msh_output);
    msh_output = NULL;
  }

  /* Free the input mesh */
  if (msh) {
    meshgems_mesh_delete(msh);
    msh = NULL;
  }

  /* ... the context: */
  if (ctx) {
    meshgems_context_delete(ctx);
    ctx = NULL;
  }

  /* ... and the strings: */
  if (fileIn)
    free(fileIn);
  if (fileOut)
    free(fileOut);
  if (sizeOut)
    free(sizeOut);

  /* Memory should be clean here */

  return 0;
}
