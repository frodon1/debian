#ifndef __ZP_NEWTON__
#define __ZP_NEWTON__

#include <Newton_raphson.h>
#include <ZP_stack.h>
#include <ZP_object.h>
#include <Auto_ptr.h>
#include <ZP_basic_type.h>

Z_START_NAMESPACE;

ZCLASS ZP_NEWTON : public ZP_OBJECT , public NEWTON_RAPHSON
{ 
  protected :
    AUTO_PTR< ZP_OBJECT > func, dfunc;
    ZP_STACK *the_stack;
    VECTOR* vec;

    ZP_FATAL_ERROR* find_solution(ZP_STACK&,int);
    ZP_FATAL_ERROR* set_move_limit(ZP_STACK&,int);
    ZP_FATAL_ERROR* set_max_iter(ZP_STACK&,int);

    virtual void type_init(char*) { type="NEWTON_RAPHSON"; }

  public :
    ZP_NEWTON();
    virtual ~ZP_NEWTON() { }

    VECTOR f_newton_raphson(const VECTOR& x);
    SMATRIX df_newton_raphson(const VECTOR& x);

    METHOD_DECLARATION_START
      METHOD("find_solution",find_solution,4)
      METHOD("set_move_limit",set_move_limit,1)
      METHOD("set_max_iter",set_max_iter,1)
    METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)

};
Z_END_NAMESPACE;

#endif
