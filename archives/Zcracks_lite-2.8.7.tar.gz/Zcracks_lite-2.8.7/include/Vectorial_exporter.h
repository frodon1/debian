#ifndef __VECTORIAL_EXPORTER__
#define __VECTORIAL_EXPORTER__

#include <Vectorial_area.h>

Z_START_NAMESPACE;

/*

FF, july 18th 2007

An abstract class to export the viewport in some vectorial formats

*/

class VECTORIAL_EXPORTER : public VECTORIAL_AREA
{
  public :
    STRING output_file_name;

    VECTORIAL_EXPORTER();
    virtual ~VECTORIAL_EXPORTER();

    virtual void do_export();
};
Z_END_NAMESPACE;

#endif
