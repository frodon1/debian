#ifndef __GEN_DEBOUND_ELEMENT__
#define __GEN_DEBOUND_ELEMENT__

#include <Contact.h>
#include <Contact_element.h>
#include <Cohesive_zone_behavior.h>
#include <Mechanical_interface_element.h>
#include <Mechanical_mesh.h>
#include <Kernel_matrix.h>
#include <Print.h>
#include <Tool_debug.h>

Z_START_NAMESPACE;

ZCLASS2 GEN_DEBOUND_ELEMENT : public MECHANICAL_INTERFACE_ELEMENT 
{
  protected :
    bool if_sym;
    int plane_stress, large_displ, one_direction;
    int the_dir, my_dim;

    static int compute_nb_dof(const char* ele_type,GEOMETRY*,int);
    void computeB(MATRIX& B,MATRIX &Bt);

    virtual bool compute_B_external(APPLICATION_MESSAGE*);

  public :
    LIST<CONTACT_ELEMENT*> c_elem;

    GEN_DEBOUND_ELEMENT(); 
    virtual void setup_dofs(const char* ele_type);

    virtual ~GEN_DEBOUND_ELEMENT();
    virtual INTEGRATION_RESULT* internal_reaction(bool,VECTOR&,SMATRIX&,bool only_get_tg_matrix);

    void add_contact_elements(CONTACT_ELEMENT*);
    void inactive_contact_elements();

    DECLARE_ASK;
    RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
