#ifndef __RENUMBERING__
#define __RENUMBERING__

#include <ZMath.h>
#include <Array.h>
#include <File.h>
#include <Buffered_list.h>
#include <Transform_geometry.h>
#include <Sub_domains.h>
#include <Utility_mesh.h>

Z_START_NAMESPACE;

class MODIFY_INFO_RECORD; 

ZCLASS TOPOLOGICAL_MESH {
  public :
    ARRAY< BUFF_LIST<int> > elements; // elements binded with nodes
    ARRAY< BUFF_LIST<int> > nodes; // nodes binded with elements
    BUFF_LIST< BUFF_LIST<int>* > adjacents;

    TOPOLOGICAL_MESH(void) { }
   ~TOPOLOGICAL_MESH(void);

    void write_out(ZOSTREAM&);
    void build_from(UTILITY_MESH&);
    int front_width(void);
    void band_width(int&,int&,int&);
    int new_front_width(ARRAY<int>&);
    void new_band_width(ARRAY<int>&,int&,int&,int&);
    int find_lowest_degree_node();
    void build_inverse_mesh(TOPOLOGICAL_MESH&);
    void build_adjacents();
};

ZCLASS ROOTED_LEVEL_STRUCTURE {
  private :
    TOPOLOGICAL_MESH *topo;
    BUFF_LIST< BUFF_LIST<int>* > contens;
    BUFF_LIST< BUFF_LIST<int>* > degrees;
    ARRAY<int> level;

  public :
    ROOTED_LEVEL_STRUCTURE(TOPOLOGICAL_MESH &t) { topo=&t; }
   ~ROOTED_LEVEL_STRUCTURE();

    void build_structure(int);
    int find(int);
    int depth() { return(!contens); }
    int width(int l) { return(!(*(contens[l]))); }
    int width() { int res=-1; for(int i=0;i<!contens;i++) if(width(i)>res) res=width(i); return(res); }
    void write_out(ZOSTREAM&);
    void sort_level(int);
    void extract_unique_list(BUFF_LIST<int>&,int);
    int distance(int n) { return(find(n)-1); }
    void compute_element_decision(ARRAY<int>&);
};

ZCLASS RENUMBERING : public TRANSFORMERS {
  public :
    STRING pb_name;
    bool overwrite;
    bool permute,subdomain; 
    int element_renumbering;
    int n_node,n_element;
    double w1,w2;
    int w1ok,w2ok;
    BUFF_LIST<int> node_front, element_front;
    ARRAY<int> node_in_front,level,element_left,node_left,element_in_front;
    ARRAY<int> decision_factor;
    ARRAY<double> m_decision_factor;
    ARRAY<int> new_node_order,new_elem_order;
    bool force_renumber; 

    void build_fronts();
    void compute_element_decision_factor(int&,double&);
    void update_front(int);

    TOPOLOGICAL_MESH topo;

    RENUMBERING(); 
   ~RENUMBERING(void) { }

    virtual MODIFY_INFO_RECORD* get_modify_info_record(); 
    void apply(UTILITY_MESH& mesh);

    void find_start_end_node(int&,int&,ROOTED_LEVEL_STRUCTURE*,TOPOLOGICAL_MESH&);
    void global_renumbering(int&,int&,int&,int&);
    void subdomain_renumbering(UTILITY_MESH&);
    void write_out();
};
Z_END_NAMESPACE;

#endif
