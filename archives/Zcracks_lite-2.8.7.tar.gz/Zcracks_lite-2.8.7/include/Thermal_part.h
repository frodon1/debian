#ifndef __Thermal_part__ 
#define __Thermal_part__ 

#include <Material_piece.h> 
#include <Int_variable_holder.h> 

Z_START_NAMESPACE;

ZCLASS THERMAL_PART : public MATERIAL_PIECE { 
   protected :
     const int dimen;

  public : 
     VECTOR_FLUX heat_flux;
     VECTOR_GRAD T_grad;
     SCALAR_VAUX Tf;

     THERMAL_PART(MATERIAL_PIECE* boss, int dim);
     THERMAL_PART(const THERMAL_PART& iso, MATERIAL_PIECE* boss);
     virtual ~THERMAL_PART(); 
     static  THERMAL_PART* read(ASCII_FILE& file,MATERIAL_PIECE* b,int dim); 

     virtual DMATRIX compute_k()=0;
     virtual DMATRIX compute_dk(const STRING&)=0;
     virtual void set_parameters()=0;
     RTTI_INFO;
}; 
Z_END_NAMESPACE;

#endif 
