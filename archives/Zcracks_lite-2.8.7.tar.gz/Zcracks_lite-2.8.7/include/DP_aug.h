//
// Gosselet 2004, Generic domain decomposition method
// see P. Gosselet, C. Rey "Non-overlapping domain decomposition methods in structural mechanics", 
//     Archives of computational methods in engineering. Vol 13 (4). Pages 515-572. 2007.
//
// Class required for FETI-DP and BDDC approaches
//     Enables the coarse (typically corners) continuity
//
#ifndef __DP_AUGMENTATION__
#define __DP_AUGMENTATION__

#include <Client.h>
#include <Array.h>
#include <List.h>
#include <DD_augmentation.h>

Z_START_NAMESPACE;

class DP_AUGMENTATION : public DD_AUGMENTATION
{
 public:
 DP_AUGMENTATION() : DD_AUGMENTATION(){}
 DP_AUGMENTATION(DD_SUB_DOMAIN &dd) : DD_AUGMENTATION(dd){}
 virtual ~DP_AUGMENTATION(){}
 virtual void set_constraints();
};

Z_END_NAMESPACE;
#endif

