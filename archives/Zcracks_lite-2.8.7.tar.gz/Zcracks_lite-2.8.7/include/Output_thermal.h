#ifndef __Output_thermal__
#define __Output_thermal__

#include <Output.h>
#include <Output_z7.h>

Z_START_NAMESPACE;

Z_END_NAMESPACE;

#endif
