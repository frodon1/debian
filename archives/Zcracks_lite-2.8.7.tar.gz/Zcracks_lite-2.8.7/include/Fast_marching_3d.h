#ifndef __FAST_MARCHING_3D__
#define __FAST_MARCHING_3D__

#include <Zbool.h>
#include <Buffered_list.h>
#include <Vtk_gpl_io_3d.h>
#include <Grid_2d.h>

Z_START_NAMESPACE;

// #define USE_HEAP

#ifdef USE_HEAP
  #include <Sorted_heap.h>
#endif

//
// 2008-09-11 FF: A generic fast marching algorithm, solving a local equations following
// the upwind values.
//
// this solver handles only a single scalar field
//
// see Fast_marching_multi_3d.h if you need a fast marching algo handling several levelsets
// at the same time
// 

class FAST_MARCHING_3D : public VTK_GNUPLOT_IO_3D
{
  protected:
    enum FM_STATE { UNKNOWN=0 , ACCEPTED=1 , TENTATIVE=2 , DISTANT=4 };
    FINITE_SET<3,unsigned int> coord;
    GRID_3D<FM_STATE> nodal_state,element_state;
#ifdef USE_HEAP
    SORTED_HEAP < FINITE_SET<3,unsigned int> , double > tentative;
    GRID_3D< int* > tentative_idx;
#else
    BUFF_LIST< FINITE_SET<3,unsigned int> > tentative;
#endif
    BUFF_LIST< FINITE_SET<3,unsigned int> > accepted,distant;

    virtual void initialize(const GRID_3D<double> &grid, GRID_3D<double> &ret)=0;
    virtual double local_solve(const GRID_3D<double> &F, const GRID_3D<double> &grid, const GRID_3D<double> &initial,
                             GRID_3D<FM_STATE> &nodal_state, FINITE_SET<3,unsigned int> &coord,bool&)=0;
    void fast_marching(const GRID_3D<double> &F, const GRID_3D<double> &grid, GRID_3D<double> &ret);

  public :
    FAST_MARCHING_3D() { }
    virtual ~FAST_MARCHING_3D() { }
};
Z_END_NAMESPACE;

#endif
