#ifndef _Isotropic_sum_
#define _Isotropic_sum_

#include <Isotropic.h>

Z_START_NAMESPACE;

ZCLASS ISO_SUM : public ISOTROPIC_HARDENING  {

   protected :
      int nb_varint;
      ARRAY<bool> active;
      PLIST<ISOTROPIC_HARDENING> isos; 
      MATRIX dchi_dchi;
      VECTOR cur_rvalue;

   public :

      ISO_SUM() : nb_varint(-1) {}
      virtual ~ISO_SUM() {}

      void add_active(ISOTROPIC_HARDENING*);
      void remove_active(ISOTROPIC_HARDENING*);

      void initialize(ASCII_FILE&,MATERIAL_PIECE*);
      bool has_recov_term();
      // iso with var_int
      double radius(double evcum, VECTOR& rvalue);
      double radius_no_r0(double evcum, VECTOR& rvalue);
      // iso without var_int
      double  radius(double evcum, double rvalue=0.0);
      double  radius_no_r0(double evcum, double rvalue=0.0);
      double  R0() const;

      // called from an embedded isotropic
      double radius_no_r0_from_within(double evcum);

      double  give_granq();
      double  dradius_dflow();

      double   potential_term()const;

      // called for isotropic with var_int
      VECTOR   dr_dv();             // derivatives, residual
      MATRIX   dq_evol_dr();        // ddchi_dchi
      VECTOR   dv_dr();             // dvcum_dchi
      void     dq_evol_dv(MATRIX&); // dchi_dvcum
      VECTOR   domega();            // recovery, dsa

      RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
