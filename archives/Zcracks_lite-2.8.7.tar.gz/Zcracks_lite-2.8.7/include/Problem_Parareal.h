// ********************************************************************
//            PARAREAL RESOLUTION OF TIME DEPENDANT PROBLEMS
// ********************************************************************
//
// written by V. Chiaruttini, setpember 2004
//


#ifndef __Problem_Parareal__
#define __Problem_Parareal__

#define PARA_TAG 31415927

#include <Bool.h>
#include <Object_factory.h>
#include <Base_problem.h>
#include <Static.h>
#include <Memory_buffer.h>
#include <Fake_stream.h>

Z_START_NAMESPACE;

// class for parareal problems

class PROBLEM_PARAREAL : public BASE_PROBLEM , CLIENT
{ 
  protected : 
    BUFF_LIST<STRING> list_procs; // names of processors
    BUFF_LIST<double> list_time,list_factor; // time limits and subset factors
    BUFF_LIST<int>    list_substep,list_propa; // nb substeps & for propagtn
    int  iteration;  // max number of iterations
    double cv_ratio; // general convergence ratio
    bool if_cv_absolu,if_modify_vint,if_ID; // is it absolu ? propagate on vint ?
    BUFF_LIST<STRING> list_dof_ratio; // list of dof for cv criterion
    BUFF_LIST<double> list_ratio; // list of ratios
    BUFF_LIST<bool>   list_if_absolu; // if cv absolu
    VECTOR	      list_P_X,list_P_vint, // list Proportionnal factor
        	      list_I_X,list_I_vint, // list Integrator factor
        	      list_D_X,list_D_vint; // list Derivator factor
    STRING file_para;    // for auxiliary problem
    
    MEMORY_BUFFER *buff_X0,*buff_X1,*buff_X1p,*buff_x1; // to save restart files
    FAKE_STREAM *file_buff; // fake file to restart
    PROBLEM_STATIC_MECHANICAL  *p1,*p2; // sub problems for computations
		bool if_cv; // to check convergence
    
		void send_state(MEMORY_BUFFER&); // send state to next processor
		void receive_state(MEMORY_BUFFER&); // receive state for previous
		
    bool init_parareal(); // initialization of parareal method
    bool modify_seq(double,int); // to set sequence to solve
    void change_output_names(PROBLEM *pb, int idom);

    virtual int parallelized(void) { return(1); }

  public:
 
    PROBLEM_PARAREAL();
    virtual ~PROBLEM_PARAREAL();

    virtual void load(const STRING& pb,const STRING& pbo);
    virtual bool Execute();

};

Z_END_NAMESPACE;

#endif   
