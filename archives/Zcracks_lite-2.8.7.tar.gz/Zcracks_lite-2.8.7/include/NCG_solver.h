//
// Gosselet 2004, Generic iterative solvers (mostly used with generic_dd)
// see P. Gosselet thesis (2003), nice paper soon
//
// Conjugate gradient solver, powerful for symetric positive definite systems
//
#ifndef __N_CG_SOLVER__
#define __N_CG_SOLVER__

#include <Array.h>
#include <math.h>
#include <File.h>
#include <Krylov_iterative_solver.h>

Z_START_NAMESPACE;

class N_CG_SOLVER : public KRYLOV_ITERATIVE_SOLVER {
protected :
  double last_ratio;
  virtual void loop();
  VECTOR diag, ndia;
  int nsyst;
public :
  N_CG_SOLVER() : KRYLOV_ITERATIVE_SOLVER() { nsyst = 0;}
  virtual ~N_CG_SOLVER() { }

  virtual void set_parameter( SOLVER_PARAMETER *sp ) {
    KRYLOV_ITERATIVE_SOLVER::set_parameter( sp );
    (( KRYLOV_ITERATIVE_SOLVER_PARAMETER* ) parameters )->ortho_type = "mgskss";
  }
  virtual void give_hessem( SMATRIX& );
  RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
