#ifndef __Zcracks_enriched_element__
#define __Zcracks_enriched_element__

// ============================================================================ 
//  Zcracks enriched element (geom enriched element with front related tip fct)
//
//  VC june 2011  
// ============================================================================ 

#include <P_element.h> 
#include <Crack_FC.h> 
#include <GTH_element.h> 
#include <Crack_FC.h> 
#include <Mcesd.h> 

#define NBXF 9

Z_START_NAMESPACE;

class GTH_ELEMENT;

ZCLASS2 ZCRACKS_ENRICHED_ELEMENT : public P_ELEMENT { 

    friend class MCESD;

    protected :
      int nb_xdofs;
      CRACK_FC *crack_front;
      ARRAY<int> used_xdofs;
      MARRAY<ARRAY<DOF*> > *xdofs;

      inline void mat2tens(MATRIX &deshape,const SMATRIX &dtmp,int pos) const;

    public :
      double RDi,RDe;
      double compute_theta(const double &r,double &dtheta) const;

      void set_partial_conditions(ARRAY<DOF*> *replacement,ARRAY<int> *enriched_nodes);

      bool if_enriched;
      bool if_partial;
      P_ELEMENT* inside; 
      GTH_ELEMENT* gthelem;

      virtual void cal_contour_outputs(const STRING& var_name,VECTOR& val_node);
      void nodes_val(VECTOR &vals);
//      virtual bool get_nodal_values()const { return(TRUE); }

      void TIP_function(VECTOR &M,MATRIX& eshape,ARRAY<DOF*> &associated_dofs);
      ZCRACKS_ENRICHED_ELEMENT(CRACK_FC *boss,ELEMENT* elem,
                 MARRAY<ARRAY <DOF*> > *_xdofs,ARRAY<DOF*> *rt,ARRAY<int> *ent);
      ZCRACKS_ENRICHED_ELEMENT(CRACK_FC *boss,GTH_ELEMENT* elem,
                 MARRAY<ARRAY <DOF*> > *_xdofs);
      virtual ~ZCRACKS_ENRICHED_ELEMENT();

      void compute_ip_position();
      virtual void setup_dofs(const char* key);

      virtual void set_material(ARRAY<BEHAVIOR*>& b,
                              PLIST<MATERIAL_DATA_INIT>& mdi,
                              ARRAY<LOCAL_FRAME*>& rot); 

      virtual bool transform_dirichlet();

      // 
      // We replace both the wrapper and inside's callback to this one, so 
      // all the time any call to get pos of integ pt is ok. Note now we need 
      // an instance for each wrapper because the its_boss ptr is used instead of 
      // the default callback 
      // 

      virtual INTEGRATION_RESULT* internal_reaction(
                       bool      if_compute_stiffness,
                       VECTOR&   resi,
                       SMATRIX&  stiff,
                       bool      only_get_tg_matrix); 

      void TIP_function(MATRIX& eshape,MATRIX &deshape) const;

      virtual void symmetric_gradient_operator(MATRIX& B);
      virtual void gradient_operator(MATRIX& B);
      virtual void shape_operator(MATRIX& op, const VECTOR &sh) const;

      virtual void reassign_behaviors(const CARRAY<BEHAVIOR*>& orig_behaviors, 
         const CARRAY<BEHAVIOR*>& new_behaviors);

      virtual bool verification() { behavior=inside->behavior; return P_ELEMENT::verification(); }

//      virtual void start(const MATRIX &m) { P_ELEMENT::start(m); inside->start(m); }
//      virtual void next(const MATRIX &m) { P_ELEMENT::next(m); inside->next(m); }
//      virtual void start() const { P_ELEMENT::start(); inside->start(); }
//      virtual void next() const { P_ELEMENT::next(); inside->next(); }
//      int ok() const { return(inside->ok()); }



      RTTI_INFO;
}; 
Z_END_NAMESPACE;

#endif 
