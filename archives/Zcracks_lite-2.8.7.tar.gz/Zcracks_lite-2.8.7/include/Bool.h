// Defining TRUE and FALSE is usually a Bad Idea,
// because you will probably be inconsistent with anyone
// else who had the same clever idea.
// Therefore:  DON'T USE THIS FILE.
// 
// 2003/02/14 A_R Cut out the Icc and undef'd existing. This
//                should get rid of a lot of annoying compilation
//                warnings (and the undefs were done almost 
//                everywhere within the if-then-elses anyway).

#ifndef __Bool__
#define __Bool__

#ifdef _WIN32

  // #include <bool.h>

  #define FALSE false 
  #define TRUE  true

  inline bool make_bool(bool i) { return i; }
#else

#ifdef TRUE
  #undef TRUE
#endif
#ifdef FALSE
  #undef FALSE
#endif

#if (__GNUG__>2)
   #define TRUE true
   #define FALSE false
   
  inline bool make_bool(int i) { return (i) ? TRUE : FALSE; }
  inline bool make_bool(bool i) { return i; }

#else

   #if ( __GNUC_MINOR__<6 || ! defined __GNUC__ )
         #undef FALSE
         #undef TRUE

         // 
         // "New" OSF1 needs to be added if you're using that 
         // 
         #if defined IRIX64
         // With the standard C++ bool compilation on IRIX6.5 gives
         // seg fault in MODIFY_INFO_RECORD on newer IRIX versions?
         // Use -LANG:bool=OFF when compiling
          #define FALSE 0
          #define TRUE  1
          #define bool int
          #define BOOL_IS_INT
         #elif (defined _WIN32 || __mips>=3) 
          #define FALSE false 
          #define TRUE  true
         // #elif !defined __ibm__
         //    enum bool { FALSE=0, TRUE=1 };
         #elif (defined HPaCC) 
          #define FALSE false 
          #define TRUE  true
         #elif (defined OSF1 && ! defined OSF1_OLD)
          #define FALSE false 
          #define TRUE  true
         #elif (defined SunOS) 
            #define FALSE false 
            #define TRUE  true
         #elif (defined SUNCC5) 
            #define FALSE false 
            #define TRUE  true
         #elif (defined AIX5) 
            #define FALSE false 
            #define TRUE  true
         #elif defined HPUX && ! defined __GNUC__
            #define FALSE 0
            #define TRUE  1
              typedef int zebu_bool;
              #define bool zebu_bool
              #define BOOL_IS_INT
         #else
            #define FALSE 0
            #define TRUE  1
            #ifndef AIX
              typedef int bool;
            #endif
            #define BOOL_IS_INT 
         #endif
   
  // this file was copied from GNU C++
  // gcc 2.6 and on have some builtins..
  // 
  #else

    #if (( defined __GNUC__ ) && ( __GNUC__ < 3 ) && ( __GNUC_MINOR__ < 8 )) 
      #include <bool.h>
    #else
      #define FALSE 0   
      #define TRUE 1
    #endif

  #endif

  inline bool make_bool(int i) { return (i) ? TRUE : FALSE; } 
  #ifndef BOOL_IS_INT 
    inline bool make_bool(bool i) { return i; } 
  #endif

#endif

#endif

#endif
