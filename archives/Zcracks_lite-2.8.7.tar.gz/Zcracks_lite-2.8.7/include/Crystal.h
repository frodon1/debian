#ifndef __Crystal__
#define __Crystal__

//======================================================================
//  CRYSTAL    This is the general-use crystal potential
//             with provision for kinematic, and
//             isotropic hardening. 
//
//           * normal() is the default error.
//           * s_loc is for localizing the stress.. e_loc returns to global
//           * still no internal variables allowed
//           * yield_rk is called automatically by yield if
//             flags&POT_FLAG_THETA_METHOD is not set
//======================================================================

#include <Rotation.h>
#include <Potential.h>
#include <Crystal_kinematic.h>
#include <Mat_data.h>

Z_START_NAMESPACE;

class NL_M_TLE_B_SD;
class ROTATION; class CRYSTAL_KINEMATIC;
class FULL_IMATRIX;
class CRYSTAL_ORIENTATION;
class APPLICATION_MESSAGE;

enum { CRYS_FLAG_HAS_H_TERMS=POT_FLAG_USER1 };
enum { CRYS_FLAG_IS_COPIED=POT_FLAG_USER2 };

ZCLASS CRYSTAL : public POTENTIAL {
   friend class CRYSTAL_KINEMATIC;
public:
   VECTOR_VINT          gamma; 
   TENSOR2_VAUX         evi; 
   VECTOR_VAUX          gvcum; 
   SCALAR_VAUX          geq; 
 
   TENSOR2              keep_sig_eff;
   VECTOR_VAUX*         tau_curr; 
   virtual void         calc_current_tau();

   // ---------------------------------------- Misc
   const TENSOR2*     keep_local_rotation; 
   LIST<const ROTATION*> rotation;              // This is kept elsewhere or deleted
   CRYSTAL*           inter_pot;
   int                geq_pos; 		        // position in var_aux of geq
   double             dt;

   enum FLTYPES { VISCO=0, PLAS=1 } ftype;
   // ---------------------------------------- Models
   ISOTROPIC_HARDENING*       its_isotropic;   // stored/deleted here
   LIST<ISOTROPIC_HARDENING*> its_isotropic_diag; // stored/deleted here
   LIST<CRYSTAL_KINEMATIC*>   its_kinematic;   // stored/deleted here 
   FLOW*                      its_flow;        // stored/deleted here
   CRYSTAL_ORIENTATION*       its_orientation; // stored/deleted here
   // ---------------------------------------- Coefs
   double              h_inter_coef;
   // ---------------------------------------- Storage
   FULL_IMATRIX*      local_bigm;
   TENSOR2            evp;
   VECTOR             dgvc;
   VECTOR             tdt_dfdc_theta;
   VECTOR             tau, yld, dfdc;
   VECTOR             slip_dens, dsd_dv;
   VECTOR             slip_dens_inter, dsd_dv_inter;
   SMATRIX            dcrdv; 

   virtual double yield_rk( const TENSOR2& sig_eff,
                            const VECTOR&  big_h_vec,
                            double dtime );

   virtual void  read_option(ASCII_FILE& file, const STRING& wht);

    // 
    // Special outputs reached through an ASK 
    // 
    virtual bool output_orientation(APPLICATION_MESSAGE* msg); 
    virtual bool generate_poly_map(APPLICATION_MESSAGE* msg); 

public: 

        CRYSTAL(); 
        CRYSTAL(CRYSTAL& pot, MATERIAL_PIECE* mp);
        virtual ~CRYSTAL();
        virtual void            initialize(ASCII_FILE&, MATERIAL_PIECE* mp); 
        virtual MATERIAL_PIECE* copy_self(MATERIAL_PIECE*); 
 
   // ------------------------------------------------------------ 
   //  Special crystal functions
   // ------------------------------------------------------------ 
   void  add_rotation(const ROTATION* pot);

   void  set_cry_interaction(CRYSTAL* pot, double h);

   virtual void  setup(int& flux_pos, int& grad_pos, int& vi_pos, int& va_pos);

   void  update_var_aux(); 

   void  dcrdv_int(MATRIX& mat, const CRYSTAL& inter_pot);

   // ------------------------------------------------------------ 

   virtual void  attach( VECTOR&  chi_vec,
                         VECTOR&  d_chi    );
   MP_DEFAULT_ATTACH1(POTENTIAL); 

   virtual double yield( const TENSOR2& sig_eff,
                         const VECTOR&  big_h_vec,
                         double dtime );

   // ------------------------------------------------------------ 
   //  Flow and parameter evolution
   // ------------------------------------------------------------ 
   
   virtual const VECTOR& param_hat( const VECTOR& dchi, 
                                     double dtime);

   virtual TENSOR2_VAUX* give_evi() { return &evi; }

   // ------------------------------------------------------------ 
   //  Inelastic deformation
   // ------------------------------------------------------------ 
   virtual const TENSOR2& e_hat();      

   virtual void  global_jacob_eel( 
                           const SMATRIX& dsig_deel,
                           MATRIX&        dFeel_deel,
                           MATRIX&        dFeel_dparam,
                           MATRIX&        dFeel_dhard,
                           MATRIX&        dFparam_deel,
                           MATRIX&        dFhard_deel
                         );

   virtual void  potential_jacob(  
                           MATRIX&        dFparam_dparam,
                           MATRIX&        dFparam_dhard,
                           MATRIX&        dFhard_dparam,
                           MATRIX&        dFhard_dhard
                        );

   // ------------------------------------------------------------ 
   //  Evolution of crystal orientations 
   // ------------------------------------------------------------
   virtual void set_local_rotation(const TENSOR2* Q); 
   virtual void add_rotation_evolution(TENSOR2& dQ, const TENSOR2& Q); 

   RTTI_INFO;
   DECLARE_ASK; 
};
Z_END_NAMESPACE;

#endif
