#ifndef __Global_equation__
#define __Global_equation__

#include <Array.h>
#include <Std_cc_stream.h>

Z_START_NAMESPACE;

class EQUATION;

ZCLASS2 EQUATION {
   public :
        int nfron;    // size of equation
        int ifront;   // position of the dof
        int nikno;    // dof id
        double eqrhs; // second member
        int ielem; // id of the element causing this dof to be eliminated
        ARRAY<double> equation;
        EQUATION(int front_value,int ifr,int nikn,int iel);
        virtual ~EQUATION();
        friend Zfstream& operator<<(Zfstream&,const EQUATION&);
        friend Zfstream& operator>>(Zfstream&,      EQUATION&);
        virtual int size_of()const;
};
Z_END_NAMESPACE;

#endif
