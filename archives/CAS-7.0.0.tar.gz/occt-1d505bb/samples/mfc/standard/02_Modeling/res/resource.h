//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Modeling.rc
//
#define IDR_MAINFRAME1                  129
#define IDR_FRAME2                      130
#define ID_BOX                          802
#define ID_Cylinder                     803
#define ID_CONE                         804
#define ID_SPHERE                       805
#define ID_TORUS                        806
#define ID_WEDGE                        807
#define ID_PRISM                        808
#define ID_REVOL                        809
#define ID_PIPE                         810
#define ID_THRU                         811
#define ID_EVOLVED                      813
#define ID_DRAFT                        814
#define ID_BUTTON815                    815
#define ID_MIRROR                       816
#define ID_MIRRORAXIS                   818
#define ID_ROTATE                       820
#define ID_SCALE                        821
#define ID_TRANSLATION                  822
#define ID_DISPLACEMENT                 823
#define ID_DEFORM                       824
#define ID_CUT                          837
#define ID_FUSE                         838
#define ID_COMMON                       839
#define ID_SECTION                      840
#define ID_PSECTION                     841
#define ID_BLEND                        842
#define ID_EVOLVEDBLEND                 843
#define ID_CHAMF                        844
#define ID_PRISM_LOCAL                  846
#define ID_DPRISM_LOCAL                 847
#define ID_REVOL_LOCAL                  849
#define ID_Pipe_LOCAL                   850
#define ID_LINEAR_LOCAL                 851
#define ID_GLUE_LOCAL                   852
#define ID_SPLIT_LOCAL                  853
#define ID_THICK_LOCAL                  854
#define ID_OFFSET_LOCAL                 855
#define ID_VERTEX                       856
#define ID_EDGE                         857
#define ID_WIRE                         858
#define ID_FACE                         859
#define ID_SHELL                        860
#define ID_COMPOUND                     861
#define ID_SEWING                       862
#define ID_BUILDER                      863
#define ID_GEOMETRIE                    864
#define ID_EXPLORER                     865
#define ID_VALID                        866
#define ID_LINEAR                       867
#define ID_SURFACE                      868
#define ID_VOLUME                       869
#define ID_FILLWITHTANG                 870
#define ID_BUTTON871                    871
#define ID_BUTTON_FILL                  871
#define ID_STOP_STOP                    32901

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         872
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
