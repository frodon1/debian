#ifndef __Pointer_New__
#define __Pointer_New__

#include <stdio.h>

#include <Assert.h>
#include <Bool.h>

Z_START_NAMESPACE;

//
// this is a generic pointer class implementation
//

// NPTR is used when the pointer has to be deleted
// so operator= can only be used once. (assert mode)
//  when the pointer does not need to be deleted just use a regular pointer
// Note : all verification are done in ZCHECK/assert mode
// ~NPTR and erase are not inline since the destructor of the object T
// should then be known

template <class T> ZCLASSt NPTR {
  protected :
     int *nitem,del_needed;
     T* ptr;
     void set_to_null()const;
     void create_nitem() { nitem=new int; }
     void assign_ptr(const NPTR<T>&) { }
     void free_ptr() { if((!ptr)&&(*nitem==0)) { delete(nitem); return; } if(ptr && (*nitem==1)) { if(del_needed) delete ptr; delete nitem; } else (*nitem)--; ptr=NULL; }
  public :
     NPTR() : ptr(NULL) { del_needed=0; create_nitem(); *nitem=0; }
     NPTR(T* p) : ptr(p) { del_needed=1; create_nitem(); *nitem=1; }
     NPTR(const NPTR<T>& p) { ptr=p.ptr; nitem=p.nitem; (*nitem)++; del_needed=p.del_needed;  }
     ~NPTR();
           operator T*() { assert(ptr); return ptr; }
           T* operator->()             { assert(ptr); return ptr; }
     const T* const operator->() const { assert(ptr); return ptr; }
           T& operator*()              { assert(ptr); return *ptr; }
     const T& operator*()  const { assert(ptr); return *ptr; }
           T* operator()()             { return ptr; }
     const T* operator()() const       { return ptr; }
     bool  if_null() const             { return (ptr) ? FALSE : TRUE;  }
     bool  if_not_null() const         { return (ptr) ? TRUE  : FALSE; }
     void erase();
     void operator=(T* p)              { free_ptr(); create_nitem(); *nitem=1; ptr=p; del_needed=1; }
     void operator=(T& p)              { free_ptr(); create_nitem(); *nitem=1; ptr=&p; del_needed=0; }
     void operator=(const NPTR<T>& p)   { free_ptr(); ptr=p.ptr; nitem=p.nitem; (*nitem)++; del_needed=p.del_needed; }
     bool operator==(const NPTR<T>& p)const   { return (ptr==p.ptr) ? TRUE : FALSE; }
     bool operator==(const T *const& p)const { return (ptr==p)     ? TRUE : FALSE; }
     void swap_pointer(NPTR<T>&);
     friend WIN_THINGIE bool operator==(const T*& t,const NPTR<T>& p) { return (t==p.ptr) ? TRUE : FALSE; }
     friend WIN_THINGIE bool operator!=(const T*& t,const NPTR<T>& p) { return (t!=p.ptr) ? TRUE : FALSE; }
};

#ifdef __GNUC__
  #define INLINE 
#else 
  #define INLINE inline 
#endif 

template <class T> INLINE NPTR<T>::~NPTR() { free_ptr(); }
template <class T> INLINE void NPTR<T>::erase() { free_ptr(); }
#define K ((NPTR<T>*)this)
template <class T> INLINE void NPTR<T>::set_to_null()const { K->free_ptr(); }
#undef K

template <class T> void NPTR<T>::swap_pointer(NPTR<T>& p2) 
{ NPTR<T> tmp; tmp=(*this); (*this)=p2; p2=tmp; }
Z_END_NAMESPACE;

#endif
