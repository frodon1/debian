#ifndef __Post_tos__
#define __Post_tos__

#include <Dichotomy.h>
#include <Newton_raphson.h>
#include <Post_range.h>
#include <Post_trace.h>
#include <Post_mises.h>

Z_START_NAMESPACE;

class ANISO_DAMAGE_INTEGRATOR;
class CHECK_INTEGRATION;

ZCLASS2 POST_TOS : public POST_SIMPLE,  public NEWTON_RAPHSON,  public DICHOTOMY {

  protected :
    Zfstream check_file;
    bool full_output, skip_compression, out_of_phase, needs_normalize, needs_temperature, 
      for_cumulation, check_integ;

    int tsz, iter, newton_calls;
    double infinity, epsilon, max_dT;
    STRING plastic_var;

    AUTO_PTR<POST_RANGE> lp_range;
    AUTO_PTR<POST_TRACE> lp_trace;
    AUTO_PTR<ANISO_DAMAGE_INTEGRATOR> aniso_integrator;
    AUTO_PTR<CHECK_INTEGRATION>       check_integration;

    ARRAY<POST_COEFF*> its_coeff;
    VECTOR initial_coef_values;

    ARRAY<VECTOR>   in_range, out_range, out_trace;

    double sig_eff, term; // optimisation for newton

    void    init_coefs();
    double  get_mean_stress_factor(double se_alt, double se_ave);
    virtual double  f_dichotomy(double)const ;
    virtual VECTOR f_newton_raphson(const VECTOR&);
    virtual SMATRIX df_newton_raphson(const VECTOR& x);

  public :

    double TT_min, TT_max;

    POST_COEFF  young, n, epsd, A, alpha, B, beta, sig_star; 

    POST_TOS();
    virtual ~POST_TOS();

    virtual MODIFY_INFO_RECORD* get_modify_info_record();
    virtual bool verify_info();

    virtual void input_i_need(int,ARRAY<STRING>&);
    virtual void output_i_give(bool&,ARRAY<STRING>&);
    virtual bool need_material_file()const { return TRUE; }
    virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);

    void compute_coefs_at_temperature(double T);
    void compute_coeff_dparam(double& dbeta, double& dsigd, double& dBstar);

    void set_infinity(double i) { infinity = i; }
    void set_for_cumulation(bool cumulation) { for_cumulation = cumulation; }
    bool is_anisothermal() { return(needs_temperature); }

};
Z_END_NAMESPACE;

#endif
