#ifndef __BB_TREE_INLINE__
#define __BB_TREE_INLINE__

// inline functions of BB_TREE

template <class T> INLINE
void BB_NODE<T>::delete_branch() 
{
  if (branch_under!=NULL) {
    branch_under->delete_branch(); delete branch_under;
    branch_under=NULL;
  }
  if (branch_upper!=NULL) {
    branch_upper->delete_branch(); delete branch_upper;
    branch_upper=NULL;
  }
}

template <class T> INLINE
bool BB_NODE<T>::is_in(const VECTOR &pos) const
{
  const double &bt=boss->tolerance;

  if (min.size()<=0 || max.size()<=0) return FALSE;
  if (pos[0]<min[0]-bt) return FALSE;
  if (pos[0]>max[0]+bt) return FALSE;
  if (pos.size()==1 || min.size()==1 || max.size()==1) return TRUE;

  if (min.size()<=1 || max.size()<=1) return FALSE;
  if (pos[1]<min[1]-bt) return FALSE;
  if (pos[1]>max[1]+bt) return FALSE;
  if (pos.size()==2 || min.size()==2 || max.size()==2) return TRUE;

  if (min.size()<=2 || max.size()<=2) return FALSE;
  if (pos[2]<min[2]-bt) return FALSE;
  if (pos[2]>max[2]+bt) return FALSE;
  return TRUE;
}

// does line P1 P2 intersect current BB ?
template <class T> INLINE
bool BB_NODE<T>::is_intersect(const VECTOR &P1,const VECTOR &P2,double &dist)
{
  // Test needs Center/Extent representation
  VECTOR Center(3),Extent(3),LMid(3),L(3),LExt(3),PT1(3),PT2(3);
  Center=.5*(min+max); // for BB
  Extent=.5*(max-min);

  // Change origin
  PT1=P1-Center;
  PT2=P2-Center;

  // Get line midpoint and extent
  LMid=.5*(PT1+PT2);
  L=(PT1-LMid);
  LExt[0]=fabs(L[0]); LExt[1]=fabs(L[1]); LExt[2]=fabs(L[2]);

  // Return distance in direction P2-P1
  dist=fabs(PT1|(P2-P1));

  // Use Separating Axis Test
  // Separation vector from box center to line center is LMid, since the line is in box space
  if ( fabs( LMid[0] ) > Extent[0] + LExt[0] ) return FALSE;
  if ( fabs( LMid[1] ) > Extent[1] + LExt[1] ) return FALSE;
  if ( fabs( LMid[2] ) > Extent[2] + LExt[2] ) return FALSE;
  // Crossproducts of line and each axis
  if ( fabs( LMid[1] * L[2] - LMid[2] * L[1])  >  (Extent[1] * LExt[2] + Extent[2] * LExt[1]) ) return FALSE;
  if ( fabs( LMid[0] * L[2] - LMid[2] * L[0])  >  (Extent[0] * LExt[2] + Extent[2] * LExt[0]) ) return FALSE;
  if ( fabs( LMid[0] * L[1] - LMid[1] * L[0])  >  (Extent[0] * LExt[1] + Extent[1] * LExt[0]) ) return FALSE;
  // No separating axis, the line intersects
  return TRUE;
}

#define THIS ((BB_NODE*)this)

template <class T> INLINE
double BB_NODE<T>::mindist2(const VECTOR &pos) const
{
  double d=0.,dp=pos[0]-min[0];
  if(dp<0.) d+=dp*dp;
  else if((dp=(pos[0]-max[0]))>0.) d+=dp*dp;
  dp=pos[1]-min[1];
  if(dp<0.) d+=dp*dp;
  else if((dp=(pos[1]-max[1]))>0.) d+=dp*dp;
  if(pos.size()>2) {
    dp=pos[2]-min[2];
    if(dp<0.) d+=dp*dp;
    else if((dp=(pos[2]-max[2]))>0.) d+=dp*dp;
  }
  return d;
}

template <class T> INLINE
double BB_NODE<T>::minmaxdist2(const VECTOR &pos) const
{
  double d;
  double q0=pos[0],rM0;
  if((2.*q0)<(min[0]+max[0])) {
    rM0=q0-max[0];
    q0-=min[0];
  } else {
    rM0=q0-min[0];
    q0-=max[0];
  }
  q0*=q0;
  rM0*=rM0;
  double q1=pos[1],rM1;
  if((2.*q1)<(min[1]+max[1])) {
    rM1=q1-max[1];
    q1-=min[1];
  } else {
    rM1=q1-min[1];
    q1-=max[1];
  }
  q1*=q1;
  rM1*=rM1;
  if(pos.size()>2) {
    double q2=pos[2],rM2;
    if((2.*q2)<(min[2]+max[2])) {
      rM2=q2-max[2];
      q2-=min[2];
    } else {
      rM2=q2-min[2];
      q2-=max[2];
    }
    q2*=q2;
    rM2*=rM2;
    d=q0+rM1+rM2;
    q1+=rM0+rM2;
    if(q1<d) d=q1;
    q2+=rM0+rM1;
    if(q2<d) d=q2;
  } else {
    d=q0+rM1;
    q1+=rM0;
    if(q1<d) d=q1;
  }
  return d;
}

// FindT
template <class T> INLINE
void BB_NODE<T>::closest(const VECTOR &pos, double &dmin, BUFF_LIST<double> &min_dist,BUFF_LIST<T*> &found) const
{
  // Algo check each branch
  // Explore closest
  // Recheck largest
  // Explore if necessary
  double dmU,dmMU,dmu,dmMu;
  // dmin must be init at .5*DBL_MAX!!!!
  // Calcul min dist
  if(this->branch_upper) {
    dmU=branch_upper->mindist2(pos);
  } else dmU=DBL_MAX;
  if(this->branch_upper) {
    dmu=branch_under->mindist2(pos);
  } else dmU=DBL_MAX;
  bool if_new_dist=FALSE;
  if(dmU>dmin) {
    // Only test under branch
    if(dmu>dmin) return;
    if(branch_under->element) {
      // add and must check branch
      dmMu=branch_under->minmaxdist2(pos);
      if(dmMu<dmin) {
        // Closest ever found
        dmin=dmMu;
        if_new_dist=TRUE;
      }
      min_dist.add(dmu);
      found.add(branch_under->element);
    } else branch_under->closest(pos,dmin,min_dist,found);
  } else if(dmu>dmin) {
    // Only test upper branch
    if(branch_upper->element) {
      // add and must check branch
      dmMU=branch_upper->minmaxdist2(pos);
      if(dmMU<dmin) {
        // Closest ever found
        dmin=dmMU;
        if_new_dist=TRUE;
      }
      min_dist.add(dmU);
      found.add(branch_upper->element);
    } else branch_upper->closest(pos,dmin,min_dist,found);
  } else {
    // Must explore both branch 1st check explore closest
    if(dmu<dmU) {
      // Closer is under
      if(branch_under->element) {
        // add and must check branch
        dmMu=branch_under->minmaxdist2(pos);
        if(dmMu<dmin) {
          // Closest ever found
          dmin=dmMu;
          if_new_dist=TRUE;
        }
        min_dist.add(dmu);
        found.add(branch_under->element);
      } else branch_under->closest(pos,dmin,min_dist,found);
      // New dmin value can be set
      if(dmU<dmin) {
        // Check second branch
        if(branch_upper->element) {
          // add and must check branch
          dmMU=branch_upper->minmaxdist2(pos);
          if(dmMU<dmin) {
            // Closest ever found
            dmin=dmMU;
            if_new_dist=TRUE;
          }
          min_dist.add(dmU);
          found.add(branch_upper->element);
        } else branch_upper->closest(pos,dmin,min_dist,found);
      } 
    } else {
      // Closer is upper
      if(branch_upper->element) {
        // add and must check branch
        dmMU=branch_upper->minmaxdist2(pos);
        if(dmMU<dmin) {
          // Closest ever found
          dmin=dmMU;
          if_new_dist=TRUE;
        }
        min_dist.add(dmU);
        found.add(branch_upper->element);
      } else branch_upper->closest(pos,dmin,min_dist,found);
      // New dmin value can be set
      if(dmu<dmin) {
        if(branch_under->element) {
          // add and must check branch
          dmMu=branch_under->minmaxdist2(pos);
          if(dmMu<dmin) {
            // Closest ever found
            dmin=dmMu;
            if_new_dist=TRUE;
          }
          min_dist.add(dmu);
          found.add(branch_under->element);
        } else branch_under->closest(pos,dmin,min_dist,found);
      }
    }
  }
  if(if_new_dist) {
    // Must check closest elem list if required
    int offset=0;
    for(int ipos=0;ipos<found.size();ipos++) {
      if(min_dist[ipos]>dmin) offset++;
      else {
        found[ipos-offset]=found[ipos];
        min_dist[ipos-offset]=min_dist[ipos];
      }
    }
    found.set_size(found.size()-offset);
    min_dist.set_size(min_dist.size()-offset);
    if(branch_under->element==found.last()) THIS->boss->last_found=branch_under;
    else if(branch_upper) THIS->boss->last_found=branch_upper;
  }
}

template <class T> INLINE
void BB_NODE<T>::get_leaves(ARRAY<BB_NODE<T>* > &all_leaves, int &pos)
{
  if ( (branch_upper==NULL) && (branch_under==NULL) ) { all_leaves[pos]=this; pos++; }
  else {
    if (branch_upper) branch_upper->get_leaves(all_leaves,pos);
    if (branch_under) branch_under->get_leaves(all_leaves,pos);
  }
}

template <class T> INLINE
int BB_NODE<T>::number_of_leaves() const
{
  int nbl=0;
  if ( (branch_upper==NULL) && (branch_under==NULL) ) nbl=1;
  else {
    if (branch_upper) nbl+=branch_upper->number_of_leaves();
    if (branch_under) nbl+=branch_under->number_of_leaves();
  }
  return(nbl);
}

template <class T> INLINE
BB_NODE<T>* BB_NODE<T>::locate(const VECTOR &pmin, const VECTOR &pmax) const
{
  unsigned char inside_upper=0,inside_under=0;

  if (!is_in(pmin)) return NULL;
  if (!is_in(pmax)) return NULL;

  if (branch_upper) {
    if (branch_upper->is_in(pmin)) inside_upper++;
    if (branch_upper->is_in(pmax)) inside_upper++;
  }

  if (branch_under) {
    if (branch_under->is_in(pmin)) inside_upper++;
    if (branch_under->is_in(pmax)) inside_upper++;
  }

  if ( (inside_upper==2) && (inside_under==2) ) INTERNAL_ERROR;

  if (inside_upper==2) return(branch_upper->locate(pmin,pmax));
  else if (inside_under==2) return(branch_under->locate(pmin,pmax));

  return(THIS);
}

// find rank of elements containing point pos in bb tree
template <class T> INLINE
void BB_NODE<T>::find(const VECTOR &pos, BUFF_LIST<T*> &found) const
{
  const double &bt=boss->tolerance;
  if (pos[dir]<min[dir]-bt) return;
  if (pos[dir]>max[dir]+bt) return;
  if (this->element) {
    if(is_in(pos)) found.add(this->element);
    THIS->boss->last_found=THIS;
  } else {
    if (this->branch_upper) branch_upper->find(pos,found);
    if (this->branch_under) branch_under->find(pos,found);
  }
}

// find rank of elements inside current box (Pmin<->Pmax) in bb tree
template <class T> INLINE
void BB_NODE<T>::find_in_box(const VECTOR &Pmin,const VECTOR &Pmax, BUFF_LIST<T*> &found) const
{
  if (this->branch_upper || this->branch_under) {
    const double &_pmin=Pmin[dir], &_pmax=Pmax[dir];
    const double &tol=this->boss->tolerance;
    if((_pmax>=branch_under->min[dir]-tol) && (_pmin<=branch_under->max[dir]+tol))
      branch_under->find_in_box(Pmin,Pmax,found);
    if((_pmax>=branch_upper->min[dir]-tol) && (_pmin<=branch_upper->max[dir]+tol))
      branch_upper->find_in_box(Pmin,Pmax,found);
  } else {
    // Check if truely instersect box
    const double &tol=this->boss->tolerance;
    if(Pmax[0]<min[0]-tol) return;
    if(Pmin[0]>max[0]+tol) return;
    if(Pmax[1]<min[1]-tol) return;
    if(Pmin[1]>max[1]+tol) return;
    if(min.size()>2){
      if(Pmax[2]<min[2]-tol) return;
      if(Pmin[2]>max[2]+tol) return;
    }
    // OK
    assert(this->element);
    found.add(this->element); // for valid extremity return rank
    THIS->boss->last_found=THIS;
  }
}

// find rank of elements intersecting whith line in bb tree
template <class T> INLINE
void BB_NODE<T>::find(const VECTOR &P1,const VECTOR &P2, BUFF_LIST<T*> &found, BUFF_LIST<double> &dist_f) const
{
  double dist;
  if(THIS->is_intersect(P1,P2,dist)) {
    if (this->branch_upper || this->branch_under) {
      branch_under->find(P1,P2,found,dist_f);
      branch_upper->find(P1,P2,found,dist_f);
    } else {
      // Order from distance for fast checking
      assert(this->element);
      int pos;
      for(pos=0;pos<found.size();pos++)
        if(dist_f[pos]>dist)
          break;
      found.add_at(pos,this->element); // for valid extremity return rank
      dist_f.add_at(pos,dist); // for valid extremity add distance
      THIS->boss->last_found=THIS;
    }
  }
}

#undef THIS

template <class T> INLINE
void BB_NODE<T>::init_node(int _prof, BB_NODE<T> *_father, BUFF_LIST< BB_NODE<T>* > &list_elem, BB_TREE<T> &_boss)
{
  this->boss=&_boss;
  prof=_prof;
  dir=prof % list_elem.first()->max.size();
  father=_father;
  build(list_elem);
}

WIN_THINGIE extern int *_dir_p;
WIN_THINGIE int _bb_node_compare(const void *_p1, const void *_p2);

// Build the bb tree
template <class T> INLINE
void BB_NODE<T>::build(BUFF_LIST< BB_NODE<T>* > &list_elem)
{
  // build the tree
  int i,j,dim=this->boss->dim;

  assert(list_elem.size());

  if(list_elem.size()==1) { 
    // a terminal leaf
    this->branch_under=this->branch_upper=NULL;
    this->min=list_elem.first()->min; 
    this->max=list_elem.first()->max;
    this->element=list_elem.first()->element;

    delete(list_elem.first());
    // keep info on tree
    this->boss->average_prof_incr(prof);
    if (prof<this->boss->min_prof()) this->boss->min_prof(prof);
    if (prof>this->boss->max_prof()) this->boss->max_prof(prof);

  } else {
    // a non terminal leaf, ie a node
    BUFF_LIST< BB_NODE<T>* > list_under,list_upper;

    // extract the bounding box of all elements
    this->min=list_elem.first()->min;
    this->max=list_elem.first()->max;

    for(j=1;j<list_elem.size();j++) {
      BB_NODE<T> &bbel=*list_elem[j];

      for(int i=0;i<dim;i++) {
        if(bbel.min[i]<this->min[i]) this->min[i]=bbel.min[i];
        if(bbel.max[i]>this->max[i]) this->max[i]=bbel.max[i];
      }
    }

    // calculate the median value, in order to balance the tree
    // sort all elements according to their bounding box
    _dir_p=&this->dir;
    ::qsort(&(list_elem.first()),list_elem.size(),sizeof(void*),_bb_node_compare);

    // get section value using median value in direction dir
    int i_section=list_elem.size()/2;
    double sec=list_elem.get(i_section)->max[dir];

/*  // handle the case where the section is constant over some elements (for instance in regular meshes)
    this->section=sec;
    int i_limit;
    for (i_limit=i_section; ((i_limit>=0) && (sec-list_elem->get(i_limit)->max[dir])==0.) ; i_limit--) { }
    i_limit++;
*/

    int i_limit=i_section;
    this->section=sec;

    // fill lists
    list_under.resize(i_limit); 
    for(i=0;i<i_limit;i++) list_under[i]=list_elem[i];
    list_upper.resize(list_elem.size()-i_limit);  j=0;
    for(i=i_limit;i<list_elem.size();i++) { list_upper[j]=list_elem[i]; j++; }

    // build recursivly
    if (list_under.size()) {
      branch_under=new BB_NODE<T>(this->bb_function,NULL);
      branch_under->init_node(prof+1,this,list_under,*this->boss);
    }

    if (list_upper.size()) {
      branch_upper=new BB_NODE<T>(this->bb_function,NULL);
      branch_upper->init_node(prof+1,this,list_upper,*this->boss);
    }
  }
}

template <class T> INLINE
BB_TREE<T>::BB_TREE(BB_FUNCTION f)
{
  tolerance=1.e-6;
  _min_prof=100000000;
  _max_prof=0;
  _average_prof=0.;
  last_found=NULL;
  use_coord=FALSE;
  if_built=FALSE;
  root=NULL;
  bb_function=f;
}

template <class T>  INLINE
void BB_TREE<T>::build(CARRAY<T*> &l)
{
  if (root) { root->delete_branch(); delete(root); root=NULL; }
  if (l.size()==0) return;

  VECTOR pmin,pmax;
  BUFF_LIST< BB_NODE<T>* > list_elem;

  bb_function(*l[0],pmin,pmax);
  dim=pmin.size();

  // build all element to be inserted in the tree
  // these bb_elements are just wrapper aroud T instances
  list_elem.resize(l.size());
  for(int ielem=0;ielem<l.size();ielem++) {
    BB_NODE<T>* bb_node=new BB_NODE<T>(bb_function,l[ielem]);
    bb_function(*l[ielem],pmin,pmax); // get bounding box
    bb_node->min=pmin;
    bb_node->max=pmax;
    bb_node->boss=this;
    list_elem[ielem]=bb_node;
  }

  // create and initialize the root tree
  root=new BB_NODE<T>(bb_function,NULL);
  root->init_node(0,NULL,list_elem,*this);
  _average_prof/=(long double)(l.size());
}

// return elements containing point P
template <class T> INLINE
bool BB_TREE<T>::find_elem(const VECTOR &P, BUFF_LIST<T*> &ret)
{
  ret.set_size(0);
  if (!root) return(FALSE);
  root->find(P,ret);
  return (ret.size());
}

// return true rank of elems intersection with line
template <class T> INLINE
bool BB_TREE<T>::find_elem(const VECTOR& P1, const VECTOR &P2, VECTOR& /*PTi*/, BUFF_LIST<T*> &ret)
{
  BUFF_LIST<double> dist;
  ret.set_size(0);
  if (!root) return(FALSE);
  root->find(P1,P2,ret,dist);
  return(ret.size());
}

// an attempt to accelerate
/*
template <class T> INLINE
T* BB_TREE<T>::find_elem_fast(const VECTOR& P)
{
  BUFF_LIST<T*> ret(1024);

  if (!root) return(NULL);

  if (last_found != NULL) {
    if (last_found->is_in(P)) return &(last_found->give_element()); else 
    if(last_found->prof>3) { // look in 8 nearest elems
      BB_NODE<T> *root_node=last_found->boss->root->father;
      root_node->find(P,ret);
      for(int i=0;i<ret.size();i++)
        if(ret[i]->is_in(P)) return &(ret[i]->give_element());
      // if doesn't work look over all tree
    }
  }
  root->find(P,ret);
  for(int i=0;i<ret.size();i++)
    if(ret[i]->is_in(P)) return &(ret[i]->give_element());

  return NULL;
}
*/

// returns list of node inside selected box
template <class T> INLINE
bool BB_TREE<T>::find_in_box(const VECTOR &Pmin,const VECTOR &Pmax, BUFF_LIST<T*> &found) const
{
  found.set_size(0);
  if (!root) return(FALSE);
  root->find_in_box(Pmin,Pmax,found);
  return(found.size());
}

template <class T> 
double closest(const VECTOR &pos,BUFF_LIST<T*> &found) // return distance get closest to pos elements
{
 /* double dst=.5*DBL_MAX;
  BUFF_LIST <double> min_dist(found.size());
  found.resize(0);
  if(last_found) {
    dst=THIS->boss->last_found->minmaxdist2(pos);
    found.add(THIS->boss->last_found);
    min_dist.add(THIS->boss->last_found->mindist2(pos));
  }
  closest(pos,dst,min_dist,found);*/
  return 0.;
}


#endif
