#ifndef __Help__
#define __Help__

#include <Defines.h> 
#include <Aaa_zmat_globals.h>

Z_START_NAMESPACE;

typedef void (*HELP_FUNCTION)();

ZCLASS HELP_CLASS {
    static int Hcount; 

  public :
    HELP_CLASS(HELP_FUNCTION);

    static void ShowHelp();
};

#define MAKE_HELP(f) Z_START_NAMESPACE;  static HELP_CLASS __helper__##f(f); Z_END_NAMESPACE;

Z_END_NAMESPACE;

#endif
