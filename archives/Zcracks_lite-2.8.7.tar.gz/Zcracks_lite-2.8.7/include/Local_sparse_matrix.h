#ifndef __Local_sparse_matrix__
#define __Local_sparse_matrix__

// ============================================================================ 
//  LOCAL_SPARSE_MATRIX     AM 07/2002
//
//  a small copy of the sparse solvers to make  sparse matrix multiplies. 
//  First by to speed up the contact rotations, but possibly useful elsewhere. 
// ============================================================================ 

#include <Error_messager.h>
#include <Sorted_list.h>

#include <Vector.h>

Z_START_NAMESPACE;

ZCLASS2 LOCAL_SPARSE_MATRIX {
  protected : 
    int          nsize  ;             // size of matrix
    bool symmetric;
    ARRAY<int>   column_pointers;     // cumulative size of columns in matrix (symmetric structure)
    ARRAY<int>   not_null;            // rank of non zero dofs in matrix (symmetric structure)
    VECTOR       upper_triangle;      // sparse storage 
    VECTOR       lower_triangle;      // sparse storage
    double& operator()(int i, int j);

  public :

    LOCAL_SPARSE_MATRIX(const LOCAL_SPARSE_MATRIX&);
    LOCAL_SPARSE_MATRIX();
    ~LOCAL_SPARSE_MATRIX();     

    void operator=(const LOCAL_SPARSE_MATRIX&);
    SMATRIX& operator[](int i);
    const SMATRIX& operator[](int i)const;

    VECTOR  operator*(const VECTOR& v)const;

    double index(int i,int j){return (*this)(i,j);};

    void    multv(const VECTOR&,VECTOR& )const;

    friend LOCAL_SPARSE_MATRIX operator+(const LOCAL_SPARSE_MATRIX&,const LOCAL_SPARSE_MATRIX&);
    friend LOCAL_SPARSE_MATRIX operator-(const LOCAL_SPARSE_MATRIX&,const LOCAL_SPARSE_MATRIX&);
    friend LOCAL_SPARSE_MATRIX operator*(const LOCAL_SPARSE_MATRIX&,double);
    friend LOCAL_SPARSE_MATRIX operator/(const LOCAL_SPARSE_MATRIX&,double);

    void initialize_structure(ARRAY< SORTED_LIST<int> > connected_array);
    void store(int i,int j,const double term);
    void initialize_matrix();
    double row_norm(int row);
};
Z_END_NAMESPACE;

#endif
