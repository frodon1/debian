#define USE_MODE_SURFACE 1
#define USE_MODE_VOLUME 1
#define MESH_ALL_COMPONENTS 0
#define SIZEMAP_FUNCTION 0

#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/meshgems.h>
#include <meshgems/adapt.h>

/* FOR OEM customers only, uncomment the following */
/*#include <meshgems_key_xxx.h>*/

/**
 * Let's assume that the following structure holds data that
 * represents the input surface mesh on client side.  
 * It could be a database handle or
 * anything else containing surface mesh data. 
 * We will build the mesh_t object that accesses it.
 * See the file meshgems/mesh.h for more detailed information
 */

struct your_mesh_internal_data_t_ {
  /*    _your_mesh_data; */
};

typedef struct your_mesh_internal_data_t_ your_mesh_internal_data_t;

/**
 * Implementation of how the number of vertices in the mesh is obtained.
 * @param[out]	nbvtx	: the number of vertices
 * @param[in]	user_data: a user pointer.
 * @return error code
 */

status_t mgtm_get_vertex_count(integer * nbvtx, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbvtx = 0;                   /* the number of vertices in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the coordinates of a mesh vertex are obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	xyz	: real[3] array containing the coordinates of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_coordinates(integer ivtx, real * xyz,
                                     void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    xyz[j] = 0.0;                 /* the j'th coordinate of the ivtx'th vertex */

  return STATUS_OK;
}

/**
 * Implementation of how the number of edges in the mesh is obtained.
 * @param[out]	nbedge	: the number of edges
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_count(integer * nbedge, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbedge = 0;                  /* the number of edges in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh edge are obtained.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	vedge	: integer[2] array containing the vertices of the edge
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_vertices(integer iedge, integer * vedge,
                                void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 2; j++)
    vedge[j] = 0;               /* the j'th vertex index of the iedge'th edge */

  return STATUS_OK;
}

/**
 * Implementation of how the number of triangles in the mesh is obtained.
 * @param[out]	nbtri	: the number of triangles
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_count(integer * nbtri, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbtri = 0;                   /* the number of triangles in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh triangle are obtained.
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]	vtri	: integer[3] array containing the vertices of the triangle
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_vertices(integer itri, integer * vtri,
                                    void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    vtri[j] = 0;                /* the j'th vertex index of the itri'th triangle */

  return STATUS_OK;
}

/**
 * Implementation of how to obtain the required property of vertices in the mesh.
 * @param[in]	ivtx	: index of the desired vertex from 1 to nbvtx
 * @param[out]	rvtx	: integer containing the required property of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_required_vertex_property(integer ivtx, integer * rvtx,
                                           void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *rvtx = 0;                    /* the ivtx'th vertex required property : 1 if the vertex is required or 0 if it is not */

  return STATUS_OK;
}

/**
 * Implementation of how to obtain the required property of edges in the mesh.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	redge	: integer containing the required property of the edge
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_required_edge_property(integer iedge, integer * redge,
					 void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *redge = 0;			/* the iedge'th edge required property : 1 if the edge is required or 0 if it is not */

  return STATUS_OK;
}


struct _your_mesh_background_internal_data_t_ {
  // _your_sizemap_data_t_;
};

typedef struct _your_mesh_background_internal_data_t_
your_mesh_background_internal_data_t;

/* 
 * The sizemap can be given with a background mesh or thanks to a function.
 * Below are the functions needed if a sizemap is given with a background mesh.
 */

  
/**
 * Implementation of how the number of vertices in the background mesh is obtained.
 * @param[out]	nbvtx	: the number of vertices
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t bg_get_vertex_count(integer * nbvtx, void *user_data)
{
  
  your_mesh_background_internal_data_t *mm =
    (your_mesh_background_internal_data_t *) user_data;
  
  *nbvtx = 0;                   /* the number of points in your sizemap; */
  
  return STATUS_OK;
}

/**
 * Implementation of how the coordinates of a background mesh vertex are obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	xyz	: real[3] array containing the coordinates of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t bg_get_vertex_coordinates(integer ivtx, real * xyz,
				   void *user_data)
{
  int j;
  your_mesh_background_internal_data_t *mm =
    (your_mesh_background_internal_data_t *) user_data;
  
  for (j = 0; j < 3; j++)
    xyz[j] = 0.0;                 /* the j'th coordinate of the ivtx'th vertex; */
  
  return STATUS_OK;
}

/**
 * Implementation of how the weight (size) of a mesh vertex
 * is obtained. 
 * @param[in]	ivtx	: index of the desired vertex from 1 to nbvtx
 * @param[out]	svtx	: real  containing the size at the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */

status_t bg_get_vertex_size(integer ivtx, real * svtx,
			    void *user_data)
{
  your_mesh_background_internal_data_t *mm =
    (your_mesh_background_internal_data_t *) user_data;
  
  *svtx = 1.0;			/* the size at the ivtx'th vertex */
  
  return STATUS_OK;
}

/**
 * Implementation of how the number of tetrahedron in the background mesh is obtained.
 * @param[out]	nbtet	: the number of tetrahedra
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t bg_get_tetrahedron_count(integer * nbtet, void *user_data)
{
  your_mesh_background_internal_data_t *mm = (your_mesh_background_internal_data_t *) user_data;
  
  *nbtet = 0;                   /* the number of tetrahedra in your background mesh */
  
  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a background mesh tetrahedra are obtained.
 * @param[in]	itet	: index of the desired triangle from 1 to nbtet
 * @param[out]	vtet	: integer[4] array containing the vertices of the tetrahedron
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t bg_get_tetrahedron_vertices(integer itet, integer * vtet,
				     void *user_data)
{
  int j;
  your_mesh_background_internal_data_t *mm = (your_mesh_background_internal_data_t *) user_data;
  
  for (j = 0; j < 3; j++)
    vtet[j] = 0;                /* the j'th vertex index of the itet'th tetrahedron */
  
  return STATUS_OK;
}


/*
 * You can define the sizemap as a function. 
 * Look in the documentation for an example of anisotropic sizemap.
 */
/**
 * Implementation of a sizemap continuous function.
 * @param[in]	xyz	: real[3] array containing the coordinates
 * @param[out]	size	: size at the xyz location above
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t sizemap_3d_fun(real *xyz, real *size, void *user_data)
{
  *size = 1.0; /* your sizemap function */
  
  return STATUS_OK;
}


/**
 * This is the message callback function that Adapt will call when
 * it wants to send a message to the caller
 * see meshgems/message.h for more details.
 *
 * @param[in] msg       : the message
 * @param[in] user_data : a user pointer.
 * @return an error code
 */
status_t my_message_cb(message_t * msg, void *user_data)
{
  char *desc;
  integer e;
  status_t ret;

  /* Get the error number */
  ret = message_get_number(msg, &e);
  if(ret != STATUS_OK)
    return ret;

  if (e == MESHGEMS_ADAPT_CODE(-4300)) {
    /* This is the error 4300, related to sizemap
     */
    printf("incompatible sizemap type with ADAPT");
  } else {
    ret = message_get_description(msg, &desc);
    if (ret != STATUS_OK)
      return ret;

    printf("MG-Adapt message : %s", desc);
  }
  return STATUS_OK;
}


status_t set_adapt_parameters(adapt_session_t * mas)
{
  status_t ret;

  /* You can here specify the Adapt options, using the API function
   * meshgems_adapt_set_param().
   */

  /* Check the Adapt User's Manual, section 4.4 to know what are the
   * available parameters (the options handled only by the executable are:
   * --help, --in, --out, --read_sizemap and --write_sizemap).
   * To use them, remove the double dash and send the value as a string.
   * See examples below.
   */


  /* For example :
   */

  /* This option changes the verbosity level of Adapt, between 1 and
   * 10.  The higher it is, the more messages Adapt will send
   * through the message callback. Default is 3.
   */
  ret = meshgems_adapt_set_param(mas, "verbose", "3");
  if (ret != STATUS_OK)
    return ret;

  /* This option changes the maximum memory allocated 
     Here we allocate 3000 megabytes, for example.
  */
  ret = meshgems_adapt_set_param(mas, "max_memory", "3000");
  if (ret != STATUS_OK)
    return ret;

  /* This option controls the adaptation mode. 
   * If the parameter is set to :
   * -"both" : a surface and volume adaptation will be processed
   * -"surface" : a surface adaptation will be processed
   * -"volume" : a volume adaptation will be processed
   * Default is "both".
   */
  if (USE_MODE_SURFACE) {
    if (USE_MODE_VOLUME) {
      ret = meshgems_adapt_set_param(mas, "adaptation", "both");
      if (ret != STATUS_OK)
	return ret;
    }
    else {
      ret = meshgems_adapt_set_param(mas, "adaptation", "surface");
      if (ret != STATUS_OK)
	return ret;
    }
  }
  else if (USE_MODE_VOLUME) {
    ret = meshgems_adapt_set_param(mas, "adaptation", "volume");
    if (ret != STATUS_OK)
      return ret;
  }
  
  /* Set this parameter to "all" if you want all connex components to be
   * meshed or to "outside_components" if you only want the main one.
   * default is the main one
   */
  if (MESH_ALL_COMPONENTS) {
    ret = meshgems_adapt_set_param(mas, "components", "all");
    if (ret != STATUS_OK)
      return ret;
  } else {
    ret = meshgems_adapt_set_param(mas, "components", "outside_components");
    if (ret != STATUS_OK)
      return ret;
  }
  
  return STATUS_OK;
}


/* A macro we will call to cleanly return from the function in case of 
 * failure 
 */

#define RETURN_WITH_MESSAGE(_ret, _msg) do{				\
    fprintf(stderr,"%s\n",_msg);					\
    if(ctx) context_delete(ctx);					\
    return _ret;							\
  }while(0);



status_t adapt_mesh(your_mesh_internal_data_t * your_mesh_internal_data,
		    your_mesh_background_internal_data_t *
		    your_mesh_background_internal_data)
{
  status_t ret;
  context_t *ctx;
  mesh_t *msh;
  mesh_t *msh_output;
  mesh_t *msh_bg;
  adapt_session_t *mas;
  sizemap_t *sizemap;
  sizemap_t *sizemap_output;

  integer i, nvm, ntm, nem, nsd;
  integer nbreqvtx = 0;
  integer isReqvtx;
  integer nbreqedge = 0;
  integer isReqedge;

  ctx = 0;
  msh = 0;
  msh_output = 0;
  msh_bg = 0;
  mas = 0;
  sizemap = 0;
  sizemap_output = 0;

  /*
   * Create the meshgems working context
   */
  ctx = context_new();
  if (!ctx)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new context");

  /*
   * Set the message callback for our context and create the mesh accessor.
   */
  ret = context_set_message_callback(ctx, my_message_cb, 0);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /*
   * Create the mesh_t structure holding the callbacks giving acces to your
   * mesh data in your_mesh_internal_data
   */
  msh = mesh_new(ctx);
  if (!msh)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new mesh");

  /*
   * Set the mesh_t callback functions that will interrogate the mm_t struct :
   * see meshgems/mesh.h for more details.
   */

  ret = mesh_set_get_vertex_count(msh, mgtm_get_vertex_count,
                                  your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret = mesh_set_get_vertex_coordinates(msh, mgtm_get_vertex_coordinates,
                                        your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
 
  ret =
      mesh_set_get_vertex_required_property(msh,
                                            mgtm_get_required_vertex_property,
                                            your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
 
  ret =
      mesh_set_get_edge_count(msh, mgtm_get_edge_count,
                              your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret = mesh_set_get_edge_vertices(msh, mgtm_get_edge_vertices,
                                   your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret =
      mesh_set_get_edge_required_property(msh,
                                          mgtm_get_required_edge_property,
                                          your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret = mesh_set_get_triangle_count(msh, mgtm_get_triangle_count,
                                    your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret = mesh_set_get_triangle_vertices(msh, mgtm_get_triangle_vertices,
                                       your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
 

  /*
   * Create a sizemap to hold the size specification for mesh vertices.
   */

  if(SIZEMAP_FUNCTION) {  
    sizemap = sizemap_new(ctx,
			  meshgems_sizemap_type_iso_3d,
			  sizemap_3d_fun,
			  your_mesh_internal_data);
  } else {
    msh_bg = mesh_new(ctx);
    
    if (!msh_bg) {
      RETURN_WITH_MESSAGE(ret, "unable to create a new mesh ");
    }
    
    mesh_set_get_vertex_count(msh_bg,
			      bg_get_vertex_count,
			      your_mesh_background_internal_data);
    mesh_set_get_vertex_coordinates(msh_bg,
				    bg_get_vertex_coordinates,
				    your_mesh_background_internal_data);
    mesh_set_get_tetrahedron_count(msh_bg,
				bg_get_tetrahedron_count,
				your_mesh_background_internal_data);
    mesh_set_get_tetrahedron_vertices(msh_bg,
				   bg_get_tetrahedron_vertices,
				   your_mesh_background_internal_data);
  
     
    sizemap = sizemap_new(msh_bg,
			  meshgems_sizemap_type_iso_mesh_vertex,
			  (void *) bg_get_vertex_size,
			  your_mesh_background_internal_data);
  }
  
  if (!sizemap)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new mesh");
  
  if (0) {
    /*
     * Display some statistics about the surface mesh.
     * The data is sent formatted to the context message callback
     * For debugging purposes
     */
    ret = mesh_compute_statistics(msh);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to perform some statistic on input mesh");
  }

#ifdef __MESHGEMS_PRIVKEY_H__
  /* If you are an OEM customer for Adapt, sign this mesh object with
   * your private key (else Adapt would reject it) */
  ret = meshgems_sign_mesh(msh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to sign input mesh");
#endif

  /*
   * Create an adapt session
   */

  mas = meshgems_adapt_session_new(ctx);
  if (!mas)
    RETURN_WITH_MESSAGE(STATUS_NOMEM,
                        "unable to create a new MeshGems-Adapt session");

  /*
   * Set the input working mesh for this adapt session
   */
  
  /*
   * Starting from a mesh.
   */
  
  ret = meshgems_adapt_set_surface_mesh(mas, msh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to set surface mesh");
  
  ret = meshgems_adapt_set_sizemap(mas, sizemap);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to set sizemap");
  
  /* 
   * You can here specify the MG-ADAPT options, using the function
   * adapt_set_param(), see the documentation.
   */

  ret = set_adapt_parameters(mas);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /* 
   * To compute the result mesh
   */
  
  ret = meshgems_adapt_compute(mas);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to compute a mesh");
  
  /*
   * Mesh generation is completed.
   * Get the generated mesh. This output mesh belongs to the
   * adapt_session. Thus the user does not have to delete it
   * afterwards.
   */
  
  ret = meshgems_adapt_get_mesh(mas, &msh_output);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting mesh");
  
  /*
   * You can get the sizemap used by Adapt to generate the mesh as well.
   * This output sizemap belongs to the adapt_session.
   * Thus the user does not have to delete it afterwards.
   */

  ret = meshgems_adapt_get_sizemap(mas, &sizemap_output);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting sizemap");
  
  /*
   * Below, are shown ways to access the data contained in the output
   * mesh and the output sizemap.  The first example accesses data and
   * prints it, while the second example uses MeshGems API to write
   * files in MESH and SOL formats.
   *
   * See meshgems/mesh.h for more details.
   *
   * Access the output mesh data.
   */

  /* EXAMPLE 1 */

  /* 
   * First get all the vertices 
   */
  ret = mesh_get_vertex_count(msh_output, &nvm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex count");

  for (i = 1; i <= nvm; i++) {
    real coo[3];
    ret = mesh_get_vertex_coordinates(msh_output, i, coo);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting vertices");
    if (0) {
      fprintf(stdout, "vertex %d is : %f %f %f \n", i, coo[0], coo[1],
              coo[2]);
    }
  }

  /* 
   * Then get all the required vertices  
   */
  for (i = 1; i <= nvm; i++) {
    ret = mesh_get_vertex_required_property(msh_output, i, &isReqvtx);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex property");
    if (isReqvtx)
      nbreqvtx++;
   }
  if (nbreqvtx) {
    fprintf(stdout, "%d required vertices in the domain \n", nbreqvtx);
    for (i = 1; i <= nvm; i++) {
      ret = mesh_get_vertex_required_property(msh_output, i, &isReqvtx);
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret,
                            "unable to get resulting vertex property");
      if (isReqvtx)
        fprintf(stdout, "required vertex %d \n", i);
    }
  }

  /* 
   * Then get all the edges 
   */
  ret = mesh_get_edge_count(msh_output, &nem);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting edge count");

  for (i = 1; i <= nem; i++) {
    integer vtx[2];
    ret = mesh_get_edge_vertices(msh_output, i, vtx);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting edge");
    if (0) {
      fprintf(stdout, "edge %d is : %d %d \n", i, vtx[0], vtx[1]);
    }
  }
  /* 
   * Then get all the required edges  
   */
  for (i = 1; i <= nem; i++) {
    ret = mesh_get_edge_required_property(msh_output, i, &isReqedge);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting edge property");
    if (isReqedge)
      nbreqedge++;
  }
  if (nbreqedge) {
    fprintf(stdout, "%d required edges in the domain \n", nbreqedge);
    for (i = 1; i <= nem; i++) {
      ret = mesh_get_edge_required_property(msh_output, i, &isReqedge);
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret, "unable to get resulting edge property");
      if (isReqedge)
        fprintf(stdout, "required edge %d \n", i);
    }
  }

  /* 
   * Then get all the triangles 
   */
  ret = mesh_get_triangle_count(msh_output, &ntm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting triangle count");

  for (i = 1; i <= ntm; i++) {
    integer vtx[3];
    ret = mesh_get_triangle_vertices(msh_output, i, vtx);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting triangle");
    if (0) {
      fprintf(stdout, "triangle %d is : %d %d %d \n", i, vtx[0], vtx[1],
              vtx[2]);
    }
  }
  
  if(USE_MODE_VOLUME) {
    /* Then get all the tetrahedra, their tags and 
     * compute some statistics on their aspect ratio 
     */
    
    ret = mesh_get_tetrahedron_count(msh_output, &ntm);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedron count");
    
    for (i = 1; i <= ntm; i++) {
      integer vtx[4], tag;
      ret = mesh_get_tetrahedron_vertices(msh_output, i, vtx);
      if (ret != STATUS_OK)
	RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedra");
      if (0) {
	fprintf(stdout, "tetra %d is : %d %d %d %d \n", i, vtx[0], vtx[1],
		vtx[2], vtx[3]);
      }
      ret = mesh_get_tetrahedron_tag(msh_output, i, &tag);
      if (ret != STATUS_OK)
	RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedra tag");
      if (0) {
	fprintf(stdout, "tetra %d is in subdomain %d\n", i, tag);
      }
   
      /* ... you may insert your stat computation here ... */

      fprintf(stdout, "\nGenerated %d vertices and %d tetrahedra\n", nvm,
	      ntm);

      /* ... you may print your stats here ... */

    }

    if (MESH_ALL_COMPONENTS) {
      /*
       * Read the subdomain identification information.
       * Only available if you have set the parameter "components" to "all"
       */
      ret = mesh_get_subdomain_count(msh_output, &nsd);
      if (ret != STATUS_OK)
	RETURN_WITH_MESSAGE(ret, "unable to get resulting subdomain count");
      
      fprintf(stdout, "Identified subdomains : %d\n", nsd);
      if (nsd > 1) {
	for (i = 1; i <= nsd; i++) {
	  integer subdomain_tag, seed_type, seed_idx, seed_orientation;
	  char *seed_type_str;
	  ret = mesh_get_subdomain_description(msh_output, i,
					       &subdomain_tag,
					       &seed_type, &seed_idx,
					       &seed_orientation);
	  if (ret != STATUS_OK)
	    RETURN_WITH_MESSAGE(ret, "unable to get a subdomain seed");
	  
	  if (seed_type == MESHGEMS_MESH_ELEMENT_TYPE_TRIA3) {
	    seed_type_str = "triangle";
	  } else {
	    /* The only seed type generated by MeshGems-Adapt is the triangle */
	    seed_type_str = "unknown error";
	  }
	  
	  fprintf(stdout,
		  "subdomain %d description is : tag=%d type=%s facet=%d orientation=%d \n",
		  i, subdomain_tag, seed_type_str, seed_idx,
		  seed_orientation);
	}
      }
    }
  }
  
  /* 
   * Get the index of the tetrehedron in the background mesh which
   * contains the given vertex (it is called a seed)
   */
  for (i = 1; i <= nvm; i++) {
    integer seed[1];
    meshgems_adapt_get_vertex_seed(mas, i, seed);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get the vertex seed interpolation");
    if (0) {
      fprintf(stdout, "seed of vertex %d is : %d  \n", i, seed[0]);
    }
  }

  /*
   * Access the output sizemap data. 
   */
  
  for (i = 1; i <= nvm; i++) {
    real size[1];
    ret= meshgems_sizemap_iso_mesh_vertex_get_size(sizemap_output, i,size);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting sizemap");
    if (0) {
      fprintf(stdout, "size at vertex %d is : %f  \n", i, size[0]);
    }

  }

  /* EXAMPLE 2 */

  /*
   * One can write the output mesh in a MESH formatted file:
   *
   * Please note that the seeds are not saved in the MESH file.
   */

  fprintf(stdout, "Writing adapted mesh in adapt_result.mesh file\n");
  ret = meshgems_mesh_write_mesh(msh_output, "adapt_result.mesh");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a .mesh file");

  /*
   * One can write the sizemap in a SOL formatted file:
   */

  fprintf(stdout, "Writing sizemap in adapt_result.sol\n");
  ret = meshgems_sizemap_write_sol(sizemap_output, "adapt_result.sol");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a .sol file");



  if (0) {
    /*
     * Display some statistics about the output mesh.
     * The data is sent formatted to the context message callback
     * for debugging purposes.
     */
    ret = mesh_compute_statistics(msh_output);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to perform some statistic on output mesh");
  }


  /*
   * We are done, give the volume mesh and sizemap back to the session 
   * and clean up everything.
   */

  meshgems_adapt_regain_mesh(mas, msh_output);
  meshgems_adapt_regain_sizemap(mas, sizemap_output);
  meshgems_adapt_session_delete(mas);
  mesh_delete(msh);
  if (sizemap)
    meshgems_sizemap_delete(sizemap);

  meshgems_context_delete(ctx);

  return STATUS_OK;
}
