#ifndef __STD_UTILITY_REL_EDGE__
#define __STD_UTILITY_REL_EDGE__

#include <Utility_relations.h>

Z_START_NAMESPACE;

ZCLASS L2_UTILITY_REL_EDGE : public UTILITY_REL_EDGE
{
  public :
    L2_UTILITY_REL_EDGE() : UTILITY_REL_EDGE() { 
      nodes.resize(2); type="L2"; 
    }
    virtual ~L2_UTILITY_REL_EDGE() { }

    virtual void to_quadratic(BUFF_LIST<UTILITY_NODE*>&,BUFF_LIST<UTILITY_REL_NODE*>&);
    RTTI_INFO;
};

ZCLASS L3_UTILITY_REL_EDGE : public UTILITY_REL_EDGE
{
  public :
    L3_UTILITY_REL_EDGE() : UTILITY_REL_EDGE() { nodes.resize(3); type="L3"; }
    virtual ~L3_UTILITY_REL_EDGE() { }
    virtual void to_quadratic(BUFF_LIST<UTILITY_NODE*>& /* added */) { ERROR("Cannot change to quadratic: already quadratic"); }

    RTTI_INFO;
}; 

ZCLASS L4_UTILITY_REL_EDGE : public UTILITY_REL_EDGE
{
  public :
    L4_UTILITY_REL_EDGE() : UTILITY_REL_EDGE() { nodes.resize(4); type="L4"; }
    virtual ~L4_UTILITY_REL_EDGE() { }
    virtual void to_quadratic(BUFF_LIST<UTILITY_NODE*>& /* added */) { ERROR("Cannot change to quadratic: already quadratic"); }

    RTTI_INFO;
}; 
Z_END_NAMESPACE;

#endif
