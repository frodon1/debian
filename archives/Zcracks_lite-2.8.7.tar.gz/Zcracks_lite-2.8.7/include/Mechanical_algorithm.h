#ifndef __Mechanical_algorithm__
#define __Mechanical_algorithm__

#include <Algorithm.h>
#include <Dof.h>

Z_START_NAMESPACE;

class DAMPING; 

ZCLASS2 MECHANICAL_ALGORITHM : public ALGORITHM {
  public :

    MECHANICAL_ALGORITHM();
    virtual ~MECHANICAL_ALGORITHM();
    INTEGRATION_RESULT* evaluate_static_residual(
                MESH&, GLOBAL_MATRIX&, 
                VECTOR& residual, 
                bool if_compute_stiffness,
                bool get_only_elementary_matrix);

    INTEGRATION_RESULT* evaluate_dynamic_residual(
                MESH& the_mesh,
                GLOBAL_MATRIX& K, GLOBAL_MATRIX& K0, GLOBAL_MATRIX& M,
                VECTOR& residual, VECTOR& accel, VECTOR& veloc, VECTOR& veloc0,
                VECTOR& df, VECTOR& df0,
                bool if_compute_stiffness,
                bool get_only_elementary_matrix, 
                double alpha,double beta, bool set_K0, DAMPING* damping, bool if_compute_internal_reac);

};
Z_END_NAMESPACE;

#endif
