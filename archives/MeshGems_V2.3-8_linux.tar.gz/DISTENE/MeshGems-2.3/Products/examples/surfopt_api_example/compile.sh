gcc -I. -L. mg-surfopt_example.c -lmg-surfopt -lmg-tetra -lmeshgems -lmeshgems_stubs -lm -lc  -o mg-surfopt_example.exe
