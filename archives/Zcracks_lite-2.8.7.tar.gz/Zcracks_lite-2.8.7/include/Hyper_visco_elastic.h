#ifndef  __Hyper_visco_elastic__
#define  __Hyper_visco_elastic__

// ---------------------------------------------------------------------------- 
//  HYPER_VISCO_ELASTIC  
// 
//  ** if you make a new hyperelastic law, you can make it work with this 
//     by just adding a new behavior reader, eg for rivlin: 
//        BEHAVIOR_READER(HYPER_VISCO_ELASTIC,rivlin_viscoelastic);
//     which is defined in Rivlin.c ... in HYPER_VISCO_ELASTIC::initialize 
//     it looks for the prefix to _viscoelastic and creates a hyper-elastic 
//     law based on that. 
// ---------------------------------------------------------------------------- 

#include <Hyperelastic_law.h>
#include <Behavior.h>
#include <Viscoelastic_terms.h>

Z_START_NAMESPACE;

ZCLASS HYPER_VISCO_ELASTIC : public BEHAVIOR {
      protected :
        AUTO_PTR<HYPERELASTIC_LAW> hyper_law; 

        PLIST<VE_SHEAR>   shear;
        PLIST<VE_VOLUMIC> volumic;

        virtual void verif_read();

        TENSOR2 cauchy_tdt, cauchy_t; 
        TENSOR2 pk2_tdt, pk2_t;

        SMATRIX  m_tgmat; 
      public :

        HYPER_VISCO_ELASTIC();
        virtual ~HYPER_VISCO_ELASTIC(); 
        
        virtual void initialize(ASCII_FILE& file, int dim, LOCAL_INTEGRATION*);

        INTEGRATION_RESULT* integrate( MAT_DATA&, 
                                       const VECTOR&, 
                                       MATRIX*&, int);

        virtual STRESS_MEASURE get_stress_measure()const { 
             return hyper_law->get_stress_measure(); 
        }

};
Z_END_NAMESPACE;

#endif
