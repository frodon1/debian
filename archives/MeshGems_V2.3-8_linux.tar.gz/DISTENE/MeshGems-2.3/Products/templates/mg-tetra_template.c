#define USE_SURFACE_SIZEMAP 0
#define MESH_ALL_COMPONENTS 0
#define INPUT_VOLUME_MESH 0
#define INSERT_VOLUME_VERTICES 1
#define OPTIMISE_VOLUME 1
#define OPTIMISE_SLIVER_TETRAHEDRA 0
#define OPTIMISE_OVERCONSTRAINED_TETRAHEDRA 0
#define USE_VOLUME_PROXIMITY 0


#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/meshgems.h>
#include <meshgems/tetra.h>

/* FOR OEM customers only, uncomment the following */
/* #include <meshgems_key_xxx.h> */

/**
 * Let's assume that the following structure holds data that
 * represents the input surface mesh on client side.  It could be a
 * database handle or anything else containing surface mesh data.  We
 * will build the mesh_t object that accesses it.  See the file
 * meshgems/mesh.h for more detailed information.
 */

struct your_internal_data_t_ {
  /* _your_data; */
};

typedef struct your_internal_data_t_ your_internal_data_t;

/**
 * Implementation of how the number of vertices in the mesh is obtained.
 * @param[out]	nbvtx	: the number of vertices
 * @param[in]     user_data	: a user pointer.
 * @return error code
 */

status_t mgtm_get_vertex_count(integer * nbvtx, void *user_data)
{
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *nbvtx = 0;                   /* the number of vertices in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the coordinates of a mesh vertex are obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	xyz	: real[3] array containing the coordinates of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_coordinates(integer ivtx, real * xyz,
                                     void *user_data)
{
  int j;
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    xyz[j] = 0.0;               /* j'th coordinate of the ivtx'th vertex */

  return STATUS_OK;
}

/**
 * Implementation of how the number of edges in the mesh is obtained.
 * @param[out]	nbedg	: the number of edges
 * @param[in]  user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_count(integer * nbedge, void *user_data)
{
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *nbedge = 0;                  /* the number of edges in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh edge are obtained.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	vedge	: integer[2] array containing the vertices of the edge
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_vertices(integer iedge, integer * vedge,
                                void *user_data)
{
  int j;
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  for (j = 0; j < 2; j++)
    vedge[j] = 0;               /* the j'th vertex index of the iedge'th edge */

  return STATUS_OK;
}


/**
 * Implementation of how the number of triangles in the mesh is obtained.
 * @param[out]	nbtri	: the number of triangles
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_count(integer * nbtri, void *user_data)
{
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *nbtri = 0;                   /* the number of triangles in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh triangle are obtained.
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]	vtri	: integer[3] array containing the vertices of the triangle
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_vertices(integer itri, integer * vtri,
                                    void *user_data)
{
  int j;
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    vtri[j] = 0;                /* the j'th vertex index of the itri'th triangle */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a quadratic mesh triangle (P2) are obtained.
 * @param[in]	m	: the mesh
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]	typetri	: integer containing the type of the triangle
 * @param[out]	evtri	: integer[] array containing the extra vertices of the triangle
 * @return error code
 */
status_t mgtm_get_triangle_extra_vertices(integer itri, integer * typetri,
                                          integer * evtri, void *user_data)
{
  int j;
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  if (1) {
    /* We want to describe a linear "3 nodes" triangle */
    *typetri = MESHGEMS_MESH_ELEMENT_TYPE_TRIA3;
  } else {
    /* We want to describe a quadratic "6 nodes" triangle */
    *typetri = MESHGEMS_MESH_ELEMENT_TYPE_TRIA6;
    for (j = 0; j < 3; j++)
      evtri[j] = 0;             /* the j'th quadratic vertex index of the itri'th triangle */
  }

  return STATUS_OK;
}

/**
 * Implementation of how the number of tetrahedron in the mesh is obtained.
 * @param[out]	nbtetra	: the number of tetrahedra
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_tetrahedron_count(integer * nbtetra, void *user_data)
{
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *nbtetra = 0;                 /* the number of tetra in your input mesh (0 if you describe a surface mesh) */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh tetrahedra are obtained.
 * @param[in]	itetra	: index of the desired tetrahedra from 1 to nbtetra
 * @param[out]	vtetra	: integer[4] array containing the vertices of the tetrahedra
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_tetrahedron_vertices(integer itetra, integer * vtetra,
                                       void *user_data)
{
  int j;
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  for (j = 0; j < 4; j++)
    vtetra[j] = 0;              /* the j'th vertex index of the itetra'th tetrahedron */

  return STATUS_OK;
}

/**
 * Implementation of how the required status of a mesh vertex is obtained.
 * @param[in]	ivtx	: index of the desired vertex from 1 to nbvtx
 * @param[out]	rvtx	: integer[1] containing the required status (0 or 1)of the vertex 
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_required_property(integer ivtx, integer * rvtx,
                                           void *user_data)
{
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  *rvtx = 0;                    /* the ivtx'th vertex required property : 1 if the vertex is required or 0 if it is not */

  return STATUS_OK;
}

/**
 * Implementation of how the weight (sizemap) of a mesh vertex
 * is obtained. 
 * @param[in]	ivtx	: index of the desired vertex from 1 to nbvtx
 * @param[out]	wvtx	: real  containing the weight of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_weight(integer ivtx, real * wvtx, void *user_data)
{
  your_internal_data_t *mm = (your_internal_data_t *) user_data;

  /*
   * You have to implement this function in the following cases:
   *   1) you are using a volume mesh as input (the macro
   *      INPUT_VOLUME_MESH is set to 1 in this file).
   *   2) you want to define a sizemap on the surface to drive
   *      the volume mesh generation (the macro
   *      USE_SURFACE_SIZEMAP is set to 1 in this file).
   */

  *wvtx = 0;                    /* the weight of the ivtx'th vertex */

  return STATUS_OK;
}

/**
 * This is the message callback function that Tetra will call when
 * it wants to send a message to the caller
 * see meshgems/message.h for more details.
 *
 * @param[in] msg       : the message
 * @param[in] user_data : a user pointer.
 * @return an error code
 */
status_t my_message_cb(message_t * msg, void *user_data)
{
  char *desc;
  integer e, ibuff[6];
  real rbuff[3];

  message_get_description(msg, &desc);
  message_get_number(msg, &e);

  if (e == MESHGEMS_TETRA_CODE(-5150)) {
    /* This is the error 5150 related to point/face intersection.
     * Get the associated integer data [1..4]
     */
    message_get_integer_data(msg, 1, 4, ibuff);
    printf("Point/face intersection : %i in %i %i %i\n",
           ibuff[0], ibuff[1], ibuff[2], ibuff[3]);
  } else if (e == MESHGEMS_TETRA_CODE(-5120)) {
    /* This is the error 5120 related to edge/face intersection.
     * Get the associated integer data [1..5]
     */
    message_get_integer_data(msg, 1, 5, ibuff);
    printf("Edge/face intersection : %i %i intersects %i %i %i\n",
           ibuff[0], ibuff[1], ibuff[2], ibuff[3], ibuff[4]);

  } else if (e == MESHGEMS_TETRA_CODE(-5110)) {
    /* This is the error 5110 related to edge/edge intersection.
     * Get the associated integer data [1..4]
     */
    message_get_integer_data(msg, 1, 4, ibuff);
    printf("Edge/edge intersection : %i %i intersects %i %i \n",
           ibuff[0], ibuff[1], ibuff[2], ibuff[3]);
  } else if (e == MESHGEMS_TETRA_CODE(-5505)) {
    /* This is the error 5505 related to face with small inner radius.
     * Get the associated integer data [1..4]
     * and real data [1..1]
     */
    message_get_integer_data(msg, 1, 4, ibuff);
    message_get_real_data(msg, 1, 1, rbuff);
    printf("Face %i : (%i, %i, %i) with small inradius : %lf \n",
           ibuff[0], ibuff[1], ibuff[2], ibuff[3], rbuff[0]);
  } else if (e == MESHGEMS_TETRA_CODE(8441)) {
    /* This is the informatio 8441 related to unrecovered edges.
     * Get the associated integer data [1..2]
     */
    message_get_integer_data(msg, 1, 2, ibuff);
    printf("Missing edge : %i %i\n", ibuff[0], ibuff[1]);
  } else if (e == MESHGEMS_TETRA_CODE(8423)) {
    /* This is the information 8423 related to unrecovered faces.
     * Get the associated integer data [1..3]
     */
    message_get_integer_data(msg, 1, 3, ibuff);
    printf("Missing face : %i %i %i\n", ibuff[0], ibuff[1], ibuff[2]);
  } else if (e == MESHGEMS_TETRA_CODE(5200)) {
    /* This is the informatio 5200 related to duplicate faces.
     * Get the associated integer data [1..3]
     */
    message_get_integer_data(msg, 1, 3, ibuff);
    printf("Warning : Found duplicate face : %i %i %i \n", ibuff[0],
           ibuff[1], ibuff[2]);
  } else {
    /* No specific handler for this message. Just print its description */
    printf("Message (%i) : %s", e, desc);
  }

  return STATUS_OK;
}

status_t set_tetra_parameters(tetra_session_t * tms)
{
  status_t ret;

  /* You can here specify the Tetra options, using the API function
   * tetra_set_param().
   * For example : 
   */

  /* This option changes the verbosity level of Tetra, between 0 and
   * 10.  The higher it is, the more messages Tetra will send
   * through the message callback. Default is 3.
   */
  ret = tetra_set_param(tms, "verbose", "3");
  if (ret != STATUS_OK)
    return ret;

  /* Set this parameter to "all" if you want all connex components to be
   * meshed or to "outside_components" if you only want the main one.
   * default is the main one
   */
  if (MESH_ALL_COMPONENTS) {
    ret = tetra_set_param(tms, "components", "all");
  } else {
    ret = tetra_set_param(tms, "components", "outside_components");
  }
  if (ret != STATUS_OK)
    return ret;

  /* The following parameters  */
  ret = tetra_set_param(tms, "optimisation_level", "standard");
  if (ret != STATUS_OK)
    return ret;

  /* The following parameter (gradation,scale) drives the point
   * density inside the generated mesh. It represents a goal and
   * cannot be guaranteed to be exactly respected, mainly because of
   * the input surface mesh constraints and of the nature of the
   * algorithms used.
   */

  /* Set the desired maximum ratio between 2 adjacent tetrahedra
   * edges. The closer it is to "1", the more uniform the mesh will be
   * Default value is "1.05"
   */
  ret = tetra_set_param(tms, "gradation", "1.05");
  if (ret != STATUS_OK)
    return ret;
 
  /* The following parameters  drive the  number of layers of tets between opposite
     surfaces 
     Default: not activated.
  */
  if (USE_VOLUME_PROXIMITY) {
    /* Set this parameter to "yes" if you want to use the special functionnality
       Default: no.
    */
    ret = tetra_set_param(tms, "use_volume_proximity", "yes");
    if (ret != STATUS_OK)
      return ret;
    /* Set this parameter to the number of layers of tets between opposite
      surfaces
   */
    ret = tetra_set_param(tms, "volume_proximity_layers", "3");
    if (ret != STATUS_OK)
      return ret;
  }

  return ret;
}


/* A macro we will call to cleanly return from the function in case of
 * failure. Deleting the context will delete all attached MeshGems
 * object (sessions, meshes, sizemaps, ...)
 */
#define RETURN_WITH_MESSAGE(_ret, _msg) do{				\
    fprintf(stderr,"%s\n",_msg);					\
    if(ctx) context_delete(ctx);					\
    return _ret;							\
  }while(0);

status_t generate_tetra_mesh(your_internal_data_t * your_internal_data)
{
  status_t ret;
  context_t *ctx;
  mesh_t *msh, *vmsh;
  tetra_session_t *tms;
  sizemap_t *sizemap, *vsizemap;

  integer i, nvm, ntm;
  integer nsd;
  real q, qmin, qmax;

  ctx = 0;
  msh = 0;
  tms = 0;
  vmsh = 0;
  sizemap = 0;
  vsizemap = 0;

  /*
   * Create the meshgems working context
   */
  ctx = context_new();
  if (!ctx)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new context");

  /*
   * Set the message callback for our context.
   */
  ret = context_set_message_callback(ctx, my_message_cb, 0);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /*
   * Create the mesh_t structure holding the callbacks giving acces to your mesh data in
   * your_internal_data
   */
  msh = mesh_new(ctx);
  if (!msh)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new mesh");

  /*
   * Set the mesh_t callback functions that will query your_internal_data structure :
   * see meshgems/mesh.h for detailed function prototypes.
   */

  mesh_set_get_vertex_count(msh, mgtm_get_vertex_count,
                            your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_vertex_coordinates(msh, mgtm_get_vertex_coordinates,
                                  your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_vertex_required_property(msh,
                                        mgtm_get_vertex_required_property,
                                        your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  mesh_set_get_edge_count(msh, mgtm_get_edge_count, your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_edge_vertices(msh, mgtm_get_edge_vertices,
                             your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  mesh_set_get_triangle_count(msh, mgtm_get_triangle_count,
                              your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_triangle_vertices(msh, mgtm_get_triangle_vertices,
                                 your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  mesh_set_get_tetrahedron_count(msh, mgtm_get_tetrahedron_count,
                                 your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_tetrahedron_vertices(msh, mgtm_get_tetrahedron_vertices,
                                    your_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  if (0) {
    /*
     * Display some statistics about the surface mesh.
     * The data is sent formated to the context message callback
     * For debugging purposes
     */
    mesh_compute_statistics(msh);
  }
#ifdef __MESHGEMS_PRIVKEY_H__
  /* If you are an OEM customer for Tetra, sign this mesh object with
   * your private key (else Tetra would reject it) */
  ret = sign_mesh(msh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to sign input mesh");
#endif

  /*
   * Create a tetra session
   */

  tms = tetra_session_new(ctx);
  if (!tms)
    RETURN_WITH_MESSAGE(STATUS_NOMEM,
                        "unable to create a new tetra session");

  /*
   * Set the input working surface or volume mesh for this tetra session
   */
  if (INPUT_VOLUME_MESH) {
    /* 
     * Starting from an existing volume mesh.
     * The sizemap is mandatory in this case.
     */
    ret = tetra_set_volume_mesh(tms, msh);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to set volume mesh");

    /*
     * Mandatory : create a sizemap to hold the size specification for mesh vertices.
     */
    sizemap =
        meshgems_sizemap_new(msh,
                             meshgems_sizemap_type_iso_mesh_vertex,
                             mgtm_get_vertex_weight, your_internal_data);
    if (!sizemap)
      RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new sizemap");
  } else {
    /* 
     * Starting from a surface mesh.
     * The sizemap is optionnal in this case (it will
     * be taken into account only on vertices not
     * belonging to the surface).
     */
    ret = tetra_set_surface_mesh(tms, msh);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to set surface mesh");
    /*
     * Optionnal : create a sizemap to hold the size specification for mesh vertices.
     */
    if (USE_SURFACE_SIZEMAP) {
      sizemap =
          meshgems_sizemap_new(msh,
                               meshgems_sizemap_type_iso_mesh_vertex,
                               mgtm_get_vertex_weight, your_internal_data);
      if (!sizemap)
        RETURN_WITH_MESSAGE(STATUS_NOMEM,
                            "unable to create a new sizemap");
    }
  }

  if (sizemap) {
    ret = tetra_set_sizemap(tms, sizemap);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to set sizemap");
  }

  ret = set_tetra_parameters(tms);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to set tetra paramters");

  /* 
   * The mesh generation process. 
   * See the meshgems/tetra.h file for more details
   */

  /*
   * We show here the different meshing steps :
   *   meshgems_tetra_mesh_boundary
   *   meshgems_tetra_insert_volume_vertices
   *   meshgems_tetra_optimise_volume_regular
   * It is also possible to replace them with only one step using the
   *  meshgems_tetra_compute_mesh function
   */

  /*
   * First generate a coarse tetrahedrisation of the surface
   */
  ret = tetra_mesh_boundary(tms);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "Unable to generate coarse mesh");

  /*
   * Then insert the volume vertices (if requested)
   */
  if (INSERT_VOLUME_VERTICES) {
    ret = tetra_insert_volume_vertices(tms);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "Unable to generate internal vertices");
  }

  /*
   * Then insert the volume vertices (if requested)
   */
  if (OPTIMISE_VOLUME) {
    ret = tetra_optimise_volume_regular(tms);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "Unable to optimise mesh volume");
  }

  if (OPTIMISE_OVERCONSTRAINED_TETRAHEDRA) {
    /*
     * Do a special post-treatment optimisation to remove over-constrained 
     * elements (ie with too many edges/faces on the input surface)
     */
    ret = tetra_optimise_volume_overconstrained(tms);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "Unable to optimise for FEM");
  }
  if (OPTIMISE_SLIVER_TETRAHEDRA) {
    /*
     * Do a special post-treatment optimisation to remove sliver
     * elements (without surface modification). 
     * This process can be time consuming.
     */
    ret = tetra_optimise_volume_sliver(tms);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "Unable to optimise sliver");
  }

  /*
   * Mesh generation is completed. Get the generated volume
   * mesh. This output mesh belongs to the tetra_session. Thus the
   * user does not have to delete it afterwards.
   */

  ret = tetra_get_mesh(tms, &vmsh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting mesh");

  /*
   * If you are interrested in this information, you can also
   * get the volume sizemap used by Tetra to generate the volume mesh.
   * This output sizemap belongs to the tetra_session.
   * Thus the user does not have to delete it afterwards.
   */

  ret = tetra_get_sizemap(tms, &vsizemap);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting sizemap");

  /*
   * Read the output mesh data. See meshgems/mesh.h for more detailed
   * prototypes.
   */

  /* First get all the vertices */
  ret = mesh_get_vertex_count(vmsh, &nvm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex count");

  ret = mesh_get_tetrahedron_count(vmsh, &ntm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedron count");

  for (i = 1; i <= nvm; i++) {
    real coo[3];
    ret = mesh_get_vertex_coordinates(vmsh, i, coo);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting vertices");
    if (0) {
      fprintf(stdout, "vertex %d coordinates are : %e %e %e \n", i,
              coo[0], coo[1], coo[2]);
    }
  }


  /* Then get all the tetrahedra and compute some statistics on their aspect ratio */

  qmin = REAL_INFINITY;
  qmax = -REAL_INFINITY;

  for (i = 1; i <= ntm; i++) {
    integer vtx[4], tag;
    ret = mesh_get_tetrahedron_vertices(vmsh, i, vtx);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedra");
    if (0) {
      fprintf(stdout, "tetra %d vertices are : %d %d %d %d \n", i,
              vtx[0], vtx[1], vtx[2], vtx[3]);
    }
    ret = mesh_get_tetrahedron_tag(vmsh, i, &tag);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting tetrahedra tag");
    if (0) {
      fprintf(stdout, "tetra %d is in subdomain %d\n", i, tag);
    }
    mesh_get_tetrahedron_aspect_ratio(vmsh, i, &q);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "internal error");
    if (q > qmax)
      qmax = q;
    if (q < qmin)
      qmin = q;
  }

  fprintf(stdout, "\nGenerated %d vertices and %d tetrahedra  \n", nvm,
          ntm);
  fprintf(stdout, "          with a quality within [%f,%f]\n", qmin, qmax);

  if (MESH_ALL_COMPONENTS) {
    /*
     * Read the subdomain identification information.
     * Only available if you have set the parameter "components" to "all"
     * See tetra documentation for more information.
     */
    ret = mesh_get_subdomain_count(vmsh, &nsd);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting subdomain count");

    fprintf(stdout, "Identified subdomains : %d\n", nsd);
    if (nsd > 1) {
      for (i = 1; i <= nsd; i++) {
        integer subdomain_tag, seed_type, seed_idx, seed_orientation;
        char *seed_type_str;
        ret = mesh_get_subdomain_description(vmsh, i,
                                             &subdomain_tag,
                                             &seed_type, &seed_idx,
                                             &seed_orientation);
        if (ret != STATUS_OK)
          RETURN_WITH_MESSAGE(ret, "unable to get a subdomain seed");

        if (seed_type == MESHGEMS_MESH_ELEMENT_TYPE_TRIA3) {
          seed_type_str = "triangle";
        } else {
          /* The only seed type generated by MeshGems-Tetra is the triangle */
          seed_type_str = "unknown error";
        }

        fprintf(stdout,
                "subdomain %d description is : tag=%d type=%s facet=%d orientation=%d \n",
                i, subdomain_tag, seed_type_str, seed_idx,
                seed_orientation);
      }
    }
  }
  /*
   * We can also directly write a .mesh formated file and a .sol formated file for the sizemap : 
   */

  fprintf(stdout, "Writing volume mesh in tetra.mesh file\n");
  ret = mesh_write_mesh(vmsh, "tetra.mesh");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a .mesh file");

  fprintf(stdout, "Writing volume sizemap in tetra.sol\n");
  ret = sizemap_write_sol(vsizemap, "tetra.sol");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a .sol file");

  if (0) {
    /*
     * Display some statistics about the output mesh.
     * The data is sent formated to the context message callback
     * for debugging purposes.
     */
    mesh_compute_statistics(vmsh);
  }

  /*
   * We are done, give the volume mesh and sizemap back to the session and clean up everything.
   */
  tetra_regain_mesh(tms, vmsh);
  tetra_regain_sizemap(tms, vsizemap);
  tetra_session_delete(tms);

  mesh_delete(msh);
  if (sizemap)
    sizemap_delete(sizemap);

  context_delete(ctx);

  return STATUS_OK;
}
