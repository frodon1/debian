#ifndef __Post_copy__ 
#define __Post_copy__ 

#include <Utility.h>
#include <Local_post_computation.h>
#include <Global_post_computation.h>
#include <Post_simple.h>
#include <Post_processor.h>
#include <Utility.h>
#include <Post_mises.h>
#include <Mises_sqrt2.h>
#include <Print.h>

Z_START_NAMESPACE;

ZCLASS2 POST_COPY : public POST_SIMPLE,
                    public GLOBAL_POST_COMPUTATION {
 public :
  int last_only; 
  int copy_batch_size;
  BUFF_LIST<STRING> vars; 
  BUFF_LIST<STRING> ovars; 
  int shift; 

  POST_COPY();
  virtual ~POST_COPY();
  virtual MODIFY_INFO_RECORD* get_modify_info_record();

  virtual int card_packet()const { return copy_batch_size; }

  virtual void input_i_need(int,ARRAY<STRING>&);
  virtual void output_i_give(bool&,ARRAY<STRING>&);
  virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);

  virtual void compute(ARRAY<POST_ELEMENT*>& post_ele, 
                       ARRAY<POST_NODE*>&    post_node,
                       const ARRAY<int>&     unknown);

};

ZCLASS2 GPP_COPY : public GLOBAL_POST_COMPUTATION {
 public :
  LIST<STRING> vars;
  LIST<STRING> ovars;

  GPP_COPY();
  virtual ~GPP_COPY();
  virtual MODIFY_INFO_RECORD* get_modify_info_record();

  virtual void input_i_need(int,ARRAY<STRING>&);
  virtual void output_i_give(bool&,ARRAY<STRING>&);
  virtual bool compute_on_ipsets()const {return(TRUE);}
  virtual void compute(ARRAY<POST_ELEMENT*>& ele,
                        ARRAY<POST_NODE*>&    node,
                        const ARRAY<int>&);
};
Z_END_NAMESPACE;

#endif 
