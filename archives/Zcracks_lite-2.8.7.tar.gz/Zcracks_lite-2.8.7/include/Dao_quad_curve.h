#ifndef __Dao_quad_curve__
#define __Dao_quad_curve__

// ============================================================================  
//  Quadratic line... 2nd order finite element edge 
// ============================================================================  

#include <stdio.h> 

#include <Geometry_parts.h> 

Z_START_NAMESPACE;

ZCLASS2 DAO_QUAD_CURVE : public DAO_CURVE {
  protected :
    MARRAY<VECTOR>   trk;

  public :
    DAO_QUAD_CURVE(DAO_GEOMETRY* bin);

    static DAO_QUAD_CURVE* read(ASCII_FILE&);
    virtual void write(Zofstream& out); 

    virtual bool calc_mid_point(GRAPHICS_POINT& pt, double t);
    virtual void select(GRAPHICS_AREA* ga, GRAPHICS_POINT& p);
    virtual double click_distance(GRAPHICS_POINT& c, bool bb);

    void set_points(LIST<DAO_POINT*>& pin); 
    VECTOR d_edge_dt(double t); 
    LIST<DAO_EDGE*> divide_into_n(int c, double pro, bool force=FALSE); 

    virtual void local_draw(GRAPHICS_AREA* ga); 
    virtual void track_selected(GRAPHICS_AREA* ga, GRAPHICS_POINT& pt); 
    virtual void select_fix(GRAPHICS_AREA*, GRAPHICS_POINT&); 

    virtual void set_by_points(LIST<DAO_POINT*>&);

    virtual void interval(double&,double&);
    virtual void curv0(const double&,double&,double&);
    virtual void curv1(const double&,double&,double&);
    virtual void curv2(const double&,double&,double&);

    // 
    // Approximated as line.. 
    // 
    virtual void write_directory(FILE* file, int& direct_pos, int& param_pos);
};  
Z_END_NAMESPACE;

#endif
