#ifndef __File__
#define __File__

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <Defines.h>
#include <List.h>
#include <Stringpp.h>
#include <Vector.h>
#include <Visible.h>
#include <Zunistd.h> 
#include <Zstream.h> 
#include <Pointer.h> 

#if defined NOCLIENT
    #define NO_ZSTR 
// #elif defined SUNCC5 
//     #define NO_ZSTR
#else
    #define YES_ZSTR 
#endif

#include <Bool.h>

Z_START_NAMESPACE;

#define MAXBUF  256
#ifdef _WIN32 
  #define BOOL_TRUE TRUE
  #define BOOL_FALSE FALSE
#else 
  #define BOOL_TRUE (bool)TRUE
  #define BOOL_FALSE (bool)FALSE
#endif 

#ifdef NO_ZSTR
  #define ZIFSTREAM ifstream
#else
  #define ZIFSTREAM Zifstream
#endif

ZCLASS ASCII_FILE : public ZIFSTREAM {
            IOS_OPENMODE mode_opening;
            ZFWHERE where_opening;
            STRING _name;
            bool _ok;
            int _level; 
            LIST<int> loop_level; 

  private : 
            bool cr_read,sub_include_active;
            ZSTREAMPOS previous_pos;
            int previous_level;
            LIST<int> characters, comments, eol_char, separator;
            int level_char, vector_in, vector_out;
            int is_temp_file; 

            void set_position(ZSTREAMPOS);
            void set_position();
            void read_spaces();
            void set_default();
            void set_eol_char();
            STRING getkey();
            STRING getkey_sl();

            ASCII_FILE* father;
            PTR<ASCII_FILE> son;
            void include_file();


   public :

           const STRING &name;
           const bool &ok;
           const int &level;

           // 
           // User-setable option flags.. all default off 
           // 
           bool  allow_environment_variables;      
           bool  allow_include_defines;            // not yet implemented 
           bool  upper_case_mode;  

           ASCII_FILE(bool set_default=BOOL_TRUE);
           ASCII_FILE( const char *const name, 
                       ZFWHERE w=ZLOCAL,
                       bool set_default=BOOL_TRUE);

           virtual ~ASCII_FILE();

           int get_next_char();

           int allowed_character(int ch)const;
           void add_character(int c);
           void remove_character(int c);

           bool is_eol_char(int c);

           void activate_sub_include() { sub_include_active=true; }
           void deactivate_sub_include() { sub_include_active=false; }
           bool sub_include_state() { return(sub_include_active); }

           void add_comment_char(int c);
           void remove_comment_char(int c);
           bool is_comment_char(int c);

           void add_separator_char(int c);
           void remove_separator_char(int c);
           bool is_separator_char(int c);

           void set_level_char(int c);

           void set_vector_key(int beg, int end);

           void set_level(const char*);

           void open( const char* const, ZFWHERE w=ZLOCAL);

           void try_to_open(const char* const, ZFWHERE w=ZLOCAL);

           void close();

           void empty_line();

           void locate(const STRING& criterion);
           void locate(const char* criterion);

           void locate_until_word_starts_with(const char* criterion, const char* stop);

           void locate_next(const STRING& criterion);
           void locate_next(const char* criterion);

          
           void locate_next_until_word_starts_with(const char* criterion, const char* stop);

           void locate_begin_line(const char *criterion);
           void locate_begin_line_next(const char*);

           void locate_at_level(int ll, const STRING& criterion);
           void locate_next_at_level(int ll, const STRING& criterion);

           STRING start_key();
           STRING next_key();

           void skip_until_word_start_with(const STRING& criterion);

           char get_char();
           char get_char_with_cr();
           int getint();
           STRING getSTRING();
           STRING getquotedSTRING();
           double getdouble();
           double getnumeral();
           VECTOR getVECTOR(int vector_size);
           VECTOR getVECTOR();
           // getLINE and getfullLINE work the same way getSTRING, etc. work: they eatup chars whereas getline() and getfullline() preserve the current stream read position
           STRING getLINE();
           STRING getfullLINE();
           STRING getline();
           STRING getfullline();
           void get(LIST<int>& li);
           void get(LIST<double>& li);
           void get(ARRAY<int>& ai,int si);
           void get_selection(BUFF_LIST<int>& sel);

           STRING getSTRING_sl();
           double getdouble_sl();
           double getnumeral_sl();
           int getint_sl();

//         sends back an empty STRING when the field between 2 separators is empty
           STRING get_next_field();
           STRING get_next_field_sl();

           void back1();
           void back(void);
           void back_and_set_previous_level(void);
           void rewind(void);

           ZSTREAMPOS get_position();

           void goto_position(ZSTREAMPOS p);
           void goto_position_and_set_previous_pos(ZSTREAMPOS p);

           static void get_file_info(STRING& name,int& line);
           static bool if_current_file();

           static ASCII_FILE* current_file();

           friend WIN_THINGIE ZISTREAM& operator>>(ZISTREAM&,STRING&);

           void make_from(STRING data); 
           void make_from(const LIST<STRING>& data); 
           void setstate(int flag);
           void okokok() { _ok=TRUE; }

           int  is_stringbuf;
           void replace_buffer(ZFILEBUFFER* newbuf);
};

#ifndef NOCLIENT
WIN_THINGIE void _write_(const ARRAY<int>& a, Zfstream& ob);
WIN_THINGIE void _write_(const ARRAY<int>& a, Zofstream& ob);
WIN_THINGIE void _read_(ARRAY<int>& a, Zfstream& ob);
WIN_THINGIE void _write_(const ARRAY<double>& a, Zfstream& ob);
WIN_THINGIE void _write_(const ARRAY<double>& a, Zofstream& ob);
WIN_THINGIE void _read_(ARRAY<double>& a, Zfstream& ob);
WIN_THINGIE void _write_(const ARRAY<float>& a, Zfstream& ob);
WIN_THINGIE void _write_(const ARRAY<float>& a, Zofstream& ob);
WIN_THINGIE void _read_(ARRAY<float>& a, Zfstream& ob);
#endif
Z_END_NAMESPACE;

#endif	
