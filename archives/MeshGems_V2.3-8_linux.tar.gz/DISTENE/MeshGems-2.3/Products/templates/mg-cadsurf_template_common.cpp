/*
 * Generic surface mesh generation template.
 * This file describes how to use MG-CADSurf
 * to generate a mesh from a given meshgems cad_t 
 */

#define USE_LOCAL_PHYSICAL_SIZE 0
#define USE_LOCAL_GEOMETRIC_SIZE 0
#define USE_LOCAL_ELEMENT_GENERATION 0

using namespace std;
#include <string.h>
#include <iostream>
#include <sstream>
#include <stdlib.h>
#include <assert.h>

extern "C" {
#include <meshgems/meshgems.h>
#include <meshgems/cadsurf.h>
}

/* FOR OEM customers only, uncomment the following */
/* #include <meshgems_key_xxx.h> */

/*
 * This function specifies the geometrical sizemap on a point
 * The pid parameter is an integer identifying which point MG-CADSurf
 * is querying.
 * See meshgems_sizemap_geometric_cad_point_t in meshgems/sizemap.h
 * for information about the function parameters.
 */ 
status_t geosize_on_point(integer pid, real * hmin, real * hmax,
                              void *user_data)
{

  if (pid % 2 == 0) {
    *hmin = 0.02;
    *hmax = 1;
  } else {
    *hmin = 0.1;
    *hmax = 0.5;
  }

  return STATUS_OK;
}

/*
 * This optional function specifies the geometrical sizemap on an edge
 * or on a wire.
 * The eid parameter is an integer identifying which edge/wire MG-CADSurf
 * is querying. This eid is the same as the one given in
 * cad_edge_new/cad_wire_new (see later in this file)
 * See meshgems_sizemap_geometric_cad_edge_t in meshgems/sizemap.h for
 * information about the function parameters.
 */
status_t geosize_on_curve(integer eid, real * geometric_approximation,
                          real * tolerance, real * hmin, real * hmax,
                          void *user_data)
{
  if (eid % 2 == 0) {
    *geometric_approximation = 1;
    *tolerance = 0;
    *hmin = 1e-1;
    *hmax = 1e0;
  } else {
    *geometric_approximation = 0;
    *tolerance = 0;
    *hmin = 1e1;
    *hmax = 1e1;
  }
  return STATUS_OK;
}

/*
 * This function specifies the geometrical sizemap on a face
 * The fid parameter is an integer identifying which face MG-CADSurf
 * is querying. This fid is the same as the one given in
 * cad_face_new (see later in this file).
 * See meshgems_sizemap_geometric_cad_face_t in meshgems/sizemap.h
 * for information about the function parameters.
 */
status_t geosize_on_face(integer fid, real * geometric_approximation,
                         real * tolerance, real * hmin, real * hmax,
                         void *user_data)
{
  if (fid % 2 == 0) {
    *geometric_approximation = 5;
    *tolerance = 0;
    *hmin = 1e2;
    *hmax = 5e2;
  } else {
    *geometric_approximation = 0;
    *tolerance = 0;
    *hmin = 5e3;
    *hmax = 5e3;
  }

  return STATUS_OK;
}

/*
 * This function specifies the sizemap on a point
 * The pid parameter is an integer identifying which point MG-CADSurf
 * is querying.
 * See sizemap_iso_cad_point_t in meshgems/sizemap.h for information about the 
 * function parameters.
 */
status_t size_on_point(integer pid, real * size, void *user_data)
{
  if (pid % 2 == 0) {
    *size = 10;
  } else {
    *size = 20;
  }

  return STATUS_OK;
}

/*
 * This function specifies the sizemap on a curve.
 * The edge_id parameter is an integer identifying which curve MG-CADSurf
 * is querying. This edge_id is the same as the one given in
 * cad_edge_new or cad_wire_new (see later in this file).
 * See sizemap_iso_cad_edge_t in meshgems/sizemap.h for information about the 
 * function parameters.
 */
status_t size_on_curve(integer edge_id, real t, real * size,
                       void *user_data)
{
  if (edge_id == 1) {
    /* set size for edge with id == 1 */
    *size = 0.5;
  } else if (edge_id == 6) {
    *size = 0.1;
  } else {
    /* for the others (this becomes the default sizemap on the other edges) */
    *size = 0.5;
  }

  return STATUS_OK;
}

/*
 * This function specifies the sizemap on a face.
 * The face_id parameter is an integer identifying which face MG-CADSurf
 * is querying. This face_id is the same as the one given in
 * cad_face_new (see later in this file).
 * See sizemap_iso_cad_face_t in meshgems/sizemap.h for information about the 
 * function parameters.
 */
status_t size_on_face(integer face_id, real * uv, real * size,
                      void *user_data)
{
  if (face_id == 1) {
    /* set size for face with id == 1 */
    *size = 0.5;
  } else if (face_id == 6) {
    *size = 0.1;
  } else {
    /* for the others (this becomes the default sizemap on the other faces) */
    *size = 0.5;
  }

  return STATUS_OK;
}

/*
 * This function specifies the sizemap on a mesh vertex.
 * The vertex_id parameter is the index of the working vertex on the associated mesh_t.
 * See sizemap_iso_mesh_vertex_t in meshgems/sizemap.h for information about the 
 * function parameters.
 */
status_t size_on_vertex(integer vertex_id, real * size, void *user_data)
{
  if (vertex_id % 2 == 0) {
    /* set size for vertex with an even index */
    *size = 0.5;
  } else {
    /* for the others (this becomes the default sizemap on the other vertices) */
    *size = 0.5;
  }

  return STATUS_OK;
}

/*
 * This function specifies the number of points desired on a curve.
 * The edge_id parameter is an integer identifying which curve MG-CADSurf
 * is querying. This edge_id is the same as the one given in
 * cad_edge_new or cad_wire_new (see later in this file).
 * See sizemap_number_of_vertices_cad_edge_t in meshgems/sizemap.h for information about the 
 * function parameters.
 */
status_t required_number_of_point_on_curve(integer edge_id, integer * n,
                                           void *user_data)
{

  if (edge_id == 6)
    *n = 21;
  else
    *n = 12;

  return STATUS_OK;
}

/*
 * This function specifies the anisotropic sizemap along a curve.
 * The edge_id parameter is an integer identifying which curve MG-CADSurf
 * is querying. This edge_id is the same as the one given in
 * cad_edge_new or cad_wire_new (see later in this file).
 * See sizemap_axisymmetric_along_cad_edge_t in meshgems/sizemap.h for information about the 
 * function parameters.
 */
status_t size_along_curve(integer edge_id, real * size1, real * size2,
                          void *user_data)
{

  if (!(edge_id % 3)) {
    /* Small size in the directions orthogonal to the edge */
    *size1 = 0.5;
    *size2 = 0.01;
  } else {
    *size1 = 0;
    *size2 = 0;
  }

  return STATUS_OK;
}

/*
 * This function specifies the isotropic sizemap on the 3D space.
 * The p parameter is the XYZ coordinates on which the size is requested.
 * See sizemap_iso_3d_t in meshgems/sizemap.h for information about the 
 * function parameters.
 */
status_t size_iso_3d(real p[3], real * size, void *user_data)
{
  real pt[3] = { 0, 0, 0 };
  real l;

  l = (p[0] - pt[0]) * (p[0] - pt[0]) +
      (p[1] - pt[1]) * (p[1] - pt[1]) + (p[2] - pt[2]) * (p[2] - pt[2]);

  assert(l >= 0);
  l = 0.1 * sqrt(l);

  if (l < 0.0001)
    l = 0.01;
  else if (l < 0.001)
    l = 0.001;
  else if (l < 0.005)
    l = 0.005;
  else if (l < 0.5)
    l = 0.1;
  else if (l < 1)
    l = 1;
  else if (l < 3)
    l = 0.01;
  else
    l = 5;

  *size = l;

  return STATUS_OK;
}

/*
 * This function specifies the anisotropic sizemap on the 3D space.
 * The p parameter is the XYZ coordinates on which the metric is requested.
 * See sizemap_aniso_3d_t in meshgems/sizemap.h for information about the 
 * function parameters.
 */
status_t size_aniso_3d(real p[3], real size[6], void *user_data)
{
  real pt[3] = { 0, 0, 0 };
  real d;

  d = (p[0] - pt[0]) * (p[0] - pt[0]) +
      (p[1] - pt[1]) * (p[1] - pt[1]) + (p[2] - pt[2]) * (p[2] - pt[2]);

  assert(d >= 0);
  d = 0.1 * sqrt(d);

  if (d < 0.0001)
    d = 0.01;
  else if (d < 0.001)
    d = 0.001;
  else if (d < 0.005)
    d = 0.005;
  else if (d < 0.5)
    d = 0.1;
  else if (d < 1)
    d = 1;
  else if (d < 3)
    d = 0.01;
  else
    d = 5;

  /* The following metric is defined by : 
   * size d along the x axis,
   * size 1 along the y axis,
   * size 3 along the z axis,
   */

  size[1] = 0;
  size[3] = 0;
  size[4] = 0;

  size[0] = 1. / (d * d);
  size[2] = 1;
  size[5] = 1. / (3 * 3);

  return STATUS_OK;
}

/*
 * This function specifies the mesh generation algorithm on a face.
 * The face_id parameter is an integer identifying which face MG-CADSurf
 * is querying. This face_id is the same as the one given in
 * cad_face_new (see later in this file).
 * See element_generation_map_cad_face_t in meshgems/element_generation_map.h for 
 * information about the function parameters.
 */
status_t type_on_face(integer face_id, generation_type_t * type,
                      void *user_data)
{
  if (face_id % 2 == 1) {
    *type = meshgems_generation_quad_dominant;
  } else {
    *type = meshgems_generation_triangle;
  }
  return STATUS_OK;
}

/* This is the interrupt callback. MG-CADSurf will call this
 * function regularily to check whether it should stop or not.
 * See the file meshgems/interrupt.h for more details.
 */
status_t interrupt_cb(integer * interrupt_status, void *user_data)
{

  if (1 /* you want to continue */ ) {
    *interrupt_status = INTERRUPT_CONTINUE;
  } else {
    /* you want to stop the meshing process */
    *interrupt_status = INTERRUPT_STOP;
  }

  return STATUS_OK;
}

/*
 * The following function will be called by MG-CADSurf message
 * printing and structured error reporting system.  See
 * context_set_message_callback (later in this template) for how to
 * set user_data.
 */
status_t message_cb(message_t * msg, void *user_data)
{
  char *desc;
  integer code, id;
  integer n, n_idata;
  double per;
  status_t ret;

  ret = STATUS_OK;
  /* You can use the calback to write the message in a defined file */

  /* Get the error number */
  ret = message_get_number(msg, &code);
  if (ret != STATUS_OK)
    return ret;

  if (code == MESHGEMS_CADSURF_CODE(5341)) {
    /* MG-CADSurf warning : a CAD face contains some adjacent and very close CAD edges */

    /* get the id of the face */
    ret = message_get_integer_data(msg, 1, 1, &id);
    if (ret != STATUS_OK)
      return ret;

    printf("Face %d contains some adjacent and very close CAD edges\n",
           id);

  } else if (code == MESHGEMS_CADSURF_CODE(8001)) {
    /* cadsurf warning : A CAD face cannot be meshed */

    /* get the id of the face */
    ret = message_get_integer_data(msg, 1, 1, &id);
    if (ret != STATUS_OK)
      return ret;

    printf("Face %d cannot be meshed\n", id);

  } else if (code == MESHGEMS_CADSURF_CODE(8002)) {
    /* MG-CADSurf warning : a CAD face was discarded because a correct
       definition could not be recovered */

    /* get the id of the face */
    ret = message_get_integer_data(msg, 1, 1, &id);
    if (ret != STATUS_OK)
      return ret;

    printf("Face %d was removed because of an unrecovable definition\n",
           id);

  } else if (code == MESHGEMS_CADSURF_CODE(8003)) {
    /* MG-CADSurf warning : a CAD face was discarded for opimization purposes */

    /* get the id of the face */
    ret = message_get_integer_data(msg, 1, 1, &id);
    if (ret != STATUS_OK)
      return ret;

    printf("Face %d was optimized out\n", id);

  } else if (code == MESHGEMS_CADSURF_CODE(8041)) {
    /* MG-CADSurf warning : a CAD face was discarded because a correct
       definition could not be recovered */

    /* get the id of the face */
    ret = message_get_integer_data(msg, 1, 1, &id);
    if (ret != STATUS_OK)
      return ret;

    printf("A tiny CAD edge on face with id %d has been removed\n", id);

  } else if (code == MESHGEMS_CADSURF_CODE(8042)) {
    /* MG-CADSurf warning : a CAD face was discarded because a correct
       definition could not be recovered */

    /* get the id of the face */
    ret = message_get_integer_data(msg, 1, 1, &id);
    if (ret != STATUS_OK)
      return ret;

    printf
        ("A tiny CAD edge on face with id %d was left in the CAD as a results of the specified options\n",
         id);

  } else if (code == MESHGEMS_CADSURF_CODE(8004)) {
    /* cadsurf warning : The required discretization of a CAD edge
       cannot be respected */

    /* get the id of the edge enitity */
    ret = message_get_integer_data(msg, 1, 1, &id);
    if (ret != STATUS_OK)
      return ret;

    printf("The required discretization of the CAD edge ");
    printf("with id : %d cannot be respected\n", id);

  } else if (code == MESHGEMS_CADSURF_CODE(8005) ||
             code == MESHGEMS_CADSURF_CODE(8006)) {
    /* periodicity warning in MG-CADSurf : an edge periodicty (8006) or a
     * face periodicity (8005) cannot be respected.  See the
     * documentation for a description of the attached data */

    integer nb1, nb2, i;
    string s = "edge", ss = "face";

    /* get the number of integer data in attached with the message */
    ret = message_get_integer_data_count(msg, &n_idata);
    if (ret != STATUS_OK)
      return ret;
    /* enumerate them : */
    /* get the index of the problematic periodicity */
    ret = message_get_integer_data(msg, 1, 1, &n);
    if (ret != STATUS_OK)
      return ret;

    printf("Error for %s periodicity #%d\n",
           (code == 8005) ? "face" : "edge", n);

    /* then get the number of entities in the first set of entities
       defining the faulty periodicity */
    ret = message_get_integer_data(msg, 2, 2, &nb1);
    if (ret != STATUS_OK)
      return ret;

    printf("(");
    /* and enumerate their id */
    for (i = 3; i <= 2 + nb1; i++) {
      ret = message_get_integer_data(msg, i, i, &id);
      if (ret != STATUS_OK)
        return ret;

      printf("%d ", id);
    }
    /* get the number of entities in the second set of entities
       defining the faulty periodicity */
    ret = message_get_integer_data(msg, 3 + nb1, 3 + nb1, &nb2);
    if (ret != STATUS_OK)
      return ret;

    printf(") <-----> (");
    /* and enumerate their id */
    for (i = 4 + nb1; i <= n_idata; i++) {
      ret = message_get_integer_data(msg, i, i, &id);
      if (ret != STATUS_OK)
        return ret;

      printf("%d ", id);
    }
    printf(")\n");

  } else if (code == MESHGEMS_CADSURF_CODE(9001)) {
    /* get the progress percentage */
    ret = message_get_real_data(msg, 1, 1, &per);
    if (ret != STATUS_OK)
      return ret;
    ret = message_get_description(msg, &desc);
    if (ret != STATUS_OK)
      return ret;

    printf("%s", desc);

  } else {
    ret = message_get_description(msg, &desc);
    if (ret != STATUS_OK)
      return ret;

    printf("MG-CADSurf message : %s", desc);
  }

  return STATUS_OK;
}

status_t set_cadsurf_parameters(cadsurf_session_t * css,
                                integer discrete_cad)
{
  status_t ret;

  /* You can here specify the CADSurf options, using the function
   * cadsurf_set_param(), see the documentation.
   */

  /* Please note that the options tags does not have
   * the same default value in mg-demo and in CADSurf.
   */

  /* For example */
  ret = cadsurf_set_param(css, "verbose", "3");
  if (ret != STATUS_OK)
    return ret;

  /* For a constaint sized mesh of 2% of the geometry */
  ret = cadsurf_set_param(css, "global_physical_size", "0.02r");
  if (ret != STATUS_OK)
    return ret;

  if (USE_LOCAL_PHYSICAL_SIZE) {
    ret = cadsurf_set_param(css, "physical_size_mode", "local");
    if (ret != STATUS_OK)
      return ret;
  }
  if (USE_LOCAL_GEOMETRIC_SIZE) {
    ret = cadsurf_set_param(css, "geometric_size_mode", "local");
    if (ret != STATUS_OK)
      return ret;
  }

  /* If you want to generate anisotropic meshes */
  ret = cadsurf_set_param(css, "metric", "anisotropic");
  if (ret != STATUS_OK)
    return ret;

  if (USE_LOCAL_ELEMENT_GENERATION) {
    ret = cadsurf_set_param(css, "element_generation", "local");
    if (ret != STATUS_OK)
      return ret;
  }

  if (discrete_cad) {
    ret = cadsurf_set_param(css, "discard_input_topology", "no");
    if (ret != STATUS_OK)
      return ret;

    ret = cadsurf_set_param(css, "process_3d_topology", "no");
    if (ret != STATUS_OK)
      return ret;
  }

  return ret;
}

status_t read_mesh(cadsurf_session_t * css, mesh_t * msh)
{
  status_t ret;

  /* retrieve mesh data (see meshgems/mesh.h for more details) */

  /* first allocate a buffer which will be suitable for any query
     (for the composite tags mainly, which sizes are not know by the
     caller) */
  integer *buff = (integer *) mesh_calloc_generic_buffer(msh);
  integer *evedg, *evtri, *evquad, type;
  assert(buff);

  integer vertex_count = 0;
  ret = mesh_get_vertex_count(msh, &vertex_count);
  if (ret != STATUS_OK)
    return ret;

  for (int i = 1; i <= vertex_count; i++) {
    real xyz[3];
    integer tag, ntag, itag;

    ret = mesh_get_vertex_coordinates(msh, i, xyz);
    if (ret != STATUS_OK)
      return ret;

    /* Now xyz contains the coordinates of vertex #i */
    printf("vertex %d coordinates are (%lf, %lf, %lf)\n", i, xyz[0],
           xyz[1], xyz[2]);

    ret = mesh_get_vertex_tag(msh, i, &tag);
    if (ret != STATUS_OK)
      return ret;

    printf("vertex %d first tag is %d\n", i, tag);

    /* Now tag contains the tag of the vertex. It may be a composite
     * tag. Check its definition */
    ret = mesh_get_composite_tag_definition(msh, tag, &ntag, buff);
    if (ret != STATUS_OK)
      return ret;

    /* buff[0..ntag-1] contains all the original tags of the vertex */
    if (ntag > 1) {
      /* There are several tags associated to the vertex #i. Print them : */
      printf("The original tags are :\n");
      for (itag = 0; itag < ntag; itag++)
        printf("%d ", buff[itag]);
      printf("\n");
    }
  }

  /* enumerate edges */
  integer edge_count = 0;
  evedg = (integer *) mesh_calloc_generic_buffer(msh);
  ret = mesh_get_edge_count(msh, &edge_count);
  if (ret != STATUS_OK)
    return ret;

  for (int i = 1; i <= edge_count; i++) {
    integer vertices[3], tag, ntag, itag;

    ret = mesh_get_edge_vertices(msh, i, vertices);
    if (ret != STATUS_OK)
      return ret;

    /* vertices[0..1] are the index of the edge #i vertices */
    printf("edge %d extremities are (%d, %d)\n", i, vertices[0],
           vertices[1]);

    ret = mesh_get_edge_extra_vertices(msh, i, &type, evedg);
    if (ret != STATUS_OK)
      return ret;

    ret = mesh_get_edge_tag(msh, i, &tag);
    if (ret != STATUS_OK)
      return ret;

    printf("edge %d first tag is %d\n", i, tag);

    ret = mesh_get_composite_tag_definition(msh, tag, &ntag, buff);
    if (ret != STATUS_OK)
      return ret;

    /* buff[0..ntag-1] contains all the original tags of the edge */
    if (ntag > 1) {
      /* There are several tags associated to the edge #i. Print them : */
      printf("The original tags are :\n");
      for (itag = 0; itag < ntag; itag++)
        printf("%d ", buff[itag]);
      printf("\n");
    }

    if (type == MESHGEMS_MESH_ELEMENT_TYPE_EDGE3) {
      /* This is a quadratic edge
       * evedg is filled with the quadratic nodes index
       */
      printf("Edge %d quadratic extra vertex is %d\n", i, evedg[0]);
    }
  }
  mesh_free_generic_buffer(evedg);

  /* enumerate triangles */
  integer triangle_count = 0;
  evtri = (integer *) mesh_calloc_generic_buffer(msh);
  ret = mesh_get_triangle_count(msh, &triangle_count);
  if (ret != STATUS_OK)
    return ret;

  for (int i = 1; i <= triangle_count; i++) {
    integer vertices[3], tag, ntag, itag;

    ret = mesh_get_triangle_vertices(msh, i, vertices);
    if (ret != STATUS_OK)
      return ret;

    /* vertices[0..2] contains are the index of the triangle #i vertices */
    printf("triangle %d vertices are (%d, %d, %d)\n", i, vertices[0],
           vertices[1], vertices[2]);

    ret = mesh_get_triangle_extra_vertices(msh, i, &type, evtri);
    if (ret != STATUS_OK)
      return ret;

    ret = mesh_get_triangle_tag(msh, i, &tag);
    if (ret != STATUS_OK)
      return ret;

    printf("triangle %d first tag is %d\n", i, tag);

    ret = mesh_get_composite_tag_definition(msh, tag, &ntag, buff);
    if (ret != STATUS_OK)
      return ret;

    if (ntag > 1) {
      /* There are several tags associated to the triangle #i. Print them : */
      printf("The original tags are :\n");
      for (itag = 0; itag < ntag; itag++)
        printf("%d ", buff[itag]);
      printf("\n");
    }

    if (type == MESHGEMS_MESH_ELEMENT_TYPE_TRIA6) {
      /* This is a quadratic triangle
       * evtri is filled with the quadratic nodes indices
       */
      printf("Triangle %d quadratic extra vertices are %d %d %d\n", i,
             evtri[0], evtri[1], evtri[2]);
    }
  }
  mesh_free_generic_buffer(evtri);

  /* enumerate quadrangles */
  integer quadrangle_count = 0;
  evquad = (integer *) mesh_calloc_generic_buffer(msh);
  ret = mesh_get_quadrangle_count(msh, &quadrangle_count);
  if (ret != STATUS_OK)
    return ret;

  for (int i = 1; i <= quadrangle_count; i++) {
    integer vertices[4], tag, ntag, itag;

    ret = mesh_get_quadrangle_vertices(msh, i, vertices);
    if (ret != STATUS_OK)
      return ret;

    /* vertices[0..3] contains are the index of the quadrangle #i vertices */
    printf("quadrangle %d vertices are (%d, %d, %d, %d)\n", i, vertices[0],
           vertices[1], vertices[2], vertices[3]);

    ret = mesh_get_quadrangle_extra_vertices(msh, i, &type, evquad);
    if (ret != STATUS_OK)
      return ret;

    ret = mesh_get_quadrangle_tag(msh, i, &tag);
    if (ret != STATUS_OK)
      return ret;

    printf("quadrangle %d first tag is %d\n", i, tag);

    ret = mesh_get_composite_tag_definition(msh, tag, &ntag, buff);
    if (ret != STATUS_OK)
      return ret;

    if (ntag > 1) {
      /* There are several tags associated to the quadrangle #i. Print them : */
      printf("The original tags are :\n");
      for (itag = 0; itag < ntag; itag++)
        printf("%d ", buff[itag]);
      printf("\n");
    }

    if (type == MESHGEMS_MESH_ELEMENT_TYPE_QUAD9) {
      /* This is a quadratic quadrangle
       * evquad is filled with the quadratic nodes index
       */
      printf("Quadrangle %d quadratic extra vertices are %d %d %d %d %d\n",
             i, evquad[0], evquad[1], evquad[2], evquad[3], evquad[4]);
    }
  }
  mesh_free_generic_buffer(evquad);
  mesh_free_generic_buffer(buff);

  /* If needed, you can query cadsurf for more information about the
   * generated mesh.  For example, you can access the parametric
   * coordinates of the generated vertices.
   */
  for (int i = 1; i <= vertex_count; i++) {
    real t, uv[2];
    integer nvl, exact, uid, j;

    ret = cadsurf_get_vertex_location_on_edge_count(css, i, &nvl);
    if (ret != STATUS_OK)
      return ret;

    /* This vertex has nvl different location on cad edges */
    printf("vertex %d has %d location on cad edges\n", i, nvl);
    for (j = 1; j <= nvl; j++) {
      ret =
          cadsurf_get_vertex_location_on_edge(css, i, j, &uid, &t, &exact);
      if (ret != STATUS_OK)
        return ret;
      /* the j-th location of the vertex is on the edge with unique
       * id (set by cad_edge_set_uid) uid, at coordinate t. If exact
       * is 1, it means the coordinates in the mesh are exact.  See
       * the function documentation in meshgems/cadsurf.h for more
       * information
       */
      printf
          ("location %d lies on edge with unique id %d with a coordinate %lf\n",
           j, uid, t);
    }
    /* This vertex has nvl different location on cad wires */
    ret = cadsurf_get_vertex_location_on_wire_count(css, i, &nvl);
    if (ret != STATUS_OK)
      return ret;

    printf("vertex %d has %d location on cad wires\n", i, nvl);
    for (j = 1; j <= nvl; j++) {
      ret =
          cadsurf_get_vertex_location_on_wire(css, i, j, &uid, &t, &exact);
      if (ret != STATUS_OK)
        return ret;
      /* the j-th location of the vertex is on the wire with unique
       * id (set by cad_wire_set_uid) uid, at coordinate t. If
       * exact is 1, it means the coordinates in the mesh are exact.
       * See the function documentation in meshgems/cadsurf.h for more
       * information
       */
      printf
          ("location %d lies on wire with unique id %d with a coordinate %lf\n",
           j, uid, t);
    }
    /* This vertex has nvl different location on cad faces */
    ret = cadsurf_get_vertex_location_on_face_count(css, i, &nvl);
    printf("vertex %d has %d location on cad faces\n", i, nvl);
    for (j = 1; j <= nvl; j++) {
      ret =
          cadsurf_get_vertex_location_on_face(css, i, j, &uid, uv, &exact);
      if (ret != STATUS_OK)
        return ret;
      /* the j-th location of the vertex is on the face with unique
       * id (set by cad_face_set_uid) uid, at coordinate uv. If
       * exact is 1, it means the coordinates in the mesh are exact.
       * See the function documentation in meshgems/cadsurf.h for more
       * information
       */
      printf
          ("location %d lies on face with unique id %d with a coordinate (%lf, %lf)\n",
           j, uid, uv[0], uv[1]);
    }
  }
  return STATUS_OK;
}

status_t generate_mesh(context_t * ctx, cad_t * c, dcad_t * dc,
                       mesh_t * imsh)
{
  status_t ret;
  sizemap_t *iso_sizemap_p = 0, *iso_sizemap_e = 0, *iso_sizemap_f = 0;
  sizemap_t *iso_sizemap_discrete = 0;
  sizemap_t *geo_sizemap_p = 0, *geo_sizemap_e = 0, *geo_sizemap_f = 0;
  sizemap_t *iso_3d_sizemap = 0, *aniso_3d_sizemap = 0;
  sizemap_t *aniso_along_edge_sizemap = 0;
  sizemap_t *required_np_e = 0;
  element_generation_map_t *element_generation_map_f = 0;

  assert(ctx);
  ret = STATUS_OK;

  /* Set the message callback in the working context */
  ret = context_set_message_callback(ctx, message_cb, 0);
  if (ret != STATUS_OK)
    return ret;

  /* Set the message interrupt in the working context */
  ret = context_set_interrupt_callback(ctx, interrupt_cb, 0);
  if (ret != STATUS_OK)
    return ret;

  /* The use of the CAD preprocessor of MG-CADSurf is strongly recommended with all CAD kernel, and 
     mandatory for all of them but OpenCASCADE */

#ifdef __MESHGEMS_PRIVKEY_H__
  /* If you are an OEM customer for MG-CADSurf, sign this CAD object with
   * your private key (else MG-CADSurf would reject it) */
  ret = meshgems_sign_cad(c);
  if (ret != STATUS_OK)
    return ret;
#endif


  /* Create and allocate the sizemap */

  if (c) {
    /* Geometric sizemap are only available for meshing on analytical CAD */
    if (USE_LOCAL_GEOMETRIC_SIZE) {
      /* if you want a geometric sizemap on points */
      geo_sizemap_p =
          sizemap_new(c, meshgems_sizemap_type_geometric_cad_point,
                      (void *) geosize_on_point, 0);
      if (!geo_sizemap_p)
        return STATUS_NOMEM;

      /* if you want a geometric sizemap on edges */
      geo_sizemap_e =
          sizemap_new(c, meshgems_sizemap_type_geometric_cad_edge,
                      (void *) geosize_on_curve, 0);
      if (!geo_sizemap_e)
        return STATUS_NOMEM;

      /* if you want a geometric sizemap on faces */
      geo_sizemap_f =
          sizemap_new(c, meshgems_sizemap_type_geometric_cad_face,
                      (void *) geosize_on_face, 0);
      if (!geo_sizemap_f)
        return STATUS_NOMEM;

    }
  }

  if (USE_LOCAL_PHYSICAL_SIZE) {
    if (c) {
      /* Analytical CAD */
      /* if you want a physical sizemap on points */
      iso_sizemap_p = sizemap_new(c, meshgems_sizemap_type_iso_cad_point,
                                  (void *) size_on_point, 0);
      if (!iso_sizemap_p)
        return STATUS_NOMEM;

      /* if you want a physical sizemap on edges */
      iso_sizemap_e = sizemap_new(c, meshgems_sizemap_type_iso_cad_edge,
                                  (void *) size_on_curve, 0);
      if (!iso_sizemap_e)
        return STATUS_NOMEM;

      /* if you want a physical sizemap on faces */
      iso_sizemap_f = sizemap_new(c, meshgems_sizemap_type_iso_cad_face,
                                  (void *) size_on_face, 0);
      if (!iso_sizemap_f)
        return STATUS_NOMEM;

      /* if you want to request a number of point on edges */
      /* The edges on which a required number is specified should be marked as REQUIRED.
       * They should not belong to a non closed periodic CAD face.
       */
      required_np_e =
          sizemap_new(c, meshgems_sizemap_type_number_of_vertices_cad_edge,
                      (void *) required_number_of_point_on_curve, 0);
      if (!required_np_e)
        return STATUS_NOMEM;

      /* if you want an isotropic sizemap on the 3D space */
      iso_3d_sizemap = sizemap_new(ctx, meshgems_sizemap_type_iso_3d,
                                   (void *) size_iso_3d, 0);
      if (!iso_3d_sizemap)
        return STATUS_NOMEM;

      /* if you want an anisotropic sizemap on the 3D space */
      aniso_3d_sizemap = sizemap_new(ctx, meshgems_sizemap_type_aniso_3d,
                                     (void *) size_aniso_3d, 0);
      if (!aniso_3d_sizemap)
        return STATUS_NOMEM;

      /* if you want an anisotropic sizemap along edges */
      aniso_along_edge_sizemap =
          sizemap_new(c, meshgems_sizemap_type_axisymmetric_along_cad_edge,
                      (void *) size_along_curve, 0);
      if (!aniso_along_edge_sizemap)
        return STATUS_NOMEM;

    } else if (imsh) {
      /* Discrete CAD */
      /* if you want a physical sizemap on mesh vertices */
      iso_sizemap_discrete =
          sizemap_new(imsh, meshgems_sizemap_type_iso_mesh_vertex,
                      (void *) size_on_vertex, 0);
      if (!iso_sizemap_discrete)
        return STATUS_NOMEM;
    }
  }

  /* Create and allocate the element_generation_map */
  if (c) {
    /* Local element generation is only available for meshing on analytical CAD */
    if (USE_LOCAL_ELEMENT_GENERATION) {

      /* if you want a element_generation_map on faces */
      element_generation_map_f =
          element_generation_map_new(c,
                                     meshgems_element_generation_map_type_cad_face,
                                     (void *) type_on_face, 0);
      if (!element_generation_map_f)
        return STATUS_NOMEM;
    }
  }



  /* create a cadsurf session (this corresponds to a cadsurf run) */
  cadsurf_session_t *css = cadsurf_session_new(ctx);
  if (!css)
    return STATUS_NOMEM;

  if (imsh) {
    /* Give the mesh object to the current cadsurf session */
    ret = cadsurf_set_mesh(css, imsh);
    if (ret != STATUS_OK)
      return ret;
  } else if (dc) {
    /* Give the DCAD object to the current cadsurf session */
    ret = cadsurf_set_dcad(css, dc);
    if (ret != STATUS_OK)
      return ret;
  } else {
    /* Give the CAD object to the current cadsurf session */
    ret = cadsurf_set_cad(css, c);
    if (ret != STATUS_OK)
      return ret;
  }

  /* Give the sizemaps to the cadsurf session */

  if (iso_sizemap_p)
    cadsurf_set_sizemap(css, iso_sizemap_p);

  if (iso_sizemap_e)
    cadsurf_set_sizemap(css, iso_sizemap_e);

  if (iso_sizemap_f)
    cadsurf_set_sizemap(css, iso_sizemap_f);

  if (geo_sizemap_p)
    cadsurf_set_sizemap(css, geo_sizemap_p);

  if (geo_sizemap_e)
    cadsurf_set_sizemap(css, geo_sizemap_e);

  if (geo_sizemap_f)
    cadsurf_set_sizemap(css, geo_sizemap_f);

  if (required_np_e)
    cadsurf_set_sizemap(css, required_np_e);

  if (iso_3d_sizemap)
    cadsurf_set_sizemap(css, iso_3d_sizemap);

  if (aniso_3d_sizemap)
    cadsurf_set_sizemap(css, aniso_3d_sizemap);

  if (aniso_along_edge_sizemap)
    cadsurf_set_sizemap(css, aniso_along_edge_sizemap);

  if (iso_sizemap_discrete) {
    assert(imsh);
    cadsurf_set_sizemap(css, iso_sizemap_discrete);
  }


  /* Give the element_generation_map to the cadsurf session */

  if (element_generation_map_f)
    meshgems_cadsurf_set_element_generation_map(css,
                                                element_generation_map_f);


  /* Set others cadsurf options. For example : */
  if (imsh) {
    ret = set_cadsurf_parameters(css, 1);
    if (ret != STATUS_OK)
      return ret;
  } else {
    ret = set_cadsurf_parameters(css, 0);
    if (ret != STATUS_OK)
      return ret;
  }

  /* Mesh the CAD with these options */
  ret = cadsurf_compute_mesh(css);

  mesh_t *msh;
  if (ret == STATUS_OK) {
    /* Everything went fine. You can get the resulting mesh */
    ret = cadsurf_get_mesh(css, &msh);
    if (ret != STATUS_OK)
      return ret;

  } else if (ret == STATUS_WARNING) {
    /* Something was not normal but you can still get the resulting mesh */
    /* Warning messages (and data) were sent to the message callback */
    ret = cadsurf_get_mesh(css, &msh);
    if (ret != STATUS_OK)
      return ret;

  } else {
    /* Their was an error while meshing */
    /* Error/Warning messages (and data) were sent to the message callback */
    /* No mesh will be returned */
    msh = 0;
  }

  if (msh) {
    /* retrieve mesh data (see meshgems/mesh.h for more details) */
    /* For example, you can here use the following function (defined 
     * above in this template) */
    ret = read_mesh(css, msh);
    if (ret != STATUS_OK)
      return ret;

    /* You can also directly write a .mesh (for visualization with medit
     * software for example) file from this mesh
     */
    ret = mesh_write_mesh(msh, "mymeshfile.mesh");
    if (ret != STATUS_OK)
      return ret;

    /* then release the mesh (give it back to the cadsurf session) */
    ret = cadsurf_regain_mesh(css, msh);
    if (ret != STATUS_OK)
      return ret;
  }

  /* Finally clean up everything */
  cadsurf_session_delete(css);

  if (geo_sizemap_p)
    meshgems_sizemap_delete(geo_sizemap_p);
  if (geo_sizemap_e)
    meshgems_sizemap_delete(geo_sizemap_e);
  if (geo_sizemap_f)
    meshgems_sizemap_delete(geo_sizemap_f);
  if (iso_sizemap_p)
    meshgems_sizemap_delete(iso_sizemap_p);
  if (iso_sizemap_e)
    meshgems_sizemap_delete(iso_sizemap_e);
  if (iso_sizemap_f)
    meshgems_sizemap_delete(iso_sizemap_f);
  if (iso_sizemap_discrete)
    meshgems_sizemap_delete(iso_sizemap_discrete);
  if (required_np_e)
    meshgems_sizemap_delete(required_np_e);
  if (iso_3d_sizemap)
    meshgems_sizemap_delete(iso_3d_sizemap);
  if (aniso_3d_sizemap)
    meshgems_sizemap_delete(aniso_3d_sizemap);
  if (aniso_along_edge_sizemap)
    meshgems_sizemap_delete(aniso_along_edge_sizemap);

  if (element_generation_map_f)
    meshgems_element_generation_map_delete(element_generation_map_f);


  return ret;
}
