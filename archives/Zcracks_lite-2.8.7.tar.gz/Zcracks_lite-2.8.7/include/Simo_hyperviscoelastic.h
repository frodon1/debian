#ifndef  __Simo_hyperviscoelastic__
#define  __Simo_hyperviscoelastic__


#include <Hyperelastic_law.h>
#include <Behavior.h>
#include <Viscoelastic_terms.h>

Z_START_NAMESPACE;

ZCLASS SIMO_HYPER_VISCO_ELASTIC : public BEHAVIOR {
      protected :
        AUTO_PTR<HYPERELASTIC_LAW> hyper_law; 

        PLIST<VE_SHEAR>   shear;
        PLIST<VE_VOLUMIC_SIMO> volumic;
        TENSOR2_VAUX Stilda0n;
        TENSOR2   sig0;
        TENSOR2 H_tilda;
        TENSOR2 h;    
        TENSOR2 one;
        TENSOR4 ONE;
        TENSOR4 UNIT;
        TENSOR4 Idev;
        SMATRIX m_tgmat;

        TENSOR2_VAUX S0n;
        TENSOR2 Q_tilda;
        TENSOR2 q;



        virtual void verif_read();

      public :

        SIMO_HYPER_VISCO_ELASTIC();
        virtual ~SIMO_HYPER_VISCO_ELASTIC(); 
        
        virtual void initialize(ASCII_FILE& file, int dim, LOCAL_INTEGRATION*);

        INTEGRATION_RESULT* integrate( MAT_DATA&, 
                                       const VECTOR&, 
                                       MATRIX*&, int);

        virtual STRESS_MEASURE get_stress_measure()const { 
             return hyper_law->get_stress_measure(); 
        }

};
Z_END_NAMESPACE;

#endif
