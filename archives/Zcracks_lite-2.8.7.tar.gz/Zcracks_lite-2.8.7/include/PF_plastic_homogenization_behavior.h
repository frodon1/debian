#ifndef __Plastic_Phasefield_behavior__
#define __Plastic_Phasefield_behavior__

#include <PF_Chemical_energy.h>


Z_START_NAMESPACE;

class MAT_DATA; class ASCII_FILE;
class PHASEFIELD_PHIC_ENERGY;

class PLASTIC_PHASEFIELD_BEHAVIOR : public BEHAVIOR, 
                                          public RUNGE_INTEGRATOR,
				          public THETA_INTEGRATOR {
  protected:
      AUTO_PTR<ELASTICITY> elas1;
      AUTO_PTR<ELASTICITY> elas2;
      COEFF eigen_coeff1,eigen_coeff2; 
      COEFF delta1,delta2;        	       
      COEFF c_ref1,c_ref2; 
      TENSOR2_FLUX sig;
      TENSOR2_VAUX sig1,sig2;
      TENSOR2_GRAD eto;
      TENSOR2_VINT Eel1, Eel2,alpha1,alpha2;
      
      TENSOR2_VAUX Ep1, Ep2, Ep,Eel;
      SCALAR_VINT  epcum1, epcum2;
      SCALAR_VAUX misec1, misec2;
      COEFF B1, B2;
      COEFF Q1, Q2;
      COEFF C1, D1, C2, D2;
      COEFF R01, R02;
      AUTO_PTR<RUNGE> runge;
      AUTO_PTR<THETA> integ_theta;
      VECTOR dgrad;
      TENSOR4   unit, unit32;   // utility dev operator s' = unit*sigma
      
      SMATRIX  dn1_ds1, dn1_dEel1;
      SMATRIX  dn2_ds2, dn2_dEel2;
            
      VECTOR   f_vec_Eel1,      f_vec_Eel2;
      VECTOR   f_vec_alpha1,    f_vec_alpha2;
      SMATRIX  dEel1_dEel1,     dEel2_dEel2;
      MATRIX   dEel1_depcum1,   dEel2_depcum2;
      MATRIX   dEel1_dalpha1,   dEel2_dalpha2;
      
      MATRIX   depcum1_dEel1,   depcum2_dEel2;
      MATRIX   depcum1_dalpha1, depcum2_dalpha2;
      
      SMATRIX  dalpha1_dalpha1, dalpha2_dalpha2;
      MATRIX   dalpha1_dEel1,   dalpha2_dEel2;
      MATRIX   dalpha1_depcum1, dalpha2_depcum2;
      
      //VECTOR  f_vec;              // residual 
      //VECTOR  dchi;              // increment of integrated vars
      //VECTOR  f_0;                // what f_vec is compared to 
      //SMATRIX f_grad;             // the jacobian matrix
      
      TENSOR2 normsig1, normsig2;
      TENSOR2 m1, m2;

      TENSOR2_VAUX defo_tr;    
      VECTOR_FLUX xi, J;
      VECTOR_GRAD C_grad, Phi_grad;
      SCALAR_VAUX mu,Phi, C;
      SCALAR_VAUX pi, pi_c;
      TENSOR2 deto;
      
      COEFF function, function2;
      
      double h, dh,d2h;
      double h_mech, dh_mech,d2h_mech;

      SCALAR_VINT eto1;
      VECTOR_VAUX grad_eto1;
      SCALAR_VINT eto2;
      VECTOR_VAUX grad_eto2;
      SCALAR_VINT eto3;
      VECTOR_VAUX grad_eto3;
      SCALAR_VINT eto4;
      VECTOR_VAUX grad_eto4;
      SCALAR_VINT eto5;
      VECTOR_VAUX grad_eto5;
      SCALAR_VINT eto6;
      VECTOR_VAUX grad_eto6;
                 
      MATRIX grad_eto;            
      //double Timeup;
      //int incr;
         
      double df_dphi, df_dc, d2f_dphi2, d2f_dc2, d2f_dphidc,d3f_dphidc2, d3f_dphi2dc;
      VECTOR grad_mu;
      
      TENSOR2 dWe_ddef, d2We_dphiddef;
      SMATRIX d2We_d2def, d3We_d2defdc; 
      double dWe_dphi, d2We_d2phi; 
      
      VECTOR d2We_ddefdc,d3We_ddefd2c, d3We_ddefdphidc;
      double dWe_dc, d2We_d2c, d3We_d3c;
      double d2We_dphidc,d3We_dphid2c,d3We_d2phidc;     
      
      SMATRIX Ceff;

      double W1r,W2r;
      double dWalpha_dphi,dWr_dphi;
      double d2Walpha_d2phi,d2Wr_d2phi;

      COEFF alpha,beta;
      COEFF onsag2,onsag1;

      PHASEFIELD_PHIC_ENERGY *energy;

  public:
      PLASTIC_PHASEFIELD_BEHAVIOR();
      virtual ~PLASTIC_PHASEFIELD_BEHAVIOR();
      virtual void initialize(ASCII_FILE&,int,LOCAL_INTEGRATION*);
      virtual void calc_grad_f(VECTOR&,SMATRIX&,const VECTOR&,const VECTOR&,double,double);
      virtual void derivative(double,const  VECTOR&,VECTOR&);
      virtual INTEGRATION_RESULT* integrate(MATERIAL_INTEGRATION_INFO&);
};
Z_END_NAMESPACE;

#endif
