#ifndef __Zebulon_GAUGE__
#define __Zebulon_GAUGE__

#include <ZMath.h>
#include <Stringpp.h>

Z_START_NAMESPACE;

ZCLASS GAUGE {
  protected :
    STRING message;
    double __min,__max,current;
    int icurrent;
    bool _stopped;

    void print(); 
    int percent(double d) { return((int)((d-__min)/(__max-__min)*100)); }

  public :
    const bool &stopped;

    GAUGE(const char *msg, double _min, double _max); 

    GAUGE() : stopped(_stopped) { message=""; __min=__max=0; reset(); }
    virtual ~GAUGE(); 

    virtual void update(); 

    virtual void set(double v); 
    virtual void finish(); 

    void set_min_max(double _min, 
                     double _max,
                     STRING s=STRING::EMPTY) { 
           __min=_min; 
          __max=_max; 
          if(__min==__max) __min=0.;
          if(__max<1.e-9) __max=1.;
          if(s!="") set_title(s); 
          else reset(); 
   }

   virtual void set_title(STRING s) { message=s; reset(); }
   virtual void reset() { current=__min; icurrent=-1; update(); _stopped=FALSE; }
};
Z_END_NAMESPACE;

#endif
