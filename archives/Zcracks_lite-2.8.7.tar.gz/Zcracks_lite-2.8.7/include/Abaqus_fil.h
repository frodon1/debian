#ifndef __Abaqus_fil__ 
#define __Abaqus_fil__ 

#include <Object_factory.h>
#include <Error_messager.h>
#include <File_function.h>
#include <File.h>
#include <Out_message.h>

#include <Utility_mesh.h>
#include <Utility_mesh_reader.h>

Z_START_NAMESPACE;

class ABAQUS_FIL_RESULTS; 
class ELEMENT_FILE; 
class FIL_POSITION;

struct FIL_POSITION;

ZCLASS ABAQUS_FIL : public UTILITY_MESH_READER {
   public :
       int hyper_debug; 

       bool reduced;
       STRING abaqus;
       STRING fil_end;
       STRING fil_name;

       LIST<long> end_toks;
       BUFF_LIST< LIST<int>* > element_nodes;
       LIST<long> node_tags;
       LIST<long> element_tags;

       long current_node;
       long current_element;
       FILE* fil;

       char buf[9];
       virtual bool    open_fil();
       virtual void    startup_fil(); 
       virtual int     getint();
       virtual double  getdouble();
       virtual STRING  getc8();
       virtual bool    check_rec(const char* fle, int lne);
       long words_read; // # of words (8-byte) read so far; formerly records
                     // when words_read>=512, it's reset to 0 by check_rec(). 
       long rec_ptr;  // # of bytes read in the current record
       long pos_ini;  // starting position of current record
       long rl;        // record length, in (8-byte) words
       long tok;

       long num_elem;
       long num_node;

       void finish_mesh();

       // 
       // Handy pre-casted copy of its_mesh->results_part
       // 
       ABAQUS_FIL_RESULTS* res; 

       // For setting bookmarks to results variables:
       long map_index;
       virtual void read_element_output();
       virtual long  skip_words(long num_words);
       virtual void reset_record();
       virtual bool start_read_record();
       virtual void report_data_err(STRING fname, long lineno);

       void copy_state(FIL_POSITION& fpos, long words_off); 
       void set_state(FIL_POSITION& fpos); 

       void add_tensor(ELEMENT_FILE& e, long& index, STRING name, int if_clear=1); 
       void add_scalar(ELEMENT_FILE& e, long& index, STRING name, int if_clear=1); 


    public :
       ABAQUS_FIL(); 
       virtual ~ABAQUS_FIL();

       virtual STRING default_extension() { return(".fil"); }
       virtual void initialize(ASCII_FILE&,UTILITY_MESH*);
       void read_element();
       void read_node();
       void read_nset();
       void read_elset();
       virtual long clear_record();
       virtual bool verify();

       // 
       // Used by the results part
       // 
       bool get_disp_record(long& node_id, VECTOR& v);  
};
Z_END_NAMESPACE;

#endif
