#ifndef __Cycle_skip__
#define __Cycle_skip__

#include <List.h> 
#include <Marray.h> 
#include <Stringpp.h> 
#include <Vector.h> 

Z_START_NAMESPACE;

class ASCII_FILE;
class ALGORITHM;
class Zfstream; 

ZCLASS2 CYCLE_SKIP { 
  protected : 
     bool         active;
     int          nb_pt_gauss; 
     LIST<STRING> components; 
     MARRAY<VECTOR> check_var1; 
     MARRAY<VECTOR> check_var2; 
     MARRAY<VECTOR> check_var3; 
     VECTOR       vint_1, vaux_1, dof_1; 
     VECTOR       vint_2, vaux_2, dof_2; 
     VECTOR       vint_3, vaux_3, dof_3; 
     double       check_limit; 

     int          max_skip;
     int          order; 
     int          error_skip; 
     int          write_post_skip; 
     double       trim, progression, max_progression; 
     double       range,min_variation;
     double       start_time, end_time; 
     double       precision; 
     int          cycle_1; 
     int          cycle_2; 
     int          cycle_3; 
     int          sequence; 
     int          start_cycle; 
     int          end_cycle; 
     int          next_stop_cycle; 
     int          current_step; 
     int          vint_size, vaux_size; 
     int          previous_skip;
 
     ALGORITHM*     its_boss; 

     virtual void         check_sizes(); 
     virtual void         do_skip(double N); 

  public : 
     CYCLE_SKIP(); 
     virtual ~CYCLE_SKIP() { } 
     virtual void initialize(ASCII_FILE& inp, ALGORITHM* pb);
     static CYCLE_SKIP* read(ASCII_FILE& inp, ALGORITHM* pb); 
  
     virtual bool manage_skip(int ipc); 

     virtual void write_restart(RST_FSTREAM& f); 
     virtual void read_restart(RST_FSTREAM& f); 

}; 
Z_END_NAMESPACE;

#endif
