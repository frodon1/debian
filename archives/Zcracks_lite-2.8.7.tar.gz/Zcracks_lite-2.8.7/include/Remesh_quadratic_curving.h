#include <Remeshing_criterion.h>
#include <Stringpp.h>
#include <Discrete_timer.h>
#include <P_element.h>
#include <Zminmax.h>
#include <Print.h>

Z_START_NAMESPACE;

// SFP 09/070/009: to remesh when 6 nodes triangles edges are curved

class REMESH_QUADRATIC_CURVING : public REMESHING_CRITERION
{
  protected :
    STRING elset_name;
    double threshold;

  public :
    REMESH_QUADRATIC_CURVING() : REMESHING_CRITERION() { }
    virtual ~REMESH_QUADRATIC_CURVING() { }

    virtual bool GetResponse(STRING &key, ASCII_FILE &inp);
    virtual bool time_for_remesh(const MESH&);

    RTTI_INFO;
};

Z_END_NAMESPACE;
