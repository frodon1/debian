#ifndef __Zbool__ 
#define __Zbool__ 

// 
// Don't use this file !
// 

#include <Bool.h> 
#define ZBOOL bool 

#endif
