#ifndef __AUTO_INPUT_ERROR__
#define __AUTO_INPUT_ERROR__

#include <Auto_ptr.h>
#include <Auto_input_data_part.h>

Z_START_NAMESPACE;

class AUTO_INPUT_READER
{
  public :
    AUTO_INPUT_READER() { }
    virtual ~AUTO_INPUT_READER() { }

    virtual bool read(AUTO_PTR<AID_PART>&)=0;
    virtual bool write(AUTO_PTR<AID_PART>&)=0;
};
Z_END_NAMESPACE;

#endif
