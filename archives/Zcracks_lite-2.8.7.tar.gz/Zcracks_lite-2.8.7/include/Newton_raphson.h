#ifndef _Newton_raphson_
#define _Newton_raphson_

#include <Bool.h>

#include <ZMath.h>

Z_START_NAMESPACE;

ZCLASS NEWTON_RAPHSON {
   private :
      VECTOR dx;
   protected :
      bool move_limit;
      int max_iter;
      double _error, max_inc;
      int _iter;
   public :
      NEWTON_RAPHSON() : move_limit(FALSE), max_iter(100) { }
      NEWTON_RAPHSON(int mi) : move_limit(FALSE), max_iter(mi) { }

      virtual ~NEWTON_RAPHSON() { } 

      void set_max_iter(int iter) { max_iter=iter; }
      void set_move_limit(double _max_inc) 
        { move_limit = TRUE; max_inc = _max_inc; }
      bool find_solution(VECTOR& sol,double tole);
      void set_dx(const VECTOR&);
      double error()const { return _error; }
      int iter()const { return _iter; }

      virtual VECTOR f_newton_raphson(const VECTOR& x)=0;
      virtual SMATRIX df_newton_raphson(const VECTOR& x);
};
Z_END_NAMESPACE;

#endif
