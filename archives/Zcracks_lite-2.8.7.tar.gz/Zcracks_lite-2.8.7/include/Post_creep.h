#ifndef __Post_creep__
#define __Post_creep__

#include <Local_post_computation.h>
#include <Post_simple.h>
#include <Post_eigen.h>
#include <Post_mises.h>
#include <Post_trace.h>
#include <Post_delay.h>

Z_START_NAMESPACE;

#define EPSILON 1.E-08

class POST_LCF;
class POST_LCF_RAINFLOW;

ZCLASS2 POST_CREEP : public POST_SIMPLE, public RUNGE_INTEGRATOR {
 private :
   ARRAY<double> times;
   AUTO_PTR<POST_EIGEN2> lp_eigen;
   AUTO_PTR<POST_TRACE> lp_trace;
   AUTO_PTR<POST_MISES> lp_mises;
   AUTO_PTR<POST_DELAY> lp_delay;
   AUTO_PTR<LOCAL_INTEGRATION> runge;

   ARRAY<VECTOR> eigen_out,trace_out,mises_out,S;

 public :
  int  tsz;
  int  is_log, cycle, discret; 
  bool delay, debug, saturating, reorder;

  VECTOR Sig0,Sig1;
  double T0,T1;
  double precision;

  POST_COEFF S0, A, r, alpha, beta, k, tau, rlogA;
  // optional, for alternate saturating form
  POST_COEFF As, rs, rslogAs;
  void init_coefs(); 

  POST_CREEP();
  virtual ~POST_CREEP();

  virtual MODIFY_INFO_RECORD* get_modify_info_record();
  virtual bool verify_info();

  virtual void input_i_need(int,ARRAY<STRING>&);
  virtual void output_i_give(bool&,ARRAY<STRING>&);
  virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
  virtual bool need_material_file()const { return TRUE; }
  virtual void derivative(double,const VECTOR&,VECTOR&);
  void set_time_vals(const ARRAY<double>& times);
  double TimeCreep(int ic);
};

Z_END_NAMESPACE;
#endif

