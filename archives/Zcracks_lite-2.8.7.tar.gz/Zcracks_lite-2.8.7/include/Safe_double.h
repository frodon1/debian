#ifndef __Safe_double__
#define __Safe_double__

#include <Stringpp.h> 

Z_START_NAMESPACE;

//
//  Safe double checks that there is enough precision in a dtoa 
//  string generation so data is not lost. 
//
WIN_THINGIE2 STRING safe_double(double); 
Z_END_NAMESPACE;

#endif
