#ifndef __Parallel_graphics_objects__
#define __Parallel_graphics_objects__

#include <Buffered_list.h>
#include <Graphics_object.h>
#include <Graphics_edge.h>
#include <Graphics_face.h>
#include <Graphics_view_manager.h>

Z_START_NAMESPACE;

ZCLASS PARALLEL_GRAPHICS_OBJECTS {

   protected :
     GRAPHICS_AREA* its_boss;

     void pga_insert(int nb_proc,double z,VECTOR& z_proc,ARRAY<int>& index_proc);
     void pga_sort(int beg, int end, VECTOR& z_proc, ARRAY<int>& index_proc);

   public :

     ARRAY< ARRAY< GRAPHICS_FACE* > >  faces_from_parallel;
     ARRAY<int>                        nb_faces_from_parallel;
     ARRAY< ARRAY< GRAPHICS_POINT* > > points_from_parallel;
     ARRAY<int>                        nb_points_from_parallel;
     BUFF_LIST< GRAPHICS_EDGE* >       edges_from_parallel;
     ARRAY< ARRAY<int> >               all_proc_faces_rank;

     PARALLEL_GRAPHICS_OBJECTS(GRAPHICS_AREA*);
     ~PARALLEL_GRAPHICS_OBJECTS();

     void set_parallel_objects_size(int ip,int nb_faces,int nb_points);
     void get_parallel_faces();
     void get_parallel_results();
     void parallel_faces_to_draw(BUFF_LIST<GRAPHICS_FACE*>& faces_to_draw,
       BUFF_LIST<GRAPHICS_EDGE*>& edges_to_draw);
     void update_for_vm_change();

};

Z_END_NAMESPACE;
#endif

