#ifndef __ZP_BASIC_TYPE__
#define __ZP_BASIC_TYPE__

#include <ZP_stack.h>
#include <ZP_object.h>
#include <Error_messager.h>

Z_START_NAMESPACE;

template <class T> ZCLASSt ZP_BASIC_TYPE : public ZP_OBJECT
{
  protected :
    int dont_delete;

  public :
    ZP_BASIC_TYPE() : ZP_OBJECT() , dont_delete(0) { contens=new T; }
    ZP_BASIC_TYPE(T i) : ZP_OBJECT() , dont_delete(0) { contens=new T; get()=i; }
    ZP_BASIC_TYPE(T *i) : ZP_OBJECT() , dont_delete(1) { contens=i; }
    virtual ~ZP_BASIC_TYPE() { if(!dont_delete) delete((T*)contens); }

    T& get() { return(*((T*)contens)); }
    IMPL_RTTI_INFO_H(ZP_OBJECT,ZP_BASIC_TYPE)
};

/*
template <class T> const char* ZP_BASIC_TYPE<T>::__type()const { return "ZP_BASIC_TYPE"; }

template <class T> const char* ZP_BASIC_TYPE<T>::isA()const { return "ZP_BASIC_TYPE"; }

template <class T> bool ZP_BASIC_TYPE<T>::__are_you_a(const char* str)const
{ 
  if(strcmp(str,"ZP_BASIC_TYPE")==0) return TRUE;
  else return ZP_OBJECT::__are_you_a(str);
}

template <class T> bool ZP_BASIC_TYPE<T>::areYouA(const char* str)const
{ 
  if(strcmp(str,"ZP_BASIC_TYPE")==0) return TRUE;
  else return ZP_OBJECT::__are_you_a(str);
}
*/

#define BASIC_CONSTRUCTORS(cname,type) cname() : ZP_BASIC_TYPE< type >() { type_init(NULL); } \
    cname(type &d) : ZP_BASIC_TYPE< type >(d) { type_init(NULL); } \
    cname(type *d) : ZP_BASIC_TYPE< type >(d) { type_init(NULL); }
Z_END_NAMESPACE;

#endif
