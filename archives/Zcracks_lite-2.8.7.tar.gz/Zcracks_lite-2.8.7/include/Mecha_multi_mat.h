#ifndef __Mecha_multi_mat__
#define __Mecha_multi_mat__

#include <Base_multi_mat.h>
#include <Marray.h>
#include <Tensor4.h>

Z_START_NAMESPACE;

ZCLASS MECHA_MULTI_MAT : public BASE_MULTI_MAT {
     int called_extract; 
  protected :

     TENSOR4 Cc;

     TENSOR2_GRAD  eto;
     TENSOR2_FLUX  sig;

     TENSOR2_VINT  Ee;   
     TENSOR2       Ee_dv;   
     TENSOR2 Ep, dEp;

     TENSOR2  eto_rate; 
     MARRAY<VECTOR>          sig_store, eto_store;
     ARRAY< TENSOR2_GRAD* > _sub_eto;
     ARRAY< TENSOR2_FLUX* > _sub_sig;
     ARRAY< TENSOR2_VINT* > _sub_eel;
     MARRAY< TENSOR2 >      _sub_eto_rate; 

     TENSOR2_FLUX& sub_sig()         { return *_sub_sig[iib]; }
     TENSOR2_GRAD& sub_eto()         { return *_sub_eto[iib]; }
     TENSOR2&      sub_eto_rate()    { return  _sub_eto_rate[iib]; }
     TENSOR2_VINT& sub_eel()         { return *_sub_eel[iib]; }
     TENSOR2&      sub_eel_dv()      { return  _sub_eel_dv[iib]; }

     PARRAY< TENSOR2_VINT > _leto; // must be integrated
     PARRAY< TENSOR2_VAUX > _lsig; // must be saved as sub dual are not transferred to the boss
     MARRAY<TENSOR2>        _dep;

     ARRAY< TENSOR2 >      _sub_eel_dv; 
     ARRAY< TENSOR2 >      _leto_dv; 

     TENSOR2&      dep()  { return _dep[iib]; }
     TENSOR2_VINT& leto() { return *_leto[iib]; }
     TENSOR2&      leto_dv() { return _leto_dv[iib]; }
     TENSOR2_VAUX& lsig() { return *_lsig[iib]; }

     ARRAY<MECHA_MULTI_MAT*> _sub_mm;
     MECHA_MULTI_MAT* sub_mm() { return _sub_mm[iib]; }

     virtual void extract_sub_grad_flux();

     virtual void compute_dep(double tau);

     virtual void compute_Cc()=0;
     virtual void compute_dEp()=0;
             void compute_Ep();

     virtual INTEGRATION_RESULT* integrate_runge();
     virtual INTEGRATION_RESULT* integrate_theta_a();
     virtual void setup(int& flux_pos, int& grad_pos, int& vi_pos, int& va_pos); 
     // 
     // RK version, must attach the _dv vars by hand 
     // 
     virtual void attach( VECTOR&  chi_vec, VECTOR&  d_chi ); 

   public :

     MECHA_MULTI_MAT();
     virtual ~MECHA_MULTI_MAT();

     virtual INTEGRATION_RESULT*  integrate(MATERIAL_INTEGRATION_INFO&);
     
     virtual void initialize(ASCII_FILE&,int,LOCAL_INTEGRATION*);

     virtual void impose_grad_rate(const VECTOR& dg); 
     virtual SMATRIX get_elasticity_matrix(MAT_DATA& mdat,double theta); 

     virtual void update_var_aux();
             void compute_actual_rates(double tau);
     virtual void apply_localization()=0;
    
     RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
