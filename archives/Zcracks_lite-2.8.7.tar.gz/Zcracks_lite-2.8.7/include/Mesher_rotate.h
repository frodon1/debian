#ifndef __ROTATE_TRANSFORMER__
#define __ROTATE_TRANSFORMER__

#include <Calcul_timer.h>
#include <Defines.h>
#include <Error_messager.h>
#include <File.h>
#include <Function.h>
#include <Marray.h>
#include <Rotation.h>
#include <Print.h>
#include <Out_message.h>

#include <Utility_mesh.h>

#include <Modify_record.h>
#include <Transform_geometry.h>

#include <Print.h>
#include <Hashed_list.h>
#include <Function.h>

Z_START_NAMESPACE;


// ============================================================================ 
//  This one applies a corrdinate rotation 
// ============================================================================ 
ZCLASS ROTATE_TRANSFORMER : public TRANSFORMERS {
  public :
     AUTO_PTR<ROTATION> rot; 
  ROTATE_TRANSFORMER() { elset_name="";} 
     virtual void initialize(ASCII_FILE& file);
     virtual void apply(UTILITY_MESH& mesh);
  //virtual MODIFY_INFO_RECORD* get_modify_info_record();
     STRING       elset_name;

};

Z_END_NAMESPACE;

#endif
