#ifndef __Global_server__
#define __Global_server__

#include <Defines.h> 

Z_START_NAMESPACE;

extern WIN_THINGIE char *program_name;
extern WIN_THINGIE char *wdir;
#define DEFAULT_FILE_BUFFER_SIZE 2097152 // 2Mo
Z_END_NAMESPACE;

#endif
