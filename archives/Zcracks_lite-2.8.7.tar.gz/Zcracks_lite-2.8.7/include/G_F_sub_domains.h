#ifndef __G_F_SUB_DOMAINS__
#define __G_F_SUB_DOMAINS__

#include <Message_passing_client.h>
#include <Sub_domains.h>
#include <Parallel_set.h>
#include <Defines.h>

Z_START_NAMESPACE;

ZCLASS2 G_F_SUB_DOMAINS : public SUB_DOMAINS {
  protected :
    MP_CLIENT *mp_client;
    STRING pb_name;

  public :
    int who_am_i;
    PARALLEL_SET_INFOS parallel_set_infos;
    BUFF_LIST<int> *my_gelements;
    BUFF_LIST<int> *my_gnodes;

    BUFF_LIST<int> *n_global_to_local; // rank transfer arrays
    BUFF_LIST<int> *n_local_to_global;
    BUFF_LIST<int> *e_global_to_local;
    BUFF_LIST<int> *e_local_to_global;
    
    G_F_SUB_DOMAINS(UTILITY_MESH &fm, const STRING &pbn,int w,int rcf, int ipc, int partial_load);
    virtual ~G_F_SUB_DOMAINS() { }

    void build_transfer_arrays();
    void assign_g_list();

    int local_to_global_e(int local_e);
    int local_to_global_n(int local_n);

    long int size_of();
};
Z_END_NAMESPACE;

#endif
