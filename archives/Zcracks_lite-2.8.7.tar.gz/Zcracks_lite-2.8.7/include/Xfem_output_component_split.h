#ifndef __Xfem_output_component_split__
#define __Xfem_output_component_split__

//============================================================================
// XFEM_OUTPUT_COMPONENT_SPLIT                                RF 01/29/2004
//
// Base class for output components supporting the Xfem split visualization 
//   
//============================================================================

#include <ZMath.h>
#include <Graphics_utility.h>
#include <Xfem_output_node.h>

Z_START_NAMESPACE;

ZCLASS2 XFEM_OUTPUT_SPLIT_BASE { 
   protected :
     OUTPUT_COMPONENT*  the_output; // set by derived class = this 
     void do_3d_face_search(UTILITY_MESH* new_mesh);

   public :
     class XFEM_SPLIT_INFO { 
        public :
          XFEM_SPLIT_INFO(); 
          ~XFEM_SPLIT_INFO(); 

          XFEM_DISCONTINUITY::X_TYPE state;
          int           ele_rank; 
          UTILITY_MESH  subdiv; 

          LIST<int>               integs; 
          LIST<UTILITY_BOUNDARY*> faces; 
          BUFF_LIST<VECTOR>       displ; 
          ARRAY<int>*             crack_faces_ranks;
          int num_val(); 
          int num_ip(); 
 
          int cycle; 
          int seq; 
          int incr; 
          bool operator==(const XFEM_SPLIT_INFO& info); 
     }; 
     
     bool store_enriched;
     static STRING last_xele_file_name;
     static UTILITY_MESH* last_xele_mesh; 
     static double xele_date;
     static bool force_xele_reload;
     static ARRAY<int>                  xranks;   // lookup of xele info based on elem rank 
     static BUFF_LIST<XFEM_SPLIT_INFO*> xele_info; 

     ARRAY<VECTOR> read_buffer;

     XFEM_OUTPUT_SPLIT_BASE();
     virtual ~XFEM_OUTPUT_SPLIT_BASE();

     virtual void clear_xele_infos(); 
     virtual void reset_xele_faces(UTILITY_MESH* new_mesh, double time=-1.);
   
     virtual void save_sub_meshes(UTILITY_FILE_DRIVER* drv);
     virtual void write_xele_stuff(GMESH* the_mesh, UTILITY_FILE_DRIVER* drv);
     virtual void binary_write_xele_stuff(GMESH* the_mesh, UTILITY_FILE_DRIVER* drv);

     virtual void read_xele_stuff(ASCII_FILE& file);
     virtual void binary_read_xele_stuff(Zfstream& file);

     virtual void split_mesh_has_changed(double t, UTILITY_FILE_DRIVER* drv, 
       UTILITY_MESH* new_mesh);

     double        keep_mag; 

     static XFEM_OUTPUT_SPLIT_BASE* global_displ_split; 
};

Z_END_NAMESPACE;

#endif 
