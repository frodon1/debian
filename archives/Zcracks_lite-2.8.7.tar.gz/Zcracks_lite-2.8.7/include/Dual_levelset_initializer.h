#ifndef __DUAL_LEVELSET_INITIALIZER__
#define __DUAL_LEVELSET_INITIALIZER__

#include <File.h>
#include <Xfem_levelset.h>
#include <Grid_3d.h>

Z_START_NAMESPACE;

class MESH;
class XFEM_3D_LEVELSET;

class DUAL_LEVELSET_INITIALIZER
{
public :
  XFEM_3D_LEVELSET *boss;
  
  DUAL_LEVELSET_INITIALIZER() { boss=NULL; }
  virtual ~DUAL_LEVELSET_INITIALIZER() { }
  
  virtual void initialize(ASCII_FILE&) { }
  virtual void initialize(XFEM_LEVELSET&,XFEM_LEVELSET&,XFEM_LEVELSET&) { }
  virtual void propagate() { }
  virtual void mesh_changed(MESH&,XFEM_LEVELSET*&,XFEM_LEVELSET*&,XFEM_LEVELSET*&) { }
  virtual void get_grid(GRID_3D<double>*&,GRID_3D<double>*&) { ERROR("Should never go there"); }
  
  virtual void write_restart_grid() { }
  
  int propagation_step;
};
Z_END_NAMESPACE;

#endif
