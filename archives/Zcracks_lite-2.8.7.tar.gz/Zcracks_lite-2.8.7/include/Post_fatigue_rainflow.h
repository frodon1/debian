#ifndef __Post_fatigue_rainflow__
#define __Post_fatigue_rainflow__

#include <Local_post_computation.h>
#include <Post_simple.h>
#include <Post_trace.h>
#include <Post_eigen.h>
#include <Post_mises.h>
#include <Post_multirange.h>
#include <Sorted_list.h>

Z_START_NAMESPACE;

class ONERA_ANISO_DAMAGE_INTEGRATOR;
class ONERA_CHECK_INTEGRATION;

ZCLASS2 POST_FATIGUE_RAINFLOW : public POST_SIMPLE {
  public :
    bool varying_additional_param;
    double infinity, epsilon, max_dT;
    int tsz, iter, reverse;

    AUTO_PTR<POST_TRACE>      lp_trace;
    AUTO_PTR<POST_EIGEN2>     lp_eigen;
    AUTO_PTR<POST_MISES>      lp_mises;
    AUTO_PTR<POST_MULTIRANGE> lp_rainflow;

    // additional stuff for anisotherm Taira
    AUTO_PTR<POST_RANGE>      lp_range;
    AUTO_PTR<ONERA_ANISO_DAMAGE_INTEGRATOR> aniso_integrator;
    AUTO_PTR<ONERA_CHECK_INTEGRATION>       check_integration;
    ARRAY<VECTOR> out_range;
    Zfstream check_file;
    double TT_min, TT_max;
    SORTED_LIST<double> temperature_definition;
    VECTOR additional_external_param;

    int  is_log, with_a, simplified_model; 
    bool normalized_coeff, use_mises, use_sign, needs_teq, out_of_phase, check_integ;
    bool compressive_sigl, check_positive_alpha;
    STRING mean_stress_method;

    POST_COEFF a, beta, M, sigma_l, sigma_u, b1, b2, sigma_p, sigma_n;
    ARRAY<POST_COEFF*> its_coeff;
    VECTOR initial_coef_values;
//  smart coefs stuff
    bool no_smart_coefs, needs_smart_coefs;
    VECTOR T_vals, beta_vals, a_vals, M_vals; 

//    Number of input cards: beg and end are real card numbers
    int cal_nb_card(int beg,int end,int tot);
//    Returns rank of card ic (card number-1)
    int cal_num_card(int beg,int end,int tot,int ic);

    POST_FATIGUE_RAINFLOW(); 
    virtual ~POST_FATIGUE_RAINFLOW();
    virtual void init_coefs();

    virtual MODIFY_INFO_RECORD* get_modify_info_record();
    virtual bool verify_info();

    virtual void input_i_need(int,ARRAY<STRING>&); 
    virtual void output_i_give(bool&,ARRAY<STRING>&); 
    virtual bool need_material_file()const { return TRUE; }
    virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&); 
    void real_compute(bool, const ARRAY<VECTOR>&,int&, ARRAY<VECTOR>&,ARRAY<int>& critical);
    VECTOR compute_Nf(bool update_coef, double T, double sa, double smax, double sh);
    void compute_coefs_at_temperature(double T);
    void setup_smart_coefs(SORTED_LIST<double>& T);
    
    void set_reverse(int rev) { reverse=rev; }
    void set_infinity(double inf) { infinity=inf; }
};

Z_END_NAMESPACE;

#endif
