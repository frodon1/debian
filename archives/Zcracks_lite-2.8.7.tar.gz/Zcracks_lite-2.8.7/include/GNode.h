#ifndef __GNode__
#define __GNode__

#include <List.h>
#include <Vector.h>
#include <Defines.h>

#include <Local_frame.h>
#include <Z_object.h>

Z_START_NAMESPACE;

class EXTERNAL_PARAMETER_VECTOR;
class ELEMENT; class LOCAL_FRAME; 

ZCLASS2 GNODE : public Z_OBJECT 
{ // geometrical node
   int _rank; // position in the list of the master mesh
  public :
   const int id;
   LIST<ELEMENT*> element;        // list of elements the node belongs to
   VECTOR coord0;                 // initial mesh coordinates  : should not be changed !!
   VECTOR coord;                  // some other coordinates to be set by the user
   AUTO_PTR<LOCAL_FRAME> local; // pointer on a class available for the
                           // definition of a local referential
   GNODE(const GNODE&);    // default : error
   GNODE();
   GNODE(int id,const VECTOR&);
   virtual ~GNODE();
   VECTOR get_coord()const;
   virtual double get_coord(int)const;
   void connect_to_element(const LIST<ELEMENT*>& connec);
   void set_elem(LIST<ELEMENT*>& list);
   void perturbate(const VECTOR&);
   void set_coord(const VECTOR& v) { coord=v; }
   void set_rank(int rk) { _rank=rk; }
   int  rank()const { return _rank; }
   int get_dimension() const { return !coord0; }
  
   friend void make_VECTOR(const GNODE&,const GNODE&,VECTOR&);
   friend double distance(const GNODE&,const GNODE&);

   GNODE& operator=(const GNODE&);
   RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
