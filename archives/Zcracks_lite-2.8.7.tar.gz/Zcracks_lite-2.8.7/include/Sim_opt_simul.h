#ifndef __Sim_opt_simul__
#define __Sim_opt_simul__

#include <Matrix.h>
#include <Sim_opt.h>

Z_START_NAMESPACE;

class DEFINE_LOAD_DIALOG;

class SIMUL_GUI : public GRAPHICS_COMMAND {

  private :

    void create_add_simul_dialog();
    void create_define_output_dialog();
    void create_define_plot_dialog(const BUFF_LIST<STRING>&);
    void create_define_from_exp_dialog(const BUFF_LIST<STRING>&);
    void create_define_from_exp_dialog_finite_strains(const BUFF_LIST<STRING>&);

    void create_edit_inp_dialog();
    void create_set_material_dialog();
    void create_define_load_dialog(bool def=TRUE);
    void create_edit_ref_dialog(STRING dialog, STRING name, STRING from);
    void update_lists();
    void update_plot_list();
    void update_load_list();
    bool update_sim();
    void get_output_names(const STRING& fmat,BUFF_LIST<STRING>& names);
    void add_load_block_from_exp();
    bool check_new_load(LOAD_BLOCK*);
    void reset_cur_load_list();
    int get_load_pos();
    bool is_finite_strains_behavior();

  public :

    int chosen_material;

    SIM_OPT_GUI* its_sim_opt;

    GRAPHICS_DATA_DIALOG* its_dialog;
    GRAPHICS_DATA_DIALOG* add_simul_dialog;
    GRAPHICS_DATA_DIALOG* define_load_dialog;
    GRAPHICS_DATA_DIALOG* define_output_dialog;
    GRAPHICS_DATA_DIALOG* define_plot_dialog;
    DEFINE_LOAD_DIALOG* matrix_dialog;
    GRAPHICS_DATA_DIALOG* define_from_exp_dialog;
    GRAPHICS_DATA_DIALOG* edit_inp_dialog;
    GRAPHICS_DATA_DIALOG* set_material_dialog;
    GRAPHICS_DATA_DIALOG* edit_ref_dialog;

    ZSIM_SIMULATION_ITEM* cur_sim;
    PLOT_ITEM* cur_plot;
    LOAD_BLOCK* cur_load;
    LOAD_BLOCK* load_temp;
    BUFF_LIST<LOAD_BLOCK*> cur_load_list;

    MATRIX local_load_vals;
    BUFF_LIST<STRING> local_output_vars;
    BUFF_LIST<STRING> selected_simulations;
    TREE_FIELD_ITEM* root_simulations;
    TREE_FIELD_ITEM* root_experiments;
    LIST<STRING> cur_plot_references;

    SIMUL_GUI();
    virtual ~SIMUL_GUI();
    virtual void initialize(GRAPHICS_COMMAND* boss,GRAPHICS_APPLICATION* app);

    virtual bool do_command(STRING);
    virtual bool do_click(int,GRAPHICS_POINT& clk,GRAPHICS_OBJECT*);
    virtual void read(ASCII_FILE&);
    virtual bool write(Zofstream& out);

};

class SIM_OPT_SIMUL : public GRAPHICS_COMMAND {

  protected :

    SIMUL_GUI* its_simul_gui;

  public :

    SIM_OPT_GUI* its_sim_opt;

    SIM_OPT_SIMUL();
    virtual ~SIM_OPT_SIMUL();
    virtual void initialize(GRAPHICS_COMMAND* boss,GRAPHICS_APPLICATION* app);

    virtual bool do_command(STRING);
    virtual bool do_click(int,GRAPHICS_POINT& clk,GRAPHICS_OBJECT*);

};
Z_END_NAMESPACE;

#endif
