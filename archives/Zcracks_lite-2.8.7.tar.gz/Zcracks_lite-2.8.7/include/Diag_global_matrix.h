#ifndef __DIAGONAL_GLOBAL_MATRIX__
#define __DIAGONAL_GLOBAL_MATRIX__

#include <Global_matrix.h>
#include <Vector.h>
#include <Mesh.h>

Z_START_NAMESPACE;

//
// 2005-12-19 carrere: a diagonal global matrix, needed for stability analysis
//

class DIAGONAL_GLOBAL_MATRIX : public GLOBAL_MATRIX
{
  public :
    VECTOR diag;

    DIAGONAL_GLOBAL_MATRIX(MESH &mesh) : GLOBAL_MATRIX() { set_to_unity(mesh); }
    virtual ~DIAGONAL_GLOBAL_MATRIX() { }

    void set_to_unity(MESH &mesh) {
      diag.resize(mesh.nb_dof());
      diag=1.;
    }

    VECTOR  operator*(const VECTOR& v)const;
    void normalize_vector(VECTOR& v)const;

    void store(const D_ELEMENT& ele,const SMATRIX& mat);
    virtual bool solve(VECTOR& displ,VECTOR& force,int if_compute_inverse,int if_compute_kernel=0);
    virtual bool solve(ARRAY<VECTOR>& displ,ARRAY<VECTOR>& force,int if_compute_inverse);
    virtual void addmult(const GLOBAL_MATRIX& mat1,double d);
    virtual void assign(const GLOBAL_MATRIX& mat1); 
    virtual void adddiag(double f);
    virtual void mult(double f);
    SMATRIX& operator[](int i);
    const SMATRIX& operator[](int i)const;
    void arvp(const ARRAY<VECTOR>& vi,ARRAY<VECTOR>& vo)const; 
    virtual void global_matrix_structure_change(UPDATE_FLAGS ident_flags);
    virtual bool link_to(GLOBAL_MATRIX *K);
    virtual void compute_flexibility_matrix(ARRAY<DOF*>& dof, MATRIX&, bool verbose_contact=FALSE);
    virtual bool is_determinant_negative()const;
    virtual GLOBAL_MATRIX_KERNEL* initialize_kernel(const DD_SUB_DOMAIN&){
      ERROR("SPARSE_MATRIX cannot be used with parallel computation");
      return(NULL);}
    virtual void enable_keep_rigid();
   

};
Z_END_NAMESPACE;

#endif
