#ifndef __SIMULATOR_DATA__
#define __SIMULATOR_DATA__

#include <Data_sourcing.h>

Z_START_NAMESPACE;

class SIM_DS_MESH;
class SIM_DS_UTI;

ZCLASS2 SIMULATOR_DATA : public POST_DATA_SOURCE {
  public :
    enum MODE { BINARY=1 , ASCII=2 };
    MODE mode;

  protected :
    STRING       its_name;
    SIM_DS_MESH* its_mesh;
    SIM_DS_UTI*  its_ut; 
    SIM_DS_UTI*  its_utp;

  public :
    STRING ascii_file_name;
    int dimension;

    SIMULATOR_DATA();
    virtual ~SIMULATOR_DATA();

    virtual void activate(const STRING&,ASCII_FILE&,AUTO_PTR<POST_MESH>&,AUTO_PTR<UT_INFO>&,AUTO_PTR<UT_INFO>&);
    virtual void open_pfiles();
    virtual void close_pfiles();
    virtual void make_ut_infop(LIST<STRING>&,LIST<STRING>&,LIST<STRING>&,ARRAY<int>&);
};
Z_END_NAMESPACE;

#endif
