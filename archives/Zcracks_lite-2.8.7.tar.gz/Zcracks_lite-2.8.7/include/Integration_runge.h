#ifndef __RUNGE__
#define __RUNGE__

#include <Integration_method.h>
#include <List.h>

Z_START_NAMESPACE;

#define RK_SCALE_ALL 1
#define RK_SCALE_ON_CHANGE 2
#define RK_SCALE_INITIAL 4
#define RK_SCALES_MULTIPLIED_BY_YMAX_R 8
#define RK_CONSTANT_SCALE 16
#define RK_ALLOW_DIV 32


ZCLASS RUNGE_INTEGRATOR {
   public :
     CARRAY<STRING>  rk_var_names;
     CARRAY<int>     rk_st_pos;
     CARRAY<int>     rk_size;
     CARRAY<double>  rk_scale;

     int     calc_tg_mat;

     virtual ~RUNGE_INTEGRATOR();
     virtual void derivative(double x,const VECTOR& v,VECTOR& der)=0;
     void resolve_flux_grad_consistency(const ARRAY<int>& sig_pos, const SMATRIX& E, const TENSOR2 norm, 
       double H, TENSOR2& dgrad, double& pdot, const TENSOR2& eel, const double D, const double dD_d);
};


ZCLASS RUNGE : public LOCAL_INTEGRATION {
   protected:  
            VECTOR dy_tmp;

   protected:
            int flags;

            LIST<STRING>  user_var_names;
            LIST<double>  user_scale;

            int    read_ymax_r;
            double ptb;
            VECTOR ymax_vec;

            void form_norm(VECTOR& ys, const VECTOR& y, const VECTOR& dy, double h);
            void rel_magnitude(const VECTOR& v2, VECTOR& v);

   public :
            int maxiter;
            double dtmin;

            double eps_r;
            double ymax_r;

            RUNGE();
            virtual ~RUNGE();
            RUNGE(const RUNGE& cpy_in);

            void set_flags(int f) { flags |= f; }

            virtual void initialize(double seps, double symax);
            virtual void initialize(ASCII_FILE&);

            virtual INTEGRATION_RESULT* runge_kutta(double t1, double dt, VECTOR& y);
            virtual INTEGRATION_RESULT* runge_kutta(double t1, double dt, VECTOR& y, VECTOR& dy);

            virtual void setup_configured_variables(int sz);
};

ZCLASS RUNGE2 : public RUNGE {
   protected:
            int    sz;
            VECTOR dy1,dy2,err,stat_dy2;
            VECTOR y_bar;
            VECTOR ykeep;
            VECTOR yinitial,dy;
            VECTOR *real_y;

            void rk21(int pok, double h, double& time,
                      VECTOR& y, VECTOR& dydx);

   public :
            RUNGE2() { }
            RUNGE2(const RUNGE2& cpy_in);
            virtual ~RUNGE2() { }
            virtual LOCAL_INTEGRATION* copy_self()const;

            virtual INTEGRATION_RESULT* runge_kutta(double t1, double dt, VECTOR& y);
            virtual INTEGRATION_RESULT* runge_kutta(double t1, double dt,
                                                    VECTOR& y, VECTOR& dydx);
};

ZCLASS RUNGE4 : public RUNGE {
  protected :
    double maxdiv;
    int steps;
    int nok, nbad, kount;
    VECTOR yscal;
    VECTOR dy1,dy2,err;
    VECTOR ak2,ak3,ak4,ak5,ak6;
    VECTOR yerr;
    VECTOR p,q,tmp;
    double h23,h3,h8;
    void   rkqs(VECTOR& y, VECTOR& dydx, double& x, double& hdid, double& hnext, double htry);
    void   rkck(VECTOR& y, VECTOR& dydx, double& x, VECTOR& err, double h);
  public :
    RUNGE4();
    RUNGE4(const RUNGE4& cpy_in);
    virtual ~RUNGE4() { }
    virtual LOCAL_INTEGRATION* copy_self()const;

    virtual void initialize(double seps, double symax);
    virtual void initialize(ASCII_FILE&);

    virtual INTEGRATION_RESULT* runge_kutta(double t1, double dt, VECTOR& y);
    virtual INTEGRATION_RESULT* runge_kutta(double t1, double dt,
                                            VECTOR& y, VECTOR& dydx);
};

Z_END_NAMESPACE;

#endif
