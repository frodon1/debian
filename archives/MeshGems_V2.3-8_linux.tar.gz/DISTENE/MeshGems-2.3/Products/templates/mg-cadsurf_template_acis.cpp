/*
 * Integration template into ACIS CAD engine.
 * This file describes how to import an ACIS ENTITY_LIST into the 
 * meshgems cad_t structure. The function generate_mesh defined in 
 * mg-cadsurf_template_common.cpp is then called to build a 
 * surface mesh using MG-CADSurf.
 */

#define CREATE_DCAD 0
#define IMPORT_WIRE 0
#define CREATE_PERIODICITY 0

#include <iostream>
#include <list>
#include <vector>
#include <map>
#include <assert.h>

using namespace std;
#include <string.h>
#include <iostream>
#include <sstream>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>

#include "kernapi.hxx"
#include "spl_api.hxx"
#include "cstrapi.hxx"
#include "intrapi.hxx"
#include "boolapi.hxx"
#include "operapi.hxx"
#include "eulerapi.hxx"
#include "ga_api.hxx"
#include "fileinfo.hxx"
#include "lists.hxx"
#include "intrapi.hxx"
#include "alltop.hxx"

#include "curve.hxx"
#include "curdef.hxx"
#include "pcurve.hxx"
#include "pcudef.hxx"
#include "surface.hxx"
#include "surdef.hxx"
#include "vector.hxx"
#include "position.hxx"
#include "vector.hxx"
#include "param.hxx"
#include "coedge.hxx"
#include "cone.hxx"
#include "intrapi.hxx"
#include "box_opts.hxx"
#include "point.hxx"
#include "wire.hxx"
#include "spa_unlock_result.hxx"

extern "C" {
#include <meshgems/meshgems.h>
} 

status_t generate_mesh(context_t * ctx, cad_t * c, dcad_t * dc,
                         mesh_t * msh);

/* Curve definition function for edges without derivatives. (defined
 * in UV by a reverse projetion 
 */
static status_t curv0_function_acis(real t, real * uv, real * dt,
                                    real * dtt, void *user_data)
{
  COEDGE *coedge = (COEDGE *) user_data;
  SPAposition pos;
  SPApar_pos param, guess;

  CURVE *cv = coedge->edge()->geometry();
  LOOP *lp = (LOOP *) coedge->owner();
  SURFACE *sf = lp->face()->geometry();
  PCURVE *pcrv = coedge->geometry();

  if (uv) {
    if (cv) {
      cv->equation().eval(t, pos);
      if (pcrv) {
        /* The pcurve result is not always reliable.
         * Use it as a guess to start the reverse projection.
         */
        pcrv->equation().
            eval((coedge->sense() == coedge->edge()->sense())? t : -t,
                 guess);
        if (guess << sf->equation().param_range()) {
          /* The guess is inside the parametric domain. Use it */
          param = sf->equation().param(pos, guess);     // reverse projection
        } else {
          param = sf->equation().param(pos);    // reverse projection
        }
      } else {
        param = sf->equation().param(pos);      // reverse projection
      }
    } else {
      return STATUS_ERROR;      // This should not happen
    }
    uv[0] = param.u;
    uv[1] = param.v;
  }

  return STATUS_OK;
}

static status_t curv3d_function_acis(real t, real * xyz, void *user_data)
{
  COEDGE *coedge = (COEDGE *) user_data;
  SPAposition pos;
  SPApar_pos param;

  const curve *cv = &(coedge->edge()->geometry()->equation());

  if (xyz) {
    cv->eval(t, pos);
    xyz[0] = pos.x();
    xyz[1] = pos.y();
    xyz[2] = pos.z();
  }

  return STATUS_OK;
}

static status_t curv3d2_function_acis(real t, real * xyz, real * dt,
                                      real * dtt, void *user_data)
{
  COEDGE *coedge = (COEDGE *) user_data;
  SPAposition pos;
  SPApar_pos param;
  SPAvector d, d2;

  const curve *cv = &(coedge->edge()->geometry()->equation());

  if (dtt)
    cv->eval(t, pos, d, d2);
  else if (dt)
    cv->eval(t, pos, d);
  else if (xyz)
    cv->eval(t, pos);

  if (xyz) {
    xyz[0] = pos.x();
    xyz[1] = pos.y();
    xyz[2] = pos.z();
  }
  if (dt) {
    dt[0] = d.x();
    dt[1] = d.y();
    dt[2] = d.z();
  }
  if (dtt) {
    dtt[0] = d2.x();
    dtt[1] = d2.y();
    dtt[2] = d2.z();

  }

  return STATUS_OK;
}

/* Surface definition function.
 * See cad_surf_t in file meshgems/cad.h for more information.
 * NOTE : if when your CAD systems evaluates second order derivatives it also
 * computes first order derivatives and function evaluation, you can optimize 
 * this example by making only one CAD call and filling the necessary xyz, du, dv, etc.. 
 * arrays.
 */
static status_t surf_function_acis(real * uv, real * xyz, real * du,
                                   real * dv, real * duu, real * duv,
                                   real * dvv, void *user_data)
{
  /* uv[2] is given. It contains the u,v coordinates of the point
   * MG-CADSurf is querying on the surface */

  /* user_data identifies the face MG-CADSurf is querying (see
   * cad_face_new later in this example)*/

  surface *sf = (surface *) user_data;

  SPApar_pos param;
  SPAposition pos;
  SPAvector d[2];
  SPAvector d2[3];
  SPAvector *pd = 0, *pd2 = 0;

  param.u = uv[0];
  param.v = uv[1];

  if (du || dv)
    pd = d;

  if (duu || duv || dvv)
    pd2 = d2;

  sf->eval(param, pos, pd, pd2);

  if (xyz) {
    /* query for the function evaluation */
    xyz[0] = pos.x();
    xyz[1] = pos.y();
    xyz[2] = pos.z();
  }

  if (du) {
    /* query for the first order derivatives */
    du[0] = d[0].x();
    du[1] = d[0].y();
    du[2] = d[0].z();
  }

  if (dv) {
    /* query for the first order derivatives */
    dv[0] = d[1].x();
    dv[1] = d[1].y();
    dv[2] = d[1].z();
  }

  if (duu) {
    /* query for the second order derivatives */
    duu[0] = d2[0].x();
    duu[1] = d2[0].y();
    duu[2] = d2[0].z();
  }

  if (duv) {
    /* query for the second order derivatives */
    duv[0] = d2[1].x();
    duv[1] = d2[1].y();
    duv[2] = d2[1].z();
  }

  if (dvv) {
    /* query for the second order derivatives */
    dvv[0] = d2[2].x();
    dvv[1] = d2[2].y();
    dvv[2] = d2[2].z();
  }

  return STATUS_OK;
}

/*
 * This function specifies a transformation between two sets of face you
 * want to make periodic.  xyz contains the coordinates of a point.
 * The coordinates of the image are stored in xyz_image.  See
 * meshgems_cad_periodicity_transformation_t in meshgems/cad.h for
 * information about the function parameters
 */
static status_t periodicity_transformation(real * xyz, real * xyz_image,
                                           void *user_data)
{
  real *r = (real *) user_data;
  integer i;

  for (i = 0; i < 3; i++)
    xyz_image[i] = xyz[i] + (*r);

  return STATUS_OK;
}

/* Helper struct and function to convert ACIS data to MeshgGems format */

typedef map < ENTITY *, integer > ENTITYmap;
struct tdata_acis_t_ {
  ENTITYmap pmap;               // map of point 
  ENTITYmap emap;               // map of edges
  ENTITYmap fmap;               // map of faces

  integer last_pid;             // last point id
  integer last_eid;             // last edge id
  integer last_fid;             // last face id
  integer last_bid;             // last body id
  integer last_uvid;            // last uv id
  integer import_2d_topo;
};
typedef tdata_acis_t_ tdata_acis_t;

void tdata_acis_delete_fun(void *c)
{
  tdata_acis_t *td = (tdata_acis_t *) c;

  delete td;
}

status_t import_acis_coedge(ENTITY * ent, tdata_acis_t * td,
                            cad_face_t * f, dcad_t * dc)
{
  status_t ret;
  COEDGE *coedge = (COEDGE *) ent;
  cad_t *c = 0;
  cad_edge_t *e = 0;
  cad_vertex_t *v = 0;
  real tmin, tmax, xyz[3];
  integer eid, pid1, pid2, first_uvid, last_coedge;

  assert(td);
  assert(f);
  ret = STATUS_OK;

  ret = cad_face_get_cad(f, &c);
  if (ret != STATUS_OK)
    return ret;

  first_uvid = td->last_uvid;

  while (coedge) {
    integer s = 1;              // curve orientation 

    last_coedge = 0;
    coedge = coedge->next();
    if (coedge == coedge->loop()->start())
      last_coedge = 1;
    coedge = coedge->previous();

    ENTITYmap::iterator it = td->emap.find(coedge->edge());
    if (it == td->emap.end()) {
      td->last_eid++;
      eid = td->last_eid;
      td->emap.insert(make_pair(coedge->edge(), eid));
    } else {
      eid = it->second;
    }

    it = td->pmap.find(coedge->edge()->start());
    if (it == td->pmap.end()) {
      td->last_pid++;
      pid1 = td->last_pid;
      td->pmap.insert(make_pair(coedge->edge()->start(), pid1));
    } else {
      pid1 = it->second;
    }

    it = td->pmap.find(coedge->edge()->end());
    if (it == td->pmap.end()) {
      td->last_pid++;
      pid2 = td->last_pid;
      td->pmap.insert(make_pair(coedge->edge()->end(), pid2));
    } else {
      pid2 = it->second;
    }

    const SPAposition coor1 =
        coedge->edge()->start()->geometry()->coords();
    const SPAposition coor2 = coedge->edge()->end()->geometry()->coords();

    xyz[0] = coor1.x();
    xyz[1] = coor1.y();
    xyz[2] = coor1.z();
    v = cad_vertex_new(c, pid1, xyz);
    if (!v)
      return STATUS_NOMEM;

    xyz[0] = coor2.x();
    xyz[1] = coor2.y();
    xyz[2] = coor2.z();
    v = cad_vertex_new(c, pid2, xyz);
    if (!v)
      return STATUS_NOMEM;

    EDGE *edge = coedge->edge();
    LOOP *lp = (LOOP *) coedge->owner();
    SURFACE *surf = ((LOOP *) coedge->owner())->face()->geometry();

    if (edge->geometry()) {
      if (edge->sense()) {
        s *= -1;
        tmin = -(double (edge->end_param()));
        tmax = -(double (edge->start_param()));
      } else {
        tmin = (double (edge->start_param()));
        tmax = (double (edge->end_param()));
      }

      if (coedge->sense()) {
        s *= -1;
      }
      /* create a new edge on face f with
       * edge_id = eid
       * tmin,tmax parametric range
       * the "no explicit derivatives" curve function
       */
      if (tmin < tmax) {
        integer uvid1, uvid2;

        e = cad_edge_new0(f, eid, tmin, tmax, curv0_function_acis, coedge);
        if (!e)
          return STATUS_NOMEM;

        if (edge->sense()) {
          ret = cad_edge_set_extremities(e, pid2, pid1);
          if (ret != STATUS_OK)
            return ret;

          ret = cad_edge_set_extremities_tag(e, pid2, pid1);
          if (ret != STATUS_OK)
            return ret;
        } else {
          ret = cad_edge_set_extremities(e, pid1, pid2);
          if (ret != STATUS_OK)
            return ret;

          ret = cad_edge_set_extremities_tag(e, pid1, pid2);
          if (ret != STATUS_OK)
            return ret;
        }

        if (last_coedge) {
          uvid1 = td->last_uvid;
          uvid2 = first_uvid;
          ++td->last_uvid;
        } else {
          uvid1 = td->last_uvid;
          uvid2 = ++td->last_uvid;
        }

        if (td->import_2d_topo) {
          if (s == 1) {
            ret = cad_edge_set_uv_extremities(e, uvid1, uvid2);
            if (ret != STATUS_OK)
              return ret;
          } else {
            ret = cad_edge_set_uv_extremities(e, uvid2, uvid1);
            if (ret != STATUS_OK)
              return ret;
          }
        }
      } else {
        assert(0);
      }

      ret = cad_edge_set_curve3d(e, curv3d_function_acis, coedge);
      if (ret != STATUS_OK)
        return ret;

      /* Set edge_tag (color) to the same value as its id (= eid) */
      ret = cad_edge_set_tag(e, eid);
      if (ret != STATUS_OK)
        return ret;

      /* Set edge orientation relatively in UV domain */
      if (surf->equation().left_handed_uv()) {
        s *= -1;
      }
      if (lp->face()->sense()) {
        s *= -1;
      }

      if (s == -1) {
        ret = cad_edge_set_orientation(e, CAD_ORIENTATION_REVERSED);
        if (ret != STATUS_OK)
          return ret;
      } else if (s == 1) {
        ret = cad_edge_set_orientation(e, CAD_ORIENTATION_FORWARD);
        if (ret != STATUS_OK)
          return ret;
      }

      if (CREATE_DCAD) {
        dcad_edge_discretization_t *de = 0;
        real tt, uv[2], xyz[3];
        integer n_required_vertices;
        status_t ret;
        integer i;

        assert(dc != 0);        /* This object must have been created earlier */

        /* Get the edge discretization associated to the current edge */
        ret = dcad_get_edge_discretization(dc, e, &de);
        if (ret != STATUS_OK)
          return ret;

        /* Set its vertex count (extremities included) */
        //n_required_vertices = ...;
        ret =
            dcad_edge_discretization_set_vertex_count(de,
                                                      n_required_vertices);
        if (ret != STATUS_OK)
          return ret;

        /* Set coordinates (t,uv,xyz) of each vertex (extremities included) */
        for (i = 1; i <= n_required_vertices; i++) {
          //tt = ...;
          //uv[0] = ...;
          //uv[1] = ...;
          //xyz[0] = ...;
          //xyz[1] = ...;
          //xyz[2] = ...;
          ret =
              dcad_edge_discretization_set_vertex_coordinates(de, i, tt,
                                                              uv, xyz);
          if (ret != STATUS_OK)
            return ret;
        }
        /* Mark this discretization as required */
        ret =
            dcad_edge_discretization_set_property(de,
                                                  DCAD_PROPERTY_REQUIRED);
        if (ret != STATUS_OK)
          return ret;
      }

    } else {
      /* An edge without geometry is a point in ACIS kernel */
      cad_point_t *p;
      cad_vertex_t *v;
      real uv[2], xyz[3];
      integer pid;

      it = td->pmap.find(coedge->edge()->start());
      if (it == td->pmap.end()) {
        td->last_pid++;
        pid = td->last_pid;
        td->pmap.insert(make_pair(coedge->edge()->start(), pid));
      } else {
        pid = it->second;
      }

      LOOP *lp = (LOOP *) coedge->owner();
      const surface *sf = &(lp->face()->geometry()->equation());
      assert(sf);
      const SPAposition coor =
          coedge->edge()->start()->geometry()->coords();

      SPApar_pos param = sf->param(coor);       // reverse projection
      uv[0] = param.u;
      uv[1] = param.v;
      p = cad_point_new(f, pid, uv);
      if (!p)
        return STATUS_NOMEM;

      ret = cad_point_set_tag(p, pid);
      if (ret != STATUS_OK)
        return ret;

      xyz[0] = coor.x();
      xyz[1] = coor.y();
      xyz[2] = coor.z();
      v = cad_vertex_new(c, pid, xyz);
      if (!v)
        return STATUS_NOMEM;

    }
    coedge = coedge->next();
    if (coedge == coedge->loop()->start())
      break;
  }
  return ret;
}

integer acis_loop_import_2d_topology(ENTITY * ent, tdata_acis_t * td)
{
  COEDGE *coedge = (COEDGE *) ent;
  integer pid1, max;
  ENTITYmap map;

  assert(td);

  max = 0;
  while (coedge) {

    ENTITYmap::iterator it = map.find(coedge->edge()->start());
    if (it == map.end()) {
      map.insert(make_pair(coedge->edge()->start(), 1));
      if (max < 1)
        max = 1;
    } else {
      pid1 = it->second;
      pid1++;
      map.erase(it);
      map.insert(make_pair(coedge->edge()->start(), pid1));
      if (pid1 > max)
        max = pid1;
    }

    it = map.find(coedge->edge()->end());
    if (it == map.end()) {
      map.insert(make_pair(coedge->edge()->end(), 1));
      if (max < 1)
        max = 1;
    } else {
      pid1 = it->second;
      pid1++;
      map.erase(it);
      map.insert(make_pair(coedge->edge()->end(), pid1));
      if (pid1 > max)
        max = pid1;
    }

    coedge = coedge->next();
    if (coedge == coedge->loop()->start())
      break;
  }

  if (max > 2)
    return 0;

  return 1;
}

status_t import_acis_loop(ENTITY * ent, tdata_acis_t * td, cad_face_t * f,
                          dcad_t * dc)
{
  status_t ret;
  LOOP *loop = (LOOP *) ent;

  assert(td);
  assert(f);
  ret = STATUS_OK;
  td->last_uvid = 1;

  while (loop) {

    td->import_2d_topo = acis_loop_import_2d_topology(loop->start(), td);

    ret = import_acis_coedge(loop->start(), td, f, dc);
    if (ret != STATUS_OK)
      return ret;

    loop = loop->next();
  }
  return ret;
}

status_t import_acis_face(ENTITY * ent, tdata_acis_t * td, cad_t * c,
                          dcad_t * dc)
{
  status_t ret;
  cad_face_t *f = 0;
  FACE *face = (FACE *) ent;

  assert(td);
  assert(c);
  ret = STATUS_OK;
  while (face) {
    surface *sf = (surface *) & (face->geometry()->equation());
    if (td->fmap.find(face) == td->fmap.end()) {
      td->last_fid++;

      f = cad_face_new(c, td->last_fid, surf_function_acis, sf);
      if (!f)
        return STATUS_NOMEM;

      /* The following call sets the face tag (color) to the same value as the face_id */
      ret = cad_face_set_tag(f, td->last_fid);
      if (ret != STATUS_OK)
        return ret;

      /* Find and set face orientation for a correct normal triangle
       * orientation in the generated mesh.
       */

      integer s = 1;

      if (sf->left_handed_uv())
        s *= -1;
      if (face->sense())
        s *= -1;

      if (s == -1) {
        ret = cad_face_set_orientation(f, CAD_ORIENTATION_REVERSED);
        if (ret != STATUS_OK)
          return ret;
      } else {
        ret = cad_face_set_orientation(f, CAD_ORIENTATION_FORWARD);
        if (ret != STATUS_OK)
          return ret;
      }

      /* set surface parametric range and periodicity properties of the
       * surface on which the face lies. For example if the face is a
       * portion of a cylinder, these 2 properties will be given for the
       * whole cylinder surface.
       *
       * The surface parametric range is the principal intervalle U and
       * V belong to in the UV space domain.
       *
       * The periodicity is given in both U and V direction. The period
       * pu in U is defined as the smallest real such that
       * surf(u,v) = surf(u+pu,v)
       * Please also note that if a face is periodic in a
       * direction, its surf function must be defined for any real value
       * in this direction.
       *
       *
       * NOTE : these properties are only usefull for the CAD preprocessor 
       * of MG-CADSurf if you want it to treat and close the CAD patches
       * which are not closed in the UV domain space (mainly periodic faces
       * or faces build on a periodic surface, like a cylinder piece). If 
       * all your CAD faces are already closed in UV domain, you do not 
       * need to set these properties.
       */

      SPAinterval param_range = sf->param_range_u();
      real ru[2], rv[2];
      ru[0] = -REAL_INFINITY;
      ru[1] = REAL_INFINITY;

      if (param_range.bounded_below()) {
        ru[0] = param_range.start_pt();
      }
      if (param_range.bounded_above()) {
        ru[1] = param_range.end_pt();
      }
      param_range = sf->param_range_v();
      rv[0] = -REAL_INFINITY;
      rv[1] = REAL_INFINITY;

      if (param_range.bounded_below()) {
        rv[0] = param_range.start_pt();
      }
      if (param_range.bounded_above()) {
        rv[1] = param_range.end_pt();
      }
      ret = cad_face_set_surface_parametric_range(f, ru, rv);
      if (ret != STATUS_OK)
        return ret;

      integer periodic_u, periodic_v;
      periodic_u = sf->periodic_u()? 1 : 0;
      periodic_v = sf->periodic_v()? 1 : 0;

      ret =
          cad_face_set_surface_periodicity(f, periodic_u, periodic_v,
                                           sf->param_period_u(),
                                           sf->param_period_v());
      if (ret != STATUS_OK)
        return ret;

      td->fmap.insert(make_pair(face, td->last_fid));
      ret = import_acis_loop(face->loop(), td, f, dc);
      if (ret != STATUS_OK)
        return ret;
    }
    face = face->next();
  }
  return ret;
}


status_t import_acis_wire(ENTITY * ent, tdata_acis_t * td, cad_t * c,
                          dcad_t * dc)
{
  status_t ret;
  WIRE *wire = (WIRE *) ent;
  ENTITY_LIST coedge_list;

  assert(td);
  assert(c);
  ret = STATUS_OK;
  if (!IMPORT_WIRE)
    return ret;
  while (wire) {
    COEDGE *coedge;
    cad_vertex_t *v;

    coedge_list.clear();
    api_get_coedges(wire, coedge_list);
    coedge = (COEDGE *) coedge_list.first();
    while (coedge) {
      EDGE *edge = coedge->edge();
      integer s = 1;
      integer eid, pid1, pid2;
      real tmin, tmax, xyz[3];

      ENTITYmap::iterator it = td->emap.find(edge);
      if (it == td->emap.end()) {
        td->last_eid++;
        eid = td->last_eid;
        td->emap.insert(make_pair(edge, eid));
      } else {
        eid = it->second;
      }
      it = td->pmap.find(edge->start());
      if (it == td->pmap.end()) {
        td->last_pid++;
        pid1 = td->last_pid;
        td->pmap.insert(make_pair(edge->start(), pid1));
      } else {
        pid1 = it->second;
      }
      it = td->pmap.find(edge->end());
      if (it == td->pmap.end()) {
        td->last_pid++;
        pid2 = td->last_pid;
        td->pmap.insert(make_pair(edge->end(), pid2));
      } else {
        pid2 = it->second;
      }

      const SPAposition coor1 =
          coedge->edge()->start()->geometry()->coords();
      const SPAposition coor2 =
          coedge->edge()->end()->geometry()->coords();

      xyz[0] = coor1.x();
      xyz[1] = coor1.y();
      xyz[2] = coor1.z();
      v = cad_vertex_new(c, pid1, xyz);
      if (!v)
        return STATUS_NOMEM;

      xyz[0] = coor2.x();
      xyz[1] = coor2.y();
      xyz[2] = coor2.z();
      v = cad_vertex_new(c, pid2, xyz);
      if (!v)
        return STATUS_NOMEM;

      if (edge->geometry()) {
        if (edge->sense()) {
          s *= -1;
          tmin = -(double (edge->end_param()));
          tmax = -(double (edge->start_param()));
        } else {
          tmin = (double (edge->start_param()));
          tmax = (double (edge->end_param()));
        }
        cad_wire_t *w =
            cad_wire_new(c, eid, tmin, tmax, curv3d2_function_acis,
                         coedge);
        if (!w)
          return STATUS_NOMEM;

        assert(w);
        ret = cad_wire_set_tag(w, eid);
        if (ret != STATUS_OK)
          return ret;
        ret = cad_wire_set_uid(w, eid);
        if (ret != STATUS_OK)
          return ret;
        if (edge->sense()) {
          ret = cad_wire_set_extremities(w, pid2, pid1);
          if (ret != STATUS_OK)
            return ret;
          ret = cad_wire_set_extremities_tag(w, pid2, pid1);
          if (ret != STATUS_OK)
            return ret;
        } else {
          ret = cad_wire_set_extremities(w, pid1, pid2);
          if (ret != STATUS_OK)
            return ret;
          ret = cad_wire_set_extremities_tag(w, pid1, pid2);
          if (ret != STATUS_OK)
            return ret;
        }
      }

      coedge = (COEDGE *) coedge_list.next();
    }
    wire = wire->next();
  }
  return ret;
}

status_t import_acis_shell(ENTITY * ent, tdata_acis_t * td, cad_t * c,
                           dcad_t * dc)
{
  status_t ret;
  SHELL *shell = (SHELL *) ent;

  assert(ent);
  assert(td);
  assert(c);
  ret = STATUS_OK;
  while (shell) {
    ret = import_acis_face(shell->face(), td, c, dc);
    if (ret != STATUS_OK)
      return ret;

    ret = import_acis_wire(shell->wire(), td, c, dc);
    if (ret != STATUS_OK)
      return ret;

    shell = shell->next();
  }
  return ret;
}

status_t import_acis_lump(ENTITY * ent, tdata_acis_t * td, cad_t * c,
                          dcad_t * dc)
{
  status_t ret;
  LUMP *lump = (LUMP *) ent;

  assert(ent);
  assert(td);
  assert(c);
  ret = STATUS_OK;
  while (lump) {
    ret = import_acis_shell(lump->shell(), td, c, dc);
    if (ret != STATUS_OK)
      return ret;

    lump = lump->next();
  }
  return ret;
}

status_t import_acis_body(ENTITY * ent, tdata_acis_t * td, cad_t * c,
                          dcad_t * dc)
{
  status_t ret;
  BODY *body = (BODY *) ent;

  assert(ent);
  assert(td);
  assert(c);
  ret = STATUS_OK;

  ret = import_acis_lump(body->lump(), td, c, dc);
  if (ret != STATUS_OK)
    return ret;

  ret = import_acis_wire(body->wire(), td, c, dc);
  if (ret != STATUS_OK)
    return ret;

  return ret;
}

status_t import_acis_entity(ENTITY * ent, tdata_acis_t * td, cad_t * c,
                            dcad_t * dc)
{
  status_t ret;

  ret = STATUS_OK;
  if (!ent)
    return ret;

  assert(td);
  assert(c);

  if (is_BODY(ent)) {
    ret = import_acis_body(ent, td, c, dc);
  } else if (is_LUMP(ent)) {
    ret = import_acis_lump(ent, td, c, dc);
  } else if (is_SHELL(ent)) {
    ret = import_acis_shell(ent, td, c, dc);
  } else if (is_WIRE(ent)) {
    ret = import_acis_wire(ent, td, c, dc);
  } else if (is_FACE(ent)) {
    ret = import_acis_face(ent, td, c, dc);
  } else {
    printf("untreated entity \n");
  }

  return ret;
}

status_t import_acis_geometry(ENTITY_LIST * entlist, context_t * ctx,
                              cad_t ** pc, dcad_t ** pdc)
{
  status_t ret;
  cad_t *c = 0;
  dcad_t *dc = 0;
  tdata_acis_t *td;
  ENTITY *ent;

  assert(entlist);
  assert(ctx);
  ret = STATUS_OK;

  c = cad_new(ctx);
  if (!c)
    return STATUS_NOMEM;

  if (CREATE_DCAD) {
    dc = dcad_new(c);
    if (!dc)
      return STATUS_NOMEM;
  }

  td = new tdata_acis_t;
  if (!td)
    return STATUS_NOMEM;

  cad_attach_object(c, td, tdata_acis_delete_fun);

  td->last_fid = 0;
  td->last_eid = 0;
  td->last_pid = 0;
  td->last_bid = 0;

  entlist->init();
  ret = STATUS_OK;
  while ((ent = entlist->next()) != 0) {
    td->last_bid++;
    ret = import_acis_entity(ent, td, c, dc);
    if (ret != STATUS_OK)
      return ret;
  }

  /*
   * If you want to set a periodicity meshing constraint (mesh
   * matching) between two sets of cad faces.  See the file
   * meshgems/cad.h for more details
   * (meshgems_cad_add_face_multiple_periodicity_with_transformation_function),
   * and the documentation.
   */
  if (CREATE_PERIODICITY) {
    integer fid1[2], fid2[2];
    integer eid1[2], eid2[2];
    integer size1, size2;
    integer nb_pt1, nb_pt2;
    real p[9], p_im[9], periodic_transformation_user_data;

    /* Example of a translation of vector (1,1,1) : 
     * fill fid1, fid2, eid1, eid2, size1, size2 with your data 
     * (See file meshgems/cad.h)
     */

    assert(size1 == size2);
    /* Set the face periodicities */
    if (1) {
      /* Define the periodic tranformation with points coordinates */
      nb_pt1 = 3;
      nb_pt2 = 3;
      assert(nb_pt1 == nb_pt2);

      /* p contains nb_pt1 points on the first set of face you want to set periodic */
      p[0] = 0;
      p[1] = 0;
      p[2] = 0;

      p[3] = 0;
      p[4] = 1;
      p[5] = 0;

      p[6] = 0;
      p[7] = 0;
      p[8] = 1;

      /* while p_im contains their images on the second set of face */
      p_im[0] = 1;
      p_im[1] = 1;
      p_im[2] = 1;

      p_im[3] = 1;
      p_im[4] = 2;
      p_im[5] = 1;

      p_im[6] = 1;
      p_im[7] = 1;
      p_im[8] = 2;

      /*
       * Set a periodicity between the size1 cad faces of fid1 array and
       * the size2 faces of fid2 array using a transformation defined by
       * the coordinates of nb_pt1 points contained in p and their
       * images contained in p_im See the file meshgems/cad.h for more
       * details on the parameters of this function
       */
      ret =
          cad_add_face_multiple_periodicity_with_transformation_function_by_points
          (c, fid1, size1, fid2, size2, p, nb_pt1, p_im, nb_pt2);
      if (ret != STATUS_OK)
        return ret;
    } else {
      /* Define the periodic tranformation with a callback */

      /*
       * Set a periodicity between the size1 cad faces of fid1 array and
       * the size2 faces of fid2 array using a transformation defined by
       * the periodicity_transformation function See the file
       * meshgems/cad.h for more details on the parameters of this
       * function
       */

      periodic_transformation_user_data = 1;

      ret = cad_add_face_multiple_periodicity_with_transformation_function
          (c, fid1, size1, fid2, size2, periodicity_transformation,
           &periodic_transformation_user_data);
      if (ret != STATUS_OK)
        return ret;
      /* Please note that in case of a translation, you can set
       * periodicity_transformation = 0 and periodic_transformation_user_data = 0.
       * In this case, the CAD preprocessor of MG-CADSurf will compute a 
       * simple translation 
       */
    }

    /* Set the edge periodicities (ie periodicity between edges while
       the associated cad faces are not required to be periodic) */
    if (1) {
      /* Define the periodic tranformation with points coordinates */
      nb_pt1 = 3;
      nb_pt2 = 3;
      assert(nb_pt1 == nb_pt2);

      /* p contains nb_pt1 points on the first set of edge you want to set periodic */
      p[0] = 0;
      p[1] = 0;
      p[2] = 0;

      p[3] = 0;
      p[4] = 1;
      p[5] = 0;

      p[6] = 0;
      p[7] = 0;
      p[8] = 1;

      /* while p_im contains their images on the second set of edge */
      p_im[0] = 1;
      p_im[1] = 1;
      p_im[2] = 1;

      p_im[3] = 1;
      p_im[4] = 2;
      p_im[5] = 1;

      p_im[6] = 1;
      p_im[7] = 1;
      p_im[8] = 2;

      /*
       * Set a periodicity between the size1 cad edges of eid1 array and
       * the size2 faces of eid2 array using a transformation defined by
       * the coordinates of nb_pt1 points contained in p and their
       * images contained in p_im See the file meshgems/cad.h for more
       * details on the parameters of this function
       */
      ret =
          cad_add_edge_multiple_periodicity_with_transformation_function_by_points
          (c, eid1, size1, eid2, size2, p, nb_pt1, p_im, nb_pt2);
      if (ret != STATUS_OK)
        return ret;
    } else {
      /* Define the periodic tranformation with a callback */

      /*
       * Set a periodicity between the size1 cad edges of eid1 array and
       * the size2 faces of eid2 array using a transformation defined by
       * the periodicity_transformation function See the file
       * meshgems/cad.h for more details on the parameters of this
       * function
       */
      periodic_transformation_user_data = 1;
      ret = cad_add_edge_multiple_periodicity_with_transformation_function
          (c, eid1, size1, eid2, size2, periodicity_transformation,
           &periodic_transformation_user_data);
      if (ret != STATUS_OK)
        return ret;
      /* Please note that in case of a translation, you can set
       * periodicity_transformation = 0 and periodic_transformation_user_data = 0.
       * In this case, the CAD preprocessor of MG-CADSurf will compute a 
       * simple translation 
       */
    }
  }
  *pc = c;
  if (dc)
    *pdc = dc;

  return ret;
}

status_t generate_mesh_for_acis(ENTITY_LIST * entlist)
{
  status_t ret;
  cad_t *c = 0;
  dcad_t *dc = 0;
  context_t *ctx = 0;

  assert(entlist);
  ret = STATUS_OK;

  ctx = context_new();
  if (!ctx)
    return STATUS_NOMEM;

  ret = import_acis_geometry(entlist, ctx, &c, &dc);
  if (ret != STATUS_OK) {
    context_delete(ctx);
    return ret;
  }

  ret = generate_mesh(ctx, c, dc, 0);

  cad_delete(c);
  if (dc)
    dcad_delete(dc);
  context_delete(ctx);

  return ret;
}
