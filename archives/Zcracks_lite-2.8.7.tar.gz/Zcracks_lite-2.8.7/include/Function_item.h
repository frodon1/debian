#ifndef __Function_item__
#define __Function_item__

#include <Sim_opt.h>
#include <Stringpp.h>
#include <List.h>
#include <Buffered_list.h>
#include <Function.h>
#include <Vector.h>
#include <Matrix.h>
#include <Array.h>
#include <File.h>
#include <Plot_item.h>
#include <Circular_list.h>
#include <Sim_opt_item.h>
#include <Zunistd.h>
#include <Sim_opt_utility.h>
#include <Simulation_item.h>

Z_START_NAMESPACE;

class FUNCTION_ITEM : public SIMULATION_ITEM {
  public :
    STRING expression;
    LIST<STRING> ref;
    bool no_zero, y_log_scale;
    double min;
    double max;
    int points;
    BUFF_LIST<STRING> coef_name;
    BUFF_LIST<bool> to_be_optimized;

    SIM_OPT_GUI* its_sim_opt;

    FUNCTION_ITEM(SIM_OPT_GUI*);
    FUNCTION_ITEM(const FUNCTION_ITEM&);
    ~FUNCTION_ITEM(){}

    virtual bool write(Zofstream& out);
    virtual void read(ASCII_FILE& file);
    virtual void run_simulation();
    virtual bool fill_plot_item(const STRING& prefix,PLOT_ITEM*);

    virtual STRING get_output_fname(const STRING& prefix);
    virtual SIMULATION_ITEM* copy_self_with_prefix(const STRING& prefix);
    virtual void write_shell_commands(Zofstream& inp);
    virtual void write_inp(SIMULATION_ITEM* old_sim);
    virtual void write_inp();

    bool fill_val(const VECTOR& x_val, VECTOR& y_val);

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
