#ifndef __Post_min_max__
#define __Post_min_max__

#include <Zminmax.h>
#include <Tensor.h>
#include <Local_post_computation.h>

Z_START_NAMESPACE;

//
// ----------------------------------------------
//

ZCLASS2 MIN_MAX_LOCAL_COMPUTATION : public LOCAL_POST_COMPUTATION {
  protected :
      LIST<STRING> vars;
      STRING class_name;

  public :
      virtual MODIFY_INFO_RECORD* get_modify_info_record();
      virtual bool verify_info();

      virtual void input_i_need(int,ARRAY<STRING>&);
};

//
// ----------------------------------------------
//

ZCLASS2 MIN_LOCAL_COMPUTATION : public MIN_MAX_LOCAL_COMPUTATION {
  public :
      MIN_LOCAL_COMPUTATION() { class_name = "min"; }

      virtual void output_i_give(bool&,ARRAY<STRING>&);
      virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
};

//
// ----------------------------------------------
//

ZCLASS2 MAX_LOCAL_COMPUTATION : public MIN_MAX_LOCAL_COMPUTATION {
  public :
      MAX_LOCAL_COMPUTATION() { class_name = "max"; }

      virtual void output_i_give(bool&,ARRAY<STRING>&);
      virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
};
Z_END_NAMESPACE;

#endif
