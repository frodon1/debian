#ifndef __Viscous_fluid_problem_emse__
#define __Viscous_fluid_problem_emse__

#include <Problem.h> 

Z_START_NAMESPACE;

ZCLASS2 VISCOUS_FLUID_MESH_EMSE : public MESH {
  public :
      VISCOUS_FLUID_MESH_EMSE() {;} 
      RTTI_INFO;
};

class INTEGRATION_RESULT;

ZCLASS2 PROBLEM_VISCOUS_FLUID_EMSE : public PROBLEM { 
   protected :
      SEQUENCE *previous_seq;
      AUTO_PTR<GLOBAL_MATRIX> K; 

      void create_mesh();
      virtual INTEGRATION_RESULT* make_iterations(); 
      virtual void update_d_dof(VECTOR & dof);

  public :  
      int    iter_max;
      int    max_nb_disp; 
      int    nb_veloc_dof; 
      bool   Newton;

      PROBLEM_VISCOUS_FLUID_EMSE();
      virtual ~PROBLEM_VISCOUS_FLUID_EMSE();

      virtual bool Execute();
      virtual bool Initialize();

      virtual bool make_increment(double);
      RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
