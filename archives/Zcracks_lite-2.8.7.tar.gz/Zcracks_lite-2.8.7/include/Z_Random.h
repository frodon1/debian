#ifndef __Random__
#define __Random__

#include <Array.h>

Z_START_NAMESPACE;

class ASCII_FILE; 

ZCLASS RANDOM_LAW {
   protected :
     static int Seed;

     static bool   Seed_set;
     double random_cumulated_probability()const;
     static void Set_default_Seed();
   public :
     virtual ~RANDOM_LAW();

     virtual void initialize(ASCII_FILE&);
     virtual double get_random_value()=0;

     static double get_random_double();
     static double get_random_double(double l,double h);
     static int get_random_int();
     static int get_random_int(int l,int h);

     static void   set_seed(int);
};

ZCLASS UNIFORM_LAW : public RANDOM_LAW {
   protected : 
     double xmin;
     double xmax;

   public :
     UNIFORM_LAW();
     UNIFORM_LAW(double xmin_set, double xmax_set);

     virtual void initialize(ASCII_FILE& file);
     double get_random_value();
};
Z_END_NAMESPACE;

#endif
