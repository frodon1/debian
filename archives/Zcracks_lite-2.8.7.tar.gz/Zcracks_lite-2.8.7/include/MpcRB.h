/// ============================================================================ 
///  class MPC_RB                                JR  17.09.2009
///      This class implements a MPC allowing all nodes of a nset to move like if they were attached to a rigid body.
///      In 3D, 6 master dofs are needed. Depending on their choice, some of the rotation components can not be determined.
///      We have therfore to carefully choose the master dofs. In order to avoid no determination, 3 choice are made (mode 1 and mode 2) 
///      which are thought to avoid such situation. 
///
///
///      o In 2D
///      2 nodes (1 and 2) are carefully selected and in mode 1, master dofs are U1x, U1y and U2y. If all 2 nodes lie on a y direction, 
///      rotation around z axis can not be determined. We then swith to mode 2 where master dofs are U1x, U1y and U2x
///
///      o In 3D
///      In mode 1, 3 nodes (1,2 and 3) are carefully selected and master dofs are U1x, U1y, U1z, U2y, U2z, U3z. If all 3 nodes lie on a 
///      plane parallel to (0xy), rotation around x axis can not be determined. If all nodes lie on a plane parallel to (Oyz), rotation around x axis can not be determined
///      In such a case, we use mode 2 where master dofs are U1x, U1y, U1z, U2y, U2z, U3y. BUT, if all nodes lie on a plane parallel to (Oyz), rotation around x axis can not be determined
///      This is the last case where we use mode 3 where master dofs are U1x, U1y, U1z, U2x, U2z, U3x
///
///      See the theorical manual for more details
/// ============================================================================ 




#include <Node.h>
#include <Relationship.h>
#include <Table_handler.h>
#include <Basic_value.h>
#include <Stringpp.h>

#ifndef __MPC_RB__
#define __MPC_RB__

Z_START_NAMESPACE;

class MPC_RB : public RELATIONSHIP {
protected:

  bool verbeux;
  STRING nset_name;

  DOF_TYPE *dof1,*dof2,*dof3;

  virtual void _set_relationship(MESH&);
  virtual void _set_relationship_2d(MESH&);
  virtual void _set_relationship_3d(MESH&);
  virtual bool GetResponse(const STRING &key, ASCII_FILE &inp); 


  bool masters_dofs_found;
  NNSET *nset; 
  double dimension;

  double x2,x3,y2,y3,z2,z3,d1,d2,d3;  //functions of relative coordinates of the master nodes. x2 and d1 (if mode 1) or x2 and d2 (if mode 2) or y2 and d3 (mode3) are denominators and should never be 0.


  int second_node,third_node;

  SMATRIX rot,rotT;
  VECTOR u0,u1,u2;
  SMATRIX rot_coeff0,rot_coeff1,rot_coeff2;
  SMATRIX coeff0,coeff1,coeff2;

  int mode;

public:

   
  MPC_RB();
  MPC_RB(const STRING &ns_name, MESH&  mesh);
  void load(ASCII_FILE&);
  void find_master_dofs_2d(ARRAY<DOF*> &master, ARRAY<VECTOR> &positions);
  void find_master_dofs_3d(ARRAY<DOF*> &master, ARRAY<VECTOR> &positions);
  int find_master_dofs(ARRAY<DOF*> &master, ARRAY<VECTOR> &positions);
  int find_master_dofs();

  SMATRIX matXmat(SMATRIX mat1,SMATRIX mat2);
  VECTOR  matXvec(SMATRIX mat,VECTOR vec);
  VECTOR  vecXvec(VECTOR  vec1,VECTOR vec2);

  VECTOR pos_1,pos_2,pos_3;
  ARRAY<DOF*> master_dof;
  ARRAY<double> coef; 


  RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
