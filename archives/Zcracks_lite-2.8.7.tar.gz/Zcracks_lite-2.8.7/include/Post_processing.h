#ifndef __Post_processing__
#define __Post_processing__

#include <List.h>
#include <Stringpp.h>

#include <Post_data_type.h>
#include <Data_sourcing.h>
#include <Global_post_computation.h>
#include <Local_post_computation.h>

Z_START_NAMESPACE;

class NSET; class ELSET; class IPSET; class ASCII_FILE; class POST_MESH;
class POST_COMPUTATION; 
class GAUGE; class POST_PROCESSOR;

// 
// this class is the base for GLOBAL_POST_PROCESSING & LOCAL_POST_PROCESSING
// it factorizes all common features
//
// --- It would possibly have been better to avoid the different
//         LIST<...> and to put these informations in the POST_COMPUTATION
//         class; on the other hand it is then possible to manage I/O
//         routine more easily
//
ZCLASS2 POST_PROCESSING {
   private   :

     LIST<STRING> xxnode,xxinteg, xxele; // after **integ, **ele in utp file
     void set_card(ASCII_FILE&);
     void set_card_at_time(ASCII_FILE&);
     int get_card_at(double at);
     void add_out_name(LIST<STRING>&,const CARRAY<STRING>&,int);
     void check_existence_of_file(POST_DATA_TYPE)const;
     void size_set(int,ARRAY<POST_ELEMENT*>&);
     void size_set(int,ARRAY<POST_NODE*>&);
     void size_set(int,ARRAY<POST_INTEG*>&);
     void size_set1(int,ARRAY<POST_ELEMENT*>&,ARRAY<POST_NODE*>&);
     void size_set1(int,ARRAY<POST_NODE*>&,ARRAY<POST_ELEMENT*>&);
     void size_set1(int,ARRAY<POST_INTEG*>&);
     bool already_with_same_type(const STRING& name,
       const POST_DATA_TYPE& type,const LIST<STRING>& lname,
       const LIST<POST_DATA_TYPE>& lpdt,int& rk);
   protected :
     enum { __LPC,__GPC };
     PLIST<POST_COMPUTATION>      post;
     LIST<int>                    post_type;
     LIST<bool>                   conforming_list;
     void add_lpc(POST_COMPUTATION*);
     void add_gpc(POST_COMPUTATION*);
     LOCAL_POST_COMPUTATION* local_computation(int i) { return (LOCAL_POST_COMPUTATION*)post[i](); }
     GLOBAL_POST_COMPUTATION* global_computation(int i) { return (GLOBAL_POST_COMPUTATION*)post[i](); }

     //  
     // All these lists are sized to the number of "locations" to run over. 
     //  
     LIST< int >                      output_to_node; 
     LIST< PDT_GROUP >                pdt_group;      // content of **file
     LIST< STRING >                   mat_files;      // content of **material_file;
     LIST< LIST<int> >                cards;          // content of **output_number
     LIST< bool >                     deformed;       // **deformed and **not_deformed key-words
     LIST< bool >                     duplicate_no;   // handle same variable names
     LIST< POST_DATA_TYPE >           out_pdt;        // where output is written
     LIST< CARRAY<STRING> >           out_name;       // names of output
     LIST< CARRAY<int> >              rk_out;         // rank of out_name in file given by out_pdt
     LIST< bool >                     every_card;   //
     LIST< CARRAY<POST_DATA_TYPE> >   in_pdt;       // where input is read
     LIST< CARRAY<STRING> >           in_name;      // names of input
     LIST< CARRAY<int> >              rk_in;        // rank of in_name in file given by in_pdt
     // SQ 12/23/08 : modif for Z8 format
     // keep nsets etc.. names and fills current_nset when needed
     CARRAY<POST_ELEMENT*>            current_elset;
     CARRAY<POST_NODE*>               current_nset; 
     CARRAY<POST_INTEG*>              current_ipset;
     LIST<STRING>                     nset_names;   // content of **nset
     LIST<STRING>                     elset_names;  // content of **elset
     LIST<STRING>                     ipset_names;  // content of **ipset

     POST_MESH* post_mesh;
     int   RunNumber;

     // 
     // RF, changed name because its compared with e.g. void LOCAL_POST_PROCESSING::load
     // which is very confusing and probably dangerous 
     // 
     bool base_load(ASCII_FILE&);

     void synchro();
     void size_current_sets(int);
     void size_set1(int); // used for global_post_processing : sizing for 1 card
     void erase(int);
     void erase(ARRAY<POST_ELEMENT*>&);
     void erase(ARRAY<POST_NODE*>&);
     void erase(ARRAY<POST_INTEG*>&);
     void start_loading(int);
     bool loading(int,ARRAY<POST_ELEMENT*>&);
     bool loading(int,ARRAY<POST_NODE*>&);
     bool loading(int,ARRAY<POST_INTEG*>&);
     bool loading_card(int,int);
     void open_mat_file(ASCII_FILE&,POST_COMPUTATION*);

     // SQ 12/22/08 : stuff for Z8 format 
     int cur_post;      // cur_post_idx
     int next_mesh_card; // ranks in cards[cur_post] of the last card for the cur mesh

     void init_mesh_change(int post_idx); 
     void get_next_mesh_cards(); // fills this_mesh_cards and sets next_mesh_card


   public :
     enum PACKET_FLAG { ANY_PACKET_FLAG = 0, FIRST_PACKET_FLAG = 1, LAST_PACKET_FLAG = 2 };

     POST_PROCESSOR *boss;
     POST_DATA_SOURCE* z8_source;

    // SQ 12/22/08 : stuff for Z8 format 
     ARRAY<int> this_mesh_cards; // cards ids for the cur mesh

     // SQ 12/22/06 : added this to store only cards where values are calculated in post files
     // utp_card_rk[i] is the rank in post files of original card i
     //   or -1 if no values are calculated for this card
     ARRAY<int> utp_card_rk;
 
     POST_PROCESSING();
     virtual ~POST_PROCESSING();
    
     void set_mesh(POST_MESH*);
     void set_RunNumber(int);

     void mk_utp(LIST<STRING>& node_pvar,
                 LIST<STRING>& integ_pvar, 
                 LIST<STRING>& ele_var);

     void nb_type_var(ARRAY<STRING>& nodep_var,
                      ARRAY<STRING>& ctnodp_var,
                      ARRAY<STRING>& integp_var,
                      ARRAY<STRING>& ctmatp_var,
                      ARRAY<STRING>& ctelep_var,
                      ARRAY<STRING>& elep_var)const;
     void prepare_set(int);
 
     // 
     // Visible for output formats. This data is not "publicly public"
     // 
     long nb_loaded; 
     long user_packet_size, packet_size;
     long current_packet;
};
Z_END_NAMESPACE;

#endif
