#ifndef __Pointer_Buffered_list__
#define __Pointer_Buffered_list__

#include <Buffered_list.h>

Z_START_NAMESPACE;


// pBUFF_LIST  implements functions for BUFF_LIST<T*> with many functions working on
//             the contents of the members instead of the members.
// 
//             if members need to be deleted, use PBUFF_LIST


template<class T> ZCLASS pBUFF_LIST : public BUFF_LIST< T* > {
     public : 
       pBUFF_LIST(int bsz=DEFAULT_BUFFERED_LIST_SIZE) : BUFF_LIST<T*>(bsz)  {}
       pBUFF_LIST(int bsz, int chunk_size) : BUFF_LIST<T*>(bsz,chunk_size)  {}
       pBUFF_LIST(const pBUFF_LIST<T*>& a);
       virtual ~pBUFF_LIST() {}

       int first_occurrence(const T& t) const
       {
          int res=-1,i;
          for(i=0;i<sz;i++){
            if((*x[i])==t) { res=i; break; }
          }
          return(res);
       }
   //  int find_first_str(const char* pc);

   // T*& get_first_str(const char* pc){
   //    int rk=find_first_str(pc);
   //    if(rk!=-1) return x[rk];
   //    return (T*) 0;
   // }
     const T*& operator[](int rank) const { assert(rank>=0 && rank<sz); return x[rank]; }        
     T*& operator[](int rank) { assert(rank>=0 && rank<sz); return x[rank]; }                    
   //const T*& operator[](const char* pc) const {return get_first_str(pc);}
   //T*& operator[](const char* pc){return get_first_str(pc);}

   //  int str_start_unique( const char *pc) const
   //  {
   //     int res=-1,i;
   //   bool first=true;
   //     for(i=0;i<sz;i++){
   //         if((*x[i]).name.start_with(pc)){
   //         if(first){first=false;res=i;}
   //         else{ res = -2; break; }
   //         }
   //     }
   //     return(res);
   //  }

      // stl
       typedef T** iterator;
        typedef const T** const_iterator;

};
/*******
PBUFF_LIST
4.7.99 MW

  vector of pointers that need to be deleted.

  New, June 2002, mw, no PTR objects.
**********/



template<class T> ZCLASS PBUFF_LIST : public pBUFF_LIST< T > {
     public : 
       PBUFF_LIST(int bsz=DEFAULT_BUFFERED_LIST_SIZE) : pBUFF_LIST<T>(bsz)  {}
       PBUFF_LIST(int bsz, int chunk_size) : pBUFF_LIST<T>(bsz,chunk_size)  {}
       virtual ~PBUFF_LIST() {
          for(int i=0;i<sz;i++) if(x[i]) delete x[i];
       }

       bool suppress() { return suppress(sz-1); }
       bool suppress(int rk) { 
          assert(rk>=0 && rk<sz);
          if(x[rk]) delete x[rk];
          for(int i=rk+1;i<sz;i++) x[i-1]=x[i];
          sz--;
          return true;
        }
};
Z_END_NAMESPACE;

#endif
