#ifndef __EXTERN_SEQUENCE__
#define __EXTERN_SEQUENCE__

#include <List.h>
#include <Sequence.h>

Z_START_NAMESPACE;

ZCLASS2 EXTERN_GROUP_OF_SEQUENCES : public GROUP_OF_SEQUENCES {
  public :
    EXTERN_GROUP_OF_SEQUENCES(LIST<GROUP_OF_SEQUENCES*>&);
   ~EXTERN_GROUP_OF_SEQUENCES();

    void initialize(int icyc, int iseq, int iincr, double ini_time, double end_time , double tolerance                                      ,double prog, STRING c_type, STRING a_type, int max_iter);
    LIST<int> valid;
    void suppress() { seqs.LIST< SEQUENCE* >::suppress(); }
};
Z_END_NAMESPACE;

#endif
