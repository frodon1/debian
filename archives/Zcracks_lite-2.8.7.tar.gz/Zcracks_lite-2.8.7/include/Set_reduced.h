#ifndef __SET_REDUCED_TRANSFORMER__
#define __SET_REDUCED_TRANSFORMER__

#include <Calcul_timer.h>
#include <Defines.h>
#include <Error_messager.h>
#include <File.h>
#include <Function.h>
#include <Marray.h>
#include <Z_Random.h>
#include <Out_message.h>

#include <Utility_mesh.h>

#include <Modify_record.h>
#include <Transform_geometry.h>

#include <Print.h>

Z_START_NAMESPACE;

// ============================================================================ 
//  Set the reduced or full integration flag for elements 
// ============================================================================ 

ZCLASS SET_REDUCED_TRANSFORMER : public TRANSFORMERS {
  protected : 
  public :
     LIST<STRING> use_elsets;
     enum { reduced=0, normal=1 };
     int type; 
     SET_REDUCED_TRANSFORMER() { } 
     virtual ~SET_REDUCED_TRANSFORMER() { } 

     MODIFY_INFO_RECORD* get_modify_info_record();

     virtual void apply(UTILITY_MESH& mesh);
};

Z_END_NAMESPACE;

#endif
