gcc -I. -L. mg-tetra_example.c -lmg-tetra -lmeshgems -lmeshgems_stubs -lm -lc  -o mg-tetra_example.exe

