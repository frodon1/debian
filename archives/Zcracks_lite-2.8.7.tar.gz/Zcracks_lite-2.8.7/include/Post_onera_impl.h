bool CNAME::NLC_NAME(double& Nr, double D0, bool above_sigl)
{
  if(!keep_natural_order && (!save_creep == 0) ) {
     return( NLC_NAME_SORTED(Nr,D0,above_sigl) );
  }

  double Dmin = 1.0/Nr;

  if(verbose) { Out<<endl; write_info(); }

  double Nrl = do_linear(D0,save_fatigue,save_creep);
  if(!above_sigl) {
    if(Nrl>infinity_creep) {
       Nr = infinity;
       return(TRUE);
    }
  }

  Nr = 0.0;
  REAL Y = 1.0 - D0;
  REAL Y1 = Y;

  // first calculate a block size to do "iter" loops (linear cumulation)
  double block_size = floor(Nrl/iter);
  if(block_size<1.0) block_size = 1.0;

  Y1 = CUMUL_NAME(Y,block_size,save_fatigue,save_creep,repeat);
  if(verbose) Out<<"Linear packet size="<<block_size<<" Y1="<<DBLE(Y1)<<endl;

  if(block_size<=1.0 && Y1<0.0) {
     Nr = 1.0;
     return(TRUE);
  }

  bool cumulation_has_started = FALSE;
  double block_size_max = 1.0, block_size_min = 1.0;
  double factor = 1.0;
  bool got_min = FALSE, got_max = FALSE;
  if(Y1<=0.) {
     got_max = TRUE;
     block_size_max = block_size;
     factor = 0.5;
  }   
  else if(Y1>=Y) {
     got_min = TRUE;
     block_size_min = block_size;
     factor = 2.0;
  }
  else cumulation_has_started = TRUE;

  if(!cumulation_has_started) {
     if(verbose) Out<<"Looking for a packet size that starts cumulation"<<endl;
     block_size *= factor;
     for(;;) {
        if(block_size<1.0 || block_size>infinity) break;
        bool needs_block = TRUE; 
        for(int i=0;i<!save_fatigue;i++) {
            for(int j=0;j<!save_fatigue[i];j++) {
                if(block_size*repeat[i]*save_fatigue[i][j][1] > 1.0) {
                   needs_block = FALSE;
                   break;
                }
            }
            if(!needs_block) break;
        }
        if(!needs_block && factor>1.0) break;
        Y1 = CUMUL_NAME(Y,block_size,save_fatigue,save_creep,repeat);
        if(verbose) Out<<" . blk="<<block_size<<" Y1="<<DBLE(Y1)<<endl;
        if(Y1>=Y)        { block_size_min = block_size; got_min = TRUE; }
        else if(Y1<=0.0) { block_size_max = block_size; got_max = TRUE; }
        else { 
           cumulation_has_started = TRUE;
           break;
        }
        if(got_min && got_max && block_size_max>block_size_min) {
           double bb = floor((block_size_max+block_size_min)/2.0);
           if(bb>block_size_min) block_size = bb;
           else break;
        }
        else block_size *= factor;
     }
  }

  if(verbose) {
     Out<<endl;
     if(cumulation_has_started) Out<<"Selected a block size, blk="<<block_size<<endl;
  }

  if(!cumulation_has_started) {
     if(!above_sigl && !save_creep) {
         // if all fatigue cycles are below the fatige limit, do
         // a linear cumulation on creep cycles
         Nr = Nrl;
     } 
     else {
         // hopeless case ... setting Nr=1.0
         Nr = Nrl;  //1.0;
     }
     return(FALSE);
  }

  bool reached_min_packet = FALSE;
  int iloop;
  for(iloop=0;;iloop++) {
      bool do_it_again = FALSE;
      Y1 = CUMUL_NAME(Y,block_size,save_fatigue,save_creep,repeat);
      if(verbose) Out<<"Y="<<DBLE(Y)<<" Y1="<<DBLE(Y1)<<" Nr="<<Nr<<" blk="<<block_size<<endl;
      if(Y1>=Y) {
         reached_min_packet = TRUE;
         do_it_again = TRUE;
         block_size *= 2.0;
      }
      if(block_size>1.0 && !reached_min_packet) {
         if(bszm == 1) {
            if((1-Y1)>Dtiny) {
               REAL Dinc = ABS(Y1-Y);
               REAL down = ((1.0-Y)>Dtiny) ? 1.0/(1.0-Y) : 1.0/(1.0-Y1);
               REAL crit = Dinc/down;
               if( ((crit>2.0*prec)&&(Dinc>(block_size*Dmin))) || (Y1<0.0) ) {
                  // when precision is met *AND* damage increment is bigger
                  // than a linear cumulation prediction based on the
                  // the most critical mechanism ... ie non linear cumulation
                  // begin to make a change
                  do_it_again = TRUE;
                  block_size /= 2.0;
                  if(block_size<2.0) block_size = 1.0;
                  //Out<<"Y="<<Y<<" Y1="<<Y1<<" blk="<<block_size<<endl;
               }
            }
         }
         else { // linear
            if(Y1<=0.0) {
               do_it_again = TRUE;
               block_size /= 2.0;
               if(block_size<2.0) block_size = 1.0;
            }
         }
      }
      if(!do_it_again) {
         if(Y1<=0.0) break;
         Y = Y1;
         Nr += block_size;
         if(Nr>infinity) {
            Out<<"infinite cumulation ?"<<endl;
            Nr = infinity;
            break;
         }
      }
      if(iloop>10*iter) {
         Out<<"Non convergence in "<<iloop<<" iterations"<<endl;
         write_info();
         Nr=infinity;
         return(FALSE);
      }
  }

  if(Nr>Nrl) Nr = Nrl;

  if(verbose) Out<<"Convergence in "<<(iloop+1)<<" iterations"<<endl;
  Timer_counter.max_count("cumulation iterations",iloop+1);

  return(TRUE);

}

REAL CNAME::CUMUL_NAME(REAL Y0, double blks, const ARRAY< ARRAY<VECTOR> >& save_fat,
  const ARRAY< ARRAY<double> >& save_cr, LIST<int>& rep)
{ double un_moins_alpha = 1.0, min_alpha = 1.e-8, max_fl = 10.0;
  VECTOR ext_param(1);

  REAL Y = Y0;
  bool got_creep = (!save_cr) ? TRUE : FALSE;
  if(!got_creep) {
     Y = pow(Y,beta+1.0);                                    // use (1-D)^(beta+1) as variabl
  }

  for(int ib=0;ib<!rep;ib++) {                               // loop on blocks

     int nr = rep[ib];
     for(int ic=0;ic<!save_fat[ib];ic++) {                   // loop on sub-cycles

         const VECTOR& fat_out = save_fat[ib][ic];
         double Flog = fat_out[2];
         un_moins_alpha = calculate_alpha(ib,ic,save_fat);

         if(!got_creep && un_moins_alpha <= min_alpha) {

             double vtot = blks*nr*Flog, vc=0.0;
             int nc =  int(vtot/max_fl);
             if(nc>=1) {
                for(int ic=0;ic<nc;ic++) {
                   REAL Fl = exp(max_fl);
                   Y = Fl*(1.-Y);                           // 1-(1-Df)^(beta+1)
                   Y = 1.0 - Y;                             // (1-Df)^(beta+1)
                   vc += max_fl;
                   if(Y<=0.0) break;
                }
             }
             if(Y<=0.0) break;
             REAL Fl = exp(vtot-vc);
             Y = 1.0 - Fl*(1.-Y);                           // (1-Df)^(beta+1)
             if(Y<=0.0) break;

         }
         else {

             int irmax = nr;
             double fact = blks;
             if(linear_block) {
                irmax = 1;
                fact = blks*nr;
             }
             for(int ir=0;ir<irmax;ir++) {                      // loop on repetition of current block

                 if(got_creep) {
                    double C = fact/save_cr[ib][ic];
                    Y = pow(Y,k+1.0) - C;                    // (1-D)^(k+1)
                    if(Y < 0.0) break;
                    Y = pow(Y,(beta+1.)/(k+1.));             // (1-D)^(beta+1)
                 }

                 if ( un_moins_alpha > min_alpha ) {          // normal case
                    double F = fact*fat_out[1];
                    if(Y<1.0) Y = pow(1.0-Y, un_moins_alpha);
                    else      Y = 0.0;
                    Y = pow(F+Y, 1.0/un_moins_alpha);         // 1-(1-Df)^(beta+1)
                 }
                 else {                                       // log cumulation
                    double vtot = fact*Flog, vc = 0.0;
                    int nc = int(vtot/max_fl);
                    if(nc>=1) {
                       for(int ic=0;ic<nc;ic++) {
                          REAL Fl = exp(max_fl);
                          Y = Fl*(1.-Y);                           // 1-(1-Df)^(beta+1)
                          Y = 1.0 - Y;                             // (1-Df)^(beta+1)
                          vc += max_fl;
                          if(Y<=0.0) break;
                       }
                    }
                    if(Y<=0.0) break;
                    REAL Fl = exp(vtot-vc);
                    Y = Fl*(1.-Y);                                 // 1-(1-Df)^(beta+1)
                 }
                 Y = 1.0-Y;                                   // (1-Df)^(beta+1)
                 if(Y<=0.0) break;
                 if(got_creep) Y = pow(Y, 1./(beta+1.));      // 1-Df

             }
             if(Y<=0.0) break;
         }
     }
     if(Y<=0.0) break;
  }

  if(!got_creep && Y>0.0) Y = pow(Y, 1./(beta+1.));
  return(Y);

}

bool CNAME::NLC_NAME_SORTED(double& Nr, double D0, bool above_sigl)
{ int i, j;

  if(!save_creep) ERROR("Cannot do cumulation in sorted mode when creep damage is included");

  if(!above_sigl) { // all cycles are below the fatigue limit
    if(D0<=0.0) Nr = infinity;
    else { // evaluate in one shot
       double Yl = log( 1.0 - pow( (1.0 - D0) , beta+1.0 ) );
       double Fl = 0.0;
       for(i=0;i<!repeat;i++) {
          for(j=0;j<!save_fatigue[i];j++) Fl += repeat[i]*save_fatigue[i][j][2];
       }
       Nr = -Yl/Fl;
       if(Nr>infinity) Nr = infinity;
    }
    return(TRUE);
  }

  if(verbose) { Out<<endl; write_info(); }

  double Nrl = do_linear(D0,save_fatigue,save_creep);

  // first sort fatigue cycles by increasing Nf
  int nb_cyc = 0;
  for(i=0;i<!repeat;i++) {
     int nb = !save_fatigue[i];  nb_cyc += nb;
  }
  ARRAY<double> nf_sort;
  ARRAY<int>   block_sort, cyc_sort, rk_sort;
  block_sort.resize(nb_cyc); cyc_sort.resize(nb_cyc); rk_sort.resize(nb_cyc); nf_sort.resize(nb_cyc);
  int pos = 0;
  for(i=0;i<!repeat;i++) {
     for(j=0;j<!save_fatigue[i];j++) {
         if(save_fatigue[i][j][3]<0.0) nf_sort[pos] = 1.e19;
         else {
             nf_sort[pos] = (save_fatigue[i][j][0]<infinity) ? save_fatigue[i][j][0] : 1.0/save_fatigue[i][j][1];
         }
         block_sort[pos] = i;
         cyc_sort[pos]   = j;
         pos++;
     }
  }

  sort_array(nf_sort,rk_sort);

  // calculate a block size to do "iter" loops (linear cumulation)
  double block_size = floor(Nrl/iter);
  if(block_size<1.0) block_size = 1.0;

  REAL Y = 1.0 - pow( (1.0 - D0) , beta+1.0);
  Nr = CUMUL_NAME_SORTED(Y,block_size,save_fatigue,repeat,block_sort,cyc_sort,rk_sort);

  return(TRUE);
}

double CNAME::CUMUL_NAME_SORTED(REAL Yi, double blks, const ARRAY< ARRAY<VECTOR> >& save_fat,
  LIST<int>& rep,  ARRAY<int>& block_sort, ARRAY<int>& cyc_sort, ARRAY<int>& rk_sort)
{ int i, ib, ic, rk, beg, loop;
  double Nr, un_moins_alpha, un_moins_alpha1,un_moins_alphai, un_moins_alphal;
  REAL Y, Y_prev;

  // the first cycle is always above sigl when entering this function
  // un_moins_alphai is for the first, un_moins_alphail for the last one above sigl
  rk = rk_sort[0];
  ib = block_sort[rk];  ic = cyc_sort[rk];
  const VECTOR& fat_out0 = save_fat[ib][ic];
  un_moins_alphai = calculate_alpha(ib,ic,save_fat);
  Y = pow(Yi,un_moins_alphai) + repeat[ib]*blks*fat_out0[1];
  un_moins_alphal = un_moins_alphai;
  int nb_above_sigl = 1;
  for(i=1;i<!rk_sort;i++) {
     rk = rk_sort[i];
     ib = block_sort[rk];  ic = cyc_sort[rk];
     const VECTOR& fat_out = save_fat[ib][ic];
     if(fat_out[3]<=0.0) break;
     un_moins_alphal =  calculate_alpha(ib,ic,save_fat);
     nb_above_sigl++;
  }

  double Fl = 0.0;
  for(i=nb_above_sigl;i<!cyc_sort;i++) {
     rk = rk_sort[i];
     ib = block_sort[rk];  ic = cyc_sort[rk];
     Fl += repeat[ib]*save_fat[ib][ic][2];
  }

  Nr = 0.0;
  un_moins_alpha1 = un_moins_alphai;
  for(loop=0;;loop++) {
     if(loop==0) { beg=1; un_moins_alpha = un_moins_alphai; }
     else        { beg=0; un_moins_alpha = un_moins_alphal; }
     if(verbose) Out<<"Y="<<DBLE(Y)<<" Nr="<<Nr<<" blk="<<blks<<endl;
     Y_prev = Y;
     for(i=beg;i<nb_above_sigl;i++) {
        rk = rk_sort[i];
        ib = block_sort[rk];  ic = cyc_sort[rk];
        const VECTOR& fat_out = save_fat[ib][ic];
        un_moins_alpha1 = calculate_alpha(ib,ic,save_fat);
        if(verbose) Out<<"un_moins_alpha="<<un_moins_alpha<<endl;
        double Di = fat_out[1];
        Y = pow(Y,un_moins_alpha1/un_moins_alpha) + repeat[ib]*blks*Di;
        if(Y>=1.0) break;
        un_moins_alpha = un_moins_alpha1;
     }
     // cumulation of all cycles below sigl in one shot
     if(nb_above_sigl<!cyc_sort) {
        Y = Y * exp( un_moins_alphal*blks*Fl );
     }
     if(Y>=1.0) {
        if(blks>1.0) {
           blks /= 2.0; 
           if(blks<2.0) blks = 1.0;
           Y = Y_prev;
           if(loop==0) loop = -1;
        }
        else break;
     }
     else {
        Nr += blks;
        if(Nr>=infinity) { Nr=infinity; break; }
        if(loop>10*iter) {
           Out<<"Non convergence in "<<loop<<" iterations"<<endl;
           write_info();
           Nr = infinity;
           return(FALSE);
        }
     }
  }

  if(verbose) Out<<"Convergence in "<<(loop+1)<<" iterations"<<endl;

  return(Nr);
}
