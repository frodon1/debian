#ifndef __ZP_UTILITY_BSET__
#define __ZP_UTILITY_BSET__

#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>
#include <Utility_set.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_UTILITY_BSET : public ZP_BASIC_TYPE< B_UTILITY_SET >
{
  protected :
    virtual ZP_FATAL_ERROR* print(ZP_STACK&,int);
    ZP_FATAL_ERROR* get_type(ZP_STACK&,int);
    ZP_FATAL_ERROR* size(ZP_STACK&,int);
    ZP_FATAL_ERROR* bracket(ZP_STACK&,int);
    virtual void type_init(char*) { type="UTILITY_BSET"; }

  public :
    BASIC_CONSTRUCTORS(ZP_UTILITY_BSET,B_UTILITY_SET);

    METHOD_DECLARATION_START
      METHOD("size",size,0)
      METHOD("type",get_type,1)
      METHOD("[]",bracket,1)
    METHOD_DECLARATION_ANCESTOR(ZP_BASIC_TYPE<B_UTILITY_SET>)

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
    ZPO_RTTI_INFO(B_UTILITY_SET)
};

typedef ZP_UTILITY_BSET ZP_B_UTILITY_SET;

Z_END_NAMESPACE;

#endif
