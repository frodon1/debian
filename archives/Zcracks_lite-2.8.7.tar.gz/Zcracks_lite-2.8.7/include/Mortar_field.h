#ifndef __MORTAR_FIELD__
#define __MORTAR_FIELD__

#include <Z_object.h>
#include <Mesh.h>
#include <Zstream.h>
#include <BB_tree_utility_mesh.h>
#include <Matrix.h>

#include <Mat_data_when.h>

Z_START_NAMESPACE;

/*
  VC, April 2006 : class for transfert between meshes using mortar method

  Right now only used for coincident volume or surface interfaces
*/

#define MORTAR_GAUSS_INTER 1
#define MORTAR_GAUSS_EXTRA 2

class GAUSS_EXTRAPOLATION;
class MORTAR_FIELD;

// Class storing a few GAUSS_EXTRAPOLATION
// Perform using shape function for interpolation
// and inverse shape function for extrapolation
class GAUSS_EXTRAPOLATION : public Z_OBJECT
{
  private :
  public :
    MESH* mesh;
    int  type; // set if extra (from GP to node) or inter (from node to GP)
    MATRIX matrix; // matrix for computations
    int nb_node,nb_GP; // infos 

    void build(int _id_elem,int _type,MESH *_mesh); // build object
    GAUSS_EXTRAPOLATION() {}
    ~GAUSS_EXTRAPOLATION() {}
};

class MORTAR_FIELD : public Z_OBJECT
{
  protected : 
    STRING elset_name;
    bool matrix_ok,if_inverse,if_ranks;
    LIST <GAUSS_EXTRAPOLATION*> extrapolation;
    LIST <int> extrapolation_id;
    int max_extra,matrix_size;
    int start_dirichlet; // rank of first dirichlet node
    BUFF_LIST <int> list_rank; // rank of associated nodes
                          // -1 means not used node
    BUFF_LIST <int> list_rank_dirichlet; // rank of associated nodes
    BUFF_LIST <NODE*> list_node,list_node_dirichlet;  // list of used nodes in mesh
    BUFF_LIST <bool> list_assemble; // says if elem has been assembled
    BUFF_LIST<DOF_TYPE*> dts;
    BUFF_LIST<int> elem_type,types_of_elem;

    int nb_values_GP;
    int nb_each_value_GP[4];

    void build_ranks();
    void assemble_matrix(D_ELEMENT&,SMATRIX&);
    void assemble_vector(D_ELEMENT& elem,VECTOR& vector,VECTOR& elem_vector);
    void assemble_vector(D_ELEMENT& elem,MARRAY<VECTOR>& vector,MATRIX& elem_vector);
    void fill_dof(MARRAY<VECTOR> &lx);

    SMATRIX MA,M_GP;          // Matrix decomposition for dirichlet conditions

  public :

    void initialize(MESH *m,STRING& elsetname);
    MESH*         mesh;     // attached mesh
    UTILITY_MESH* umesh;    // attached utility mesh
    SMATRIX matrix;         // matrice for transfer (standart for shake of simplicity)
    VECTOR  vx,vy,vz;       // Dofs decomposition
    BB_TREE_UTILITY_MESH bb_tree;        // bounding box tree attached to current mesh
    bool use_coord;         // should use updated mesh ?

    MORTAR_FIELD() : Z_OBJECT(), mesh(NULL), umesh(NULL) {
      matrix_ok=FALSE; if_inverse=FALSE; max_extra=20;
      extrapolation.resize(0);
      extrapolation_id.resize(0);
      if_ranks=FALSE;
      elset_name = "ALL_ELEMENT";
    }
    ~MORTAR_FIELD() { for(int i=0;i<extrapolation.size();i++) delete extrapolation[i]; }

    // Locate position in ref system
    int locate(VECTOR& xi,const VECTOR &xp,double conv=1.e-5, int max_iter=50);

    // Utility function
    void build_matrix();
    void solve(const VECTOR& f,VECTOR &x,DOF_TYPE* dof_type); // to solve for one vector on nodes
    void solve(const MARRAY<VECTOR> &lf,MARRAY<VECTOR> &lx,BUFF_LIST<DOF_TYPE*> &ldof_type);
                                                              // for a list of vectors
    void solve_GP(const MARRAY<VECTOR> &lf,MARRAY<VECTOR> &lx);
    void build_vector_from(MORTAR_FIELD& field,DOF_TYPE* dof,VECTOR &f); // for computation of rhs
    void build_vector_from(MORTAR_FIELD& field,MARRAY<VECTOR> &lf); // for list
    void build_vector(MORTAR_FIELD& field,DOF_TYPE* dof,VECTOR &f); // for computation of rhs
    void build_vector(MORTAR_FIELD& field,MARRAY<VECTOR> &lf); // for list

    // For Gauss points
    void init_nb_GP_values();
    void extract_GP_values_at_point(VECTOR &pos,VECTOR &values);
    void fill_GP(MARRAY<VECTOR> &lx);
    void write_GP_values_from_nodal(P_ELEMENT &elem,MATRIX &values,MATRIX &elem_coord);
    void build_vector_GP_from(MORTAR_FIELD& field,MARRAY<VECTOR> &lf); // for list
    void build_vector_GP(MORTAR_FIELD& field,MARRAY<VECTOR> &lf); // for list
    void transfert_GP_from(MORTAR_FIELD& field);

    // Build extrapolation matrix
    void build_extrapolation(int elem_id,GAUSS_EXTRAPOLATION* &current_extrapolation);
 
    // Transfert function
    
    // From another mesh
    // Transfert a vector corresponding to dofs to dofs vector
    void transfert_nodal_from(MORTAR_FIELD& field,const VECTOR &f,VECTOR &x); 
    // For whole mesh
    void transfert_nodal_from(MORTAR_FIELD& field); // Transfert only nodal values
    void transfert_integ_from(MORTAR_FIELD& field); // Transfert only integration values
    void transfert_from(MORTAR_FIELD& field);  // Tranfert all mesh

    // To another mesh
    // Specific nodal values
    void transfert_nodal_to(MORTAR_FIELD& field,const VECTOR& x,VECTOR &f)
      { field.transfert_nodal_from(*this,x,f); } 
    // For whole mesh
    void transfert_nodal_to(MORTAR_FIELD& field) // Transfert only nodal values
      { field.transfert_nodal_from(*this); } 
    void transfert_integ_to(MORTAR_FIELD& field) // Transfert only integration values
      { field.transfert_integ_from(*this); } 
    void transfert_to(MORTAR_FIELD& field)  // Tranfert all mesh
      { field.transfert_from(*this); } 

    void anchor(MESH *);
    void anchor(UTILITY_MESH *);

    // Fast transfert reinterpolation
    void transfert_nodal_direct_from(MORTAR_FIELD& field); // Transfert only nodal values
    void transfert_integ_direct_from(MORTAR_FIELD& field); // Transfert only integration values
    void transfert_nodal_diff_direct_from(MORTAR_FIELD& field); // Transfert only nodal values
    void transfert_integ_diff_direct_from(MORTAR_FIELD& field); // Transfert only integration values
    RTTI_INFO;
};

Z_END_NAMESPACE;
#endif
