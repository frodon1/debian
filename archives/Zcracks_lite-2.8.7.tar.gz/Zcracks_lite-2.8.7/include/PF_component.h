#ifndef __PF_component_behavior__
#define __PF_component_behavior__

#include <PF_gen_behavior.h>
//#include <PF_energy.h>

Z_START_NAMESPACE;

class PHASEFIELD_BEHAVIOR;

class PHASEFIELD_BEHAVIOR_COMPONENT {  
public :
   PHASEFIELD_BEHAVIOR* boss;
   PHASEFIELD_BEHAVIOR_COMPONENT() {};
   virtual ~PHASEFIELD_BEHAVIOR_COMPONENT() {};
   virtual void initialize(PHASEFIELD_BEHAVIOR* its_boss){boss=its_boss;};
   virtual void pre_integrate(PHASEFIELD_INTEGRATION_INFO*) {};
   virtual void integrate(PHASEFIELD_INTEGRATION_INFO*)=0;
   virtual void derivative(double,const  VECTOR&,VECTOR&) {};
   virtual void calc_grad_f(VECTOR&,SMATRIX&,const VECTOR&,const VECTOR&,double,double) {};

};


class PHASEFIELD_COMPONENT : public PHASEFIELD_BEHAVIOR_COMPONENT {

public :

   PHASEFIELD_COMPONENT() {};
   void initialize(PHASEFIELD_BEHAVIOR* its_boss);
   void integrate(PHASEFIELD_INTEGRATION_INFO*);
};


class DIFFUSION_COMPONENT : public PHASEFIELD_BEHAVIOR_COMPONENT {

public :

   DIFFUSION_COMPONENT() {};
   void initialize(PHASEFIELD_BEHAVIOR* its_boss);
   void integrate(PHASEFIELD_INTEGRATION_INFO*);
};


class ELASTIC_COMPONENT : public PHASEFIELD_BEHAVIOR_COMPONENT {

public :
   ELASTIC_COMPONENT() {};
   void initialize(PHASEFIELD_BEHAVIOR* its_boss);
   void pre_integrate(PHASEFIELD_INTEGRATION_INFO*);
   void integrate(PHASEFIELD_INTEGRATION_INFO*);
};


class PLASTIC_COMPONENT : public PHASEFIELD_BEHAVIOR_COMPONENT {

public :
   PLASTIC_COMPONENT() {};
   void initialize(PHASEFIELD_BEHAVIOR* its_boss);
   void pre_integrate(PHASEFIELD_INTEGRATION_INFO*);
   void integrate(PHASEFIELD_INTEGRATION_INFO*);
   void calc_grad_f(VECTOR&,SMATRIX&,const VECTOR&,const VECTOR&,double,double);
   void derivative(double,const  VECTOR&,VECTOR&) ;
};

Z_END_NAMESPACE; 

#endif
