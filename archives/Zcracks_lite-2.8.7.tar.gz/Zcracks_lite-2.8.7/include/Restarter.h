#ifndef __RESTARTER__
#define __RESTARTER__

#include <Defines.h>
#include <Stringpp.h>
#include <Auto_readable.h>

Z_START_NAMESPACE;

ZCLASS2 RESTARTER : public AUTO_READABLE {
  public :
    enum MODE {NO_RESTART,WRITE_RESTART,READ_WRITE_RESTART};

  protected :
    STRING file;
    MODE mode;

  public :
    RESTARTER();
    virtual ~RESTARTER();

    virtual bool declare_data(AUTO_PTR<AID_PART>&);

    const MODE& get_restart_mode() { return(mode); }
    const MODE& get_mode() { return(mode); }
    void set_restart_mode(MODE m) { mode=m; }
    void set_mode(MODE m) { mode=m; }

    const STRING& get_file() { return(file); }
    void  set_file(STRING s) { file=s; }
};

Z_END_NAMESPACE;

#endif
