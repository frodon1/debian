#ifndef __CREATE_BSET_WRAPPER__
#define __CREATE_BSET_WRAPPER__

#include <List.h>
#include <Stringpp.h>
#include <Geometry_parts.h>
#include <Dao_create_bset_domain.h>

Z_START_NAMESPACE;

class CREATE_BSET_WRAPPER {
  public :
    BUFF_LIST<DAO_POINT*> select_points; 

    CREATE_BSET_WRAPPER();
    virtual ~CREATE_BSET_WRAPPER();

    void create(STRING , STRING , DOMAIN10_CREATE_COMMAND::KINEMATIC_ORDER, LIST<DAO_POINT*> &);
    void create(STRING name,
                STRING elset_name ,
                DOMAIN10_CREATE_COMMAND::KINEMATIC_ORDER kinematic_order,
                LIST<DAO_EDGE*> &edges);

    void set_local_name(STRING,STRING);
};
Z_END_NAMESPACE;

#endif
