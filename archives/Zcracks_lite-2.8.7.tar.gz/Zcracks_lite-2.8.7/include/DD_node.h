#ifndef __DD_NODE__
#define __DD_NODE__

#include <Buffered_list.h>
#include <Node.h>

Z_START_NAMESPACE;

class DD_SUBDOMAIN;
class DD_DOF;

ZCLASS2 DD_NODE {
  friend class DD_SUBDOMAIN;
  public :
    ARRAY<DD_DOF*> dd_dofs;
    int    global_rank,color;
    double shared;
    NODE *node;

    DD_NODE() { color=-1; global_rank=-1; shared=1.; node=NULL;}
    DD_NODE(NODE *n,int gr,double sh=1.) { color=-1; global_rank=gr; shared=sh; node=n;}
   ~DD_NODE() { }

    int nb_dof() const {return(!dd_dofs);}

    DD_DOF* get_dof(int i) const {return(dd_dofs[i]);}

    DD_DOF* operator[](int i) { return(get_dof(i)); }
    int operator!() { return(nb_dof()); }

    bool operator==(const DD_NODE &d) const{ return(global_rank==d.global_rank); }

    DD_NODE& operator=(const DD_NODE &d) {
      global_rank=d.global_rank; shared=d.shared;
      node=d.node; dd_dofs=d.dd_dofs;
      return(*this);
    }
};

Z_END_NAMESPACE;

#endif
