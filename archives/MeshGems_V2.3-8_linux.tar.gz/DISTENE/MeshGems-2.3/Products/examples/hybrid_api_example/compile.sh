gcc -I. -L.  mg-hybrid_example.c -lmg-hybrid -lmg-hexa -lmg-tetra -lmg-cadsurf -lmeshgems -lmeshgems_stubs -lm -lc  -o mg-hybrid_example.exe
