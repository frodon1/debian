#define USE_LOCAL_PHYSICAL_SIZE 0

#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>


#include <meshgems/meshgems.h>
#include <meshgems/hexa.h>

/* FOR OEM customers only, uncomment the following */
/*#include <meshgems_key_xxx.h>*/

/**
 * Let's assume that the following structure holds data that represents the input surface
 * mesh on client side.  It could be a database handle or
 * anything else containing surface mesh data. 
 * We will build the mesh_t object that accesses it.
 * See the file meshgems/mesh.h for more detailed information
 */

struct your_mesh_internal_data_t_ {
  //_your_mesh_data;
};

typedef struct your_mesh_internal_data_t_ your_mesh_internal_data_t;

/**
 * Implementation of how the number of vertices in the mesh is obtained.
 * @param[out]	nbvtx	: the number of vertices
 * @param[in]     user_data	: a user pointer.
 * @return error code
 */

status_t mgtm_get_vertex_count(integer * nbvtx, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbvtx = 0;                   //the_number_of_vertex_in_your_mesh;

  return STATUS_OK;
}

/**
 * Implementation of how the coordinates of a mesh vertex are obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	xyz	: real[3] array containing the coordinates of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */

status_t mgtm_get_vertex_coordinates(integer ivtx, real * xyz,
                                     void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    xyz[j] = 0;                 //j_th_coordinate_of_the_ivtx_th_vertex;

  return STATUS_OK;
}

/**
 * Implementation of how the number of edges in the mesh is obtained.
 * @param[out]	nbedg	: the number of edges
 * @param[in]  user_data: a user pointer.
 * @return error code
 */

status_t mgtm_get_edge_count(integer * nbedge, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbedge = 0;                  //the_number_of_edge_in_your_mesh;

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh edge are obtained.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	vedge	: integer[2] array containing the vertices of the edge
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_vertices(integer iedge, integer * vedge,
                                void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 2; j++)
    vedge[j] = 0;               //j_th_vertex_index_of_the_iedge_th_edge;

  return STATUS_OK;
}

/**
 * Implementation of how the number of triangles in the mesh is obtained.
 * @param[out]	nbtri	: the number of triangles
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_count(integer * nbtri, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbtri = 0;                   // the_number_of_triangle_in_your_mesh;

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh triangle are obtained.
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]	vtri	: integer[3] array containing the vertices of the triangle
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_vertices(integer itri, integer * vtri,
                                    void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    vtri[j] = 0;                //j_th_vertex_index_of_the_itri_th_triangle;

  return STATUS_OK;
}

/**
 * Implementation of how the number of tetrahedron in the mesh is obtained.
 * @param[out]	nbtetra	: the number of tetrahedra
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_tetrahedron_count(integer * nbtetra, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbtetra = 0;                 //the_number_of_tetra_in_your_mesh;

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh tetrahedra are obtained.
 * @param[in]	itetra	: index of the desired tetrahedra from 1 to nbtetra
 * @param[out]	vtetra	: integer[4] array containing the vertices of the tetrahedra
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_tetrahedron_vertices(integer itetra, integer * vtetra,
                                       void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 4; j++)
    vtetra[j] = 0;              // j_th_vertex_index_of_the_itetra_th_tetrahedron;

  return STATUS_OK;
}

/**
 * Implementation of how the number of volume subdomains in the mesh is obtained.
 * @param[out]	nbsub	: the number of volume subdomains
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_subdomain_count(integer * nbsub, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbsub = 1;                   //the_number_of_subdomain_in_your_mesh
}

/**
 * Implementation of how the subdomain seed description of a mesh subdomain are obtained.
 * @param[in]	isd	: index of the desired subdomain seed description from 1 to nbsd
 * @param[out]	subdomain_tag	: integer containing the tag used for the elements belonging to the subdomain
 * @param[out]	seed_type	: integer containing the subdomain seed element type of the subdomain
 * @param[out]	seed_idx	: integer containing the subdomain seed element index of the subdomain
 * @param[out]	seed_orientation: integer containing the subdomain seed element orientation of the subdomain
 *                                    (normal is assumed to point toward the inside of the subdomain). Value can be 
 *                                    MESH_ORIENTATION_FORWARD or MESH_ORIENTATION_REVERSE
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_subdomain_description(integer isd,
                                        integer * subdomain_tag,
                                        integer * seed_type,
                                        integer * seed_idx,
                                        integer * seed_orientation,
                                        void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *subdomain_tag = 0;           // the_subdomain_tag_of_the_isd_th_sudomain
  *seed_type = MESH_ELEMENT_TYPE_TRIA3; // the_seed_type_tag_of_the_isd_th_sudomain
  *seed_idx = 0;                //the_index_of_the_seed_element_for_the_isd_th_subdomain 
  *seed_orientation = MESH_ORIENTATION_FORWARD; // the_seed_orientation_of_the_isd_th_sudomain
}

struct _your_sizeatpoints_internal_data_t_ {
  // _your_sizemap_data_t_;
};

typedef struct _your_size_at_points_internal_data_t_
    your_size_at_points_internal_data_t;

status_t size_at_points_get_vertex_count(integer * nbvtx, void *user_data)
{

  your_size_at_points_internal_data_t *mm =
      (your_size_at_points_internal_data_t *) user_data;

  *nbvtx = 0;                   //the_number_of_points_in_your_sizemap;

  return STATUS_OK;
}

status_t size_at_points_get_vertex_coordinates(integer ivtx, real * xyz,
                                               void *user_data)
{

  int j;
  your_size_at_points_internal_data_t *mm =
      (your_size_at_points_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    xyz[j] = 0;                 // j_th_corrdinate_of_the_ivtx_th_vertex;

  return STATUS_OK;
}

status_t size_at_points_get_vertex_size(integer ivtx, real * svtx,
                                        void *user_data)
{

  your_size_at_points_internal_data_t *mm =
      (your_size_at_points_internal_data_t *) user_data;

  *svtx = 0;                    //size_at_the_ivtx_th_vertex;

  return STATUS_OK;
}

/**
 * This is the message callback function that Hexa will call when
 * it wants to send a message to the caller
 * see meshgems/message.h for more details.
 *
 * @param[in] msg       : the message
 * @param[in] user_data : a user pointer.
 * @return an error code
 */
status_t my_message_cb(message_t * msg, void *user_data)
{

  char *desc;
  integer e, ibuff[6];
  real r;
  status_t ret;

  /* Get the error number */
  ret = message_get_number(msg, &e);

  if (e == MESHGEMS_HEXA_CODE(-5105)) {
    /* This is the error 5105 related to points 
     * which are too close to one another or coincident.
     * Get the associated integer data [1..2]
     */
    message_get_integer_data(msg, 1, 2, ibuff);
    printf("Vertex %i and vertex %i are too close to one another \n",
           ibuff[0], ibuff[1]);

  } else if (e == MESHGEMS_HEXA_CODE(-5390)) {
    /* This is the error 5390, related to non closed input surface mesh
     */
    printf("the input mesh may not define a closed surface");
  } else {
    ret = message_get_description(msg, &desc);
    if (ret != STATUS_OK)
      return ret;

    printf("MG-Hexa message : %s", desc);
  }

  return STATUS_OK;

}

/* A macro we will call to cleanly return from the function in case of failure */
#define RETURN_WITH_MESSAGE(_ret, _msg) do{				\
    fprintf(stderr,"%s\n",_msg);					\
    if(hxs) hexa_session_delete(hxs);				\
    if(msh) mesh_delete(msh);						\
    if(sizemap) sizemap_delete(sizemap);				\
    if(ctx) context_delete(ctx);					\
    return _ret;							\
  }while(0);

status_t hexa_mesh(your_mesh_internal_data_t * your_mesh_internal_data,
                   your_size_at_points_internal_data_t *
                   your_size_at_points_internal_data)
{
  status_t ret;
  context_t *ctx;
  mesh_t *msh, *vmsh;
  hexa_session_t *hxs;
  sizemap_t *sizemap;
  mesh_t *backgroundmesh;
  integer i, nvm, nhm, ntrim;
  integer reqedg;
  integer nedg, nf;
  integer nsd;
  real q, qmin, qmax;

  ctx = NULL;
  msh = NULL;
  hxs = NULL;
  vmsh = NULL;
  sizemap = NULL;
  backgroundmesh = NULL;

  /*
   * Create the meshgems working context
   */
  ctx = context_new();
  if (!ctx)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new context");

  /*
   * Set the message callback for our context and create the mesh accessor.
   */
  ret = context_set_message_callback(ctx, my_message_cb, NULL);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /*
   * Create the mesh_t structure holding the callbacks giving acces to your mesh data in
   * your_mesh_internal_data
   */
  msh = mesh_new(ctx);
  if (!msh)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new mesh");

  /*
   * Set the mesh_t callback functions that will interogate the mm_t struct :
   * see meshgems/mesh.h for more details.
   */

  mesh_set_get_vertex_count(msh, mgtm_get_vertex_count,
                            your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_vertex_coordinates(msh, mgtm_get_vertex_coordinates,
                                  your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  mesh_set_get_edge_count(msh, mgtm_get_edge_count,
                          your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_edge_vertices(msh, mgtm_get_edge_vertices,
                             your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  mesh_set_get_triangle_count(msh, mgtm_get_triangle_count,
                              your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_triangle_vertices(msh, mgtm_get_triangle_vertices,
                                 your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  mesh_set_get_subdomain_count(msh, mgtm_get_subdomain_count,
                               your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  mesh_set_get_subdomain_description(msh, mgtm_get_subdomain_description,
                                     your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");


  /*
   * Optionnal : create a sizemap to hold the size specification for mesh vertices.
   */
  if (USE_LOCAL_PHYSICAL_SIZE) {

    backgroundmesh = mesh_new(ctx);

    if (!backgroundmesh) {
      RETURN_WITH_MESSAGE(ret, "unable to create a new mesh ");
    }

    mesh_set_get_vertex_count(backgroundmesh,
                              size_at_points_get_vertex_count,
                              your_size_at_points_internal_data);
    mesh_set_get_vertex_coordinates(backgroundmesh,
                                    size_at_points_get_vertex_coordinates,
                                    your_size_at_points_internal_data);

    sizemap = sizemap_new(backgroundmesh,
                          meshgems_sizemap_type_iso_mesh_vertex,
                          (void *) size_at_points_get_vertex_size,
                          your_size_at_points_internal_data);

    if (!sizemap)
      RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new mesh");
  }

  if (0) {
    /*
     * Display some statistics about the surface mesh.
     * The data is sent formated to the context message callback
     * For debugging purposes
     */
    mesh_compute_statistics(msh);
  }
#ifdef __MESHGEMS_PRIVKEY_H__
  /* If you are an OEM customer for MG-HEXA, sign this mesh object with
   * your private key (else MG-HEXA would reject it) */
  ret = meshgems_sign_mesh(msh);
  if (ret != STATUS_OK)
    return ret;
#endif

  /*
   * Create an hexa session
   */

  hxs = hexa_session_new(ctx);
  if (!hxs)
    RETURN_WITH_MESSAGE(STATUS_NOMEM,
                        "unable to create a new hexa session");

  /*
   * Set the input working surface or volume mesh for this hexa session
   */

  /*
   * Starting from a surface mesh.
   * The sizemap is optionnal in this case.
   */
  ret = hexa_set_surface_mesh(hxs, msh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to set surface mesh");

  if (sizemap) {
    /* Sizemap is optionnal here */
    ret = hexa_set_sizemap(hxs, sizemap);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to set surface sizemap");
  }

  /* You can here specify the MG-HEXA options, using the function
   * hexa_set_param(), see the documentation.
   */
  if (0) {
    /* For example, here are some MG-HEXA options. 
     * See the documentation for the complete list of options.
     */

    /* This option changes the verbosity level of Hexa, between 1 and
     * 10.  The higher it is, the more messages Hexa will send
     * through the message callback. Default is 3.
     */
    ret = hexa_set_param(hxs, "verbose", "3");
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "internal error");

    /* Set this parameter to all if you want all connex component to be
     * meshed or to outside_components if you only want the main one.
     * default is all
     */
    ret = hexa_set_param(hxs, "component", "all");
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "internal error");

    /* Set the desired minimal_size
     */
    ret = hexa_set_param(hxs, "min_size", "1.05");
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "internal error");

    /* Set the desired maximal_size
     */
    ret = hexa_set_param(hxs, "max_size", "2.05");
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "internal error");

    /* To use the optional sizemap
     */
    if (USE_LOCAL_PHYSICAL_SIZE) {
      ret = hexa_set_param(hxs, "physical_size_mode", "local");
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret, "internal error");
    }
  }

  /* To compute volume mesh */
  ret = hexa_compute_volume_mesh(hxs);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to compute a volume mesh");
  /*
   * Mesh generation is completed.
   * Get the generated volume mesh. This output mesh belongs to the
   * hexa_session. Thus the user does not have to destroy it
   * afterwards.
   */

  ret = hexa_get_mesh(hxs, &vmsh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting mesh");

  /*
   * Read the output mesh data. See meshgems/mesh.h for more details.
   */

  /* First get all the vertices */
  ret = mesh_get_vertex_count(vmsh, &nvm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex count");

  ret = mesh_get_hexahedron_count(vmsh, &nhm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting hexahedron count");

  for (i = 1; i <= nvm; i++) {
    real coo[3];
    ret = mesh_get_vertex_coordinates(vmsh, i, coo);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting vertices");
    if (0) {
      fprintf(stdout, "vertex %d is : %f %f %f \n", i, coo[0], coo[1],
              coo[2]);
    }
  }

  /* Then get all the hexahedra and compute some statistics on their aspect ratio */

  qmin = REAL_INFINITY;
  qmax = -REAL_INFINITY;

  for (i = 1; i <= nhm; i++) {
    integer vtx[8], tag;
    ret = mesh_get_hexahedron_vertices(vmsh, i, vtx);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting hexahedra");
    if (0) {
      fprintf(stdout, "hexa %d is : %d %d %d %d \n", i, vtx[0], vtx[1],
              vtx[2], vtx[3], vtx[4], vtx[5], vtx[6], vtx[7]);
    }
    ret = mesh_get_hexahedron_tag(vmsh, i, &tag);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting hexahedra tag");
    if (0) {
      fprintf(stdout, "hexa %d is in subdomain %d\n", i, tag);
    }
    mesh_get_hexahedron_aspect_ratio(vmsh, i, &q);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "internal error");
    if (q > qmax)
      qmax = q;
    if (q < qmin)
      qmin = q;
  }

  fprintf(stdout, "\nGenerated %d vertices and %d hexahedra  \n", nvm,
          nhm);
  fprintf(stdout, "          with a quality within [%f,%f]\n", qmin, qmax);

  /*
   * We can also directly write a .mesh formatted file :
   */

  fprintf(stdout, "Writing volume mesh in output_hexa.mesh file\n");
  ret = mesh_write_mesh(vmsh, "output_hexa.mesh");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a .mesh file");

  if (1) {
    /*
     * Display some statistics about the output mesh.
     * The data is sent formated to the context message callback
     * for debugging purposes.
     */
    mesh_compute_statistics(vmsh);
  }

  /*
   * We are done, give the volume mesh back to the session and clean up everything.
   */

  hexa_regain_mesh(hxs, vmsh);
  hexa_session_delete(hxs);
  mesh_delete(msh);
  if (sizemap)
    sizemap_delete(sizemap);

  context_delete(ctx);

  return STATUS_OK;
}
