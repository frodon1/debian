#ifndef __ZeBMARC__
#define __ZeBMARC__

typedef double real; 

#include <Stringpp.h> 
#include <Behavior.h> 
#include <Mat_data.h> 
#include <Zmat_class.h>

extern "C" {
#ifdef HPUX 
void quit(
#elif defined AIX
void quit(
#else 
void quit_(
#endif
      int* _code   		
);
}

extern "C" {
#ifdef HPUX 
void zebmarc(
#elif defined AIX
void zebmarc(
#else 
void zebmarc_(
#endif
      real* , // young[], 	// 1.1
      real* , // poiss[], 	// 1.2
      real* , // shear[], 	// 1.3
      real* bmat,  	        // 1.4
      real* ustrrt,    		// 1.5
      real* stran, 		// 1.6
      real* dstran,    		// 1.7
      real* thmsti,    		// 1.8
      real* , // eelas[], 	// 1.9

      real* stress,   		// 2.1
      real* sinc,   		// 2.2
      real* , // gf[], 	        // 2.3
      real* , // epl[]	        // 2.4
      real* avgine,    		// 2.5
      real* , // eqcr	        // 2.6
      real* , // eqcpnc	        // 2.7
      real* , // yd	        // 2.8
      real* , // yd1	        // 2.9
      real* , // vscpar[]	// 2.10

      real* dt,   		// 3.1
      real* dtdl,   		// 3.2
      real* time, 		// 3.3
      real* dtime, 		// 3.4
      real* , // xintp[]	// 3.5
      int* _ntens, 		// 3.6
      int* , // m	        // 3.7
      int* , // nn	        // 3.8
      int* , // kc	        // 3.9
      int* , // mat	        // 3.10
 
      int* _ndi, 		// 4.1
      int* _nshr , 	        // 4.2
      int* , // ncrd	        // 4.3 
      int* , // ianiso	        // 4.4 
      int* _nstatv,    		// 4.5
      int* , // inc   	        // 4.6 
      int* _ncycle,    		// 4.7
      int* , // lovl 	        // 4.8 

      int* , // nvsplm 	        // 5.1 
      char* cmname		// 5.2
);
}

Z_START_NAMESPACE;

ZCLASS ZMARC_HANDLER {
  public :
    double First_Time;
    STRING cmname;
    int issued_size_message;
    int warn_diverge;
    int finite_strain;
    int save_energies;
    int needs_temperature;
    int use_tangent;
    int print_debug,use_local_debug,debug_ele,debug_gp;

    int zero_stress,zero_strain;
    
    BEHAVIOR* behavior;
    MAT_DATA mdat;

    AUTO_PTR<LOCAL_FRAME> rotation;

    //
    // Initial values
    //
    LIST<STRING> initial_vars;
    LIST<double> initial_vals;
    
    // 
    // state_var_shear_alter is the transform for shear components in vint, vaux. 
    // if it is M_SQRT2 the output uses engineering shear.. (i.e. ein12*2)
    // if it is 1.0/M_SQRT2 you get what zebulon gives - the real component
    // The default is engineering shear to be consistant with sig and eto 
    // which cannot be adjusted. 
    // 
    double       state_var_shear_alter; 
    LIST<int>    vint_sqrt2_pos; 
    LIST<int>    vaux_sqrt2_pos; 

    //
    //  Stuff for auto time stepping
    //
    LIST<STRING> limit_vars;
    LIST<double> limit_vals;
    double       security;
    double       divergence;

    int flux_position, flux_size; 
    int grad_position, grad_size; 

    VECTOR keep_flux; 
    VECTOR grad0; 
    VECTOR dgrad; 

    MATRIX tg_tmp;

    int is_shell; 

    ZMARC_HANDLER();
};

Z_END_NAMESPACE;
#endif
