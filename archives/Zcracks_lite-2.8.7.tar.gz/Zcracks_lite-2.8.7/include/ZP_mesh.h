#ifndef __ZP_MESH__
#define __ZP_MESH__

#include <ZP_stack.h>
#include <Mesh.h>
#include <ZP_object.h>
#include <ZP_type.h>

#include <ZP_int.h>
#include <ZP_double.h>
#include <ZP_stack.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_MESH : public ZP_TYPE< MESH >
{
  protected :
    virtual ZP_FATAL_ERROR* print(ZP_STACK&) { return(0); }

    ZP_FATAL_ERROR* assign(ZP_STACK&,int);
    void type_init(char*) { type="MESH"; }

    ZP_FATAL_ERROR* nb_dof(ZP_STACK&,int);
    ZP_FATAL_ERROR* nb_node(ZP_STACK&,int);
    ZP_FATAL_ERROR* get_dof(ZP_STACK&,int);
    ZP_FATAL_ERROR* get_dof_elset(ZP_STACK&,int);
    ZP_FATAL_ERROR* get_node(ZP_STACK&,int);
    ZP_FATAL_ERROR* get_element(ZP_STACK&,int);
    ZP_FATAL_ERROR* find_nset(ZP_STACK&,int);
    ZP_FATAL_ERROR* find_elset(ZP_STACK&,int);
    ZP_FATAL_ERROR* find_bset(ZP_STACK&,int);

  public :
    CONSTRUCTORS(ZP_MESH,MESH);

    METHOD_DECLARATION_START
      METHOD("get_dof_elset",get_dof_elset,2)
      METHOD("get_dof",get_dof,1)
      METHOD("get_node",get_node,1)
      METHOD("get_element",get_element,1)
      METHOD("nb_node",nb_node,0)
      METHOD("nb_dof",nb_dof,0)
      METHOD("find_nset",find_nset,1)
      METHOD("find_elset",find_elset,1)
      METHOD("find_bset",find_bset,1)
    METHOD_DECLARATION_ANCESTOR(ZP_TYPE< MESH >)

    ZPO_RTTI_INFO(MESH)
};
Z_END_NAMESPACE;

#endif
