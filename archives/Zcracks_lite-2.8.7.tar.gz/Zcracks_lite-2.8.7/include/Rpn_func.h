#ifndef SKIP_STD_FUNCTION

#ifndef __Rpn_func__
#define __Rpn_func__

#include <Func_defs.h>
#include <Stringpp.h>

Z_START_NAMESPACE;

ZCLASS RPN_FUNC {
  public :
    STRING name;
    int nb_var;
    int built_in;
    int rk;
    double *value;
    f_numeric F;

    RPN_FUNC() : name("no name"),nb_var(-1), built_in(-1), rk(-1), value(NULL), F(NULL) {}
   ~RPN_FUNC() { }
};

Z_END_NAMESPACE;
#endif
#endif
