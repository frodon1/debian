#ifndef __WRAPPER_HELPER__
#define __WRAPPER_HELPER__

Z_START_NAMESPACE;

#define START_ACCESS(aclass) ZP_FATAL_ERROR* aclass :: acess(STRING &member, ZP_STACK &stack, bool resolv) { \
  AUTO_PTR<ZP_OBJECT> zpo; if(FALSE) { } \

#define END_ACCESS(aclass) else { if(resolv) return(NULL); \
  ZP_ISSUE_FATAL_ERROR("member "+member+" is not part of type "+#aclass); } return(NULL); }

#define CAST_MEMBER(aname,atype) else if(member == #aname) { if(resolv) ZP_ISSUE_RESOLVED ; \
  zpo=new ZP_##atype(& ( atype & ) aname); stack.add(zpo); }

#define MEMBER(aname,atype) else if(member == #aname) { if(resolv) ZP_ISSUE_RESOLVED ; \
  zpo=new ZP_##atype(& aname); stack.add(zpo); }

#define P_MEMBER(aname,atype) else if(member == #aname) { if(resolv) ZP_ISSUE_RESOLVED ; \
  zpo=new ZP_##atype(& aname); stack.add(zpo); }

#define START_METHOD(aclass,amethod) ZP_FATAL_ERROR* aclass :: amethod(ZP_STACK &stack, int nb_params) { int tot; if(FALSE) { } 

#define END_METHOD(aclass,amethod) else TYPE_MISMATCH_ERROR( #amethod ); return(NULL); }

#define CASE_PARAM_0(amethod) \
  else if(nb_params==0) { tot=0; return(get(). amethod (stack)); }

#define CASE_PARAM_1(amethod,atype) \
  else if(nb_params==1 && stack[!stack-1]->CheckType( #atype )) { \
    tot=!stack-1; \
    atype * v_##atype; v_##atype= & ZP_##atype :: cast(stack[tot]); tot++; \
    ZP_FATAL_ERROR* _ret=get(). amethod ( stack , v_##atype ); \
    for(int i=0;i<1;i++) stack.pop(); \
    return(_ret); \
  }

#define CASE_PARAM_2(amethod,atype1,atype2) \
  else if(nb_params==2 && stack[!stack-2]->CheckType( #atype1) && stack[!stack-1]->CheckType( #atype2 ) ) { \
    tot=!stack-2; \
    atype1 * v1_##atype1; v1_##atype1= & ZP_##atype1 :: cast(stack[tot]); tot++; \
    atype2 * v2_##atype2; v2_##atype2= & ZP_##atype2 :: cast(stack[tot]); tot++; \
    ZP_FATAL_ERROR *_ret=get(). amethod ( stack , v1_##atype1 , v2_##atype2 ); \
    for(int i=0;i<2;i++) stack.pop(); \
    return(_ret); \
  }

#define CASE_PARAM_3(amethod,atype1,atype2,atype3) \
  else if(nb_params==3 && stack[!stack-3]->CheckType( #atype1 ) && stack[!stack-2]->CheckType( #atype2 ) \
          && stack[!stack-1]->CheckType( #atype3 ) ) { \
    tot=!stack-3; \
    atype1 * v1_##atype1; v1_##atype1= & ZP_##atype1 :: cast(stack[tot]); tot++; \
    atype2 * v2_##atype2; v2_##atype2= & ZP_##atype2 :: cast(stack[tot]); tot++; \
    atype3 * v3_##atype3; v3_##atype3= & ZP_##atype3 :: cast(stack[tot]); tot++; \
    ZP_FATAL_ERROR *_ret=get(). amethod ( stack , v1_##atype1 , v2_##atype2 , v3_##atype3 ); \
    for(int i=0;i<3;i++) stack.pop(); \
    return(_ret); \
  }

#define CASE_PARAM_4(amethod,atype1,atype2,atype3,atype4) \
  else if(nb_params==4 && stack[!stack-4]->CheckType( #atype1 ) && stack[!stack-3]->CheckType ( #atype2 ) \
          && stack[!stack-2]->CheckType( #atype3 ) && stack[!stack-1]->CheckType( #atype4 ) ) { \
    tot=!stack-4; \
    atype1 * v1_##atype1; v1_##atype1= & ZP_##atype1 :: cast(stack[tot]); tot++; \
    atype2 * v2_##atype2; v2_##atype2= & ZP_##atype2 :: cast(stack[tot]); tot++; \
    atype3 * v3_##atype3; v3_##atype3= & ZP_##atype3 :: cast(stack[tot]); tot++; \
    atype4 * v4_##atype4; v4_##atype4= & ZP_##atype4 :: cast(stack[tot]); tot++; \
    ZP_FATAL_ERROR *_ret=get(). amethod ( stack , v1_##atype1 , v2_##atype2 , v3_##atype3 , v4_##atype4); \
    for(int i=0;i<4;i++) stack.pop(); \
    return(_ret); \
  }

#define CASE_PARAM_5(amethod,atype1,atype2,atype3,atype4,atype5) \
    else if(nb_params==5 && stack[!stack-5]->CheckType( #atype1 ) && stack[!stack-4]->CheckType( #atype2 ) \
          && stack[!stack-3]->CheckType( #atype3 ) && stack[!stack-2]->CheckType( #atype4 ) \
          && stack[!stack-1]->CheckType( #atype5) ) { \
    tot=!stack-5; \
    atype1 * v1_##atype1; v1_##atype1= & ZP_##atype1 :: cast(stack[tot]); tot++; \
    atype2 * v2_##atype2; v2_##atype2= & ZP_##atype2 :: cast(stack[tot]); tot++; \
    atype3 * v3_##atype3; v3_##atype3= & ZP_##atype3 :: cast(stack[tot]); tot++; \
    atype4 * v4_##atype4; v4_##atype4= & ZP_##atype4 :: cast(stack[tot]); tot++; \
    atype5 * v5_##atype5; v5_##atype5= & ZP_##atype5 :: cast(stack[tot]); tot++; \
    ZP_FATAL_ERROR *_ret=get(). amethod ( stack , v1_##atype1 , v2_##atype2 , v3_##atype3 , v4_##atype4 , v5_##atype5); \
    for(int i=0;i<5;i++) stack.pop(); \
    return(_ret); \
  }

#define CASE_PARAM_6(amethod,atype1,atype2,atype3,atype4,atype5,atype6) \
    else if(nb_params==6 && stack[!stack-6]->CheckType( #atype1 ) && stack[!stack-5]->CheckType( #atype2 ) \
          && stack[!stack-4]->CheckType( #atype3 ) && stack[!stack-3]->CheckType( #atype4 ) \
          && stack[!stack-2]->CheckType( #atype5 ) && stack[!stack-1]->CheckType( #atype6 ) ) { \
    tot=!stack-6; \
    atype1 * v1_##atype1; v1_##atype1= & ZP_##atype1 :: cast(stack[tot]); tot++; \
    atype2 * v2_##atype2; v2_##atype2= & ZP_##atype2 :: cast(stack[tot]); tot++; \
    atype3 * v3_##atype3; v3_##atype3= & ZP_##atype3 :: cast(stack[tot]); tot++; \
    atype4 * v4_##atype4; v4_##atype4= & ZP_##atype4 :: cast(stack[tot]); tot++; \
    atype5 * v5_##atype5; v5_##atype5= & ZP_##atype5 :: cast(stack[tot]); tot++; \
    atype6 * v6_##atype6; v6_##atype6= & ZP_##atype6 :: cast(stack[tot]); tot++; \
    ZP_FATAL_ERROR *_ret=get(). amethod ( stack , v1_##atype1 , v2_##atype2 , v3_##atype3 , v4_##atype4 , v5_##atype5 , v6_##atype6); \
    for(int i=0;i<6;i++) stack.pop(); \
    return(_ret); \
  }

#define CASE_PARAM_7(amethod,atype1,atype2,atype3,atype4,atype5,atype6,atype7) \
    else if(nb_params==7 && stack[!stack-7]->CheckType( #atype1 ) && stack[!stack-6]->CheckType( #atype2 ) \
          && stack[!stack-5]->CheckType( #atype3 ) && stack[!stack-4]->CheckType( #atype4 ) \
          && stack[!stack-3]->CheckType( #atype5 ) && stack[!stack-2]->CheckType( #atype6 ) \
          && stack[!stack-1]->CheckType( #atype7)) { \
    tot=!stack-7; \
    atype1 * v1_##atype1; v1_##atype1= & ZP_##atype1 :: cast(stack[tot]); tot++; \
    atype2 * v2_##atype2; v2_##atype2= & ZP_##atype2 :: cast(stack[tot]); tot++; \
    atype3 * v3_##atype3; v3_##atype3= & ZP_##atype3 :: cast(stack[tot]); tot++; \
    atype4 * v4_##atype4; v4_##atype4= & ZP_##atype4 :: cast(stack[tot]); tot++; \
    atype5 * v5_##atype5; v5_##atype5= & ZP_##atype5 :: cast(stack[tot]); tot++; \
    atype6 * v6_##atype6; v6_##atype6= & ZP_##atype6 :: cast(stack[tot]); tot++; \
    atype7 * v7_##atype7; v7_##atype7= & ZP_##atype7 :: cast(stack[tot]); tot++; \
    ZP_FATAL_ERROR *_ret=get(). amethod ( stack , v1_##atype1 , v2_##atype2 , v3_##atype3 , v4_##atype4 , v5_##atype5 , \
                             v6_##atype6 , v7_##atype7); \
    for(int i=0;i<7;i++) stack.pop(); \
    return(_ret); \
  }

#define CASE_PARAM_8(amethod,atype1,atype2,atype3,atype4,atype5,atype6,atype7,atype8) \
    else if(nb_params==8 && stack[!stack-8]->CheckType( #atype1 ) && stack[!stack-7]->CheckType( #atype2 ) \
          && stack[!stack-6]->CheckType( #atype3 ) && stack[!stack-5]->CheckType( #atype4 ) \
          && stack[!stack-4]->CheckType( #atype5 ) && stack[!stack-3]->CheckType( #atype6 ) \
          && stack[!stack-2]->CheckType( #atype7 ) && stack[!stack-1]->CheckType( #atype8 ) ) { \
    tot=!stack-8; \
    atype1 * v1_##atype1; v1_##atype1= & ZP_##atype1 :: cast(stack[tot]); tot++; \
    atype2 * v2_##atype2; v2_##atype2= & ZP_##atype2 :: cast(stack[tot]); tot++; \
    atype3 * v3_##atype3; v3_##atype3= & ZP_##atype3 :: cast(stack[tot]); tot++; \
    atype4 * v4_##atype4; v4_##atype4= & ZP_##atype4 :: cast(stack[tot]); tot++; \
    atype5 * v5_##atype5; v5_##atype5= & ZP_##atype5 :: cast(stack[tot]); tot++; \
    atype6 * v6_##atype6; v6_##atype6= & ZP_##atype6 :: cast(stack[tot]); tot++; \
    atype7 * v7_##atype7; v7_##atype7= & ZP_##atype7 :: cast(stack[tot]); tot++; \
    atype8 * v8_##atype8; v8_##atype8= & ZP_##atype8 :: cast(stack[tot]); tot++; \
    ZP_FATAL_ERROR *_ret=get(). amethod ( stack , v1_##atype1 , v2_##atype2 , v3_##atype3 , v4_##atype4 , v5_##atype5 , \
                             v6_##atype6 , v7_##atype7 , v8_##atype8); \
    for(int i=0;i<8;i++) stack.pop(); \
    return(_ret); \
  }

#define CASE_PARAM_9(amethod,atype1,atype2,atype3,atype4,atype5,atype6,atype7,atype8,atype9) \
    else if(nb_params==9 && stack[!stack-9]->CheckType( #atype1 ) && stack[!stack-8]->CheckType( #atype2 ) \
          && stack[!stack-7]->CheckType( #atype3 ) && stack[!stack-6]->CheckType( #atype4 ) \
          && stack[!stack-5]->CheckType( #atype5 ) && stack[!stack-4]->CheckType( #atype6 ) \
          && stack[!stack-3]->CheckType( #atype7 ) && stack[!stack-2]->CheckType( #atype8 ) \
          && stack[!stack-1]->CheckType( #atype9 ) ) { \
    tot=!stack-9; \
    atype1 * v1_##atype1; v1_##atype1= & ZP_##atype1 :: cast(stack[tot]); tot++; \
    atype2 * v2_##atype2; v2_##atype2= & ZP_##atype2 :: cast(stack[tot]); tot++; \
    atype3 * v3_##atype3; v3_##atype3= & ZP_##atype3 :: cast(stack[tot]); tot++; \
    atype4 * v4_##atype4; v4_##atype4= & ZP_##atype4 :: cast(stack[tot]); tot++; \
    atype5 * v5_##atype5; v5_##atype5= & ZP_##atype5 :: cast(stack[tot]); tot++; \
    atype6 * v6_##atype6; v6_##atype6= & ZP_##atype6 :: cast(stack[tot]); tot++; \
    atype7 * v7_##atype7; v7_##atype7= & ZP_##atype7 :: cast(stack[tot]); tot++; \
    atype8 * v8_##atype8; v8_##atype8= & ZP_##atype8 :: cast(stack[tot]); tot++; \
    atype9 * v9_##atype9; v9_##atype9= & ZP_##atype9 :: cast(stack[tot]); tot++; \
    ZP_FATAL_ERROR *_ret=get(). amethod ( stack , v1_##atype1 , v2_##atype2 , v3_##atype3 , v4_##atype4 , v5_##atype5 , \
                             v6_##atype6 , v7_##atype7 , v8_##atype8 , v9_##atype9); \
    for(int i=0;i<9;i++) stack.pop(); \
    return(_ret); \
  }

#define CASE_PARAM_10(amethod,atype1,atype2,atype3,atype4,atype5,atype6,atype7,atype8,atype9,atype10) \
    else if(nb_params==10 && stack[!stack-10]->CheckType( #atype1 ) && stack[!stack-9]->CheckType( #atype2 ) \
          && stack[!stack-8]->CheckType( #atype3 ) && stack[!stack-7]->CheckType( #atype4 ) \
          && stack[!stack-6]->CheckType( #atype5 ) && stack[!stack-5]->CheckType( #atype6 ) \
          && stack[!stack-4]->CheckType( #atype7 ) && stack[!stack-3]->CheckType( #atype8 ) \
          && stack[!stack-2]->CheckType( #atype9 ) && stack[!stack-1]->CheckType( #atype10) ) { \
    tot=!stack-10; \
    atype1 * v1_##atype1; v1_##atype1= & ZP_##atype1 :: cast(stack[tot]); tot++; \
    atype2 * v2_##atype2; v2_##atype2= & ZP_##atype2 :: cast(stack[tot]); tot++; \
    atype3 * v3_##atype3; v3_##atype3= & ZP_##atype3 :: cast(stack[tot]); tot++; \
    atype4 * v4_##atype4; v4_##atype4= & ZP_##atype4 :: cast(stack[tot]); tot++; \
    atype5 * v5_##atype5; v5_##atype5= & ZP_##atype5 :: cast(stack[tot]); tot++; \
    atype6 * v6_##atype6; v6_##atype6= & ZP_##atype6 :: cast(stack[tot]); tot++; \
    atype7 * v7_##atype7; v7_##atype7= & ZP_##atype7 :: cast(stack[tot]); tot++; \
    atype8 * v8_##atype8; v8_##atype8= & ZP_##atype8 :: cast(stack[tot]); tot++; \
    atype9 * v9_##atype9; v9_##atype9= & ZP_##atype9 :: cast(stack[tot]); tot++; \
    atype0 * v0_##atype0; v0_##atype0= & ZP_##atype0 :: cast(stack[tot]); tot++; \
    ZP_FATAL_ERROR *_ret=get(). amethod ( stack , v1_##atype1 , v2_##atype2 , v3_##atype3 , v4_##atype4 , v5_##atype5 , \
                             v6_##atype6 , v7_##atype7 , v8_##atype8 , v9_##atype9 , v0_##atype0); \
    for(int i=0;i<10;i++) stack.pop(); \
    return(_ret); \
  }
Z_END_NAMESPACE;

#endif
