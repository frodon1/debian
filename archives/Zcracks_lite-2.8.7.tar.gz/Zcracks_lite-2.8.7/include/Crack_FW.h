#ifndef __CRACK_FW__
#define __CRACK_FW__

#include <Vector.h>
#include <Matrix.h>
#include <List.h>
#include <Stringpp.h>

#include <Element.h>
#include <Crack_FE.h>
#include <Crack_FG.h>
#include <Crack_FS.h>
#include <Crack_FC.h>
#include <Crack_FV.h>
#include <Node.h>
#include <B3Splines_field.h>
#include <CFV_build.h>
#include <BB_tree_utility_mesh.h>

Z_START_NAMESPACE;


class CRACK_FE;
class CRACK_FV;
class CRACK_FS;

class CRACK_FW : public Z_OBJECT 
{
  private :
    int _dim;
    int _nb_ddl;

  public :

    CRACK_FC *front;
    CRACK_FV *volume;
    CRACK_FS *surface;

    LIST<NODE*> node_liset;	// nodes in liset (ordered) 
    LIST<VECTOR> node;	// node coordinates of the spline (first and last one for computation only)

    void erase();

    void compute_K(int mode, double &K_value);

    CRACK_FW() ;
    ~CRACK_FW() { this->erase(); }

};
Z_END_NAMESPACE;

#endif
