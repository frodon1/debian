#ifndef __Xfem_utility_elements__
#define __Xfem_utility_elements__

#include <Utility_elements.h> 
#include <Std_utility_element.h> 

Z_START_NAMESPACE;

ZCLASS2 XFEM_UTILITY_ELEMENT : public UTILITY_ELEMENT {
  public :
    VECTOR raw_values;

    XFEM_UTILITY_ELEMENT(); 
    XFEM_UTILITY_ELEMENT(const XFEM_UTILITY_ELEMENT& in); 
    virtual ~XFEM_UTILITY_ELEMENT() { } 

    virtual void local_draw(GRAPHICS_AREA* ga);
    virtual void run_face_setup(int force_setup=0);
    virtual void run_face_setup_disp(const ARRAY<VECTOR>& disp, double mag);

    virtual void set_ctnod(ARRAY<int>& markers, VECTOR& values);
 // virtual void set_ctele(VECTOR& values, int& index);
 // virtual void set_integ(VECTOR& values, int& index);

    virtual int  num_contour_vals()const; 
    virtual void report_to_inside_faces(const ARRAY<UTILITY_BOUNDARY>&) {}

    RTTI_INFO;
};

Z_END_NAMESPACE;

#endif 
