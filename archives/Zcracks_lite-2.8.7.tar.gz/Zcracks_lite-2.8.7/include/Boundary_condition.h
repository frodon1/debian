#ifndef __Boundary_condition__
#define __Boundary_condition__

#include <Base_restart_defines.h>

#include <Hierarchy.h>
#include <Object_factory.h>
#include <Stringpp.h>
#include <Table_handler.h>
#include <Base_problem.h>
#include <Dof.h>
#include <Ask.h>

Z_START_NAMESPACE;

class GLOBAL_MATRIX; 
class MESH; 
class NODE; 
class PROBLEM;

ZCLASS2 BC : public virtual BASE_VALUE_HANDLER {
  protected :
    LIST<STRING>   group_name;
    bool has_limit; 
    double from, to;
    

    virtual bool support_constant_value()const;
    virtual void _update(MESH&)=0;

    double  ramp_time;
    double  ramp_st_time;

  public :
    enum KIND { UNKNOWN=0 , PRIMAL=1 , DUAL=2 , MIXED=4 };

    PROBLEM* its_boss; 

    BC();
    virtual ~BC();

    virtual void load(ASCII_FILE&,PROBLEM&,int ipc)=0;
    virtual bool declare_data(AUTO_PTR<AID_PART>&);

    bool if_active()const;
    void update(MESH&);
    virtual void mesh_will_change(MESH&) { } // Called during remeshing if the mesh is going to change
    virtual void mesh_changed(MESH&) { } // Called during remeshing if the mesh changed
    virtual void after_mesh_setup(MESH&) { }
    virtual void add_stiffness_and_residual_contribution(GLOBAL_MATRIX*,VECTOR&);
    virtual void add_damping_contribution(double coeff, GLOBAL_MATRIX* C);
    virtual void add_residual_contribution(double coeff, VECTOR &R, VECTOR& veloc);


    virtual void reinit(MESH*);
    virtual void read_restart(RST_FSTREAM&);
    virtual void write_restart(RST_FSTREAM&);
    
    virtual KIND kind() { return(UNKNOWN); }
    virtual STRING applied_on() { return(""); }
    
    virtual bool verification();
 
    bool has_activity_switch;
    bool activity_switch;

    STRING diagnostic_header; //< a synthetic information on the BC, like the total force it added to the system
    VECTOR diagnostic_value;  //< its output is activated with the ***bc_diagnostic command

    // 
    // Either reduces or releases according to the values of 
    // ramp_time ramp_st_time.. you have to set that up. 
    // 
    void ramp_off_ndof(DOF_TYPE *type, VECTOR& start_vals, ARRAY<NODE*>& nodes); 

    void set_limit(double,double);

    LIST<STRING> &get_group_name() { return(group_name); }

    DECLARE_ASK;
    DERIVED;
};

Z_END_NAMESPACE;

#endif
