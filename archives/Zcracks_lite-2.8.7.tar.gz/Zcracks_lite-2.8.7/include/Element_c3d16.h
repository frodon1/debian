#ifndef __GF_Q6LQ__
#define __GF_Q6LQ__

// ========================================================================
// April 2004 N.C. Fix some bugs
//
// error when using c3d16 element => no geometry info
// pbs in the orientation of the face (need to add check_orientation
//             face ).
//
// N.G.and  N.C. 03 06 06
//    Move the declaration of GF_Q6LQ to use it in Element_c3d12.c
// ========================================================================

#include <Array.h>
#include <Object_factory.h>
#include <Utility_elements.h>
#include <Utility_boundary.h>
#include <GeomSpace.h>
#include <Print.h>
#include <Graphics_area.h>
#include <Graphics_face.h>
#include <Verbose.h>
#include <Vector.h>
#include <Global_parameter.h>
#include <P_container.h>

#include <Integration_point_computer.h>
#include <Layer_geom_info.h>

#include <Graphics_view_manager.h>

Z_START_NAMESPACE;

#define __STD_FACES__ { if(!faces) { elem_faces=faces; return; } }
#define pt(rank) (nodes[rank]->position)

inline static double dot_product(const VECTOR& v1, const VECTOR& v2) { return v1|v2; }

class GF_Q6LQ : public GRAPHICS_FACE
{
// A specific graphics face which knows how to draw multilayred .integ results
  protected :
    int nbg;

  public :
    GF_Q6LQ() : GRAPHICS_FACE() { nbg=0; }
    virtual ~GF_Q6LQ() { }
    void set_nbg(int i) {
      nbg=i;
    }
    virtual void paint_integ_face(GRAPHICS_AREA&);

    // These two are absolutely necessary, otherwise the one from GRAPHICS_FACE
    // will be used, causing a wrong memory space length to be allocated for any
    // new GF_Q6LQ operation
    void* operator new(size_t t) { return (void*)::new char[t]; }
    void  operator delete(void* oo) { delete[]((char*)oo); }

    RTTI_INFO;
};

class C3D16_L_UTILITY_ELEMENT : public UTILITY_ELEMENT {
  protected :
    int active_layer,nb_layer,nb_gauss_layer,nb_gp_tot;
    int nb_surface_gauss;
    bool g_faces_inited;
    LAYER_GEOM_INFO *its_info;

  public :
    C3D16_L_UTILITY_ELEMENT() : UTILITY_ELEMENT() { space_dim=3; g_faces_inited=FALSE; its_info=NULL; }
    C3D16_L_UTILITY_ELEMENT(const C3D16_L_UTILITY_ELEMENT& in) : UTILITY_ELEMENT(in) { 
      num_gp=0;
      active_layer=nb_layer=nb_gauss_layer=nb_gp_tot=-1;
      g_faces_inited=FALSE;
    }

    virtual ~C3D16_L_UTILITY_ELEMENT() {
      active_layer=-1;
    }

    virtual void initialize(const STRING& t) {
      UTILITY_ELEMENT::initialize(t);
      nodes.resize(16);
      num_gp=0;
      active_layer=nb_layer=nb_gauss_layer=nb_gp_tot=-1;
    }

    bool set_info() {
      if(its_info) return(TRUE);
      // if(!g_info) { ERROR("No geometry info ?"); return(FALSE); }
      if(!g_info) {return(FALSE); }
      if(!g_info->__are_you_a("LAYER_GEOM_INFO")) { ERROR("Bad geometry info"); return(FALSE); }
      its_info=(LAYER_GEOM_INFO*)g_info; return(TRUE);
    }

    virtual UTILITY_ELEMENT* element_copy_self();
    virtual UTILITY_ELEMENT* copy_to_linear(ARRAY<UTILITY_NODE*>& rem);

    virtual void build_gp_position();
    virtual void get_element_axis(ARRAY<VECTOR>&);
//    virtual void get_information_for_layer(VECTOR&);
    virtual void invert_element(int axe_number);
    virtual void add_bsets(B_UTILITY_SET&, BUFF_LIST<UTILITY_NODE*>&);
    virtual ARRAY<UTILITY_BOUNDARY>& get_faces();

    virtual int   num_contour_vals()const;
    virtual void  set_ctnod(ARRAY<int>& markers, VECTOR& values);
    virtual void set_integ(VECTOR& values, int& index);
    virtual void set_integ_skin(VECTOR& values, int& index);

    void* operator new(size_t t) { return(::new char[t]); }
    void  operator delete(void* oo) { delete[]((char*)oo); }            

    virtual bool do_command(STRING);

    virtual void run_face_setup(int force_setup=0);
    virtual void run_face_setup_disp(const ARRAY<VECTOR>& disp,double mag);

    virtual void check_orientation(bool ori=TRUE);

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
