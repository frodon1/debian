#ifndef  __Behavior_plane_stress__

// ============================================================================ 
//  BEHAVIOR_PLANE_STRESS   modifier to impose plane stress condition
//  ***behavior gen_evp plane_stress
//  ***behavior gen_evp plane_stress auto_step
//  ***behavior gen_evp lagrange_rotate auto_step plane_stress
//  ....

#include <Mat_data_init.h>
#include <Mechanical_behavior.h>
#include <Behavior_defines.h>
#include <Behavior_wrapper.h>

Z_START_NAMESPACE;

ZCLASS BEHAVIOR_PLANE_STRESS : public BEHAVIOR_WRAPPER {
   protected :
      bool finite_strain;
      SCALAR_VAUX   et33;

      virtual void attach_all(MAT_DATA& mdat );


   public :

      bool skip_first, absolu;
      int miter;
      double eps;


      BEHAVIOR_PLANE_STRESS();
      virtual void initialize(ASCII_FILE& file, int dim, LOCAL_INTEGRATION*);
      virtual void  init();

      virtual SMATRIX get_elasticity_matrix(MAT_DATA&,double);
      virtual bool get_tangent(MATRIX& tg_matrix,const MAT_DATA& mdat);

//    Should be defined ?
//    virtual VECTOR  get_vector_value(STRING what);
//    virtual TENSOR2 get_tensorial_value(STRING what);
//    virtual MATRIX  get_matrix_value(STRING what);
//
//    virtual TENSOR2 get_non_mechanical_strain(MAT_DATA& mdat,double theta);
//    virtual TENSOR2 get_non_mechanical_dstrain(MAT_DATA& mdat,double theta);
//
      virtual void set_null_stress_component(int index);

      
      virtual INTEGRATION_RESULT*  integrate( MAT_DATA&        mdat,
                                      const  VECTOR&   delta_grad,
                                      MATRIX*&         tg_matrix,
                                      int              flags_in       );
      RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
