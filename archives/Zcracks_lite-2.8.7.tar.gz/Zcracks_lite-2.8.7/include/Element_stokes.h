#ifndef __STOKES_ELEMENT__
#define __STOKES_ELEMENT__

// Implémentation d'un élément Stokes mixte P2/P1 et P1+/P1

#include <Viscous_fluid_element_EMSE.h>

Z_START_NAMESPACE;


class ELEMENT_STOKES : public VISCOUS_FLUID_ELEMENT_EMSE
{
  protected :
    static ARRAY<const REF_GAUSS_POINT*> ref_gp_r;
    static int nb_node_pressure;
    static double density;
    static VECTOR gravity; 
    static const int noeudsPres3D [];
    static const int noeudsPres2D [];
    static bool compute_gravity;
    DOF_TYPE ** vDofs ;

    int compute_nb_dof(int nb_node_u,int dim);
    int mechanical_tsz();

    virtual void compute_bubble_BAB(MATRIX & C, MATRIX & Bl, const VECTOR & I, VECTOR & RP, double lvolume);
    virtual void diagonalise(MATRIX & C, double eps);
    virtual void compute_Kvv(MATRIX & Kvv, MATRIX & B, MATRIX & Bt);
    virtual void compute_Kvp(MATRIX & Kvp, MATRIX & Bl_t, const VECTOR & I, const VECTOR & sh);
    virtual void compute_scd_membre(VECTOR & RV, const VECTOR & sh);

    virtual void read_density_and_gravity(VECTOR & MasseVolumique);
    virtual void read_viscosity(VECTOR & Viscosite);

  public :

    ELEMENT_STOKES () : VISCOUS_FLUID_ELEMENT_EMSE(), vDofs(0) { ; }
    virtual ~ELEMENT_STOKES ();
		

    NODE*              get_node(int i)           { return (NODE*) node[i]; }
    const NODE*        get_node(int i) const     { return (NODE*) node[i]; }


    virtual void setup_dofs(const char*);
    virtual INTEGRATION_RESULT* internal_reaction(bool,VECTOR&,SMATRIX&,bool only_get_tg_matrix=FALSE);
    static void setNbNodPressure(int nbP) { nb_node_pressure = nbP; }

    //void compute_numerical_error();
    

};
Z_END_NAMESPACE;

#endif        //  __STOKES_ELEMENT__
