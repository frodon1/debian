#ifndef __ZP_RUNGE__
#define __ZP_RUNGE__

#include <Integration_runge.h>
#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_vector.h>
#include <Auto_ptr.h>

Z_START_NAMESPACE;

class ZP_OBJECT_PROC;

ZCLASS ZP_RUNGE : public ZP_OBJECT , 
                   public RUNGE_INTEGRATOR , 
                   public RUNGE2 { 
  protected :
    AUTO_PTR< ZP_OBJECT > deriva;
    ZP_STACK *the_stack;
    VECTOR *vint,*dvint;

    virtual ZP_FATAL_ERROR* print(ZP_STACK&,int);
    ZP_FATAL_ERROR* xintegrate(ZP_STACK&,int);
    ZP_FATAL_ERROR* integrate(ZP_STACK&,int);

    virtual void type_init(char*) { }

  public :
    ZP_RUNGE();
    virtual ~ZP_RUNGE() { }

    virtual void derivative(double,const VECTOR&,VECTOR&);

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);

    METHOD_DECLARATION_START
      METHOD("xintegrate",xintegrate,5)
      METHOD("integrate",integrate,6)
    METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)
};
Z_END_NAMESPACE;

#endif
