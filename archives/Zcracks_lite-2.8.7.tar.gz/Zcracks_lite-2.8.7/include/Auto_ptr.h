#ifndef __Auto_ptrX__
#define __Auto_ptrX__


//
// FF, nov 10th, 2004
//   A real automatic pointer class, much nicer than the standard PTR<T> class
//   This class uses a reference couting to know exactly when the pointer becomes useless, and delete it
//
//   Works perfectly, since this class is widely used in zProgram
//
//   Just use it as a regular C++ pointer (except that you dont have to delete it)
//

#include <Defines.h>
#include <Bool.h>
#include <Assert.h>
#include <Error_messager.h>

Z_START_NAMESPACE;

#ifdef PTR
   #undef PTR
#endif 

template <class T> class AUTO_PTR;


template <class T>
ZCLASSt AUTO_COUNTED
{
  friend class AUTO_PTR<T>;
  private :
    T* my_pt;
    unsigned count;
    bool dont_care;
   
    AUTO_COUNTED(T* pt) : my_pt(pt),count(0),dont_care(FALSE) { }
    ~AUTO_COUNTED() { Assert(count==0); 
       if(!dont_care) if(my_pt) delete(my_pt); 
    }

    unsigned GetRef() { return(++count); }
    unsigned FreeRef() { Assert(count>0); return(--count); }
};

template <class T> 
ZCLASSt AUTO_PTR
{
  friend class AID_OBJ_AUTO_PTR;
  private :
    AUTO_COUNTED<T>* ip;

    void UnBind() { if(!Null() && ip->FreeRef()==0) delete(ip); ip=NULL; }
    T*& get_internal_ref() { 
      if (ip==NULL) ip=new AUTO_COUNTED<T>(NULL);     
      return(ip->my_pt);
    }

  public :
    AUTO_PTR() : ip(NULL) { }

    // DO NOT remove the 'explicit' decl there
    // I do not want these constructors to be used by implicit conversions
    explicit AUTO_PTR(T* pt) { 
      ip=new AUTO_COUNTED<T>(pt); 
      ip->GetRef(); 
    }

    AUTO_PTR(const AUTO_PTR<T>& o) { 
      ip=o.ip; 
      if(!Null()) ip->GetRef(); 
    }

    ~AUTO_PTR() { UnBind(); }

    operator T*() { 
    #ifdef ZCHECK2
      if(Null()) ERROR("Null dereferencing"); 
    #endif
      if(Null()) return(NULL); 
      return(ip->my_pt); 
    }

    T* operator()() { 
    #ifdef ZCHECK2
      if(Null()) ERROR("Null dereferencing"); 
    #endif
      if(Null()) return(NULL); 
      return(ip->my_pt); 
    }

    T* operator->() { 
    #ifdef ZCHECK2
      if(Null()) ERROR("Null dereferencing"); 
    #endif
      if(Null()) return(NULL); 
      return(ip->my_pt); 
    }

    T&  operator*() { 
    #ifdef ZCHECK2
      if(Null()) ERROR("Null dereferencing"); 
    #endif
      T* _t=NULL;
      if(Null()) return(*_t); 
      return(*(ip->my_pt)); 
    }

    const T* ptr() const {
    #ifdef ZCHECK2
      if(Null()) ERROR("Null dereferencing"); 
    #endif
      if(Null()) return(NULL); 
      return(ip->my_pt); 
    }

    const T* operator->() const {  
    #ifdef ZCHECK2
      if(Null()) ERROR("Null dereferencing"); 
    #endif
      if(Null()) return(NULL); 
      return(ip->my_pt); 
    }

    const T&  operator*() const {  
    #ifdef ZCHECK2
      if(Null()) ERROR("Null dereferencing"); 
    #endif
      T* _t=NULL;
      if(Null()) return(*_t);
      return(*(ip->my_pt)); 
    }

    AUTO_PTR<T>& operator=(const AUTO_PTR<T>& o) { 
      if(!o.Null()) o.ip->GetRef();  
      UnBind(); ip=o.ip; 
      return(*this); 
    }

    AUTO_PTR<T>& operator=(T *o) {
      UnBind(); 
      ip=new AUTO_COUNTED<T>(o); 
      ip->GetRef();
      return(*this);
    }

    bool operator==(const AUTO_PTR<T>& l) { return(ip->my_pt==l.ip->my_pt); }
    bool operator!=(const AUTO_PTR<T>& l) { return(!((*this)==l)); }

    void GetRef() { 
    #ifdef ZCHECK
      if(Null()) ERROR("Null dereferencing"); 
    #endif
      ip->GetRef(); 
    }

    void FreeRef() {
    #ifdef ZCHECK
      if(Null()) ERROR("Null dereferencing"); 
    #endif
      ip->FreeRef(); 
      if(ip->count==0) delete(ip); 
      ip=NULL;
    }

    void DontCare() { 
    #ifdef ZCHECK
      if(ip==NULL) ERROR("Null dereferencing"); 
    #endif
      ip->dont_care=TRUE; 
    }

    // 
    // Why rename these with now-new mixed case functions??? RF Jul 08 2006
    //
    // No special reason... FF 10/2006
    //
    bool Null() const {
      if(ip==NULL) return(TRUE);
      if(ip->my_pt==NULL) return(TRUE);
      return(FALSE);
    }
    bool NotNull() const { return(!Null()); }
    void SetNull() { UnBind(); }

    unsigned int count() { if(ip) return(ip->count); else return(0); }

    void erase() { FreeRef(); }

    bool if_null() const { return Null(); } 
    bool if_not_null() const { return(NotNull()); }
};

// #define __PTR__
// #define PTR AUTO_PTR
Z_END_NAMESPACE;

#endif
