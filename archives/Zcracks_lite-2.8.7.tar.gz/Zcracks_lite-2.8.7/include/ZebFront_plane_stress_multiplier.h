#ifndef __ZebFront_plane_stress_multiplier___ 
#define __ZebFront_plane_stress_multiplier___ 

// ============================================================================ 
//  ZebFront_plane_stress_multiplier.h                            RF 01/08/2007 
//
//  Contains a small material piece which can be used to add a variable for 
//  plane stress lagrange-multipliers. This is primarily for ZebFront where we
//  want a variable added only in the PS case (will be a sub-class)
// ============================================================================ 

#include <Behavior.h> 

Z_START_NAMESPACE;

ZCLASS ZF_PLANE_STRESS_MULTIPLIER : public MATERIAL_PIECE { 
   public: 
     TENSOR2 t_s,  t_u; 
     VECTOR  vt_s, vt_u; 

     SCALAR_VINT  eps_33;
     int     index;

     ZF_PLANE_STRESS_MULTIPLIER(); 
     virtual ~ZF_PLANE_STRESS_MULTIPLIER(); 

     virtual void resize(int sz); 
     virtual void initialize(ASCII_FILE& file, MATERIAL_PIECE* boss); 
     RTTI_INFO;
 
     
}; 

ZCLASS ZF_BEAM_MULTIPLIER : public MATERIAL_PIECE {
   public:
     TENSOR2 t_s22,  t_u22;
     VECTOR  vt_s22, vt_u22;

     TENSOR2 t_s33,  t_u33;
     VECTOR  vt_s33, vt_u33;

     SCALAR_VINT  eps_22;
     SCALAR_VINT  eps_33;
     int     index;

     ZF_BEAM_MULTIPLIER();
     virtual ~ZF_BEAM_MULTIPLIER();

     virtual void resize(int sz);
     virtual void initialize(ASCII_FILE& file, MATERIAL_PIECE* boss);
};

Z_END_NAMESPACE;

#endif 
