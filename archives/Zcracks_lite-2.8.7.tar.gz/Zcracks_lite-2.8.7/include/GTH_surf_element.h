#ifndef __GTH_surf_element__
#define __GTH_surf_element__

#include <List.h>
#include <Matrix.h>
#include <Vector.h>
#include <Node.h>
#include <P_element.h>

Z_START_NAMESPACE;

class GTH_SELEMENT: public D_ELEMENT {
   private :
     ARRAY <P_ELEMENT*> linked_elements;
     VECTOR local_phi;
     CRACK_FS *its_boss;

   public :
     ARRAY <NODE*> interface_nodes;
     GTH_SELEMENT() { }
     ~GTH_SELEMENT() { }
     void initialize();
     void make_geom();

     // local singular surface integrations
     void compute_Tx(const VECTOR &x,VECTOR &T_values); // for given x
                                                        // integrate over current
                                                        // surf element
     void compute_T(VECTOR &T_values); // for current surf elem loop over the
                                       // whole CRACK_FS
};

Z_END_NAMESPACE;
#endif

