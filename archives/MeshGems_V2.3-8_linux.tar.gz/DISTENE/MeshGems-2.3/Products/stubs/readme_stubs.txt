
1) Introduction

The MeshGems API provides a stub system that allows the integrator to
override some functions of the standard C library with its own
functions.

For the moment, only the memory management functions (malloc, calloc,
realloc and free) can be replaced, but this system will be extended to
other standard functions in the future.

2) How it works

All functions that can be overridden are called by MeshGems libraries
through a wrapper function prefixed with "meshgems_". For example, the
MeshGems code does not call "malloc()" but "meshgems_malloc()".  These
functions are provided by a separate dynamic library
(libmeshgems_stubs.so on Linux platforms and meshgems_stubs.dll on
Windows platforms) for which we provide the source code, so that the
integrator can redefine them.

3) How to use

The file stubs/meshgems_stubs.c defines the implementation of the functions
that can be replaced.

The integrator can modify this meshgems_stubs.c file for his needs.
This file has then to be recompiled into a dynamic stubs
implementation library :

   a) on Linux platforms : The command

      gcc -m32 -fPIC -I../include  -DMESHGEMS_LINUX_BUILD -shared meshgems_stubs.c  -o libmeshgems_stubs.so 

    will produce the libmeshgems_stubs.so dynamic library for 32 bit
    architecture (replace -m32 by -m64 for 64bit)

   b) on Windows platforms : The commands

      cl /MD /c /I..\include /DMESHGEMS_DLL_BUILD meshgems_stubs.c 
      cl /MD meshgems_stubs.obj /link /dll /out:meshgems_stubs.dll
    
    will produce the meshgems_stubs.dll dynamic library 


This dynamic library shall replace the existing one provided with MeshGems
dynamic libraries.

