#ifndef __PARALLEL_REMESH__
#define __PARALLEL_REMESH__

#include <Utility_mesh.h>
#include <Utility_results_database.h>
#include <Transform_geometry.h>
#include <Auto_remesh.h>

Z_START_NAMESPACE;

  //
  //  2009-07-19 FF: remesh the problem, in parallel.
  //    it works by first remeshing interfaces between domains, then the interior.
  //    It also updates the DD_SUB_DOMAIN object to reflect the new domain decomposition.
  //

  class YAMS_GHS3D;
  class BSET_TRANSFORM;
  class DD_SUB_DOMAIN;
  
  class PARALLEL_REMESH : public TRANSFORMERS
  {
  protected :
    PARALLEL_REMESH_INFO *pinfo;
    
    bool get_pinfo(APPLICATION_MESSAGE*);
    
  public :
    PARALLEL_REMESH();
    virtual ~PARALLEL_REMESH();
    
    virtual bool GetResponse(STRING,ASCII_FILE&);
    virtual void initialize(ASCII_FILE& file);
    virtual void apply(UTILITY_MESH& mesh);
    
    RTTI_INFO;
    DECLARE_ASK;
  };
  
  class REOPEN_PARALLEL_REMESH : public PARALLEL_REMESH 
  {
  protected :
    STRING base_name;
  
  public :
    REOPEN_PARALLEL_REMESH() : PARALLEL_REMESH() { }
    virtual ~REOPEN_PARALLEL_REMESH() { }
  
    virtual void apply(UTILITY_MESH& mesh);
    virtual bool GetResponse(STRING,ASCII_FILE&);
  };
  
  class PARALLEL_YAMS : public PARALLEL_REMESH 
  {
  protected :
    UTILITY_MESH* old_mesh;
    DD_SUB_DOMAIN* domain;
    YAMS_GHS3D* yams;
    BSET_TRANSFORM* nset_to_bset;
    ARRAY<STRING> inter_name;

    bool preserve_inter_topo;
  
  public :
    PARALLEL_YAMS();
    virtual ~PARALLEL_YAMS() { };
  
    virtual void apply(UTILITY_MESH& mesh);
    virtual bool GetResponse(STRING,ASCII_FILE&);
    virtual void initialize(ASCII_FILE& file);
  
    void build_interf_liset();
    void init_yams();
  };

Z_END_NAMESPACE;

#endif
