#ifndef __Zele_class__
#define __Zele_class__

//
// Conflict with the real() decl in Complex.h .. "real" is used
// in the z-mat code for handling single/double precision explicit
// interfaces.
//
#define SKIP_COMPLEX_INLINES

#include <Defines.h> 
#include <Mechanical_mesh.h> 
#include <Integration_method.h> 
#include <Problem.h> 
#include <Mesh.h> 
#include <D_element.h> 

#include <Stringpp.h> 
#include <Behavior.h> 
#include <Mat_data.h> 
#include <Zmat_skip.h> 
#include <Zmat_storage.h> 
 
#include <Sequence.h> 
#include <P_element.h> 
#include <Pointer.h>

Z_START_NAMESPACE;

extern WIN_THINGIE STRING zele_keep_odir;
extern WIN_THINGIE STRING zele_keep_job;

extern WIN_THINGIE LIST<EXTERNAL_PARAM*> ZeBaBa_EP_list;

enum ZELE_SOLVER_TYPE { 
   ZELE_INVALID, 
   ZELE_ABAQUS, 
   ZELE_ABAQUS_EXPLICIT, 
   ZELE_COSMOS, 
   ZELE_MARC, 
   ZELE_ANSYS, 
   ZELE_MAX_SOLVERS
}; 

ZCLASS2 ZELE_HANDLER {
  public :
    STRING exedir; 
    STRING mat_file; 

    double First_Time;
    double time_1, time_2; 
    int    seq; 

    SEQUENCE  fake_seq; 

    // 
    // The Zele is setup just like a full problem. In preload mode 
    // we use that for finding the num dofs etc which will affect the 
    // abaqus input deck. 
    // 
    PTR<PROBLEM> the_problem; 

    int        keep_debug_flag; 
    int        use_local_debug; 
    LIST<int>  debug_ele; 
    LIST<int>  debug_gp; 
    double     start_debug_time; 
    double     end_debug_time; 

    int abq_version;

    //
    // Direct parameter related stuffs.. basically hacks.
    //
    int          needed_param_vars;
    LIST<STRING> extra_variables;
    int          needs_temperature;
    int          temperature_mode;
    double       temp_ini;
    LIST<STRING> param_names;
    LIST<int>    param_locations;
    LIST<double> param_ini;
    LIST<int>    param_mode;
    LIST<STRING>  fixed_param_names;
    LIST<double>  fixed_param_values;


    ZELE_HANDLER();
    virtual ~ZELE_HANDLER();
    virtual void initialize(); 

    virtual void preload_setup(); 
    virtual void end_of_load_setup(); 
//  P_ELEMENT* get_element(int id, int type, int num_nodes);  

    ARRAY< ARRAY<int> > stored_remaps; 
    ARRAY<int>&   get_remap(D_ELEMENT* ele); 
};

extern WIN_THINGIE2 ZELE_HANDLER* zelh; 
Z_END_NAMESPACE;

#endif
