/*=========================================================================

  Program:   ParaView
  Module:    vtkPVEnvironmentInformation.h

  Copyright (c) Kitware, Inc.
  All rights reserved.
  See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
// .NAME vtkPVEnvironmentInformation - Information object that can
// be used to obtain values of environment variables.
// .SECTION Description
// vtkPVEnvironmentInformation can be used to get values of environment
// variables.

#ifndef vtkPVEnvironmentInformation_h
#define vtkPVEnvironmentInformation_h

#include "vtkPVClientServerCoreDefaultModule.h" //needed for exports
#include "vtkPVInformation.h"

class VTKPVCLIENTSERVERCOREDEFAULT_EXPORT vtkPVEnvironmentInformation : public vtkPVInformation
{
public:
  static vtkPVEnvironmentInformation* New();
  vtkTypeMacro(vtkPVEnvironmentInformation, vtkPVInformation);
  void PrintSelf(ostream& os, vtkIndent indent);

  // Description:
  // Transfer information about a single object into this object.
  // The object must be a vtkPVEnvironmentInformationHelper.
  virtual void CopyFromObject(vtkObject* object);

  // Description:
  // Manage a serialized version of the information.
  virtual void CopyToStream(vtkClientServerStream*);
  virtual void CopyFromStream(const vtkClientServerStream*);

  // Description:
  // Get the value of an environment variable
  vtkGetStringMacro(Variable);

protected:
  vtkPVEnvironmentInformation();
  ~vtkPVEnvironmentInformation();

  char* Variable;     // value of an environment variable

  vtkSetStringMacro(Variable);

private:
  vtkPVEnvironmentInformation(const vtkPVEnvironmentInformation&) VTK_DELETE_FUNCTION;
  void operator=(const vtkPVEnvironmentInformation&) VTK_DELETE_FUNCTION;
};


#endif

