#ifndef __FM_RENORMALIZATION_EXTENT_3DVELOC_3D__
#define __FM_RENORMALIZATION_EXTENT_3DVELOC_3D__

#include <Fast_marching_multi_3d.h>
#include <Distance_computer.h>

Z_START_NAMESPACE;

/*

  2008-12-05 FF

  Compute the distance to a curve which is the intersection of two levelsets, phi and psi.
  
  The distance is computed by solving |\nabla rho|=1, using a FMM

  Also compute the extension of the velocity field, so that

  grad(V_i).grad(rho) = 0, for i=1,2,3

*/

/*

8 values needed : rho, phi , v1 , v2 , v3 , gr1 , gr2 , gr3
7 values should be enough, but we must pass phi & psi to the FM init method, so 8 values are used
instead of 7

*/

ZCLASS2 FM_RENORMALIZATION_EXTENT_3DVELOC_3D : public FAST_MARCHING_MULTI_3D<8,0>
{
  protected :
    DISTANCE_COMPUTER::MODE dst_mode;
    DISTANCE_COMPUTER dist;

    void (*velocity_computer)(const VECTOR&,VECTOR&);

    virtual void initialize(const GRID_3D< FINITE_SET<8,double> >&, GRID_3D< FINITE_SET<8,double> >&);
    virtual void local_solve(const GRID_3D< FINITE_SET<8,double> > &grid, 
                             const GRID_3D< FINITE_SET<8,double> > &initial, FINITE_SET<8,double> &ret, 
                             FINITE_SET<3,unsigned int> &coord,bool&);
    void velocity_on_front(const VECTOR &x, VECTOR &v);

  public :
    bool reconstruct_rho;

    FM_RENORMALIZATION_EXTENT_3DVELOC_3D() : FAST_MARCHING_MULTI_3D<8,0>() { dst_mode=DISTANCE_COMPUTER::CUBIC; 
      reconstruct_rho=FALSE;
    }
    virtual ~FM_RENORMALIZATION_EXTENT_3DVELOC_3D() { }

    void apply(const GRID_3D<double>&, const GRID_3D<double>&, 
               GRID_3D<double>&, GRID_3D< FINITE_SET<3,double> >&, GRID_3D< FINITE_SET<3,double> >&,
               void (*)(const VECTOR&, VECTOR&)=NULL);
};
Z_END_NAMESPACE;

#endif
