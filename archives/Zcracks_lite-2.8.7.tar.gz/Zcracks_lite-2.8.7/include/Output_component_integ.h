#ifndef __Output_component_integ__ 
#define __Output_component_integ__ 

//
// FF, June 24th, 2003
//
//  implementation of IP output
//
#include <Utility_file_driver.h>
#include <Utility_z8_results.h>
#include <Output_component.h>
#include <Behavior.h>
#include <Print.h>

Z_START_NAMESPACE;

ZCLASS2 OUTPUT_COMPONENT_INTEG : public OUTPUT_COMPONENT {
  protected :
    STRING       class_key;

    MESH* its_mesh;
    BUFF_LIST<STRING> vars;
    int wnb_gp_tot;

    VECTOR s_val;
    MARRAY<VECTOR> v_val;
    MARRAY<TENSOR2> t_val;

  public :
    OUTPUT_COMPONENT_INTEG();
    virtual ~OUTPUT_COMPONENT_INTEG();
    virtual void initialize(ASCII_FILE& file);

    virtual void look_at_params(UTILITY_FILE_DRIVER* drv, MESH& mesh, ARRAY<BEHAVIOR*>& behavior);

    virtual void write_output(UTILITY_FILE_DRIVER* drv);
    virtual void get_results(double time, STRING comp);
};
Z_END_NAMESPACE;

#endif 
