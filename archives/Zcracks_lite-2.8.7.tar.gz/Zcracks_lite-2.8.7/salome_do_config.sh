#!/bin/bash

# -*- Mode: shell-script; sh-shell: bash -*-

export Z7PATH=${ZCRACKSHOME}
source ${Z7PATH}/lib/Z7_profile
export Z7LICENSE=${Z7PATH}/EDF_ZCRACKS_2016_2019.zlic

# export Z7TEST=$Z7PATH/TESTS
# export Z7HANDBOOK=$Z7PATH/HANDBOOK

export ZSETUP_USE_CPP=yes
export Z7_USE_HNAME=Stars
export ZSETUP_USE_SCANNER=yes

# I don't want to risk Z7EXTRALIBS being recompiled automatically
# If needed, source the do_config_bash_for_compilation
export Z7EXTRALIBS_SRC="$Z7PATH/../EXTRA_LIBS"
export Z7EXTRALIBS="$Z7PATH/00_Z84_libs"

export ZMAKE_CONCURRENCY=12
export ZOTHER_LIBS="-lGL -lGLU"
export PATH="$Z7PATH/PUBLIC/lib-Linux_64/Zmesh/bin:${PATH}"

# Language and locales
#export LC_NUMERIC=C

# export DLIM8VAR="dlim8 1:1:29030@10.122.51.15/005056010130::9de2ce714bcb5ec8ced9926a1087298ebeca6affe852286633abe41cb4a85b4b"
# export DISTENE_LICENSE_FILE="Use global envvar: DLIM8VAR"
# export DISTENE_LICENCE_FILE_FOR_YAMS='"$DISTENE_LICENSE_FILE"'
# export DISTENE_LICENCE_FILE_FOR_MGCLEANER='"$DISTENE_LICENSE_FILE"'

# Paraview
#export PV_PLUGIN_PATH=$Z7PATH/PUBLIC/lib-Linux_64/Paraview
