#ifndef __Variables_history__
#define __Variables_history__

#include <Buffered_list.h>
#include <Stringpp.h>
#include <Sim_opt_item.h>

Z_START_NAMESPACE;

class SIM_OPT_GUI;
class GRAPHICS_DATA_DIALOG;

class VARIABLES_HISTORY : public SIM_OPT_ITEM {

  private :
    SIM_OPT_GUI* its_sim_opt;

  public :
    STRING comment;
    BUFF_LIST<STRING> var_names;
    BUFF_LIST<double> var_values;
    BUFF_LIST<bool> var_optimized;
    GRAPHICS_DATA_DIALOG* its_dialog;

    VARIABLES_HISTORY(SIM_OPT_GUI* boss);
    VARIABLES_HISTORY(const STRING&,SIM_OPT_GUI*,const BUFF_LIST<STRING>&);
   ~VARIABLES_HISTORY() {}

    void load();
    bool write(Zofstream& out);
    bool read(ASCII_FILE&);
};
Z_END_NAMESPACE;

#endif
