#ifndef __Uncoupled_rupture__
#define __Uncoupled_rupture__

#include <Defines.h>
#include <File.h>
#include <Elasticity.h>
#include <Mechanical_behavior.h>
#include <Out_message.h>
#include <Utility.h>
 
#include <Print.h>

Z_START_NAMESPACE;
 
//
// I changed damage from a VINT to a VAUX.. because in gen_evp... maybe in
// porous.. the integration vectors are adjusted to be = size of mdat.var_int()..
// the real problem is that the VINT's will have to do something like
// eel.place_var(deel,dvar); // see the problem? if we operate on a sub vector
// (with the integration method) the offsets will all be wrong because they
// are in relation to the problem's VINT variable list, and not just the
// active MATERIAL_PIECE (the sub-behavior).
//
ZCLASS DAMAGE_MODEL_UC : public MATERIAL_PIECE {
   protected :
     SCALAR_VAUX damage;
   public :
     DAMAGE_MODEL_UC();
     virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
     virtual ~DAMAGE_MODEL_UC();
     virtual bool broken(MAT_DATA&)=0;
     virtual bool fading(const MAT_DATA&,double&);
     virtual void update(MAT_DATA&)=0;
     RTTI_INFO;
};
 
ZCLASS RICE_TRACEY_DM : public DAMAGE_MODEL_UC {
     STORED_VARIABLE_SPEC *strain;
     ARRAY<STRING> tn;
     COEFF A,B;
     double Rc;
     double fading_damage;
 
     STRING name_strain, name_stress;
   public :
     RICE_TRACEY_DM();
     virtual ~RICE_TRACEY_DM();
     virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
     virtual bool broken(MAT_DATA&);
     virtual void update(MAT_DATA&);
     virtual bool fading(const MAT_DATA&,double&);
     RTTI_INFO;
};
 
ZCLASS UNCOUPLED_RUPTURE : public M_B_SD {
   protected :
     VECTOR  sig_storage, eto_storage;
     TENSOR2_FLUX* mb_flux;
     TENSOR2_GRAD* mb_grad;
 
     SMATRIX           tgmat;
     AUTO_PTR<DAMAGE_MODEL_UC> its_damage;
     AUTO_PTR<BEHAVIOR>     its_behavior;
     AUTO_PTR<ELASTICITY>   its_broken;
   public :
     UNCOUPLED_RUPTURE();
     virtual ~UNCOUPLED_RUPTURE();
     virtual void initialize(ASCII_FILE&,int,LOCAL_INTEGRATION*);
     virtual INTEGRATION_RESULT* integrate(MAT_DATA&,const VECTOR&,MATRIX*&,int);
     virtual void setup(int&,int&,int&,int&);
     RTTI_INFO;
};
 
Z_END_NAMESPACE;

#endif
