#ifndef __Z_SERVER__
#define __Z_SERVER__

#include <Bool.h>
#include <Base_problem.h>
#include <Server.h>

Z_START_NAMESPACE;

/**
 This class implement the ZeBuLoN server module.
  This class is runned in parallel mode by the master task (ie the first launched task
in PVM3 or the first enroled task in MPI). 
Basically it enters an infinite loop to process requests (parallel I/O for instance) coming
from other tasks.
It also has the reponsability to watch the parallel problem, ie to check that all tasks
are running correctly.
As other BASE_PROBLEM derivatives, it overloads method named Execute.
 */
ZCLASS Z_SERVER : public BASE_PROBLEM {
  protected :
    /// a pointer to an object responsible for the request process loop
    ZSERVER *zserver;

  public :
    /// default constructor
    Z_SERVER(void) { zserver=NULL; }
    virtual  ~Z_SERVER(void) { if(zserver) delete(zserver); }

    /// execution method
    virtual bool Execute();
 
    /** try to parse keyword key from file inp.
     If successfull (ie keyword contained in key is a keyword understood by this class), return TRUE.
     Otherwise, return FALSE.
     */
    virtual bool GetResponse(const char* const key, ASCII_FILE& inp);
};
Z_END_NAMESPACE;

#endif
