#ifndef __Generalized_eigen_solver__
#define __Generalized_eigen_solver__

#include <Defines.h>
#include <Global_matrix.h>
#include <File.h>

/*

FF, oct 28, 2011

A generic definition of what is a generalized eigen solver.

Such solvers solves for : K.x=l.A.x and returns the possible values for l (values) and x (modes) knowing K and A

*/


Z_START_NAMESPACE;

class PROBLEM;
class PROBLEM_EIGEN;

struct GENERALIZED_EIGEN_SOLVER_INFO
{
  GENERALIZED_EIGEN_SOLVER_INFO() { maximal_number_of_modes=5; }

  int maximal_number_of_modes;
  VECTOR values,energies;
  ARRAY<VECTOR> modes;
};

ZCLASS2 GENERALIZED_EIGEN_SOLVER : public Z_OBJECT
{
  protected :
    PROBLEM_EIGEN *its_problem;

  public  :
    STRING               global_matrix_type;
    SOLVER_PARAMETER*    gmp;

    GENERALIZED_EIGEN_SOLVER();
    virtual ~GENERALIZED_EIGEN_SOLVER();

    virtual bool load(ASCII_FILE&)= 0;
    virtual bool solve(GLOBAL_MATRIX& K,GLOBAL_MATRIX& A, GENERALIZED_EIGEN_SOLVER_INFO &infos)=0;

    double eigen_norm(GLOBAL_MATRIX& M , VECTOR& v);
    void   set_problem(PROBLEM*);

    virtual bool impose_matrix_type(STRING&) { return(false); }
};

Z_END_NAMESPACE;

#endif
