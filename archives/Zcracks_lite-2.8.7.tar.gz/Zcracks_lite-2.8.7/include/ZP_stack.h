#ifndef __ZP_STACK__
#define __ZP_STACK__

#include <ZP_error.h>
#include <ZP_buff_list.h>
#include <ZP_object.h>
#include <Object_factory.h>
#include <Auto_ptr.h>
#include <ZP_mark.h>

Z_START_NAMESPACE;

class ZP_ENV;

ZCLASS ZP_STACK : public ZP_BUFF_LIST< AUTO_PTR<ZP_OBJECT> >
{
  public :
    ZP_STACK() { }
    virtual ~ZP_STACK() { }

    ZP_ENV *associated_env;

//   void pop() { last().free_up(); suppress(); }
   void pop() { 
#ifdef ZCHECK
     if (sz) {
       if((*this).last()->type=="mark") {
         ERROR("Poping a mark ????");
       }
     }
#endif
     suppress(); 
   }
//   void _pop() { suppress(); }

  void add(AUTO_PTR<ZP_OBJECT> &z)
  {
    ZP_BUFF_LIST< AUTO_PTR<ZP_OBJECT> >::add(z);
  }

  void add(ZP_OBJECT *z)
  {
    AUTO_PTR<ZP_OBJECT> zpo; zpo=z;
    ZP_BUFF_LIST< AUTO_PTR<ZP_OBJECT> >::add(zpo);
  }

  void mark(void *v)
  {
    AUTO_PTR<ZP_OBJECT> zpo;
    ZP_MARK *zpm=new ZP_MARK; zpm->who=v;

    zpo=zpm;
    ZP_BUFF_LIST< AUTO_PTR<ZP_OBJECT> >::add(zpo);
  }

  void unmark(void *v)
  {
    int i,j,mark_seen;

    mark_seen=-1;
    for(i=(*this).size()-1;i>=0;i--)
      if((*this)[i]->type=="mark") { 
        ZP_MARK *zpm=(ZP_MARK*)((*this)[i]());
 
        if(zpm->who==v) {
          mark_seen=i; 
          break; 
        }
      }
    if(mark_seen==-1) { 
      ERROR("internal error: cannot find mark");
      CRITICAL("can't continue");
    }
    j=(*this).size();
    for(i=0;i<j-mark_seen;i++) suppress();
  }

  void insert_at_beginning(AUTO_PTR<ZP_OBJECT> &zpo)
  {
    int i;
    ARRAY<AUTO_PTR<ZP_OBJECT> > l((*this).size());

    for(i=0;i<(*this).size();i++) l[i]=(*this)[i];
    this->resize(0); add(zpo);
    for(i=0;i<l.size();i++) add(l[i]);
  }

/*  void insert_before_last_mark(AUTO_PTR<ZP_OBJECT> &zpo)
  {
    int i,j,mark_seen;
    LIST<AUTO_PTR<ZP_OBJECT> > l;

    mark_seen=-1;
    for(i=!(*this)-1;i>=0;i--)
      if((*this)[i]->type=="mark") { mark_seen=i; break; }
    if(mark_seen==-1) return; 
    for(i=mark_seen;i<!(*this);i++) l.add((*this)[i]);
    j=!(*this); for(i=0;i<j-mark_seen;i++) _pop();
    add(zpo); for(i=0;i<!l;i++) add(l[i]);
  }

   int get_nargs()
   {
     int result,i;

     result=0;
     for(i=!(*this)-1;i>=0;i--) {
       if((*this)[i]->type=="nop") { break; }
       else if((*this)[i]->type!="mark") result++;
     }
     return(result);
   }
*/

//  void suppress_all_nop()
//  {
//    int i,j,end;
//
//    end=0;
//    while(!end) {
//      j=0;
//      for(i=!(*this)-1;i>=0;i--) {
//        if((*this)[i]->type=="nop") {
//           suppress(i);
//           j=1;
//           break;
//         }
//      }
//      if(j==0) end=1;
//    }
//  }

//  void suppress_nop()
//  {
//    if(!(*this)) 
//      while((*this).last()->type=="nop") {
//        suppress();
//        if(!(*this)==0) return;
//      }
//  }

//  void insert_nop()
//  {
//    AUTO_PTR<ZP_OBJECT> zpo;
//
//    zpo=new ZP_NOP;
//    add(zpo);
//  }


  void print() 
  {
    int i,j;

    Out<<"Stack size: "<<(*this).size()<<endl;
    j=(*this).size();
    for(i=0;i<j;i++) {
      Out<<i<<": "<<(*this)[i]->type<<" ";
      (*this)[i]->print(*this,0);
      Out<<endl;
    }
    Out<<endl<<flush;
  }

};

#define METHOD_DECLARATION_START virtual ZP_FATAL_ERROR* method(STRING &_name, int nb_params, ZP_STACK &stack,bool resolv=FALSE) {

#define METHOD_DECLARATION_EMPTY_ANCESTOR(a) virtual ZP_FATAL_ERROR* method(STRING &_name, int nb_params, ZP_STACK &stack,bool resolv=FALSE) { \
  return(a::method(_name,nb_params,stack,resolv)); } 

#define METHOD_DECLARATION_ANCESTOR(a) return(a::method(_name,nb_params,stack,resolv)); return(NULL); }

#define METHOD(n,proc,arg) \
  if(_name==n) { \
    if(resolv) return(new ZP_FATAL_ERROR("resolved")); \
    if(arg) { \
      if(nb_params != arg) { \
        STRING _msg_; _msg_="Not enough arguments for method "; _msg_=_msg_+#n; \
        return(new ZP_FATAL_ERROR(_msg_)); \
      } \
    } \
    return(proc(stack,nb_params)); \
  } else

#define TYPE_MISMATCH_ERROR(n) { \
  STRING _msg_; \
  _msg_=STRING::EMPTY+"At (or near) line "+itoa(_exec_line+1)+": type mismatch error between "; \
  for (int _ii=stack.size()-nb_params;_ii<stack.size();_ii++) _msg_=_msg_+stack[_ii]->type+" "; \
  _msg_=_msg_+" and "+this->ZP_OBJECT::type+" for method "+#n; return(new ZP_FATAL_ERROR(_msg_)); \
}

#define TYPE_MISMATCH_ERROR_2(n) { \
  STRING _msg_; \
  _msg_="At (or near) line "; _msg_=_msg_+itoa(_exec_line+1)+": type mismatch error between  "\
  +stack.last()->type+", "+stack[stack.size()-2]->type+" and "+this->ZP_OBJECT::type+\
  " for method "+#n; return(new ZP_FATAL_ERROR(_msg_)); \
}

#define TYPE_MISMATCH_ERROR_1(n) { \
  STRING _msg_; \
  _msg_="At (or near) line "; _msg_=_msg_+itoa(_exec_line+1)+": type mismatch error between  "+stack.last()->type+\
  " and "+this->ZP_OBJECT::type+" for method: "+#n; \
  return(new ZP_FATAL_ERROR(_msg_)); \
}

#define CHECK_ARGS(n,nn) { \
  if(stack.size()<##n) { \
    STRING _msg_; _msg_="Not enough arguments for method "+##nn+"/"+ZP_OBJECT::type; \
    return(new ZP_FATAL_ERROR(_msg_)); \
  } \
}
Z_END_NAMESPACE;

#endif
