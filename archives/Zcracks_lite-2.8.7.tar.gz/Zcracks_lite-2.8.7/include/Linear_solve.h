#ifndef __LINEAR_SOLVE__
#define __LINEAR_SOLVE__

#include <CG_solver.h>

Z_START_NAMESPACE;

ZCLASS2 LINEAR_SOLVE : public CG_SOLVER {
  private :
    MATRIX *K;
    VECTOR *F;

  protected :
    virtual void initialize();
    virtual void prodD(VECTOR&,VECTOR&);
    inline void set_right_hand_side(VECTOR&);

  public :
    LINEAR_SOLVE() { }
    LINEAR_SOLVE(int dd, double e) : CG_SOLVER(dd,e) { }
   ~LINEAR_SOLVE() { }

    void set_matrix(MATRIX &k) { K=&k; }
    void solve(VECTOR&,VECTOR&);
};
Z_END_NAMESPACE;

#endif
