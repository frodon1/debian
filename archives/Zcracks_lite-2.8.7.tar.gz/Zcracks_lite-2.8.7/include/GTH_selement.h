// ****************************************************************************
// SURFACE ELEMENT FOR GTHETA FORMULATION
// 
// Virtual surface element to perform various integrals
//
// GE & VC
// november 2008
// ****************************************************************************

#ifndef __GTH_selement__
#define __GTH_selement__

#include <List.h>
#include <Matrix.h>
#include <Vector.h>
#include <Node.h>
#include <P_element.h>
#include <Crack_FC.h>
#include <Crack_FS.h>

// Element geometry is c2d8 with Barsoum modification on first element

Z_START_NAMESPACE;

class CRACK_FC;
class CRACK_FS;

class GTH_SELEMENT: public D_ELEMENT {
  private :
    int nb_gp,nb_node,dim;

    // nodes should be given in the correct c2d8 order!
    // front is 1-2-3 side 
    // 0: is 7-8-1 
    // 1: is 3-4-5
    // according to phi_local
    MARRAY < ARRAY <int> > node_index; // Node index 

    void build_phi(int phi_local,MARRAY <VECTOR*> &phi_input,MARRAY <VECTOR*> &phi_output);

    void get_fields(); // use to build GP coordinate in linked volume elements

    
    STRING geom_type;

    GEOMETRY *geometry;

    // To compute once mech values
    double nu,E,mu;

  public :

    MATRIX elem_coord; // store current elem coord

    void get_real_GP_pos(VECTOR &pos); // compute position of surface GP
    void get_real_pos(VECTOR &xi,VECTOR &pos); // compute true position of current point

    virtual void get_coord(); // to compute integrations

    double GP_tolerance; // error admissible when searching GP position

    bool if_xfem;

    CRACK_FS *surface;

    void make_geom();

    void compute_normal(VECTOR & xi, VECTOR &normal);
    void compute_normal(VECTOR &normal);

    void compute_vector_field(MARRAY<VECTOR*> &input,VECTOR &output,const VECTOR &xi);
    void compute_vector_field(MARRAY<VECTOR*> &input,VECTOR &output);

    void compute_phi(const VECTOR &xi, MATRIX &phi_mode);
    void compute_phi(MATRIX &phi_mode);
    void compute_grad_phi(const VECTOR &xi,ARRAY <SMATRIX> &grad_phi_mode,double &jacob,MATRIX &gradient,int phiok=-1); //GW
    void compute_grad_gradu(const VECTOR &xi,MARRAY <SMATRIX> &grad_gradu,SMATRIX &gradu,double &jacob,MATRIX   &gradient); //GW

    inline void compute_dsigma(const VECTOR &x,const VECTOR &y,ARRAY < MARRAY < SMATRIX > > &dsigma,SMATRIX &rvv); //GW
    void compute_grad_v(const VECTOR &x,ARRAY<SMATRIX> &grad_v); //GW
	
    void compute_grad_v_reg(const VECTOR &x,ARRAY<SMATRIX> &grad_v,int phiok=-1); // GW 19 juillet 2012
    inline void compute_sigma(const VECTOR &x,const VECTOR &y,MARRAY < SMATRIX >  &sigma,VECTOR &rv); // GW 19 juillet 2012

    GTH_SELEMENT() { }
    GTH_SELEMENT(CRACK_FS *boss,MARRAY < ARRAY <int> > &_node_index,bool _if_xfem);
    ~GTH_SELEMENT();

};

Z_END_NAMESPACE;

#endif
