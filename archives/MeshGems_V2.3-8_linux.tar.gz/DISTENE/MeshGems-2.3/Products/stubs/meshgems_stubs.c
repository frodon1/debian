#include <meshgems/stubs.h>

#include <stdlib.h>

void *meshgems_malloc(size_t size)
{
  return malloc(size);
}

void *meshgems_calloc(size_t nmemb, size_t size)
{
  return calloc(nmemb, size);
}

void *meshgems_realloc(void *ptr, size_t size)
{
  return realloc(ptr, size);
}

void meshgems_free(void *ptr)
{
  free(ptr);
}
