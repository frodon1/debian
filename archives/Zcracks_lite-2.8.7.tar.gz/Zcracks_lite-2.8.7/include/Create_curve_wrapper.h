#ifndef __CREATE_CURVE_WRAPPER__
#define __CREATE_CURVE_WRAPPER__

#include <Stringpp.h>
#include <List.h>
#include <Geometry_parts.h>

Z_START_NAMESPACE;

class CREATE_CURVE_WRAPPER
{
  public :
    CREATE_CURVE_WRAPPER();
    virtual ~CREATE_CURVE_WRAPPER();

    void create_poly_curve(STRING);
    void create_pc_curve(STRING);
    void create_quad_curve(STRING);
    void create_bspline_ctrl(STRING);
    void create_cubic_continuous_curve(STRING);
    void set_by_points(STRING,LIST<DAO_POINT*>&);
    void set_cubic_continuous_curve(STRING,LIST<DAO_POINT*>&,LIST<DAO_POINT*>&,LIST<VECTOR>&,LIST<VECTOR>&);
};
Z_END_NAMESPACE;

#endif
