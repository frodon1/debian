#ifndef __Post_trace__
#define __Post_trace__

#include <Local_post_computation.h>
#include <Post_simple.h>

Z_START_NAMESPACE;

ZCLASS2 POST_TRACE :public POST_SIMPLE {
 protected :
  int   tsz;
 public :
  POST_TRACE();
  virtual ~POST_TRACE();
  MODIFY_INFO_RECORD* get_modify_info_record(); 
  virtual void input_i_need(int,ARRAY<STRING>&);
  virtual void output_i_give(bool&,ARRAY<STRING>&);
  virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
};

Z_END_NAMESPACE;
#endif

