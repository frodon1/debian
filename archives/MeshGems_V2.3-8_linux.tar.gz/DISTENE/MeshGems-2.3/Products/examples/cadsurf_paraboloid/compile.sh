gcc -I. -L. cadsurf_paraboloid.c -lmg-cadsurf -lmeshgems -lmeshgems_stubs -lmg-tetra -lm -lc  -o paraboloid.exe
