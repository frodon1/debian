#ifndef __VTK_GNUPLOT_IO_3D__
#define __VTK_GNUPLOT_IO_3D__

#include <Defines.h>
#include <Stringpp.h>
#include <Grid_3d.h>
#include <Buffered_list.h>

Z_START_NAMESPACE;

ZCLASS VTK_GNUPLOT_IO_3D
{
  public :
    void save_vtk(STRING fname, const GRID_3D<double> &grid);
    void save_vtk(STRING fname, const GRID_3D<bool> &grid);  //TODO : a template method
    void save_vtk(STRING fname, const GRID_3D<double> &grid, const GRID_3D<bool> &grid_bool);
    void save_vtk(STRING fname, const GRID_3D< FINITE_SET<3,double> > &grid);
    void save_vtk(STRING fname, const BUFF_LIST<VECTOR>& grid, const BUFF_LIST<VECTOR>& vectors);

    VTK_GNUPLOT_IO_3D() { }
    virtual ~VTK_GNUPLOT_IO_3D() { }
};
Z_END_NAMESPACE;

#endif
