/*
  FF, december 12th, 2007
  A simple 3D tricubic interpolant
*/

#ifndef __TRICUBIC_INTERPOLATION__
#define __TRICUBIC_INTERPOLATION__

#include <Defines.h>
#include <Implicit_surface.h>

Z_START_NAMESPACE;

ZCLASS TRICUBIC_INTERPOLATION : public IMPLICIT_SURFACE
{
  protected :
    static TRICUBIC_INTERPOLATION *active;

    double alpha[3],beta[3];

    SMATRIX unity_tricubic;
    VECTOR v_amn;

    void build_tricubic_on_unity();
    virtual void update_initial_estimate(VECTOR &v) const;
    virtual void update_estimate(VECTOR &v) const;

    double value_(const double x, const double y, const double z) const;
    void gradient_(const double x, const double y, const double z, VECTOR &g) const;

    bool do_projection4(const double x, const double y, const double z, VECTOR &p, const double ratio=1.e-4) const;

    static void sqp_obj(int,int,double*,double*,void*);
    static void sqp_constr(int,int,double*,double*,void*);
    static void sqp_grad_obj(int,int,double *,double *,void (*)(int,int, double *,double *,void *),void *);
    static void sqp_grad_constr(int,int,double *,double *,void (*)(int,int, double *,double *,void *),void *);

  public :
    double x0,y0,z0;
    double dx,dy,dz;
    double values[64];

    TRICUBIC_INTERPOLATION() : IMPLICIT_SURFACE() { }
    ~TRICUBIC_INTERPOLATION() { }

    void initialize(const double _x0, const double _y0, const double _z0, 
                    const double _dx, const double _dy, const double _dz, 
                    const double _values[64]);
    
    virtual double value(const double x, const double y, const double z) const;
    virtual void gradient(const double x, const double y, const double z, VECTOR &g) const;
    virtual void hessian(const double x, const double y, const double z, SMATRIX &h) const;
    virtual bool projection(const double x, const double y, const double z, VECTOR &p, const double ratio=1.e-4) const;
};
Z_END_NAMESPACE;

#endif
