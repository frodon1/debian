#ifndef __Element_topology__
#define __Element_topology__

#include <Defines.h> 
#include <Stringpp.h> 
#include <Aaa_zmat_globals.h>

Z_START_NAMESPACE;

enum TOPOLOGY {
        P1,
        LIN2,  LIN3,  LIN4,
        TRI3,  TRI6,  QUAD4, QUAD8,
        TET4,  TET10, HEX8,  HEX20,
        WEDG6, WEDG15,
        PYRA5, PYRA13,
        GENERIC1,
        GENERIC2,
        GENERIC3,
        GENERIC4,
        GENERIC5,
        GENERIC6,
        GENERIC7,
        GENERIC8,
        GENERIC9,
        NO_TOPOLOGY,
        MAX_TOPOLOGY
};

WIN_THINGIE STRING   translate(TOPOLOGY top); 
WIN_THINGIE TOPOLOGY translate(STRING name); 


class Z_ELEMENT_TYPE { 
// The 'Z' has been added, because this stupid windows already define ELEMENT_TYPE...
// (in winioctl.h)
  public:
    STRING           element_type;  // element type name
    TOPOLOGY         topology_type; // element topology type
    int              ndim;          // element space dimension

    Z_ELEMENT_TYPE() { 
       element_type  = ""; 
       topology_type = NO_TOPOLOGY; 
       ndim          = -1; 
    } 
    Z_ELEMENT_TYPE(const Z_ELEMENT_TYPE& cpy) { 
       element_type  = cpy.element_type;
       topology_type = cpy.topology_type;
       ndim          = cpy.ndim;
    } 
    Z_ELEMENT_TYPE& operator=(const Z_ELEMENT_TYPE& cpy) { 
       element_type  = cpy.element_type; 
       topology_type = cpy.topology_type; 
       ndim          = cpy.ndim; 
       return *this; 
    } 
    int operator==(const Z_ELEMENT_TYPE& et)const { 
       if (element_type!=et.element_type) return 0; 
       if (topology_type!=et.topology_type) return 0; 
       if (ndim!=et.ndim) return 0; 
       return 1; 
    } 
    int operator!=(const Z_ELEMENT_TYPE& et)const { return (this->operator==(et)) ? 0 : 1; }
};

// 
// class providing all the topology information
// 
class ELEMENT_TOPOLOGY {
  public:
    Z_ELEMENT_TYPE  type;          // element type
    int           nnode;         // number of nodes on element
    int           nface;         // number of faces
    int           nedge;         // number of edges
    int           ndot;          // number of dots

    ELEMENT_TOPOLOGY() { 
        nnode = 0; 
        nface = 0; 
        nedge = 0; 
        ndot  = 0; 
    }

    ELEMENT_TOPOLOGY(const ELEMENT_TOPOLOGY& cpy) { 
       type    = cpy.type;
       nnode   = cpy.nnode;
       nface   = cpy.nface;
       nedge   = cpy.nedge;
       ndot    = cpy.ndot;
    }
    ELEMENT_TOPOLOGY& operator=(const ELEMENT_TOPOLOGY& cpy) { 
       type    = cpy.type; 
       nnode   = cpy.nnode; 
       nface   = cpy.nface; 
       nedge   = cpy.nedge; 
       ndot    = cpy.ndot; 
       return *this; 
    } 
    int operator==(const ELEMENT_TOPOLOGY& et)const { 
       if (type!=et.type) return 0; 
       if (nnode!=et.nnode) return 0; 
       if (nface!=et.nface) return 0; 
       if (nedge!=et.nedge) return 0; 
       if (ndot!=et.ndot) return 0; 
       return 1; 
    } 
    int operator!=(const ELEMENT_TOPOLOGY& et)const { return (this->operator==(et)) ? 0 : 1; }

}; 

// 
// class relating a import face name to a face id
// 
class FACEMAP {
  public:
     STRING    name;          // import face name
     int       id;            // zebulon face id

    FACEMAP() { 
        id = 0; 
    }

    FACEMAP(const FACEMAP& cpy) { this->operator=(cpy); } 
    FACEMAP& operator=(const FACEMAP& cpy) { 
       name    = cpy.name; 
       id      = cpy.id; 
       return *this; 
    } 
    int operator==(const FACEMAP& et)const { 
       if (name!=et.name) return 0; 
       if (id  !=et.id) return 0; 
       return 1; 
    } 
    int operator!=(const FACEMAP& et)const { return (this->operator==(et)) ? 0 : 1; }
};

// 
// class relating an import element type to a zebulon element type
//
class ELEMENT_MAP {
 public:
    STRING     import_name;   // import element type name
    STRING     name;          // zebulon element type name
    int        ndim;          // element space dimension

    ELEMENT_MAP() { 
        ndim = -1; 
    }

    ELEMENT_MAP(const ELEMENT_MAP& cpy) { this->operator=(cpy); } 
    ELEMENT_MAP& operator=(const ELEMENT_MAP& cpy) { 
       import_name    = cpy.import_name; 
       name    = cpy.name; 
       ndim    = cpy.ndim; 
       return *this; 
    } 
    int operator==(const ELEMENT_MAP& et)const { 
       if (name!=et.name) return 0; 
       if (import_name!=et.import_name) return 0; 
       if (ndim  !=et.ndim) return 0; 
       return 1; 
    } 
    int operator!=(const ELEMENT_MAP& et)const { return (this->operator==(et)) ? 0 : 1; }
};


// Conversion function two obtain topology informations for a zebulon elt
extern WIN_THINGIE void zebulon_topology_tables(bool if_out=TRUE);
extern WIN_THINGIE ELEMENT_TOPOLOGY get_element_topology(STRING element_name);

Z_END_NAMESPACE;

#endif
