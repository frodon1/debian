#define USE_MODE_FIX 1
#define USE_MODE_CHECK 0

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/meshgems.h>
#include <meshgems/cleaner.h>

/* FOR OEM customers only, uncomment the following */
/*#include <meshgems_key_xxx.h>*/

/**
 * Let's assume that the following structure holds data that
 * represents the input surface mesh on client side.  
 * It could be a database handle or
 * anything else containing surface mesh data. 
 * We will build the mesh_t object that accesses it.
 * See the file meshgems/mesh.h for more detailed information
 */

struct your_mesh_internal_data_t_ {
  /*    _your_mesh_data; */
};

typedef struct your_mesh_internal_data_t_ your_mesh_internal_data_t;

/**
 * Implementation of how the number of vertices in the mesh is obtained.
 * @param[out]	nbvtx	: the number of vertices
 * @param[in]     user_data	: a user pointer.
 * @return error code
 */

status_t mgtm_get_vertex_count(integer * nbvtx, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbvtx = 0;                   /* the number of vertex in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the coordinates of a mesh vertex are obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	xyz	: real[3] array containing the coordinates of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_coordinates(integer ivtx, real * xyz,
                                     void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    xyz[j] = 0;                 /* j'th coordinate of the ivtx'th vertex */

  return STATUS_OK;
}

/**
 * Implementation of how the tag of a mesh vertex is obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	tag	: integer[1] array containing the tag of the vertex ivtx
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_tag(integer ivtx, integer * tag, void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *tag = 0;                     /* tag of the vertex ivtx */

  return STATUS_OK;
}

/**
 * Implementation of how the number of edges in the mesh is obtained.
 * @param[out]	nbedg	: the number of edges
 * @param[in]  user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_count(integer * nbedge, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbedge = 0;                  /* the number of edge in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh edge are obtained.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	vedge	: integer[2] array containing the vertices of the edge
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_vertices(integer iedge, integer * vedge,
                                void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 2; j++)
    vedge[j] = 0;               /* j'th vertex index of the iedge'th edge */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh edge are obtained.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	tag	: integer[1] array containing the tag of the iedge edge
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_tag(integer iedge, integer * tag, void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *tag = 0;                     /* tag of the edge iedge */

  return STATUS_OK;
}


/**
 * Implementation of how the number of triangles in the mesh is obtained.
 * @param[out]	nbtri	: the number of triangles
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_count(integer * nbtri, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbtri = 0;                   /* the number of triangle in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh triangle are obtained.
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]	vtri	: integer[3] array containing the vertices of the triangle
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_vertices(integer itri, integer * vtri,
                                    void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    vtri[j] = 0;                /* j'th vertex index of the itri'th triangle */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh triangle are obtained.
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]  tag	: integer[1] array containing the tag of the triangle itri
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_tag(integer itri, integer * tag,
                               void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *tag = 0;                     /* tag of the triangle itri */

  return STATUS_OK;
}



/**
 * Implementation of how the number of quadrangle in the mesh is obtained.
 * @param[out]	nbquad	: the number of quadrangle
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_quadrangle_count(integer * nbquad, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbquad = 0;                  /* the number of quad in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh quadrangle are obtained.
 * @param[in]	iquad	: index of the desired quadrangle from 1 to nbquad
 * @param[out]	vquad	: integer[4] array containing the vertices of the quadrangle
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_quadrangle_vertices(integer iquad, integer * vquad,
                                      void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 4; j++)
    vquad[j] = 0;               /* j'th vertex index of the iquad'th quadrangle */

  return STATUS_OK;
}

/**
 * Implementation f how the vertices of a mesh quandrangle are obtained.
 * @param[in]	iquad	: index of the desired iquad from 1 to nbquad
 * @param[out]	tag	: integer[1] array containing the tago of the quadrangle iquad
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_quadrangle_tag(integer iquad, integer * tag,
                                 void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *tag = 0;                     /* tag of the quadrangle iquad */

  return STATUS_OK;
}

/**
 * Implementation of how the required vertices in the mesh are obtained.
 * @param[in]	ireqvertex: index of the desired required vertex from 1 to nbreqvertex
 * @param[out]	reqvertex	: integer required property of the vertex
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_required_vertex_property(integer ivtx, integer * rvtx,
                                           void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *rvtx = 0;                    /* the ivtx'th vertex required property : 1 if the vertex is required or 0 if it is not */

  return STATUS_OK;
}

/**
 * Implementation of how the corners in the mesh are obtained.
 * @param[in]	icorner: index of the desired corner from 1 to nbvertex
 * @param[out]	corner	: integer corner property of the vertex
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_corner_property(integer ivtx, integer * corner,
                                  void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *corner = 0;                  /* the ivtx'th corner property : 1 if the vertex is a corner or 0 if it is not */

  return STATUS_OK;
}

/**
 * Implementation of how the required edges in the mesh are obtained.
 * @param[in]	iedge: index of the desired required edge from 1 to nbedge
 * @param[out]	reqedge	: integer required property of the edge
 * @param	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_required_edge_property(integer iedge, integer * redge,
                                         void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *redge = 0;                   /* the iedge'th edge required property : 1 if the edge is required or 0 if it is not */

  return STATUS_OK;
}


/**
 * Implementation of how the required edges in the mesh are obtained.
 * @param[in]	ireqedge: index of the desired required edge from 1 to nbreqedge
 * @param[out]	reqedge	: integer required property of the edge
 * @param	user_data: a user pointer.
 * @return error code
 */

status_t mgtm_get_ridge_property(integer iedge, integer * ridge,
                                 void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *ridge = 0;                   /* the iedge'th ridge property : 1 if the edge is a ridge or 0 if it is not */

  return STATUS_OK;
}


/**
 * This is the message callback function that Cleaner will call when
 * it wants to send a message to the caller
 * see meshgems/message.h for more details.
 *
 * @param[in] msg       : the message
 * @param[in] user_data : a user pointer.
 * @return an error code
 */
status_t my_message_cb(message_t * msg, void *user_data)
{
  char *desc;
  integer e;
  status_t ret;

  ret = message_get_description(msg, &desc);
  if (ret != STATUS_OK) {
    printf("internal error");
    return ret;
  }

  ret = message_get_number(msg, &e);
  if (ret != STATUS_OK) {
    printf("internal error");
    return ret;
  }

  if (e == 0) {
    /* this is an information */
    printf("INFO : %s", desc);
  }

  if (e < 0) {
    printf("ERROR : %s", desc);
  }

  return STATUS_OK;
}



status_t set_cleaner_parameters(cleaner_session_t * mcs)
{
  status_t ret;
  /* You can here specify the Cleaner options, using the API function
   * meshgems_cleaner_set_param().
   * For example : 
   */

  /* This option changes the verbosity level of Cleaner, between 1 and
   * 10.  The higher it is, the more messages Cleaner will send
   * through the message callback. Default is 3.
   */
  ret = meshgems_cleaner_set_param(mcs, "verbose", "3");
  if (ret != STATUS_OK)
    return ret;

  if (USE_MODE_FIX) {
    /* This option sets the number of passes for the fix mode, between
     * 1 and 2.
     * 1 : analyses and fixes mesh with a two pass cleaning procedure
     * 2 : analyses and fixes mesh with only the first stage of the 
     * cleaning procedure
     */
    ret = meshgems_cleaner_set_param(mcs, "number_of_passes", "1");
    if (ret != STATUS_OK)
      return ret;
    /* or */
    ret = meshgems_cleaner_set_param(mcs, "number_of_passes", "2");
    if (ret != STATUS_OK)
      return ret;
  }
  /*
   * Set this parameter to yes to insert vertices on planes to 
   * improve mesh quality.
   * Default is not to mesh planes
   * May be useful for poor quality triangulations (eg. STL or 
   * DXF triangulations)
   */
  ret = meshgems_cleaner_set_param(mcs, "remesh_planes", "yes");
  if (ret != STATUS_OK)
    return ret;

  /*
   * Set the threshold angle below which 2 connected triangles are 
   * considered overlapping
   * Default is 15 degrees."
   * Reduce this value if model contains sharp angles below this 
   * threshold that must be kept overlap_angle is set to this angle 
   * if it is higher
   */
  ret = meshgems_cleaner_set_param(mcs, "folding_angle", "15");
  if (ret != STATUS_OK)
    return ret;

  /*
   * Set the angle below which 2 unconnected triangles are 
   * considered overlapping
   * Default is 15 degrees."
   * folding_angle is set to this angle if it is lower
   */
  ret = meshgems_cleaner_set_param(mcs, "overlap_angle", "15");
  if (ret != STATUS_OK)
    return ret;

  /*
   * Set the distance threshold above which 2 points are considered 
   * distinct.
   * Default is computed from model.
   * Sets the tolerance_displacement to 1/5 of this size
   */
  ret = meshgems_cleaner_set_param(mcs, "resolution_length", "0.15");
  if (ret != STATUS_OK)
    return ret;

  /*
   * Set the distance below which two unconnected triangles are 
   * considered overlapping
   * Default is computed from model
   * Reduce this value if too many overlaps are detected
   */
  ret = meshgems_cleaner_set_param(mcs, "overlap_distance", "0.15");
  if (ret != STATUS_OK)
    return ret;

  /*
   * Set the displacement threshold below which modification is 
   * allowed.
   * Default is computed from model
   * Unused in collision resolution
   * tolerance_displacement is set to resolution_length if it is lower.
   */
  ret = meshgems_cleaner_set_param(mcs, "tolerance_displacement", "0.15");
  if (ret != STATUS_OK)
    return ret;


  /*
   * Set the surface size threshold below which holes are filled.
   * Default is not to fill holes.
   */
  ret = meshgems_cleaner_set_param(mcs, "min_hole_size", "0.1");
  if (ret != STATUS_OK)
    return ret;

  /*
   * Set the applicable fixing operations
   * Default is 'ignore'
   * ignore  : applies all fixing operations
   * respect : disables fixing operations which induce topology 
   * modifications
   */

  ret = meshgems_cleaner_set_param(mcs, "topology", "respect");
  if (ret != STATUS_OK)
    return ret;
  /* or */
  ret = meshgems_cleaner_set_param(mcs, "topology", "ignore");
  if (ret != STATUS_OK)
    return ret;

  return STATUS_OK;

}


/* A macro we will call to cleanly return from the function in case of failure */
#define RETURN_WITH_MESSAGE(_ret, _msg) do{				\
    fprintf(stderr,"%s\n",_msg);					\
    if(mcs) cleaner_session_delete(mcs);				\
    if(msh) mesh_delete(msh);						\
    if(ctx) context_delete(ctx);					\
    return _ret;							\
  }while(0);




status_t cleaner_mesh(your_mesh_internal_data_t * your_mesh_internal_data)
{
  status_t ret;
  context_t *ctx;
  mesh_t *msh, *msh_output;
  cleaner_session_t *mcs;
  integer i, nvm, ntm, nem, nqm;
  integer nbcorner = 0, nbreqvtx = 0;
  integer isCorner, isReqvtx;
  integer nbridge = 0, nbreqedge = 0;
  integer isReqedge, isRidge;

  integer ntag, *buff = NULL;

  ctx = 0;
  msh = 0;
  mcs = 0;
  msh_output = 0;


  /*
   * Create the meshgems working context
   */
  ctx = context_new();
  if (!ctx)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new context");

  /*
   * Set the message callback for our context and create the mesh accessor.
   */
  ret = context_set_message_callback(ctx, my_message_cb, 0);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /*
   * Create the mesh_t structure holding the callbacks giving acces to your mesh data in
   * your_mesh_internal_data
   */
  msh = mesh_new(ctx);
  if (!msh)
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new mesh");

  /*
   * Set the mesh_t callback functions that will interogate the mm_t struct :
   * see meshgems/mesh.h for more details.
   */

  ret = mesh_set_get_vertex_count(msh, mgtm_get_vertex_count,
                                  your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret = mesh_set_get_vertex_coordinates(msh, mgtm_get_vertex_coordinates,
                                        your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret = mesh_set_get_vertex_tag(msh, mgtm_get_vertex_tag,
                                your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret =
      mesh_set_get_vertex_required_property(msh,
                                            mgtm_get_required_vertex_property,
                                            your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret =
      mesh_set_get_vertex_corner_property(msh, mgtm_get_corner_property,
                                          your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret =
      mesh_set_get_edge_count(msh, mgtm_get_edge_count,
                              your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret = mesh_set_get_edge_vertices(msh, mgtm_get_edge_vertices,
                                   your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret =
      mesh_set_get_edge_tag(msh, mgtm_get_edge_tag,
                            your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret =
      mesh_set_get_edge_required_property(msh,
                                          mgtm_get_required_edge_property,
                                          your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret = mesh_set_get_edge_ridge_property(msh, mgtm_get_ridge_property,
                                         your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret = mesh_set_get_triangle_count(msh, mgtm_get_triangle_count,
                                    your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret = mesh_set_get_triangle_vertices(msh, mgtm_get_triangle_vertices,
                                       your_mesh_internal_data);

  ret = mesh_set_get_triangle_tag(msh, mgtm_get_triangle_tag,
                                  your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  ret = mesh_set_get_quadrangle_count(msh, mgtm_get_quadrangle_count,
                                      your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret = mesh_set_get_quadrangle_vertices(msh, mgtm_get_quadrangle_vertices,
                                         your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");
  ret = mesh_set_get_quadrangle_tag(msh, mgtm_get_quadrangle_tag,
                                    your_mesh_internal_data);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");


#ifdef __MESHGEMS_PRIVKEY_H__
  /* If you are an OEM customer for Cleaner, sign this mesh object with
   * your private key (else Cleaner would reject it) */
  ret = meshgems_sign_mesh(msh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to sign input mesh");
#endif

  /*
   * Create a cleaner session
   */

  mcs = cleaner_session_new(ctx);
  if (!mcs)
    RETURN_WITH_MESSAGE(STATUS_NOMEM,
                        "unable to create a new cleaner session");

  /*
   * Set the input working surface for this cleaner session
   */

  /*
   * Starting from a surface mesh.
   */

  ret = cleaner_set_surface_mesh(mcs, msh);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to set surface mesh");

  /* 
   * You can here specify the MG-CLEANER options, using the function
   * cleaner_set_param(), see the documentation.
   */

  ret = set_cleaner_parameters(mcs);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /* 
   * Analyses and fixes mesh OR  performs checks only (no fixing)
   */

  if (USE_MODE_FIX) {
    /* 
     * Analyses and fixes mesh with a cleaning procedure.
     * Does not write diagnostics into the output file.
     */
    ret = meshgems_cleaner_fix(mcs);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "internal error");
  }

  if (USE_MODE_CHECK) {

    /* 
     * Performs checks only (no fixing) 
     * Write diagnostics into the output file.
     */
    ret = meshgems_cleaner_check(mcs);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "internal error");
  }

  /*
   * Mesh generation is completed.
   * Get the generated mesh. This output mesh belongs to the
   * cleaner_session. Thus the user does not have to destroy it
   * afterwards.
   */

  ret = meshgems_cleaner_get_mesh(mcs, &msh_output);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting mesh");

  /*
   * Read the output mesh data. See meshgems/mesh.h for more details.
   */

  buff = (integer *) mesh_calloc_generic_buffer(msh_output);

  /* First get all the vertices */
  ret = mesh_get_vertex_count(msh_output, &nvm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex count");

  for (i = 1; i <= nvm; i++) {
    real coo[3];
    integer tag;
    ret = mesh_get_vertex_coordinates(msh_output, i, coo);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting vertices");
    if (0) {
      fprintf(stdout, "vertex %d is : %f %f %f \n", i, coo[0], coo[1],
              coo[2]);
    }
    ret = mesh_get_vertex_tag(msh_output, i, &tag);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex tag");
    /* Now tag contains the tag of the vertex. */
    if (0) {
      fprintf(stdout, "vertex %d is in subdomain %d\n", i, tag);
    }
    if (0) {
      /* A tag may be a composite tag. Here is how to check its definition */
      /* The same can be done for edge/triangle/... tags. */
      ret = mesh_get_composite_tag_definition(msh_output, tag, &ntag, buff);
      if (ret != STATUS_OK)
	return ret;

      /* buff[0..ntag-1] contains all the original tags of the vertex */
      if (ntag > 1) {
	/* There are several tags associated to the vertex #i. Print them : */
	integer itag;
	printf("The original tags are :\n");
	for (itag = 0; itag < ntag; itag++)
	  printf("%d ", buff[itag]);
	printf("\n");
      }
    }
  }

  /* Then get all the property of the vertex : corner, required vertex 
   * or no particular property  */
  for (i = 1; i <= nvm; i++) {
    ret = mesh_get_vertex_required_property(msh_output, i, &isReqvtx);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex property");
    if (isReqvtx)
      nbreqvtx++;
    ret = mesh_get_vertex_corner_property(msh_output, i, &isCorner);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting vertex property");
    if (isCorner)
      nbcorner++;
  }
  if (nbreqvtx) {
    fprintf(stdout, "%d required vertices in the domain \n", nbreqvtx);
    for (i = 1; i <= nvm; i++) {
      ret = mesh_get_vertex_required_property(msh_output, i, &isReqvtx);
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret,
                            "unable to get resulting vertex property");
      if (isReqvtx)
        fprintf(stdout, "required vertex %d \n", i);
    }
  }
  if (nbcorner) {
    fprintf(stdout, "%d corners in the domain \n", nbcorner);
    for (i = 1; i <= nvm; i++) {
      ret = mesh_get_vertex_corner_property(msh_output, i, &isCorner);
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret,
                            "unable to get resulting vertex property");
      if (isCorner)
        fprintf(stdout, "corner %d \n", i);
    }
  }

  /* Then get all the edge */
  ret = mesh_get_edge_count(msh_output, &nem);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting edge count");

  for (i = 1; i <= nem; i++) {
    integer vtx[2], tag;
    ret = mesh_get_edge_vertices(msh_output, i, vtx);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting edge");
    if (0) {
      fprintf(stdout, "edge %d is : %d %d \n", i, vtx[0], vtx[1]);
    }
    ret = mesh_get_edge_tag(msh_output, i, &tag);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting edge tag");
    if (0) {
      fprintf(stdout, "edge %d is in subdomain %d\n", i, tag);
    }

  }
  /* Then get all the property of the edge : ridge, required edge 
   * or no particular property  */
  for (i = 1; i <= nem; i++) {
    ret = mesh_get_edge_required_property(msh_output, i, &isReqedge);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting edge property");
    if (isReqedge)
      nbreqedge++;
    ret = mesh_get_edge_ridge_property(msh_output, i, &isRidge);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting edge property");
    if (isRidge)
      nbridge++;
  }
  if (nbreqedge) {
    fprintf(stdout, "%d required edges in the domain \n", nbreqedge);
    for (i = 1; i <= nem; i++) {
      ret = mesh_get_edge_required_property(msh_output, i, &isReqedge);
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret, "unable to get resulting edge property");
      if (isReqedge)
        fprintf(stdout, "required edge %d \n", i);
    }
  }
  if (nbridge) {
    fprintf(stdout, "%d ridges in the domain \n", nbridge);
    for (i = 1; i <= nem; i++) {
      ret = mesh_get_edge_ridge_property(msh_output, i, &isRidge);
      if (ret != STATUS_OK)
        RETURN_WITH_MESSAGE(ret, "unable to get resulting edge property");
      if (isRidge)
        fprintf(stdout, "ridge %d \n", i);
    }
  }

  /* Then get all the triangle and quadrangle */

  ret = mesh_get_triangle_count(msh_output, &ntm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting triangle count");

  for (i = 1; i <= ntm; i++) {
    integer vtx[3], tag;
    ret = mesh_get_triangle_vertices(msh_output, i, vtx);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting triangle");
    if (0) {
      fprintf(stdout, "triangle %d is : %d %d %d \n", i, vtx[0], vtx[1],
              vtx[2]);
    }
    ret = mesh_get_triangle_tag(msh_output, i, &tag);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting triangle tag");
    if (0) {
      fprintf(stdout, "triangle %d is in subdomain %d\n", i, tag);
    }
  }

  ret = mesh_get_quadrangle_count(msh_output, &nqm);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to get resulting quadrangle count");

  for (i = 1; i <= nqm; i++) {
    integer vtx[4], tag;
    ret = mesh_get_quadrangle_vertices(msh_output, i, vtx);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting quadrangle");
    if (0) {
      fprintf(stdout, "quadrangle %d is : %d %d %d %d \n", i, vtx[0],
              vtx[1], vtx[2], vtx[3]);
    }
    ret = mesh_get_quadrangle_tag(msh_output, i, &tag);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get resulting quadrangle tag");
    if (0) {
      fprintf(stdout, "quadrangle %d is in subdomain %d\n", i, tag);
    }
  }

  if(buff) mesh_free_generic_buffer(buff);

  /*
   * We can also directly write a .mesh formatted file :
   */

  /* Please note that composite tag definitions are not written in the
     .mesh file as of today */

  fprintf(stdout, "Writing surface mesh in cleaner_result.mesh file\n");
  ret = mesh_write_mesh(msh_output, "cleaner_result.mesh");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "unable to write a .mesh file");

  /* 
   * With the check mode, Cleaner performs checks on the surface 
   * mesh to detect potential problems. 
   * The resulting areas are gathered as sets of triangles grouped by 
   * fault category
   * The categories of faults are:
   * SmallTri, BadShape, Overlap, FreeEdge, Inter and NearTri 
   */

  if (USE_MODE_CHECK) {
    integer id_Tri;
    integer nb_smallTri;
    ret = meshgems_cleaner_mesh_get_SmallTri_count(mcs, &nb_smallTri);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get SmallTri element count");
    if (nb_smallTri > 0) {
      fprintf(stdout, "%d Fault_SmallTri \n", nb_smallTri);
      for (i = 1; i <= nb_smallTri; i++) {
        ret = meshgems_cleaner_mesh_get_SmallTri(mcs, i, &id_Tri);
        if (ret != STATUS_OK)
          RETURN_WITH_MESSAGE(ret, "unable to get SmallTri element");
        fprintf(stdout, "%d\n", id_Tri);
      }
    }
    integer nb_badShape;
    ret = meshgems_cleaner_mesh_get_BadShape_count(mcs, &nb_badShape);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret,
                          "unable to get Fault_BadShape element count ");
    if (nb_badShape > 0) {
      fprintf(stdout, "%d Fault_BadShape\n", nb_badShape);
      for (i = 1; i <= nb_badShape; i++) {
        ret = meshgems_cleaner_mesh_get_BadShape(mcs, i, &id_Tri);
        if (ret != STATUS_OK)
          RETURN_WITH_MESSAGE(ret, "unable to get Fault_BadShape element");
        fprintf(stdout, "%d\n", id_Tri);
      }
    }
    integer nb_Overlap;
    ret = meshgems_cleaner_mesh_get_Overlap_count(mcs, &nb_Overlap);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get Overlap element count");
    if (nb_Overlap > 0) {
      fprintf(stdout, "%d Fault_Overlap\n", nb_Overlap);
      for (i = 1; i <= nb_Overlap; i++) {
        ret = meshgems_cleaner_mesh_get_Overlap(mcs, i, &id_Tri);
        if (ret != STATUS_OK)
          RETURN_WITH_MESSAGE(ret, "unable to get Overlap element");
        fprintf(stdout, "%d\n", id_Tri);
      }
    }
    integer nb_FreeEdge;
    ret = meshgems_cleaner_mesh_get_FreeEdge_count(mcs, &nb_FreeEdge);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get FreeEdge element count");
    if (nb_FreeEdge > 0) {
      fprintf(stdout, "%d Fault_FreeEdge\n", nb_FreeEdge);
      for (i = 1; i <= nb_FreeEdge; i++) {
        ret = meshgems_cleaner_mesh_get_FreeEdge(mcs, i, &id_Tri);
        if (ret != STATUS_OK)
          RETURN_WITH_MESSAGE(ret, "unable to get FreeEdge element ");
        fprintf(stdout, "%d\n", id_Tri);
      }
    }
    integer nb_Inter;
    ret = meshgems_cleaner_mesh_get_Inter_count(mcs, &nb_Inter);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get Inter element count");
    if (nb_Inter > 0) {
      fprintf(stdout, "%d Fault_Inter\n", nb_Inter);
      for (i = 1; i <= nb_Inter; i++) {
        ret = meshgems_cleaner_mesh_get_Inter(mcs, i, &id_Tri);
        if (ret != STATUS_OK)
          RETURN_WITH_MESSAGE(ret, "unable to get Inter element ");
        fprintf(stdout, "%d\n", id_Tri);
      }
    }
    integer nb_NearTri;
    ret = meshgems_cleaner_mesh_get_NearTri_count(mcs, &nb_NearTri);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to get NearTri element count");
    if (nb_NearTri > 0) {
      fprintf(stdout, "%d Fault_NearTri\n", nb_NearTri);
      for (i = 1; i <= nb_NearTri; i++) {
        ret = meshgems_cleaner_mesh_get_NearTri(mcs, i, &id_Tri);
        if (ret != STATUS_OK)
          RETURN_WITH_MESSAGE(ret, "unable to get NearTri");
        fprintf(stdout, "%d\n", id_Tri);
      }
    }

  }


  /*
   * We are done, give the volume mesh back to the session and clean up 
   everything.
   */

  cleaner_regain_mesh(mcs, msh_output);
  cleaner_session_delete(mcs);
  mesh_delete(msh);

  context_delete(ctx);

  return STATUS_OK;
}
