#ifndef __ZP_DAO_QUAD_CURVE__
#define __ZP_DAO_QUAD_CURVE__

#include <Geometry_parts.h>
#include <ZP_stack.h>
#include <ZP_object.h>
#include <Dao_quad_curve.h>
#include <Poly_curve.h>
#include <ZP_dao_edge.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_DAO_QUAD_CURVE : public ZP_DAO_EDGE 
{
  protected :
    virtual ZP_FATAL_ERROR* print(ZP_STACK&,int);
    ZP_FATAL_ERROR* add(ZP_STACK&,int);
    ZP_FATAL_ERROR* reset(ZP_STACK&,int);

    virtual void type_init(char*) { _CHECK_DGLP_ type="QUAD_CURVE"; }
    virtual void dao_add() { dao_geom_link_program->other_entities.add(&get()); }
    virtual void dao_delete() { if(dao_linked==0) dao_geom_link_program->other_entities.suppress_item(&get()); }
    void _dao_delete() { dao_geom_link_program->other_entities.suppress_item(&get()); }

  public :
    ZP_DAO_QUAD_CURVE() : ZP_DAO_EDGE(NULL) { type_init(NULL); contens=new DAO_QUAD_CURVE(dao_geom_link_program); dont_delete=0; dao_add(); }
    ZP_DAO_QUAD_CURVE(DAO_QUAD_CURVE *d) : ZP_DAO_EDGE(d) { type_init(NULL); }

    DESTRUCTORS_DAO(ZP_DAO_QUAD_CURVE)

    virtual DAO_QUAD_CURVE& get() { return(*((DAO_QUAD_CURVE*)contens)); }

    METHOD_DECLARATION_START
      METHOD("add",add,1)
      METHOD("reset",reset,0)
    METHOD_DECLARATION_ANCESTOR(ZP_DAO_EDGE)

    ZPO_RTTI_INFO(DAO_QUAD_CURVE)
};
Z_END_NAMESPACE;

#endif
