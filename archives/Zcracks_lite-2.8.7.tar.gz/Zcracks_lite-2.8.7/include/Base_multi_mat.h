#ifndef __Base_multi_mat__
#define __Base_multi_mat__

// ============================================================================ 
//   BASE_MULTI_MAT         Z8.1-Z8.2 conversion Sept 15 2000 RF 
// 
//   I put the sub-behaviors in this class (instead of behavior), and kept 
//   the "iterator" sense of accessign all sub stuffs. i find that interface 
//   somewhat less legible, and definately less "patchable" for special 
//   implementations which could come up outside the main development tree. 
// 
//    o Note that this iterator thing is not safe for nested loops... something
//      which is probably needed for implicit integration 
// ============================================================================ 

#include <ZMath.h>
#include <Behavior.h>
#include <Pointer.h>
#include <Dictionnary.h>
#include <File.h>
#include <Integration_runge.h>
#include <Integration_theta.h>
#include <Object_factory.h>
#include <Rotation.h>
#include <Tensor4.h>
#include <Z_object.h>

Z_START_NAMESPACE;

ZCLASS BASE_MULTI_MAT : public BEHAVIOR, 
                  public RUNGE_INTEGRATOR,
                  public THETA_INTEGRATOR {

 // 
 // please pretend this section is private if you can 
 // 
 public :  
   STRING           debug_name; 

   int              iib; 
   PLIST<BEHAVIOR>  sub_behavior;
   LIST<double>    _frac;
   PLIST<ROTATION> _lrotation;
   LIST<STRING>    _names;

   STRING  mm_flux_name; 
   STRING  mm_grad_name; 
   int     self_int_size; 
   int     self_aux_size; 

 public :
   int copy_vec_values(VECTOR& v1,int pos, const VECTOR& v2, int st, int len); 

   int              Variable_coefs, Coef_evaluated;

   VECTOR           util;
   VECTOR           integration_vector;
   VECTOR           rate_vector;

   void attach_behavior_vectors(VECTOR& vint, VECTOR& dvint); 

   ARRAY<VECTOR>    behavior_vints; 
   ARRAY<VECTOR>    behavior_dvints; 

   VECTOR           m_f_vec;
   VECTOR           m_d_chi;
   VECTOR           m_f_0;
   SMATRIX          m_f_grad;

   AUTO_PTR<RUNGE>              intrk;
   AUTO_PTR<THETA>              inttn;

   void rotate_to_material(TENSOR2&);
   void rotate_from_material(TENSOR2&);
   void rotate_to_material(TENSOR4&);
   void rotate_from_material(TENSOR4&);
   void rotate_to_material(VECTOR&);
   void rotate_from_material(VECTOR&);

   void start() { iib=0; }
   bool ok()    { return (iib==nb()) ? FALSE : TRUE; }
   void next()  { iib++; }

   int nb()     { return !sub_behavior; }
         BEHAVIOR& behavior()      { return *sub_behavior[iib]; }
   const BEHAVIOR& behavior()const { return *((BASE_MULTI_MAT*)this)->sub_behavior[iib]; }
         BEHAVIOR* get_sub_behavior(int i)      { return sub_behavior[i](); }
   const BEHAVIOR* get_sub_behavior(int i)const { return ((BASE_MULTI_MAT*)this)->sub_behavior[i](); }

   double&        frac()     { return _frac[iib]; }
   const double&  frac()const{ return _frac[iib]; }

   AUTO_PTR<ROTATION>& lrotation() { return _lrotation[iib]; }

   virtual int index_size(); 

   // ------------------------------------------------------------ 
   // Setup manages the material-piece connectivity, and places the stored-variables 
   // to appropriate positions on the VINT/VAUX vectors. The function can also be used 
   // for configuration of local data strutures at the start of the problem, and when 
   // these var positions and sizes are fixed. 
   // 
   // The func setup_integration_vectors can be overloaded.. in the base class 
   // the integration vector holds all vints for this and all sub_behaviors. 
   // staggered solves like in the TFA model need to adjust that. 
   // ------------------------------------------------------------ 
   virtual void setup(int& flux_pos, int& grad_pos, int& vi_pos, int& va_pos); 
   virtual void setup_integration_vectors();  // called at the end of setup 

   virtual void init_material_data(MAT_DATA& mdat); 

   virtual void extract_sub_grad_flux(); 
   virtual void set_var_aux_to_var_aux_ini(); 
   virtual void set_var_int_to_var_int_ini(); 
   virtual void attach( VECTOR&  chi_vec, VECTOR&  d_chi ); 


   // 
   // Default error 
   // 
   virtual void derivative(double, const VECTOR &, VECTOR &); 
   virtual void calc_grad_f(VECTOR &, SMATRIX &, 
                            const VECTOR &, const VECTOR &, 
                            double, double); 
   virtual void material_derivative(double tau, const VECTOR& var, VECTOR& dvar);
   virtual void material_grad_f(VECTOR& f_vec, SMATRIX& f_grad, const VECTOR& chi_vec,
                            const VECTOR& d_chi, double theta, double dt);

 public :
   double keep_theta; // set at each call of theta_at_time... 
   double theta_at_time(double tau); 

   BASE_MULTI_MAT();
   virtual ~BASE_MULTI_MAT();
   virtual void initialize(ASCII_FILE&, int, LOCAL_INTEGRATION*);
   virtual int base_read(const STRING&,ASCII_FILE&,LOCAL_INTEGRATION*);

   RTTI_INFO;
};

Z_END_NAMESPACE;
#endif

