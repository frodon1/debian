#ifndef __Dao_grid__
#define __Dao_grid__

#include <Vector.h>

#include <Graphics_object.h>
#include <Graphics_command.h>

Z_START_NAMESPACE;

class DAO_GEOMETRY; 
class GRAPHICS_AREA; 

ZCLASS2 DAO_GRID : public GRAPHICS_COMMAND, 
                 public GRAPHICS_OBJECT {
  protected : 
    DAO_GEOMETRY* its_dao; 
    GRAPHICS_DATA_DIALOG* its_dialog;

    int mode;
    LIST<int> mode_options;

    virtual void local_draw(GRAPHICS_AREA* ga);
    virtual void draw_grid(double fact_x, double fact_y); 
  public : 

    DAO_GRID();
    virtual void    initialize(GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app); 

    virtual void   put_pt_on_grid(GRAPHICS_POINT& clk); 
    virtual VECTOR convert_point(GRAPHICS_POINT& pp1, GRAPHICS_POINT& pp2); 
    virtual bool do_command(STRING cmd);
    virtual bool do_click(int track, GRAPHICS_POINT& click, GRAPHICS_OBJECT* target);

    double         spacing; 
    double         steps; 
    GRAPHICS_POINT center; 
    int active; 

    int click_number; 
    VECTOR click1; 
    VECTOR click2; 
    VECTOR click3; 

    //
    // This is the drawing coordiante system which is used for
    // direct clicking on the screen. Points are obtained by sending
    // the click to get_click_point .. which creates a DAO_POINT if
    // there was not one.. and can use a grid if desired
    //
    VECTOR draw_plane_center;  // the plane is dpc + u*dpx + v*dpy
    VECTOR draw_plane_x;
    VECTOR draw_plane_y;
    VECTOR draw_plane_norm;

    // 
    // Returns 1 for X-Y plane... eventually 2 for Y-Z, 3 for Z-X ... 
    // 
    int is_standard_grid(); 
}; 
Z_END_NAMESPACE;

#endif
