#ifndef __Explicit_damping__
#define __Explicit_damping__

// ============================================================================ 
//  Base classes for explicit damping methods. 
// ============================================================================ 

#include <Vector.h>

Z_START_NAMESPACE;


class PROBLEM_EXPLICIT_MECHANICAL; 

ZCLASS2 EXPLICIT_DAMPING { 
    protected:
      VECTOR Fdamp; 

      PROBLEM_EXPLICIT_MECHANICAL* its_boss; 
    public:
      
      EXPLICIT_DAMPING();
      virtual ~EXPLICIT_DAMPING(); 
      virtual void initialize(ASCII_FILE& file, PROBLEM_EXPLICIT_MECHANICAL* boss); 

      virtual const VECTOR& compute_force(const VECTOR& velocity); 
      virtual void          adjust_critical_time(double& /* crit_time */) { } 
      virtual bool          active()const { return TRUE; } 
}; 

ZCLASS2 EXPLICIT_DAMPING_CONSTANT : public EXPLICIT_DAMPING {
    public:
      double coef; 

      EXPLICIT_DAMPING_CONSTANT();
      virtual ~EXPLICIT_DAMPING_CONSTANT();
      virtual void initialize(ASCII_FILE& file, PROBLEM_EXPLICIT_MECHANICAL* boss);

      virtual const VECTOR& compute_force(const VECTOR& velocity);
      virtual bool active()const { return (coef>0.0); } 
};  
Z_END_NAMESPACE;

#endif
