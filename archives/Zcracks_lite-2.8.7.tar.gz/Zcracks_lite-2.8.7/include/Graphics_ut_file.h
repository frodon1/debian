#ifndef __Ut_file__
#define __Ut_file__

#include <Defines.h> 
#include <List.h> 
#include <Stringpp.h> 
#include <Aaa_zmat_globals.h>

Z_START_NAMESPACE;

class ASCII_FILE; 

ZCLASS GRAPHICS_UT_FILE { 
  protected : 
  public : 
    GRAPHICS_UT_FILE(); 
    GRAPHICS_UT_FILE(ASCII_FILE& file); 
    virtual ~GRAPHICS_UT_FILE(); 

    void read(ASCII_FILE& file); 

    STRING        pb_name; 
    STRING        meshfile;  
    STRING        ctmat_suff, node_suff, integ_suff; 
    STRING        ctele_suff;
    STRING        ctnod_suff;
    LIST<STRING>  node;      
    LIST<STRING>  integ;     
    LIST<STRING>  element;   

    LIST<double>  map;        //  the times are stored here. 
    LIST<STRING>  map_m_file; //  this is so the mesh can change 
}; 
Z_END_NAMESPACE;

#endif 
