#ifndef __Graphics_color_names__
#define __Graphics_color_names__

Z_START_NAMESPACE;

static const char* GRAPHICS_COLOR_NAMES[50] = {
                            "GRAPHICS_BLACK",
                            "GRAPHICS_WHITE",
                            "GRAPHICS_RED",
                            "GRAPHICS_BLUE",
                            "GRAPHICS_YELLOW",
                            "GRAPHICS_GREEN",
                            "GRAPHICS_ORANGE",
                            "GRAPHICS_VIOLET",
                            "GRAPHICS_OLD_BLUE",
                            "GRAPHICS_OLD_YELLOW",
                            "GRAPHICS_OLD_GREEN",
                            "GRAPHICS_MAROON",
                            "GRAPHICS_PINK",
                            "GRAPHICS_GRAY",
                            "GRAPHICS_COL_255_250_205", // LemonChiffon
                            "GRAPHICS_COL_123_104_238", // medium slate blue
                            "GRAPHICS_COL_95_158_160", // CadetBlue
                            "GRAPHICS_COL_143_188_143", // DarkSeaGreen
                            "GRAPHICS_COL_154_205_50", // YellowGreen
                            "GRAPHICS_COL_240_230_140", // khaki
                            "GRAPHICS_COL_205_92_92", // IndianRed
                            "GRAPHICS_COL_160_82_45", // sienna
                            "GRAPHICS_COL_222_184_135", // burlywood
                            "GRAPHICS_COL_245_245_220", // beige
                            "GRAPHICS_COL_255_165_0", // orange
                            "GRAPHICS_COL_255_20_147", // deep pink
                            "GRAPHICS_COL_176_48_96", // maroon
                            "GRAPHICS_COL_208_32_144", // violet red
                            "GRAPHICS_COL_240_255_255", // azure1
                            "GRAPHICS_COL_30_144_255", // DodgerBlue1
                            "GRAPHICS_COL_135_206_255", // SkyBlue1
                            "GRAPHICS_COL_0_255_127", // SpringGreen1
                            "GRAPHICS_COL_127_255_0", // chartreuse1
                            "GRAPHICS_COL_192_255_62", // OliveDrab1
                            "GRAPHICS_COL_255_193_37", // goldenrod1
                            "GRAPHICS_COL_255_48_48", // firebrick1
                            "GRAPHICS_COL_255_114_86", // coral1
                            "GRAPHICS_COL_155_48_255", // purple1
                            "GRAPHICS_COL_205_181_205" // thistle3
};
Z_END_NAMESPACE;

#endif
