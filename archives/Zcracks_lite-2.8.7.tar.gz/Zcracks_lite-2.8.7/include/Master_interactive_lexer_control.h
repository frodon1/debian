#ifndef __MASTER_INTERACTIVE_CONTROL__
#define __MASTER_INTERACTIVE_CONTROL__

#include <Stringpp.h>
#include <Graphics_data_dialog.h>
#include <ZP_piece.h>

Z_START_NAMESPACE;

class INTERACTIVE_LEXER_PB;
class ZP_PROGRAM_ITEM;
class ZP_ENV;

#define ZP_MASTER_ISSUE(a) { STRING cmd = a; MASTER_INTERACTIVE_LEXER_CONTROL::active_engine->put(cmd); } 
#define ZPM_NAME(a)  "\""+a->name+"\""

ZCLASS MASTER_INTERACTIVE_LEXER_CONTROL : public COMMANDER {
  protected :
    GRAPHICS_DATA_DIALOG *more_dialog,*error_dialog;
    INTERACTIVE_LEXER_PB *its_lexer_pb;
    LIST< AUTO_PTR<ZP_PIECE> > tape;
    LIST< ZP_FATAL_ERROR*> errors;
    STRING last_cmd;
    bool recording;

    GRAPHICS_DATA_DIALOG *session_dialog;
    Zofstream session_file;
    STRING session_file_name;

    void build_error_dialog();
    void build_more_dialog();
    void update_error_dialog();
    void update_dialog();
    virtual void save();
    void save_all();

    void restore_session();

  public :
    static MASTER_INTERACTIVE_LEXER_CONTROL *active_engine;
    static ZP_ENV* active_env();
    static INTERACTIVE_LEXER_PB* active_lexer();

    MASTER_INTERACTIVE_LEXER_CONTROL();
    virtual ~MASTER_INTERACTIVE_LEXER_CONTROL();

    virtual bool do_command(STRING);
    int put(STRING);
    int put(LIST<STRING>&);

    void finish();
    void start();

    static void check_unique_object_name(const STRING radix, STRING &name, int &rk);
    static bool does_exist(STRING &name);
};

Z_END_NAMESPACE;

#endif
