// JR  09/02/2011..
//This global variable is used to handle a pointer toward the main problem within a python script
//TODO : merge Problem_global.h  in Global.h



#ifndef __Problem_global__
#define __Problem_global__


#include <Base_problem.h>
#include <Defines.h>



Z_START_NAMESPACE;

extern  WIN_THINGIE BASE_PROBLEM* problem_global;
extern  WIN_THINGIE void* problem_global_python_data; //void* should be a PyObject, but we wait for Python.h to be included in the whole project
extern  WIN_THINGIE void* problem_global_python_data_container; //same as problem_global_python_data but is of simpler use. problem_global_python_data is kept for retro-compatibility
extern  WIN_THINGIE bool problem_global_python_data_set; //return false if problem_global_python_data_container has been not afected, true if it was

Z_END_NAMESPACE;

#endif
