#ifndef _Rivlin_viscoelasticity_
#define _Rivlin_viscoelasticity_

// ---------------------------------------------------------------------------- 
// RIVLIN_VISCOELASTIC  
// ---------------------------------------------------------------------------- 

#include <Rivlin.h>

Z_START_NAMESPACE;

/*** 

** 
** 
**  Moved to Hyper_visco_elastic.h  RF 1/22/2001 ** I'm leaving this 
**  in here for now in case others have some modifs to resolve with 
**  cvs soon... 
** 
ZCLASS RIVLIN_VISCOELASTIC : public RIVLIN {
      protected :
        class SHEAR : public MATERIAL_PIECE {
           TENSOR2_VAUX   v_dev; 
           COEFF          tau, omega;
           SHEAR(ASCII_FILE&,RIVLIN_VISCOELASTIC*,int);
           friend class RIVLIN_VISCOELASTIC;
        };

        class VOLUMIC : public MATERIAL_PIECE {
           SCALAR_VAUX    v_vol;
           COEFF          tau, omega;
           VOLUMIC(ASCII_FILE&,RIVLIN_VISCOELASTIC*,int);
           friend class RIVLIN_VISCOELASTIC;
        };

        PLIST<SHEAR>   shear;
        PLIST<VOLUMIC> volumic;

        virtual void verif_read();
        virtual void read_data(ASCII_FILE&);

      public :

        RIVLIN_VISCOELASTIC();
        virtual ~RIVLIN_VISCOELASTIC(); 
        virtual int base_read(const STRING&,ASCII_FILE&);

        INTEGRATION_RESULT* integrate( MAT_DATA&, 
                                       const VECTOR&, 
                                       MATRIX*&, int);
};

***/ 
Z_END_NAMESPACE;

#endif
