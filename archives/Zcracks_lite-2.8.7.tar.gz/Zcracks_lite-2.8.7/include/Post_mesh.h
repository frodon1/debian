#ifndef __Post_mesh__
#define __Post_mesh__

#include <Bool.h>

#include <GMesh.h>
#include <Post_data_type.h>
#include <Post_element.h>
#include <Post_node.h>
#include <Post_integ.h>
#include <Ut_info.h>

Z_START_NAMESPACE;

ZCLASS2 POST_MESH : public GMESH  {
    friend class EXTRACTOR;
  protected :
    int node_position_loaded_at;
    int nb_integ_value, nb_contour_mat_ele_value;
    bool nodes_have_been_moved;
    void message(int,...)const;

    virtual GNODE* make_node(int,const VECTOR&);
  public :
    MESH_INFO_READER *mir;

    enum { 
       NONE=1, 
       SKIP_FOR_PARALLEL=4
    };

    POST_MESH(); 
    virtual ~POST_MESH();

    POST_ELEMENT*       get_elem(int i)      { return (POST_ELEMENT*)(GMESH::get_element(i)); }
    const POST_ELEMENT* get_elem(int i)const { return (POST_ELEMENT*)(GMESH::get_element(i)); }
    POST_NODE*          get_node(int i)      { return (POST_NODE*)GMESH::get_node(i); }
    const POST_NODE*    get_node(int i)const { return (POST_NODE*)GMESH::get_node(i); }

    virtual void set_mesh_info(const STRING&);
    virtual void deformed(int);
    virtual void undeformed();
    virtual void set_offsets();

    G_F_SUB_DOMAINS* create_sub_domain(UTILITY_MESH&,const STRING&,
     int,int rcf=1);

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
