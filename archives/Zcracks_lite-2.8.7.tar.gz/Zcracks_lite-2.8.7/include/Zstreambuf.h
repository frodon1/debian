#ifndef __Zstreambuf__ 
#define __Zstreambuf__ 

#include <Zios.h>   
#include <Defines.h>   

Z_START_NAMESPACE;

#ifdef AIX5 
  typedef fpos_t ZSTREAMPOS;
  typedef off_t  ZSTREAMOFF;
  typedef fpos_t ZSTREAMSIZE;
#else
  typedef long long   ZSTREAMPOS;
  typedef long long   ZSTREAMOFF;
  typedef long long   ZSTREAMSIZE;
#endif 

ZCLASS ZSTREAMBUF {
public:
    virtual ~ZSTREAMBUF();

    inline int in_avail() const;
    inline int out_waiting() const;
    int        sgetc();
    int        snextc();
    int        sbumpc();
    void       stossc();

    inline int sputbackc(char);

    inline int sputc(int);
    inline int sputn(const char *,int);
    inline int sgetn(char *,int);

    virtual int sync();

    virtual ZSTREAMBUF* setbuf(char *, int);
    virtual ZSTREAMPOS seekoff(ZSTREAMOFF,ZIOS::SEEK_DIR,int=ZIOS::in|ZIOS::out);
    virtual ZSTREAMPOS seekpos(ZSTREAMPOS, int=ZIOS::in|ZIOS::out);

    virtual int xsputn(const char *,int);
    virtual int xsgetn(char *,int);

    virtual int overflow(int=EOF) = 0; // pure virtual function
    virtual int underflow() = 0;        // pure virtual function

    virtual int pbackfail(int);

    void dbp();

    void lock() { }
    void unlock() { }

protected:
    ZSTREAMBUF();
    ZSTREAMBUF(char *,int);

    inline char * base() const;
    inline char * ebuf() const;
    inline char * pbase() const;
    inline char * pptr() const;
    inline char * epptr() const;
    inline char * eback() const;
    inline char * gptr() const;
    inline char * egptr() const;
    inline int blen() const;
    inline void setp(char *,char *);
    inline void setg(char *,char *,char *);
    inline void pbump(int);
    inline void gbump(int);

    void setb(char *,char *,int =0);
    inline int unbuffered() const;
    inline void unbuffered(int);
    int allocate();
    virtual int doallocate();

private:
    int   _fAlloc;
    int   _fUnbuf;
    int   x_lastc;
    char* _base;
    char* _ebuf;
    char* _pbase;
    char* _pptr;
    char* _epptr;
    char* _eback;
    char* _gptr;
    char* _egptr;
};

inline int   ZSTREAMBUF::in_avail() const { return (gptr()<_egptr) ? (_egptr-gptr()) : 0; }
inline int   ZSTREAMBUF::out_waiting() const { return (_pptr>=_pbase) ? (_pptr-_pbase) : 0; }

inline int   ZSTREAMBUF::sputbackc(char _c){ return (_eback<gptr()) ? *(--_gptr)=_c : pbackfail(_c); }

inline int   ZSTREAMBUF::sputc(int _i){ return (_pptr<_epptr) ? (unsigned char)(*(_pptr++)=(char)_i) : overflow(_i); }

inline int   ZSTREAMBUF::sputn(const char * _str,int _n) { return xsputn(_str, _n); }
inline int   ZSTREAMBUF::sgetn(char * _str,int _n) { return xsgetn(_str, _n); }

inline char* ZSTREAMBUF::base() const { return _base; }
inline char* ZSTREAMBUF::ebuf() const { return _ebuf; }
inline int   ZSTREAMBUF::blen() const  {return ((_ebuf > _base) ? (_ebuf-_base) : 0); }
inline char* ZSTREAMBUF::pbase() const { return _pbase; }
inline char* ZSTREAMBUF::pptr() const { return _pptr; }
inline char* ZSTREAMBUF::epptr() const { return _epptr; }
inline char* ZSTREAMBUF::eback() const { return _eback; }
inline char* ZSTREAMBUF::gptr() const { return _gptr; }
inline char* ZSTREAMBUF::egptr() const { return _egptr; }
inline void  ZSTREAMBUF::gbump(int _n) { if (_egptr) _gptr += _n; }
inline void  ZSTREAMBUF::pbump(int _n) { if (_epptr) _pptr += _n; }
inline void  ZSTREAMBUF::setg(char * _eb, char * _g, char * _eg) {_eback=_eb; _gptr=_g; _egptr=_eg; x_lastc=EOF; }
inline void  ZSTREAMBUF::setp(char * _p, char * _ep) {_pptr=_pbase=_p; _epptr=_ep; }
inline int   ZSTREAMBUF::unbuffered() const { return _fUnbuf; }
inline void  ZSTREAMBUF::unbuffered(int _f) { _fUnbuf = _f; }
Z_END_NAMESPACE;

#endif  
