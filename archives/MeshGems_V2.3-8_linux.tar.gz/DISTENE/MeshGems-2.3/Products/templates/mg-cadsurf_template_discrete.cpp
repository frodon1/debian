/*
 * Integration template into discrete CAD engine.
 * This file describes how to import a tesselation into the 
 * meshgems mesh_t structure. The function generate_mesh defined in 
 * mg-cadsurf_template_common.cpp is then called to build a 
 * surface mesh using MG-CADSurf.
 */

#include <iostream>
#include <list>
#include <vector>
#include <map>
#include <assert.h>

extern "C" {
#include <meshgems/meshgems.h>
} 

status_t generate_mesh(context_t * ctx, cad_t * c, dcad_t * dc,
                         mesh_t * msh);

/**
 * Let's assume that the following structure holds data that
 * represents the input surface tesselation on client side.  It could be a
 * database handle or anything else containing surface mesh data.  We
 * will build the mesh_t object that accesses it.  See the file
 * meshgems/mesh.h for more detailed information.
 */
struct your_mesh_internal_data_t_ {
  /*    _your_mesh_data; */
};

typedef struct your_mesh_internal_data_t_ your_mesh_internal_data_t;

/**
 * Implementation of how the number of vertices in the mesh is obtained.
 * @param[out]	nbvtx	: the number of vertices
 * @param[in]     user_data	: a user pointer.
 * @return error code
 */

status_t mgtm_get_vertex_count(integer * nbvtx, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbvtx = 0;                   /* the number of vertex in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the coordinates of a mesh vertex are obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	xyz	: real[3] array containing the coordinates of the vertex
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_coordinates(integer ivtx, real * xyz,
                                     void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    xyz[j] = 0;                 /* j'th coordinate of the ivtx'th vertex */

  return STATUS_OK;
}

/**
 * Implementation of how the tag of a mesh vertex is obtained.
 * @param[in]	ivtx	: index of the desired vertex coordinates from 1 to nbvtx
 * @param[out]	tag	: integer[1] array containing the tag of the vertex ivtx
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_vertex_tag(integer ivtx, integer * tag, void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *tag = 0;                     /* tag of the vertex ivtx */

  return STATUS_OK;
}

/**
 * Implementation of how the number of edges in the mesh is obtained.
 * @param[out]	nbedg	: the number of edges
 * @param[in]  user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_count(integer * nbedge, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbedge = 0;                  /* the number of edge in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh edge are obtained.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	vedge	: integer[2] array containing the vertices of the edge
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_vertices(integer iedge, integer * vedge,
                                void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 2; j++)
    vedge[j] = 0;               /* j'th vertex index of the iedge'th edge */

  return STATUS_OK;
}

/**
 * Implementation of how the tag of a mesh edge is obtained.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	tag	: integer[1] array containing the tag of the iedge edge
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_edge_tag(integer iedge, integer * tag, void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *tag = 0;                     /* tag of the edge iedge */

  return STATUS_OK;
}

/**
 * Implementation of how to get to required property of a mesh edge.
 * @param[in]	iedge	: index of the desired edge from 1 to nbedge
 * @param[out]	req	: integer[1] array telling whether the edge is required or not
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_required_edge_property(integer iedge, integer * req,
                                         void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *req = 0;                     /* this edge is not required */

  return STATUS_OK;
}

/**
 * Implementation of how the number of triangles in the mesh is obtained.
 * @param[out]	nbtri	: the number of triangles
 * @param     user_data	: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_count(integer * nbtri, void *user_data)
{
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *nbtri = 0;                   /* the number of triangle in your mesh */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh triangle are obtained.
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]	vtri	: integer[3] array containing the vertices of the triangle
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_vertices(integer itri, integer * vtri,
                                    void *user_data)
{
  int j;
  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  for (j = 0; j < 3; j++)
    vtri[j] = 0;                /* j'th vertex index of the itri'th triangle */

  return STATUS_OK;
}

/**
 * Implementation of how the vertices of a mesh triangle are obtained.
 * @param[in]	itri	: index of the desired triangle from 1 to nbtri
 * @param[out]  tag	: integer[1] array containing the tag of the triangle itri
 * @param[in]	user_data: a user pointer.
 * @return error code
 */
status_t mgtm_get_triangle_tag(integer itri, integer * tag,
                               void *user_data)
{

  your_mesh_internal_data_t *mm = (your_mesh_internal_data_t *) user_data;

  *tag = 0;                     /* tag of the triangle itri */

  return STATUS_OK;
}

status_t import_discrete_geometry(your_mesh_internal_data_t * mdata,
                                  context_t * ctx, mesh_t ** pmsh)
{
  status_t ret;
  mesh_t *msh = 0;

  assert(mdata);
  assert(ctx);
  ret = STATUS_OK;


  /*
   * Create the mesh_t structure holding the callbacks giving acces to your mesh data in
   * mdata
   */
  msh = mesh_new(ctx);
  if (!msh)
    return STATUS_NOMEM;

  /*
   * Set the mesh_t callback functions (see meshgems/mesh.h for more details).
   */

  ret = mesh_set_get_vertex_count(msh, mgtm_get_vertex_count, mdata);
  if (ret != STATUS_OK)
    return ret;

  ret =
      mesh_set_get_vertex_coordinates(msh, mgtm_get_vertex_coordinates,
                                      mdata);
  if (ret != STATUS_OK)
    return ret;

  ret = mesh_set_get_vertex_tag(msh, mgtm_get_vertex_tag, mdata);
  if (ret != STATUS_OK)
    return ret;


  ret = mesh_set_get_edge_count(msh, mgtm_get_edge_count, mdata);
  if (ret != STATUS_OK)
    return ret;

  ret = mesh_set_get_edge_vertices(msh, mgtm_get_edge_vertices, mdata);
  if (ret != STATUS_OK)
    return ret;

  ret = mesh_set_get_edge_tag(msh, mgtm_get_edge_tag, mdata);
  if (ret != STATUS_OK)
    return ret;

  ret =
      mesh_set_get_edge_required_property(msh,
                                          mgtm_get_required_edge_property,
                                          mdata);
  if (ret != STATUS_OK)
    return ret;


  ret = mesh_set_get_triangle_count(msh, mgtm_get_triangle_count, mdata);
  if (ret != STATUS_OK)
    return ret;

  ret =
      mesh_set_get_triangle_vertices(msh, mgtm_get_triangle_vertices,
                                     mdata);
  if (ret != STATUS_OK)
    return ret;

  ret = mesh_set_get_triangle_tag(msh, mgtm_get_triangle_tag, mdata);
  if (ret != STATUS_OK)
    return ret;

  *pmsh = msh;

  return ret;
}

status_t generate_mesh_for_discrete_geometry(your_mesh_internal_data_t *
                                             mdata)
{
  status_t ret;
  mesh_t *msh;
  cad_t *c = 0;
  dcad_t *dc = 0;
  context_t *ctx = 0;

  assert(mdata);
  ret = STATUS_OK;

  ctx = context_new();
  if (!ctx)
    return STATUS_NOMEM;

  ret = import_discrete_geometry(mdata, ctx, &msh);
  if (ret != STATUS_OK) {
    context_delete(ctx);
    return ret;
  }

  ret = generate_mesh(ctx, 0, 0, msh);

  mesh_delete(msh);
  context_delete(ctx);

  return ret;
}
