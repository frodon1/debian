#ifndef __Mecha_multi_mat_hetero__
#define __Mecha_multi_mat_hetero__

#include <ZMath.h>
#include <Mecha_multi_mat.h>

Z_START_NAMESPACE;

ZCLASS MECHA_MULTI_MAT_HETERO : public MECHA_MULTI_MAT {
  protected :
     bool ifCc;
     ARRAY<TENSOR4> _Cs,_Csm1,_As,_Bs;
     TENSOR4 Ccm1;
     TENSOR4& Cs()   { return _Cs[iib]; }
     TENSOR4& Csm1() { return _Csm1[iib]; }
     TENSOR4& As()   { return _As[iib]; }
     TENSOR4& Bs()   { return _Bs[iib]; }
     void compute_Cs();
     void compute_from_As();
     void compute_from_Bs();
     virtual void compute_Cc();
  public :
     MECHA_MULTI_MAT_HETERO();
     virtual ~MECHA_MULTI_MAT_HETERO();
     virtual void initialize(ASCII_FILE&, int, LOCAL_INTEGRATION*);
};
Z_END_NAMESPACE;

#endif
