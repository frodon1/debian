#ifndef __ZP_GLOBAL_MATRIX__
#define __ZP_GLOBAL_MATRIX__

#include <Defines.h>
#include <ZP_stack.h>
#include <Global_matrix.h>
#include <ZP_object.h>
#include <ZP_stack.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_GLOBAL_MATRIX : public ZP_OBJECT
{
  protected :
    GLOBAL_MATRIX& get() { return(*((GLOBAL_MATRIX*)contens)); }
    virtual void type_init(char*) { type="GLOBAL_MATRIX"; }

    ZP_FATAL_ERROR* store(ZP_STACK&,int);

  public :
    ZP_GLOBAL_MATRIX() : ZP_OBJECT() { contens=NULL; }

//  virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);

    METHOD_DECLARATION_START
      METHOD("store",store,2)
    METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)

    ZPO_RTTI_INFO(GLOBAL_MATRIX)
};
Z_END_NAMESPACE;

#endif
