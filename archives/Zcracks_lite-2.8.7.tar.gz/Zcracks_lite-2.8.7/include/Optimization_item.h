#ifndef __Optimization_item__
#define __Optimization_item__

#include <Stringpp.h>
#include <Sim_opt_item.h>
#include <Comparison_item.h>
#include <Constraint_item.h>
#include <Sim_opt_utility.h>

Z_START_NAMESPACE;

class OPTIMIZATION_ITEM : public SIM_OPT_ITEM {
  public :
    STRING method;
    PLIST<COMPARISON_ITEM> comparisons;
    PLIST<CONSTRAINT_ITEM> constraints;

    OPTIMIZATION_ITEM();
    OPTIMIZATION_ITEM(const OPTIMIZATION_ITEM&,const STRING& name);
    virtual ~OPTIMIZATION_ITEM();
   
    bool write(Zofstream& out);
    void read(ASCII_FILE&);
    virtual void copy(const STRING& old_name, const STRING& new_name);
    virtual void move(const STRING& old_name, const STRING& new_name);
    virtual void deleted();
};
Z_END_NAMESPACE;

#endif
