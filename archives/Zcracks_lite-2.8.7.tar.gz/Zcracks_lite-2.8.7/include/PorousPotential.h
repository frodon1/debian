#ifndef __PorousPotential__
#define __PorousPotential__

#include <Auto_ptr.h>
#include <Flow.h>
#include <Isotropic.h>
#include <Mechanical_behavior.h>
#include <Porous.h>
#include <PorousCriterion.h>
#include <PorousKinematic.h>
#include <PorousMicrostructure.h>
#include <PorousNucleation.h>
#include <PorousPotentialData.h>
#include <PorousSwell.h>

Z_START_NAMESPACE;

class POROUS_PLASTIC;

class POROUS_POTENTIAL : public MATERIAL_PIECE {
       friend class POROUS_KINEMATIC;
       friend class POROUS_PLASTIC;
       friend class POROUS_CRITERION;
    protected :
       int rank;
       //STRING name;
       POROUS_PLASTIC* pboss;
       AUTO_PTR<POROUS_CRITERION>     criterion;
       AUTO_PTR<FLOW>                 flow;
       AUTO_PTR<ISOTROPIC_HARDENING>  isotropic_hardening;
       bool plasticity;
       bool yield_status;
       double R_at_theta, overstress, distance;

       PLIST<STRAIN_NUCLEATION>  strain_nucleation;
       PLIST<STRAIN_NUCLEATION>  strain_nucleation_cl;
       bool has_nucleation, has_crack_like_nucleation;
       double A_sum, Acl_sum;

       COEFF zi;
       COEFF Ag;

       PLIST<POROUS_KINEMATIC>  kinematic;
       ARRAY<POROUS_POTENTIAL_DATA> pp_data_kin;
       bool has_kinematic;
       POROUS_KINEMATIC& kin(int k) { return *(kinematic[k]); }
       TENSOR2_VAUX X;

       AUTO_PTR<POROUS_SWELL> swell;

       PLIST<POROUS_MICROSTRUCTURE> microstructure;

       double regul;
       void init_regularize() { regul=1.; }
       void regularize() { regul/=10.; }

       TENSOR2 tau_stress_at_theta; // effective stress tensor
       SCALAR_VINT p, fg, fn, fncl;
       SCALAR_VAUX pe, ft, Tau, fv;
       bool use_Tau;
       POROUS_POTENTIAL_DATA pp_data;
       double flow_rate,Fp,Fpe,C00;

       double dp, dfg, dfn, dfncl;

       void check_porosity();
       void check_plastic_strain();
       INTEGRATION_RESULT* set_kinematic();
       void setup(const TENSOR2&,bool if_rk=FALSE);
       bool if_broken();
       bool if_plastic();
       void check_values();
       void set_incr(const VECTOR&);
       void set_deriv(const VECTOR&,double);
       void set_deriv_rk(VECTOR&);
       // much used quantities
       TENSOR2 _dep;     const TENSOR2& dep()     { return _dep; }
       TENSOR2 _dep_ddp; const TENSOR2& dep_ddp() { return _dep_ddp; }
       TENSOR2 _dep_dfv; const TENSOR2& dep_dfv() { return _dep_dfv; }
       TENSOR2 _dep_dft; const TENSOR2& dep_dft() { return _dep_dft; }
       TENSOR4 _dep_dstress; const TENSOR4& dep_dstress() { return _dep_dstress; }
       ARRAY<TENSOR2> dalpha, nal;
       ARRAY<double> D_C;
       ARRAY<TENSOR4> _dep_dalpha; const TENSOR4& dep_dalpha(int k) { return _dep_dalpha[k]; }
       ARRAY<TENSOR4> _dXi_dalpha; const TENSOR4& dXi_dalpha(int k) { return _dXi_dalpha[k]; }
       void keep_seq();

    public :
       POROUS_POTENTIAL();
       virtual ~POROUS_POTENTIAL();
       void initialize(ASCII_FILE& file,POROUS_PLASTIC*, const STRING&,int);
       void set_null_seq() { pp_data.seq=0.; }
       void calc_grad_f(VECTOR&,SMATRIX&, double, double,const TENSOR4&);
       void calc_grad_f_adiabatic(SCALAR_VINT&,SMATRIX&, double, double);
       TENSOR4 compute_EPtangent(const TENSOR4&);

       double get_pe()const { return pe(); }
       const SCALAR_VAUX& triax_macro()const;
       double get_R_at_theta()const { return R_at_theta; }
       POROUS_CRITERION* get_porous_criterion() { return criterion; }
       POROUS_PLASTIC* beboss() { return pboss; }
     RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
