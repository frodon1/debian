#ifndef __EXTRACTOR_MESH__
#define __EXTRACTOR_MESH__

#include <Object_factory.h>
#include <File.h>
#include <Utility_mesh.h>
#include <Mesher_module.h>
#include <Stringpp.h>
#include <Sub_domains.h>

Z_START_NAMESPACE;

// FF, 11.13.2002
//
// A mesher module which constructs the geof file associated to a given
//   domain
// IN  : global_file.geof global_file.cut
// OUT : mesh_of_domain_i.geof
//

class EXTRACTOR_MESH : public MESHER_MODULE
{
  private :
    SUB_DOMAINS *sub;

  public :
    EXTRACTOR_MESH(void) { sub=NULL; };
    EXTRACTOR_MESH(ASCII_FILE&) { sub=NULL; };
   ~EXTRACTOR_MESH(void) { if(sub) delete(sub); };
   
    virtual void initialize(ASCII_FILE&,MESHER*);
    virtual void apply();
};
Z_END_NAMESPACE;

#endif
