#ifndef __ZP_DICHOTOMY__
#define __ZP_DICHOTOMY__

#include <Dichotomy.h>
#include <ZP_stack.h>
#include <ZP_object.h>
#include <Auto_ptr.h>
#include <ZP_basic_type.h>

Z_START_NAMESPACE;

ZCLASS ZP_DICHOTOMY : public ZP_OBJECT , public DICHOTOMY { 
  protected :
    AUTO_PTR< ZP_OBJECT > func_dichotomy;
    AUTO_PTR< ZP_OBJECT > func_deriv;
    ZP_STACK *the_stack;
    double* s0;

    ZP_FATAL_ERROR* find_solution(ZP_STACK&,int);
    ZP_FATAL_ERROR* find_solution_deriv(ZP_STACK&,int);
    ZP_FATAL_ERROR* find_solution_up(ZP_STACK&,int);
    ZP_FATAL_ERROR* find_solution_up_deriv(ZP_STACK&,int);
    ZP_FATAL_ERROR* find_solution_down(ZP_STACK&,int);
    ZP_FATAL_ERROR* find_solution_down_deriv(ZP_STACK&,int);

    virtual void type_init(char*) { type="DICHOTOMY"; }

  public :
    ZP_DICHOTOMY();
    virtual ~ZP_DICHOTOMY() { }

    double f_dichotomy(double v) const;
    double fdot_dichotomy(double v) const;

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);

    METHOD_DECLARATION_START
      METHOD("find_solution",find_solution,4)
      METHOD("find_solution",find_solution_deriv,5)
      METHOD("find_solution_up",find_solution_up,4)
      METHOD("find_solution_up_deriv",find_solution_up_deriv,5)
      METHOD("find_solution_down",find_solution_down,4)
      METHOD("find_solution_down_deriv",find_solution_down_deriv,5)
    METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)
};
Z_END_NAMESPACE;

#endif
