#ifndef __ZP_OBJECT_PROC__
#define __ZP_OBJECT_PROC__

#include <ZP_stack.h>
#include <ZP_status.h>
#include <ZP_object.h>

Z_START_NAMESPACE;

class ZP_PROC;

ZCLASS ZP_OBJECT_PROC : public ZP_OBJECT
{
  protected :
    int dont_delete;

  public :
    ZP_OBJECT_PROC() : ZP_OBJECT() , dont_delete(1) { type="function"; contens=NULL; }
    ZP_OBJECT_PROC(ZP_PROC *zpp) : ZP_OBJECT() , dont_delete(1) { type="function"; contens=zpp; }
    virtual ~ZP_OBJECT_PROC();

    ZP_PROC& get() { return(*((ZP_PROC*)contens)); }

    virtual ZP_FATAL_ERROR*  print(ZP_STACK&);
    virtual ZP_STATUS action(ZP_STACK&);

    virtual void type_init(char*) { }

/*
    METHOD_DECLARATION_START
      METHOD("()",action,0)
    METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)
*/
};

Z_END_NAMESPACE;

#endif
