#ifndef __MESH_COMMAND_WRAPPER__
#define __MESH_COMMAND_WRAPPER__

#include <Stringpp.h>
#include <List.h>

Z_START_NAMESPACE;

class UTILITY_NODE;
class UTILITY_ELEMENT;

class MESH_COMMAND_WRAPPER
{
  public :
    MESH_COMMAND_WRAPPER();
    virtual ~MESH_COMMAND_WRAPPER();

    void set_options(ARRAY<int>&);
    void set_view_options(int);
    void set_nset_options(ARRAY<int>&);
    void set_bset_options(ARRAY<int>&);
    void set_eset_options(ARRAY<int>&);

    void set_view_bset(ARRAY<STRING>&);
    void set_view_eset(ARRAY<STRING>&);
    void set_view_nset(ARRAY<STRING>&);

    void highlight_elem(UTILITY_ELEMENT*, int);
    void highlight_node(UTILITY_NODE*, int);
    void no_highlight_node();

    void apply_options();

    void enable();
    void disable();
};
Z_END_NAMESPACE;

#endif
