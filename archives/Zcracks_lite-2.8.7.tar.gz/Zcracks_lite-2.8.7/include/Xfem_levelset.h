#ifndef __XFEM_LEVELSET__
#define __XFEM_LEVELSET__

#include <Vector.h>
#include <Matrix.h>
#include <Interpolation.h>
#include <Xfem_vector_external_parameter.h>

Z_START_NAMESPACE;

class MESH;
class NODE;
class ELEMENT;

/*
  All these things have been taken from 

  Non-planar 3D crack growth by the extended finite element
  and level sets, parts I and II

  A. Gravouil, N. Moes, T. Belytschko
  Int. Jour. Num. Meth. Engng, 2002
  53 : 2549-2568 
  53 : 2569-2596 
*/

class XFEM_LEVELSET_OPERATOR_AND_SECOND_MEMBER;

ZCLASS2 XFEM_LEVELSET : public XFEM_VECTOR_EXTERNAL_PARAMETER
{
  protected :
    LIST<NODE*> nodes_to_converge_on;
    BUFF_LIST<ELEMENT*> elements_to_converge_on;
    LIST<NODE*> nodes_to_operate_on;
    BUFF_LIST<ELEMENT*> elements_to_operate_on;
    MESH *mesh;

    int max_node();
    int max_elem();

    NODE* node(int);
    ELEMENT* elem(int);

    void compute_gradient(const VECTOR &field, MATRIX &grad);
    void solve_HJ(XFEM_LEVELSET_OPERATOR_AND_SECOND_MEMBER&);

  public :
    XFEM_LEVELSET();
    virtual ~XFEM_LEVELSET();

    void write();

    void normalize();
    void orthogonalize(XFEM_LEVELSET&);

    bool is_orthogonal(XFEM_LEVELSET&,double *max_scal=NULL);
    bool is_normalized(double *max_scal=NULL, double *min_scal=NULL);

    void set_mesh(MESH*);
    const MESH& get_mesh() { return(*mesh); }

    void restrict_convergence(BUFF_LIST<NODE*>&);
    void restrict_operation(BUFF_LIST<NODE*>&);
    void unrestricted_operation() { nodes_to_operate_on.resize(0); elements_to_operate_on.resize(0); }

    RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
