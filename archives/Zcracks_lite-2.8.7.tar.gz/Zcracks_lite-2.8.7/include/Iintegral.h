#ifndef __Jintegral__ 
#define __Jintegral__ 

#include <Vector.h> 

Z_START_NAMESPACE;

struct I_MAIL {
   double ener;
   VECTOR da, dUtip;
   VECTOR center;
   VECTOR qnode;
   double young, poisson;
};    
Z_END_NAMESPACE;

#endif
