#ifndef __Geometry_extras__ 
#define __Geometry_extras__ 

// ============================================================================
//  Extra stuff for iges translation, etc 
// ============================================================================

#include <Geometry_parts.h> 

Z_START_NAMESPACE;


ZCLASS2 IGES_SUBFIGURE : public DAO_EDGE {
   public :
     LIST<DAO_EDGE*> edges; 

     IGES_SUBFIGURE(DAO_GEOMETRY* bin);

     virtual void read_iges(ASCII_FILE& file);

     RTTI_INFO; 
};

ZCLASS2 IGES_SUBFIGURE_INSTANCE : public DAO_EDGE {
   public :
     IGES_SUBFIGURE_INSTANCE(DAO_GEOMETRY* bin);
     virtual void read_iges(ASCII_FILE& file);

     RTTI_INFO; 
};

Z_END_NAMESPACE;

#endif
