#ifndef __Math_inline__
#define __Math_inline__
 
#include <math.h> 
#include <Math_function.h> 

Z_START_NAMESPACE;
Z_END_NAMESPACE;

#endif
