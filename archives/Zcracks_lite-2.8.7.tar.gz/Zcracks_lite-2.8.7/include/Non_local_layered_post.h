#ifndef __NON_LOCAL_LAYERED_POST__
#define __NON_LOCAL_LAYERED_POST__

#include <Post_computation.h>
#include <Post_processor.h>
#include <Global_post_computation.h>

Z_START_NAMESPACE;

//
// 2006-03-23 carrere: computes ply-wise averages
//

class NON_LOCAL_LAYERED_POST : public GLOBAL_POST_COMPUTATION {
	protected :
		int nb_var_nl;
		int nb_layer;
		LIST<STRING> vars;
	public : 
		NON_LOCAL_LAYERED_POST(){};
		~NON_LOCAL_LAYERED_POST(){};

		virtual void compute(ARRAY<POST_ELEMENT*>&,ARRAY<POST_NODE*>&,const ARRAY<int>&);
		virtual MODIFY_INFO_RECORD* get_modify_info_record();
		virtual bool verify_info();

		virtual void input_i_need(int,ARRAY<STRING>&);
	        virtual void output_i_give(bool&,ARRAY<STRING>&);
		virtual bool compute_on_ipsets()const { return TRUE; }	
		POST_DEFAULT_COMPUTE_INTEG(GLOBAL_POST_COMPUTATION);
		virtual void specify_IO(PDT_GROUP, POST_DATA_TYPE&, bool&)const;
};
Z_END_NAMESPACE;

#endif
