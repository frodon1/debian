#ifndef __FLUID_ELEMENT__
#define __FLUID_ELEMENT__

// ===================================================================== 
//  EMSE - March 2011
//  FLUID_ELEMENT  
//
//  A very simple class, just to be able to use RTTI infos : 
//  all fluid elements should derived from this class
// ===================================================================== 

#include <Array.h>
#include <Matrix.h>
#include <Stringpp.h>
#include <Bool.h>
#include <Error_messager.h>
#include <ZMath.h>
#include <Marray.h>
#include <Rotation.h>
#include <Utility.h>
#include <Clock.h>
#include <Global_matrix.h>
#include <GMesh.h>
#include <Integration_result.h>
#include <Behavior.h>
#include <Coefficient.h>
#include <Node.h>
#include <Space.h>

#include <P_element.h>

Z_START_NAMESPACE;

ZCLASS2 FLUID_ELEMENT : public P_ELEMENT {
 protected :
  int ele_flags;
  int m_grad_size;
  void make_b_mat (const MATRIX&,MATRIX&) const;

  enum { NONE=0,
         USE_CONV_TERMS=1,
         REDUCE_ORDER_OF_P=2
  };

 public :
  FLUID_ELEMENT(); 
  virtual ~FLUID_ELEMENT();

  virtual int grad_size()const { return m_grad_size; }

  RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
