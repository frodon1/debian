#ifndef __UTLITY_REL_FACE__
#define __UTLITY_REL_FACE__

#include <Utility_relations.h>

Z_START_NAMESPACE;

ZCLASS T3_UTILITY_REL_FACE : public UTILITY_REL_FACE {
  public :
    T3_UTILITY_REL_FACE() : UTILITY_REL_FACE() { nodes.resize(3); type="T3"; }
    virtual ~T3_UTILITY_REL_FACE() { }

    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE*>&);
    virtual void to_quadratic();
    RTTI_INFO;
};

ZCLASS T6_UTILITY_REL_FACE : public UTILITY_REL_FACE {
  public :
    T6_UTILITY_REL_FACE() : UTILITY_REL_FACE() { nodes.resize(6); type="T6"; }
    virtual ~T6_UTILITY_REL_FACE() { }

    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE*>&);
    virtual void to_quadratic() { ERROR("cannot change to quadratic: already quadratic"); }
    RTTI_INFO;
};

ZCLASS T10_UTILITY_REL_FACE : public UTILITY_REL_FACE {
  public :
    T10_UTILITY_REL_FACE() : UTILITY_REL_FACE() { nodes.resize(10); type="T10"; }
    virtual ~T10_UTILITY_REL_FACE() { }

    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE*>&);
    virtual void to_quadratic() { ERROR("cannot change to quadratic: already quadratic"); }
    RTTI_INFO;
};


ZCLASS Q4_UTILITY_REL_FACE : public UTILITY_REL_FACE {
  public :
    Q4_UTILITY_REL_FACE() : UTILITY_REL_FACE() { nodes.resize(4); type="Q4"; }
    virtual ~Q4_UTILITY_REL_FACE() { }

    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE*>&);
    virtual void to_quadratic();
    RTTI_INFO;
};

ZCLASS Q8_UTILITY_REL_FACE : public UTILITY_REL_FACE {
  public :
    Q8_UTILITY_REL_FACE() : UTILITY_REL_FACE() { nodes.resize(8); type="Q8"; }
    virtual ~Q8_UTILITY_REL_FACE() { }

    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE*>&);
    virtual void to_quadratic() { ERROR("cannot change to quadratic: already quadratic"); }
    RTTI_INFO;
};

ZCLASS Q6LQ_UTILITY_REL_FACE : public UTILITY_REL_FACE
{
  public :
    Q6LQ_UTILITY_REL_FACE() : UTILITY_REL_FACE() { nodes.resize(6); type="Q6LQ"; }
    virtual ~Q6LQ_UTILITY_REL_FACE() { }

    virtual void build_edges(BUFF_LIST<UTILITY_REL_EDGE*>&);
    virtual void to_quadratic() { ERROR("NOT IMPLEMENTED ERROR"); }
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
