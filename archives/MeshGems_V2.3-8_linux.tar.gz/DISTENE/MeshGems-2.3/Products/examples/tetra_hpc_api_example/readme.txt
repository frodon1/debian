This document gives some hints on how you can compile the mg-tetra_hpc_example.c

First, copy the corresponding dynamic libraries and the meshgems include directory in this directory.

Then, run 

      * ./compile.sh on a Linux platform
or 
      * compile.bat on a Windows platform

A mg-tetra_hpc_example.exe executable will be created in this directory.

