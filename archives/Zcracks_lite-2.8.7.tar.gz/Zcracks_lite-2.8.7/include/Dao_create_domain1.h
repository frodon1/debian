#ifndef __DOMAIN1_CREATE_COMMAND__
#define __DOMAIN1_CREATE_COMMAND__

#include <Std_cc_stream.h>
#include <Out_message.h>

#include <Error_messager.h>
#include <Graphics_area.h>
#include <Graphics_command.h>
#include <Graphics_data_dialog.h>
#include <Dao_geom.h>

#include <Print.h>

Z_START_NAMESPACE;

class CREATE_DOMAIN1_WRAPPER;

class DOMAIN1_CREATE_COMMAND : public GRAPHICS_COMMAND 
{
  protected :
    int       current_index; 
    LIST<int> boundary_index; 
    DAO_GEOMETRY*         its_dao; 
    GRAPHICS_DATA_DIALOG* its_dialog;
    LIST<DAO_EDGE*> active_edges;
    CREATE_DOMAIN1_WRAPPER *wrapper;
    int nbd;

  public :
    enum KINEMATIC_ORDER { LINEAR=0 , QUADRATIC=1 };
    enum INTEGRATION_MODE { NORMAL=0 , REDUCED=1 };
    enum METHOD { AVERAGING=0 , SIDE_2_4_LINEAR=1 , LINE_ELEMENT=2 };
    enum TYPE { S3D_3D_LINES=0 , C2D=1 , CAX=2 , L2D=3 , L3D=4 };

    DOMAIN1_CREATE_COMMAND();
    virtual void initialize(GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app); 

    virtual ~DOMAIN1_CREATE_COMMAND();
    virtual bool do_command(STRING cmd);
    virtual bool do_click(int track, GRAPHICS_POINT& click, GRAPHICS_OBJECT* target);
};
Z_END_NAMESPACE;

#endif
