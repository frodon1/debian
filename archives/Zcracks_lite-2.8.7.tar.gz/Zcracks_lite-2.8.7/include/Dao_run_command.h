#ifndef __Dao_run_command__ 
#define __Dao_run_command__ 

#include <Std_cc_stream.h>

#include <Out_message.h> 

/*
#ifdef _WIN32
#include <Stdafx.h> 
#include <NT_globals.h> 
#include <NT_run_information.h> 
#define _WIN32XXX
#endif
*/


#include <Error_messager.h> 
#include <Dao_geom.h> 
#include <Graphics_command.h> 
#include <Graphics_area.h> 
#include <Graphics_application.h> 
#include <Utility_mesh.h> 
#include <NT_tools.h> 

Z_START_NAMESPACE;

extern WIN_THINGIE int run_sub_problem(int argc, char* argv[]); 

ZCLASS2 CALCUL_COMMAND : public ZMASTER_EXTENSION 
{
  public :
    LIST<STRING> tokens; 
    DAO_GEOMETRY*         its_dao;
    GRAPHICS_DATA_DIALOG* its_dialog;
    STRING  cmd_lin; 

    STRING keep_inp_name; 
    int def_cmd; 
    LIST<STRING> modes; 
    void setup_modes(); 
    STRING fname; 
    STRING set_command();

#ifdef _WIN32XXX
      HANDLE th;
#endif
  public :
    CALCUL_COMMAND(); 
    virtual void initialize(GRAPHICS_COMMAND* boss, GRAPHICS_APPLICATION* app); 
    bool do_command(STRING); 
};
Z_END_NAMESPACE;

#endif
