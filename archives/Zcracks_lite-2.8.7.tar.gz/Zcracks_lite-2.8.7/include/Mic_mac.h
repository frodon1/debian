#ifndef __MIC_MAC__
#define __MIC_MAC__

#include <Std_cc_stream.h>

#include <Base_problem.h>
#include <Darray.h>

Z_START_NAMESPACE;

class PERIODIC_PROBLEM;

class MIC_MAC : public BASE_PROBLEM {
  public :
    LIST<MATRIX*> A_list;
    DARRAY< SMATRIX* > D;
    LIST< SMATRIX*> L_s;
    LIST< double* > frac_s;
    int tot_gp;
     
  private :
    LIST<MATRIX*> B_list;
    LIST<VECTOR> fluxs;
    STRING local_problem;
    VECTOR grad;
    MATRIX ele_by_elset;
    PERIODIC_PROBLEM *pp;
    int has_A,has_D,consistency,comp_D,comp_A,sq2,comp_B,irun,has_to_write_K;

    int by_elset,save3d;
    LIST<STRING> elset_name;
    MATRIX ele_elset_corres;
    double write_K_factor;
    double S;
    int has_to_eliminate;
    LIST<COEFFICIENT*> coefficient_list;

    void compute();
    void compute_B(PERIODIC_PROBLEM*);
    void compute_A(PERIODIC_PROBLEM*);
    void compute_D();
    void check_consistency();
    void write_K();
    void eliminate(MATRIX&,MATRIX&);
    void find_B(MATRIX&,MATRIX&,MATRIX&);

  public :
    MIC_MAC(void);
    virtual  ~MIC_MAC(void);

    virtual bool Execute(void);
    virtual void load(const STRING&,const STRING&);
    virtual int parallelized(void) { return(1); }
};
Z_END_NAMESPACE;

#endif
