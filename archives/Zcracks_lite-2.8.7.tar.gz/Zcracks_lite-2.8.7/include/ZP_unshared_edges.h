#ifndef __ZP_MESHER_UNSHARED_EDGES__
#define __ZP_MESHER_UNSHARED_EDGES__

/*

#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>
#include <Unshared_edges.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_MESHER_UNSHARED_EDGES : public ZP_BASIC_TYPE< UNSHARED_EDGES_TRANSFORM >
{
  protected :
    int apply(ZP_STACK&);
    int add(ZP_STACK&);
    int reset(ZP_STACK&);
    virtual void type_init(char*) { type="MESHER_UNSHARED_EDGES"; }

  public :
    BASIC_CONSTRUCTORS(ZP_MESHER_UNSHARED_EDGES,UNSHARED_EDGES_TRANSFORM);

    METHOD_DECLARATION_START
      METHOD("apply",apply,1)
      METHOD("add",add,1)
      METHOD("reset",reset,0)
    METHOD_DECLARATION_ANCESTOR(ZP_BASIC_TYPE<UNSHARED_EDGES_TRANSFORM>)

    virtual int acess(STRING&,ZP_STACK&,bool resolv=FALSE);
};
Z_END_NAMESPACE;
*/

#endif
