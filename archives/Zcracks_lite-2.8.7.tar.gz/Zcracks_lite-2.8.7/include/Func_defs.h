#ifndef SKIP_STD_FUNCTION

#ifndef __Func_defs__
#define __Func_defs__

#include <Defines.h>

Z_START_NAMESPACE;

//
// compute error codes follow. BD_XXXX stands for BadDomain_XXX
//
enum CALCUL_RESULT { 
	N_PARS=-1,
		OK=1,
		FNO_DATA=2,
		N_U_RES=3,
		BD_TAN=4,
                     BD_DIV=5,
					 BD_ACOSH=6,
					 BD_ASINH=7,
					 BD_ATANH=8,
                     BD_ASIN=9,
					 BD_ACOS=10,
					 BD_LN=11,
					 BD_SQRT=12,
					 BD_POW=13 
};

typedef int (*f_numeric)(int&,double*);

Z_END_NAMESPACE;
#endif
#endif
