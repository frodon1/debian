#ifndef _Rivlin_
#define _Rivlin_

// ============================================================================  
//  RIVLIN hyperelasticity.  
//
//  ** RF 01/22/2001 I re-wrote this using a material piece for the 
//     hyperelastic law in order to get a cleaner implementation of the 
//     nonlinear viscoelastic case. 
//
//  ** Mixed form only now? 
//  
// ============================================================================  
#include <Behavior.h>
#include <Integration_result.h>
#include <Mechanical_behavior.h>
#include <Hyperelastic_law.h>
#include <Swap.h>

Z_START_NAMESPACE;

ZCLASS RIVLIN_HYPER_LAW : public HYPERELASTIC_LAW {
  public :
      void neg_energy_error(double W, double i1, double i2, double i3 );

      SCALAR_GRAD  p;
      SCALAR_FLUX  dv;

      TENSOR2_VINT eel;
      SCALAR_VINT  welas;

      TENSOR2_VAUX  pk2_0, E;
      AUTO_PTR<SCALAR_VAUX> e1, e2, e3;
      AUTO_PTR<SCALAR_VAUX> dmg, d_disc;
      bool damageable, save_princ_strain;

      COEFF c10, c01, c20, c11;
      COEFF c02, c30, c21, c12;
      COEFF c03;
      COEFF d_inf, eta;
      COEFF Kv;

      virtual void verify_read();
      virtual void setup(int& flux_pos, int& grad_pos, int& vi_pos, int& va_pos); 

      RIVLIN_HYPER_LAW();
      virtual ~RIVLIN_HYPER_LAW();
      virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
      virtual int base_read(const STRING&,ASCII_FILE&);

      virtual INTEGRATION_RESULT* integrate(const  VECTOR& delta_grad, int flags);
      virtual BEHAVIOR::STRESS_MEASURE get_stress_measure() const;


     
      TENSOR2& give_pk2_0() { return pk2_0; } 
      TENSOR2& give_E()     { return E; } 

};
Z_END_NAMESPACE;

#endif
