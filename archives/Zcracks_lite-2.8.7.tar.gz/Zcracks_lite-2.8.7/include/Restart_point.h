#ifndef __RESTART_POINT__
#define __RESTART_POINT__

//
// FF, June 17th, 2005 : a class to create a memory restart point
//

#include <Memory_buffer.h>
#include <Zstream.h>
#include <Problem.h>

Z_START_NAMESPACE;

class RESTART_POINT
{
  protected :
    MEMORY_BUFFER *buffer;

  public :
    RESTART_POINT() { buffer=NULL; } 
    ~RESTART_POINT() { if(buffer) delete(buffer); }

    void create(PROBLEM&);
    void restart(PROBLEM&, bool reset_clock=TRUE);
};

/*
  Use : 

  RESTART_POINT rst;

  rst.create(a_problem); // save the current problem state in memory
  ......
  .....
  .....
  rst.restart(a_problem); // reinitialise the current problem at its previous state
*/
Z_END_NAMESPACE;

#endif
