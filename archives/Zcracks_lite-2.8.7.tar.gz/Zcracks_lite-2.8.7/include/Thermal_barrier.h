#ifndef _Thermal_barrier_
#define _Thermal_barrier_

#include <Local_post_computation.h>
#include <Newton_raphson.h>
#include <P_lexer.h>
#include <Post_simple.h>
#include <Simulator.h>
#include <Simulator_model.h>
#include <Simul_load.h>
#include <Utility_connections.h>
#include <Utility_mesh.h>

Z_START_NAMESPACE;

//
// 2008-11-28 squilici: base class for Thermal Barrier Coatings damage criterions
//

// Note : only for 3D problems

// **process thermal_barrier
//   *var sig  % necessary to sort out the normal in case of corner nodes
//   *eto eto
// [ *integration ... ]
//   *layer lname1 fname1 [ sec1 ]
//   *layer lname2 fname2 [ sec2 ]
//   ...
// [ *output lname:cname [invariants] ]
// [ *damage type ]

class POST_THERMAL_BARRIER;

// Base class for implementation of particular TB_DAMAGE_MODELs
ZCLASS2 TB_DAMAGE_MODEL : public Z_OBJECT 
{
  protected :
   POST_THERMAL_BARRIER* its_boss;

  public :
   double infinity;

   ARRAY<STRING>           layer_names;
   ARRAY< ARRAY<STRING> >  layer_components;
   ARRAY<STRING>           invariants;
   ARRAY<STRING>           outputs;

   ARRAY<STRING> coef_names;

   TB_DAMAGE_MODEL();
   virtual ~TB_DAMAGE_MODEL();

   virtual void initialize(POST_THERMAL_BARRIER*, ASCII_FILE&)=0;
   virtual void compute_invariants(VECTOR&)=0;
   virtual void compute_damage(const ARRAY<VECTOR>& in, const VECTOR& invariants, 
     const VECTOR& /* coefs */, VECTOR& out)=0;
   virtual bool check_coefs(const VECTOR& /* coefs */) { return(TRUE); }
   const ARRAY<VECTOR>& get_results(const STRING& layer);
};

class Z7P_TB_DAMAGE : public TB_DAMAGE_MODEL
{
  private :
   STRING   prog_name;
   P_LEXER  program;
   ZP_ENV   zp_env;

   ZP_TYPENAME *ty_vector;
   ZP_NAME *zpn_v;

  public :
   Z7P_TB_DAMAGE();
   ~Z7P_TB_DAMAGE() {}
 
   void initialize(POST_THERMAL_BARRIER*, ASCII_FILE&);
   void compute_invariants(VECTOR&);
   void compute_damage(const ARRAY<VECTOR>& in, const VECTOR& invariants, 
     const VECTOR& coefs, VECTOR& out);
};

class Z7P_TB_GET_RESULT : public ZP_OBJECT
{
  protected :
    ZP_TYPENAME *ty_vector;
    ZP_NAME *zpn_v;

    TB_DAMAGE_MODEL* tb_post;
    virtual void type_init(char*) { }

    ZP_FATAL_ERROR* par(ZP_STACK& stack,int);

  public :
    Z7P_TB_GET_RESULT(TB_DAMAGE_MODEL* post);
    virtual ~Z7P_TB_GET_RESULT() { }

   METHOD_DECLARATION_START
     METHOD("()",par,1)
   METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)
};

class TB_LAYER 
{ 
  public :
   POST_THERMAL_BARRIER* its_boss;
   LOCAL_INTEGRATION*    integ;

   STRING name;

   AUTO_PTR<SIMUL_MODEL> model;
   LIST<STRING> vars; // all model variables
   VECTOR results;    // model variables values at the current increment

   BUFF_LIST<STRING> outputs;
   BUFF_LIST<int>    output_ranks;
   BUFF_LIST<bool>   is_user_output;
   ARRAY<VECTOR>     output_vals;

   // in: name expected by the damage model, out: real mat var name
   BUFF_LIST<STRING> alias_in, alias_out;

   TB_LAYER() {}
   ~TB_LAYER() {}

   void initialize(ASCII_FILE& file, LOCAL_INTEGRATION*, POST_THERMAL_BARRIER*);
   void create_model();
   void integrate();
   void fill_output(int& pos, ARRAY<VECTOR>& out);
    
};

class POST_THERMAL_BARRIER : public POST_SIMPLE {
  protected :
   bool   output_invariants, output_eto, output_normal, skip_damage;
   bool   got_temperature, do_cooling;
   int    tsz, inc_cool;
   STRING eto_name;
   double infinity, Tref_cool, time_cool;

   ARRAY<bool>  nodes_on_skin;
   UTILITY_MESH* zmesh;
   UTILITY_CONNECTION connec;

   // following 2 may be used to re-calculate eto from sig
   AUTO_PTR<SIMUL_MODEL>     elasticity;
   AUTO_PTR<ROTATION>        rotation;

   PLIST<TB_LAYER>           layers;
   AUTO_PTR<TB_DAMAGE_MODEL> damage_model;
   BUFF_LIST<STRING>         user_outputs;

   ARRAY<int> parameter_ranks;

   PLIST<POST_COEFF> coefs;
   VECTOR            coef_values;

   void get_nodes_on_skin();
   VECTOR find_normal(UTILITY_ELEMENT*, const UTILITY_NODE*, const TENSOR2&);
   TENSOR2 compute_rot_tensor(const VECTOR& norm);
   void setup_simul_load(int ncard);
   void read_elasticity(ASCII_FILE& file, LOCAL_INTEGRATION* integ);
   void integrate_elasticity(const ARRAY<VECTOR>& in, ARRAY<VECTOR>& eel);

  public :
   AUTO_PTR<SIMULATOR_TEST> simul_test, simul_test_3d;
   TABULAR_SIMUL_LOAD       *simul_load, *simul_load_3d;

   POST_THERMAL_BARRIER();
   virtual ~POST_THERMAL_BARRIER();

   TB_LAYER* get_layer(const STRING& name);

   virtual void read_process(ASCII_FILE&, ASCII_FILE&, MODIFY_INFO_RECORD* m=NULL);
   virtual MODIFY_INFO_RECORD* get_modify_info_record();
   virtual bool verify_info();
   virtual void input_i_need(int,ARRAY<STRING>&);
   virtual void output_i_give(bool&,ARRAY<STRING>&);
   virtual void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
   virtual bool need_material_file()const { return TRUE; }
};
Z_END_NAMESPACE;

#endif
