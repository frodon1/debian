#ifndef __Imatrix__
#define __Imatrix__

// ============================================================================ 
//   IMATRIX - Class which acts as a MATRIX but is sufficiantly different to
//   warrent it's own class.. ie differant storage invalidating (,) operator.
//   he includes coefficients, and is smart about the multiplications it makes
//   with math entities.
//      * the enum is used to control 
//        loading in by different hardenings
// ============================================================================ 

#include <Bool.h>
#include <Defines.h>
#include <Hierarchy.h>
#include <List.h>
#include <ZMath.h>
#include <Matrix.h>

#include <Material_piece.h>
#include <Coefficient.h>

Z_START_NAMESPACE;

class STRING;

ZCLASS IMATRIX : public MATERIAL_PIECE {
protected :
   int            its_type;
 
public :
   MATRIX         _mat;
   enum INTER_MAT_TYPE { NONE=0, SCALAR=2, VEC=4, MAT=8, GEN_MATRIX=16,
                         B_INTER=32, F_INTER=64 };
                  IMATRIX(MATERIAL_PIECE* mp);
   int            type()const { return its_type; }
   void           resize(int n, int m) { _mat.resize(n,m); }
   int            operator!() const { return( _mat.size() ); } // depreciated
   int            size()const       { return( _mat.size() ); }

         double&  operator()(int i, int j)       { return _mat(i,j); }
   const double&  operator()(int i, int j) const { return _mat.operator()(i,j); }
  
   virtual bool verificaion() { return(TRUE); }

   MATRIX mulin(const MATRIX &p) const { MATRIX ret; mulin(ret,p); ret.set_temporary(); return(ret); }   
   MATRIX mul(const MATRIX &p) const { MATRIX ret; mul(ret,p); ret.set_temporary(); return(ret); }

   VECTOR mulin(const VECTOR &p) const { VECTOR ret; mulin(ret,p); ret.set_temporary(); return(ret); }
   VECTOR mul(const VECTOR &p) const { VECTOR ret; mul(ret,p); ret.set_temporary(); return(ret); }

   virtual void mulin(MATRIX&, const MATRIX&)const=0;
   virtual void mul(MATRIX&, const MATRIX&)const=0;

   virtual void mulin(VECTOR&, const VECTOR&)const=0;
   virtual void mul(VECTOR&, const VECTOR&)const=0;

   friend  WIN_THINGIE MATRIX   operator*(const IMATRIX& i, const MATRIX& m);
   friend  WIN_THINGIE MATRIX   operator*(const MATRIX& m, const IMATRIX& i);
   friend  WIN_THINGIE VECTOR   operator*(const IMATRIX& i, const VECTOR& v);
   friend  WIN_THINGIE VECTOR   operator*(const VECTOR& v, const IMATRIX& i);

   virtual MATRIX   d_param(const STRING& param); 
   RTTI_INFO;
};


// **********************************************************************
//   INTERACTION classes
//
//                *   BASic_INTERACTION class.  this is an array of
//                    multipliers (coefficients) which are stored as
//                    a DMATRIX for conveniance (now).  other opimizations
//                    are possible.
//                *   FULLly_filled_INTERACTION is a way to provide full
//                    matrix behavior in the same framework
// **********************************************************************

ZCLASS BAS_IMATRIX : public IMATRIX  {
protected:
public:
             BAS_IMATRIX(MATERIAL_PIECE* mp);
             BAS_IMATRIX(MATERIAL_PIECE* mp, int m);
 
   void  mulin(MATRIX&, const MATRIX&)const;
   void  mul(MATRIX&, const MATRIX&)const;
   void  mulin(VECTOR&, const VECTOR&)const;
   void  mul(VECTOR&, const VECTOR&)const;
   RTTI_INFO;
};

ZCLASS FULL_IMATRIX : public IMATRIX  {
protected:
public:
             FULL_IMATRIX(MATERIAL_PIECE* mp);
             FULL_IMATRIX(MATERIAL_PIECE* mp, int n, int m);
 
   void  mulin(MATRIX&, const MATRIX&)const;
   void  mul(MATRIX&, const MATRIX&)const;
   void  mulin(VECTOR&, const VECTOR&)const;
   void  mul(VECTOR&, const VECTOR&)const;

   MATRIX&   give_matrix() { return _mat; }
   RTTI_INFO;
};

// **************************************** 
//  this starts the custom interactions input by the user..
//  there may be derived interactions from this one for the off
//  diagonal elements. the special deal is that elements
//  can be set in a variety of ways.. 
// **************************************** 

ZCLASS STD_IMATRIX : public BAS_IMATRIX  {
protected:
    LIST<COEFF*>       coeff;
    LIST<int>          starts;
    LIST<int>          len;
public:  
    STD_IMATRIX(MATERIAL_PIECE* mp, int int_var_sz);
    virtual void load_coef(int st, int len, COEFF& coin); 
    virtual bool calc_coef(); 

    virtual MATRIX   d_param(const STRING& param); 
   RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
