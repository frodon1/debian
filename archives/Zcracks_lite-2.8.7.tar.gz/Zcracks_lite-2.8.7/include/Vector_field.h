#ifndef __VECTOR_FIELD__
#define __VECTOR_FIELD__

#include <Mesh.h>
#include <Zstream.h>

Z_START_NAMESPACE;

// JDG 2006/07/07 : a replacement for FE_FIELDs, 
//   The idea is to have a purely algebraic object to handle a vector field on a geometrical manyfold
//   It is used to store data (dofs, reactions, integrated values) at nodes and/or gauss points, 
//   The class provides :
//      - simple arithmetics (sum, product by a scalar), max, etc...
//      - transfer btw nodes / gp 
//      - transfer btw (non-necessarily) conforming meshes (cf VC's MORTAR_FIELD) 
//      - i/o (used for code-coupling, so should remain general : write to file or memory adress -> mpi, mpcci) 
//   The following classes will use this object : 
//      - BC_IMPOSE_NODAL_DOF_FROM_(FIELD/FILE/MPCCI/TRANSFER/FUNCTION) 
//      - DATA_TRANSFER (say some of them)  
//  There is (currently) no boolean to specify a reaction (or not a reaction), so data_names must be U1 for displacements, RU1 for reactions (bug: how is dof R1 handled ?) 

// FIXMEs : check which functions should be virtual or not / public or protected

class VECTOR_FIELD {
// private: 
//   VECTOR_FIELD& operator=(const VECTOR_FIELD&); // forbids unintentional copy ... DATA_TRANSFER::describe() en a  malheureusement besoin ... 
//   VECTOR_FIELD(const VECTOR_FIELD&);            // forbids unintentional copy ... use copy() below instead

public:
  enum LOCATION {UNKNOWN, NODAL, INTEG, ELEM};
protected: 
  MESH* mesh;
  STRING set_name;           // name of an elset/nset, depending on the usage (I recommend building both in the .geof file)
  LIST<STRING>  data_names;  // name of dofs, or dofs reaction, or anything else (e.g. U1, RU1, TP, RTP etc..) 
  ARRAY<VECTOR> stored_data; // the actual values
  LOCATION location;         // where the stored_data are known. 

  // the next two functions are protected, because there's an extract() function below... 
  void extract_nodal();      // re-reads the values and fills stored_data (at nodes) 
  void extract_integ();      // ...                                       (at Gauss points). 
  void extract_elem();       // ...                                       (one single value per boundary element). 
  
public: 
  VECTOR_FIELD(): mesh(NULL), location(UNKNOWN) { }
  virtual ~VECTOR_FIELD() { }

  // copy operators: 2007/03/01 I reluctantly make them available (they cost a lot, if used too often) 
  VECTOR_FIELD& operator=(const VECTOR_FIELD&);
  VECTOR_FIELD(const VECTOR_FIELD&);

  VECTOR_FIELD& copy (const VECTOR_FIELD&); // copy operator ... I'm not calling it "operator=" because each call is expensive, and should be deliberate

  void initialize(MESH*, const STRING& /*set*/, const LIST<STRING>&/*names*/, LOCATION);
  void initialize(MESH*, const STRING& /*set*/, const STRING&/*single name*/, LOCATION);
  void initialize(const VECTOR_FIELD&);

  const VECTOR& get_nodal_value(int idx) const; // if data is stored at gps, the function does the conversion
  const VECTOR& get_integ_value(int idx) const;
  const VECTOR& get_elem_value(int idx) const;


  VECTOR get_nodal_value() const; // creates a single VECTOR containing all datas (stored by : data1@node1, ... data1@nodeN, data2@node1, etc...) 
  VECTOR serialize() const; // creates a single VECTOR containing all datas (stored by : data1@node1, ... data1@nodeN, data2@node1, etc...) , resp. for elem data.

  void set_nodal_value(int idx, const VECTOR& data);
  void set_integ_value(int idx, const VECTOR& data);
  void set_elem_value(int idx, const VECTOR& data);

  // get/set with no translation on the-fly ; assumes that developper did it beforehand
  void set_hard_value(int idx, const VECTOR& data) { stored_data[idx] = data; }
  const VECTOR& get_hard_value(int idx) const { return stored_data[idx] ; }

  void set_nodal_value(const VECTOR& data); // sets all data from a single vector
  void set_integ_value(const VECTOR& data);
  void set_elem_value(const VECTOR& data);

  void set_nodal_value(double);        // sets all indexes to the same value
  void set_integ_value(double);
  void set_elem_value(double);
  //  void set_hard_value(double);

  // transfer to new meshes, or between nodes<->integ  ... add a flag 'method = mortar/interp' ??
  VECTOR_FIELD& transfer (const MESH& new_mesh); // NOT IMPLEMENTED YET
  VECTOR_FIELD& transfer (LOCATION);             // NOT IMPLEMENTED YET

  // I/O:
  //      file format : U1(node1), ... U1(nodeN), U2(node1), ... U2(nodeN), etc... 
  void extract();          // refills 'stored_data' with fresh data from the mesh ... could be called update ? should i make it protected, and call it in ::write ?
  void read (Zifstream&, bool binary=true);  // add an option binary/text, another float/double (if binary), another nodal/integ ?
  void write(Zofstream&, bool binary=true);  


  // arithmetics: 
  VECTOR_FIELD operator* (double) const ;
  VECTOR_FIELD operator+ (const VECTOR_FIELD&) const ;
  VECTOR_FIELD operator- (const VECTOR_FIELD&) const ;

  VECTOR_FIELD& operator+= (const VECTOR_FIELD&);
  VECTOR_FIELD& operator+= (double);
  VECTOR_FIELD& operator-= (const VECTOR_FIELD&);
  VECTOR_FIELD& operator*= (double);
  VECTOR_FIELD& operator/= (double);

  double norm_infty() const ; 
  double norm_infty(int* bad_node, int* bad_dof=NULL) const ; // this one also returns which node-rank/dof is faulty
  // I should also add something like a L2 norm, taking into account the geometric integration ... 

  STRING get_name() const ; 
  STRING get_set_name() const  { return(set_name); }
  const LIST<STRING>& get_data_names() const { return(data_names); }
  MESH* get_mesh() { return(mesh); }
  int get_field_size() const { return stored_data.size(); }
  LOCATION get_location() const { return location ; }
};

Z_END_NAMESPACE;

#endif
