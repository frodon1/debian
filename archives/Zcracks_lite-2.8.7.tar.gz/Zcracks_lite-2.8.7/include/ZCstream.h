#ifndef _ZCSTREAM_H
#define _ZCSTREAM_H

//
// Zcstream allows the programmer to fork processes and communicated with children.
// The standard use of this class is as following. This example shows how to get 
// system information in a portable way:
//

/**** 
Zcstream uname;
ARRAY<STRING> result;

  result.resize(4);
  uname.open("/bin/uname -s -n -r -m",ZIOS::in);
  for(int i=0;i<4;i++) uname>>result[i];
  uname.close();
  sys_name=result[0]; sys_name.remove_all('.');
  host_name=result[1]; host_name.remove_all('.');
  version=result[2]; version.remove_all('.');
  arch=result[3]; arch.remove_all('.');
\end{verbatim}
****/ 

#include <Defines.h>
#include <Std_cc_stream.h>
#include <Pbuf.h>
#include <Fbuf.h>
#include <Out_message.h>

Z_START_NAMESPACE;

ZCLASS Zcstream : virtual public ZIOS, 
                          public ZIOSTREAM {
  private:
    ZFILEBUFFER *my_pbuf;

  public:
    enum WHERE { local, net};
    WHERE where;
 
    Zcstream();
    Zcstream(int fd);
    Zcstream(int fd, char *p, int l); /* Deprecated */
    Zcstream(const char *name, IOS_OPENMODE mode, WHERE w=local);
    ~Zcstream();
    void close();

    ZFILEBUFFER* rdbuf() const; 
    ZFILEBUFFER* private_rdbuf() { return(my_pbuf); }
    void open(const char *name, IOS_OPENMODE mode, WHERE w=local);
    int is_open() const { return ((ZFILEBUFFER*)rdbuf())->is_open(); }
 
    void attach(int fd);
    void setstate(ZIOSTATE flag) { state |= flag; }

  private :
    void __fb_init(WHERE w=local);
    void delete_buf();
};
Z_END_NAMESPACE;

#endif
