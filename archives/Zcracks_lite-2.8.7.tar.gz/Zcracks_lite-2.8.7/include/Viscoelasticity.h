#ifndef __Viscoelasticity__ 
#define __Viscoelasticity__ 

// ---------------------------------------------------------------------------- 
// LINEAR_VISCOELASTIC  
// ---------------------------------------------------------------------------- 

#include <Defines.h>
#include <File.h>
#include <Error_messager.h>

#include <Clock.h>
#include <Integration_result.h>
#include <Integration_method.h>
#include <Int_variable_holder.h>
#include <Mat_data.h>
#include <Mechanical_behavior.h>
#include <Coefficient.h>
#include <Print.h>
#include <Viscoelastic_terms.h>

Z_START_NAMESPACE;

class LINEAR_VISCOELASTIC; 

ZCLASS LINEAR_VISCOELASTIC : public M_B_SD {
      protected :

        COEFF         K0, K_inf;
        COEFF         G0, G_inf;

        TENSOR2_VINT  eel;
        SCALAR_VAUX   ev; 
        SMATRIX       tgmat;
        TENSOR2       unity; 
        MATRIX        Va, Ua; 
        PLIST<VE_SHEAR>   shear;
        PLIST<VE_VOLUMIC> volumic;

        MATRIX stor_v;

      public :

        LINEAR_VISCOELASTIC();
        ~LINEAR_VISCOELASTIC(); 
        virtual void initialize(ASCII_FILE& file,int dim, LOCAL_INTEGRATION*);

        INTEGRATION_RESULT* integrate( MAT_DATA& mdat, 
                                       const VECTOR& delta_grad, 
                                       MATRIX*& tg_matrix, int flags );
};

#endif
Z_END_NAMESPACE;


