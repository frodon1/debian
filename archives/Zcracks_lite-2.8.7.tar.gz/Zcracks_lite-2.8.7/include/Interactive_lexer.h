#ifndef __INTERACTIVE_LEXER__
#define __INTERACTIVE_LEXER__

#include <P_lexer.h>
#include <Base_problem.h>

Z_START_NAMESPACE;

ZCLASS INTERACTIVE_LEXER : public P_LEXER 
{
  public :
    ZP_PROGRAM_ITEM_LIST *whole_code;
    STRING source;
    int pos;

    INTERACTIVE_LEXER() : P_LEXER() { is_interactive=TRUE; pos=0; whole_code=NULL; }
    virtual ~INTERACTIVE_LEXER() { }

    virtual int LexerInput(char*,int);
    virtual void LexerError( const char*);

    virtual int parse();
};

ZCLASS INTERACTIVE_LEXER_PB : public BASE_PROBLEM
{
  protected :
    INTERACTIVE_LEXER i_lexer;
    ZP_PROGRAM_ITEM_LIST whole_code;
    ZP_ENV *env;
    ZP_STACK stack;

  public :
    LIST< AUTO_PTR<ZP_PIECE> > &instructions;

    INTERACTIVE_LEXER_PB();
    virtual ~INTERACTIVE_LEXER_PB() { if(env) delete(env); }

    virtual bool Execute();

    int enter(STRING&,ZP_STATUS&);
    void up();
    void down();

    int  execute_last_statement(ZP_STATUS&);
    void save(STRING);
    void load(STRING);

    void reset();

    const ZP_ENV& get_env() { return(*env); }
};
Z_END_NAMESPACE;

#endif
