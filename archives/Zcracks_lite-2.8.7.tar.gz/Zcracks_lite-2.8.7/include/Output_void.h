#ifndef __Output_void__ 
#define __Output_void__ 

// ============================================================================  
//  Z8.2 Void output driver for testing  RF 10/10/2002 
// ============================================================================  

#include <Output.h>

Z_START_NAMESPACE;

ZCLASS2 OUTPUT_VOID : public OUTPUT {
 protected :
 public :
     OUTPUT_VOID(); 
     virtual ~OUTPUT_VOID();

     virtual void initialize(PROBLEM* pb, ASCII_FILE* inp);
     virtual bool base_read(STRING cctl1, ASCII_FILE& inp); 

     virtual void open_files(MODE m=OPEN);
     virtual void close_files();

     virtual void write_output(MESH& mesh,ARRAY<BEHAVIOR*>& behavior);
     virtual void setup(ARRAY<BEHAVIOR*>&,MESH& mesh, RESTARTER::MODE lrestart_mode,int io, bool rescan=FALSE); 
};

Z_END_NAMESPACE;
#endif   

