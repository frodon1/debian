#ifndef __PARALLEL_DEFINES__
#define __PARALLEL_DEFINES__

#define PARALLEL_CLIENT_OPTION "-pclient"

#define MAX_HOSTS 128 // Ok, Ok... I know that such hard-coded sizes is
                     // forbidden bye jb but, due to PVM3 library,
                     // I cannot make otherwise. I beg your pardon :-(
//
// ZeBuLoN system runtime messages
//
#define Z_N_NODE 1001
#define Z_START_ACK 1000
#define Z_GLOBAL_REQUEST 1008
#define Z_WD 1013
#define Z_PARENT 1014
#define Z_NOTIFICATION 1016

#endif
