#ifndef __Simulator_model__
#define __Simulator_model__

// ============================================================================  
//     o  It is up to the *MODEL* to handle the rotation!! .. ZebFront tries to 
//        check the best it can.. please verify
// ============================================================================  

#include <Array.h>
#include <File.h>
#include <Hierarchy.h>
#include <ZMath.h>
#include <Rotation.h>
#include <Object_factory.h>
#include <Stringpp.h>
#include <Print.h>

#include <Integration_runge.h>
#include <Integration_theta.h>

Z_START_NAMESPACE;

class YIELD_SPEC;
class SIMULATOR_TEST;

ZCLASS SIMUL_MODEL : public virtual RUNGE_INTEGRATOR {
   public :
     VECTOR         coefs;
     LIST<STRING>   coef_names;

     // 
     // Used in the "standard" simul model... ie not 
     // basic_nl_simul or gen_evp 
     // 
     LIST<STRING>   observ_vars; 
     LIST<STRING>   vint_name, vaux_name; 
     VECTOR         var_int,var_aux;
     VECTOR         grad,flux;
     VECTOR         var_int_bu,var_aux_bu;

     VECTOR         param_0,param_ini,param;

     virtual VECTOR& get_var_int() { return var_int; } 
     virtual VECTOR& get_var_aux() { return var_aux; } 
     virtual VECTOR& get_grad();  
     virtual VECTOR& get_flux(); 

     VECTOR         dglobal;
     ARRAY<STRING>  load;
     RUNGE*         m_intrk;
     AUTO_PTR<ROTATION>  simulation_rotation; 
     int            behavior_based; 
     virtual int    simul_unlocked(); 

   public :
     LIST<STRING> criterion_names; 

     static SIMUL_MODEL*  read(ASCII_FILE& file, SIMULATOR_TEST* tst);
     virtual void material_read_loop(ASCII_FILE& file); 
     virtual void read_coef(ASCII_FILE& file); 

     SIMUL_MODEL();
     virtual ~SIMUL_MODEL();
     virtual void initialize(ASCII_FILE&,
                             LOCAL_INTEGRATION*, 
                             SIMULATOR_TEST* tst);

     virtual void simul_attach_dgrad_parts(VECTOR& dg);
     virtual void set_external_parameters(const VECTOR& p0, 
                                          const VECTOR& pini, 
                                          const VECTOR& p); 

     // 
     // returns FALSE if not ok 
     // 
     virtual bool simul_integrate(VECTOR& dgl, ARRAY<STRING>& ctl, double dtime);

     virtual LIST<STRING> get_all_variable_names(); 
     virtual VECTOR       get_all_variables(); 
     virtual void results(VECTOR& res, ARRAY<STRING>& wht);
     virtual void do_yield(Zofstream& ofile, YIELD_SPEC& spec);

     virtual void derivative(double,const VECTOR&,VECTOR&);

     virtual void read_mat_file(ASCII_FILE& mat);
     virtual void write_mat_file(STRING& name);
     virtual void give_coef_vals(VECTOR& coefs, ARRAY<STRING> wht);
     virtual void set_coef_vals(ARRAY<STRING> wht, const VECTOR& coefs);
             void set_coef_vals(ARRAY<STRING> wht, const MATRIX& coefs);
     virtual void get_flux_grad_names(LIST<STRING>& f_name, LIST<STRING>& g_name); 
     virtual void set_ini_vals(STRING& wht, double value);
     virtual void init_problem(const ARRAY<STRING>& ctl, const VECTOR& vals) {}

     // 02/25/2014 : used eg. by UNLOAD_OFFSET_YIELD that plays with the current problem state
     // overloaded in FEA_MAT_WRAPPER where it is indeed needed
     virtual void save_problem_state() {}
     virtual void restore_problem_state() {}
     virtual void set_problem_state(const ARRAY<STRING>& ctl, const VECTOR&) {}

     void  save_vars();
     void  restore_vars();

     virtual void   init();
     virtual void   reset();

     int if_behavior_based()const { return behavior_based; } 
     HIERARCHY_BASE;
};

#define MAKE_SIM_READER(a,b) DECLARE_OBJECT(SIMUL_MODEL,a,b)

Z_END_NAMESPACE;
#endif

