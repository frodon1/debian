#ifndef __INTERNAL_REACTION_COMPUTER__
#define __INTERNAL_REACTION_COMPUTER__

#include <Z_object.h>
#include <Defines.h>

Z_START_NAMESPACE;
Z_USE_NAMESPACE;


class MESH;
class GLOBAL_MATRIX;
class D_ELEMENT;
class INTEGRATION_RESULT;
class VECTOR;
class SMATRIX;

/*

FF, august 23rd, 2011

These classes defines callbacks which, when installed into a PROBLEM object, take control to
compute reactions at the MESH or at the ELEMENT level, bypassing the standard methods.

One normally creates instances of these classes in a plugin and install them during the input reading.

*/

ZCLASS2 INTERNAL_REACTION_COMPUTER : public Z_OBJECT {
  public :
    INTERNAL_REACTION_COMPUTER() { }
    virtual ~INTERNAL_REACTION_COMPUTER() { }

    virtual INTEGRATION_RESULT* apply(MESH*,GLOBAL_MATRIX*,bool,bool);
    RTTI_INFO;
};

ZCLASS2 INTERNAL_REACTION_COMPUTER_FOR_ELEMENT : public Z_OBJECT {
  public :
    INTERNAL_REACTION_COMPUTER_FOR_ELEMENT() { }
    virtual ~INTERNAL_REACTION_COMPUTER_FOR_ELEMENT() { }

    virtual INTEGRATION_RESULT* apply(D_ELEMENT*,bool , VECTOR&, SMATRIX&, bool);
    RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
