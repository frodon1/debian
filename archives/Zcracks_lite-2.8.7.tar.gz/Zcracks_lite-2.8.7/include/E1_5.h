#ifndef __E1_5__
#define __E1_5__

#include <Mcesd.h>

Z_START_NAMESPACE;

ZCLASS2 E1_5 : public MCESD {
      bool origin_computed;
   protected :
      virtual void compute_B(MATRIX&);
      int pos_Ezz;
      int pos_Ezx;
      int nb_displ;
    public :
      E1_5();
      virtual ~E1_5();
      virtual void setup_dofs(const char* ele_type);

      virtual int material_dimension()const;
};
Z_END_NAMESPACE;

#endif
