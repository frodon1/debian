#ifndef SKIP_STD_FUNCTION

#ifndef __Function__
#define __Function__

#include <Func_defs.h>
#include <List.h>
#include <Rpn_func.h>

#include <Tokens.h>
#include <Variable.h>
#include <Stringpp.h>
#include <File.h>
#include <Aaa_zmat_globals.h>

Z_START_NAMESPACE;

ZCLASS PAR_PAIR {
  public :
    int open,close;

  PAR_PAIR() { }
 ~PAR_PAIR() { }

  PAR_PAIR& operator=(const PAR_PAIR &p) { open=p.open; close=p.close; return(*this); }
  int operator==(const PAR_PAIR &p) { return((open==p.open)&&(close==p.close)); } 
};

ZCLASS FUNCTION {
  private :

   static bool Function_started;

   LIST<TOKEN> tokens; // store the list of algebraic tokens
   LIST<TOKEN> rpn_tokens; // store the list of rpn tokens (ie the rpn translation)
   int good;

   void parse(STRING &alge);
   int translate(LIST<TOKEN> &rpn_t, LIST<TOKEN> &alge_t);
   int pre_analyze(void);
   void assign_p(void);
   void assign_p_value(void);
   void order_l_var(void);

  public :

   enum FUNC_ERROR { OK=0, NC_PAR=1, NO_PAR=2 , 
                     SYN=3, B_NAG=4, B_FSY=5, TFA=6, 
                     B_ASS=7,E_EXI=8};

   int narg;
   LIST<VARIABLE> l_var;
   STRING algebraic;
   RPN_FUNC rpn;

   FUNCTION();
   FUNCTION(const FUNCTION&);
  ~FUNCTION() { }

   bool operator==(const FUNCTION& fin); 

   int analyze(const STRING& al,bool _issue_error=FALSE) ;

   double compute(int &err,bool _issue_error=FALSE);

   double compute();
   
   double compute(ARRAY<double>& tab);
   double compute(VECTOR& v);

   double compute(double d);

   // 
   // compute_derivative is a forward only finite difference, and 
   // compute_derivative_2nd is dy = (f(x+dx)-f(x-dx))/(2*dx)
   // 
   double compute_derivative(int rk,int &err,bool _issue_error=FALSE, double pert=1.e-7);  
   double compute_derivative_2nd(int rk,int &err,bool _issue_error=FALSE, double pert=1.e-12);
    
   // 
   // Why no analytical derivative here?... actually why no 
   // analy 1st and 2nd order derivatives (comment rf 01/26/03). 
   // 

   void learn(const STRING& name);

   void fOut(void);

   void issue_error(int,...);
   void issue_numerical_error(int,...);

   bool initialize(ASCII_FILE& f, bool _issue_error=TRUE);
   static FUNCTION* read(ASCII_FILE&,bool _issue_error=TRUE);
   static FUNCTION* make(const STRING&,bool _issue_error=TRUE);

   static void learn_in_file(STRING &f);
};

extern WIN_THINGIE PLIST<FUNCTION> BUILT_IN_FUNC;

extern WIN_THINGIE const char* H_BUILT_IN_OPER[];
extern WIN_THINGIE f_numeric H_O_NUMERIC[];
extern WIN_THINGIE int H_BUILT_IN_PRIOR[];

extern WIN_THINGIE const char* H_BUILT_IN_FUNC[];
extern WIN_THINGIE f_numeric H_F_NUMERIC[];
extern WIN_THINGIE int H_BUILT_IN_ARGS[];

extern WIN_THINGIE const int H_N_BUILT_IN_FUNC;
extern WIN_THINGIE const int H_N_BUILT_IN_OPER;

WIN_THINGIE void init_func_lib();

Z_END_NAMESPACE;

#endif

#endif

