#ifndef __Coefficient_T6__
#define __Coefficient_T6__

// ============================================================================ 
//  COEFFICIENT_T6 class... Used to be ELASTICITY
//
//  o  He will call the MATERIAL_PIECE in charge of the matrix 
//     in order to have parameters for coeff. dependence, etc. 
// ============================================================================ 

#include <ZMath.h>
#include <Array.h>
#include <Coefficient.h>
#include <Material_piece.h>
#include <Tensor6.h>
#include <Tensor3.h>

Z_START_NAMESPACE;

class ASCII_FILE; class COEFFICIENT; 

ZCLASS COEFFICIENT_TENSOR6 : public TENSOR6,
                            public MATERIAL_PIECE {
    bool first_time, optimized;
 protected :
    virtual void compute_matrix()=0;    
    enum     TYPE {  _ISOTROPIC_, 
                     _DIAGONAL_, 
                     _CUBIC_, 
                     _TRANS_ISO_,
                     _ORTHOTROPIC_, 
                     _ANISOTROPIC_ 
                   } the_type; 
    void _initialize(MATERIAL_PIECE* boss,TYPE atype,int _tsz);
  public :
    COEFFICIENT_TENSOR6();
    COEFFICIENT_TENSOR6(const COEFFICIENT_TENSOR6&);
    virtual ~COEFFICIENT_TENSOR6();

    virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*,const STRING&)=0;
    bool    if_constant()const;
    virtual bool calc_coef();
    virtual void attach( VECTOR& chi);
    virtual void attach( VECTOR& chi, VECTOR& d_chi );

    COEFFICIENT_TENSOR6& operator=(double);
    COEFFICIENT_TENSOR6& operator=(const COEFFICIENT_TENSOR6&);

    friend WIN_THINGIE TENSOR3 operator*(const COEFFICIENT_TENSOR6&,const TENSOR3&);
    friend WIN_THINGIE TENSOR6 operator*(const COEFFICIENT_TENSOR6&,double);
    friend WIN_THINGIE TENSOR6 operator*(double,const COEFFICIENT_TENSOR6&);
    RTTI_INFO;
};

ZCLASS S_COEFFICIENT_TENSOR6 : public COEFFICIENT_TENSOR6 {
   protected :
      void _initialize(MATERIAL_PIECE*,TYPE);
   public : 
      S_COEFFICIENT_TENSOR6();
      virtual ~S_COEFFICIENT_TENSOR6();
      static  S_COEFFICIENT_TENSOR6* read( ASCII_FILE&     file,
                                      MATERIAL_PIECE*    boss,
                                      const char*        nm="y",
                                      const char*        def="default" );

    RTTI_INFO;
};

ZCLASS NS_COEFFICIENT_TENSOR6 : public COEFFICIENT_TENSOR6 {
   protected :
      void _initialize(MATERIAL_PIECE*,TYPE);
   public : 
      NS_COEFFICIENT_TENSOR6();
      virtual ~NS_COEFFICIENT_TENSOR6();
      static  NS_COEFFICIENT_TENSOR6* read( ASCII_FILE&     file,
                                       MATERIAL_PIECE*    boss,
                                       const char*        nm="y",
                                       const char*        def="default" );
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
