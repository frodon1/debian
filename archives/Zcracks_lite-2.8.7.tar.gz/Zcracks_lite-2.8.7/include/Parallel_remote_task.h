#ifndef __PARALLEL_REMOTE_TASK__
#define __PARALLEL_REMOTE_TASK__

#include <Z_object.h>

Z_START_NAMESPACE;

class PARALLEL_REMOTE;
class MP_INTERFACE;

ZCLASS PARALLEL_REMOTE_TASK : public Z_OBJECT
{
  protected :
    PARALLEL_REMOTE *the_server;
    MP_INTERFACE *mpi;
    int from,to,who;

  public :
    long int color;

    PARALLEL_REMOTE_TASK() { the_server=NULL; mpi=NULL; color=0; }
    virtual ~PARALLEL_REMOTE_TASK() { }

    void set_server(PARALLEL_REMOTE *s) { the_server=s; }
    void set_mpi(MP_INTERFACE *m) { mpi=m; }
  
    void set_from(int i) { from=i; }
    void set_to(int i) { to=i; }
    void set_who(int i) { who=i; }

    virtual int handle_message(int m)=0;
    virtual int get_tag()=0;
    RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
