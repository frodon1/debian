#ifndef __ZP_PLOT__
#define __ZP_PLOT__

#include <ZP_stack.h>
#include <ZP_object.h>

Z_START_NAMESPACE;

ZCLASS ZP_PLOT : public ZP_OBJECT
{
  protected :
    STRING labelx,labely,title,style;

    ZP_FATAL_ERROR* plot(ZP_STACK&,int);

    virtual void type_init(char*)  { }

  public :
    ZP_PLOT() : ZP_OBJECT() { type="plot"; labelx=labely=title=""; style="lines"; }
    virtual ~ZP_PLOT() { }

    METHOD_DECLARATION_START
      METHOD("plot",plot,2)
    METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
};
Z_END_NAMESPACE;

#endif
