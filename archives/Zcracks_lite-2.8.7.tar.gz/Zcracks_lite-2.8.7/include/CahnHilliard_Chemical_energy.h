#ifndef __CahnHilliard_Phasefield_cchic_energy__
#define __CahnHilliard_Phasefield_cchic_energy__

#include <Material_piece.h>
#include <Object_factory.h>
#include <Problem.h>
#include <Int_variable_holder.h>
#include <Elasticity.h>
#include <Integration_runge.h>
#include <Integration_theta.h>
#include <Behavior.h>
#include <CahnHilliard_Chemical_behavior.h>

Z_START_NAMESPACE;

class MAT_DATA; class ASCII_FILE; class CAHNHILLIARD_CHEMICAL_BEHAVIOR;

ZCLASS2 CAHNHILLIARD_CHEMICAL_ENERGY {
   public :
     COEFF D,H_chi,gamma,Lamda;
     COEFF mobility_v_D_over_d2f_dcv2;
     double psi, dpsi_dc, d2psi_d2c, d2psi_dc_dcchi, dpsi_dcchi, d2psi_d2cchi, d3psi_d3c;

     double mobility_v, kappa, F, W, alpha;
     BEHAVIOR* boss;

     CAHNHILLIARD_CHEMICAL_ENERGY();
     virtual ~CAHNHILLIARD_CHEMICAL_ENERGY();
     virtual void initialize(ASCII_FILE& file,BEHAVIOR* its_boss);
     virtual void compute_stuff(double, double)=0;
     virtual void set_parameters();
};

Z_END_NAMESPACE;
#endif
