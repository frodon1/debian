#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/meshgems.h>
#include <meshgems/adapt.h>

#define FREE_AND_STRDUP(_p_,_s_) if(_p_) free(_p_); _p_=NULL; _p_ = strdup(_s_)

/*
 * message callback function
 */
status_t my_message_cb(message_t * msg, void *user_data)
{
  FILE *f = (FILE *) user_data;
  char *desc;
  integer e, n, m;
  integer i, i_data[10];
  real r_data[10];
  n = m = 0;

  message_get_description(msg, &desc);
  message_get_number(msg, &e);

  if (e == 0) {
    fprintf(f, "mg-adapt info : %s", desc);
  } else {
    if (e < 0) {
      fprintf(f, "mg-adapt ERROR %i : %s", MESHGEMS_ABS_CODE(e), desc);
    } else {
      fprintf(f, "mg-adapt info %i : %s", MESHGEMS_CODE(e), desc);
    }
    message_get_integer_data_count(msg, &n);
    message_get_real_data_count(msg, &m);
    if (e < 0 || n > 0 || m > 0) {
      fprintf(f, "MGMESSAGE %i ", e);
      fprintf(f, " %i", n);
      if (n > 0) {
        message_get_integer_data(msg, 1, n, i_data);
        for (i = 0; i < n; i++)
          fprintf(f, " %i", i_data[i]);
      }
      fprintf(f, " %i", m);
      if (m > 0) {
        message_get_real_data(msg, 1, m, r_data);
        for (i = 0; i < m; i++)
          fprintf(f, " %f", r_data[i]);
      }
      fprintf(f, " \n");
    }
  }

  return STATUS_OK;
}



/* A macro we will call to cleanly return from the function in case of
 * failure. Deleting the context will delete all attached MeshGems
 * object (sessions, meshes, sizemaps, ...)
 */
#define RETURN_WITH_MESSAGE(_ret, _msg) do{				\
    fprintf(stderr,"%s\n",_msg);					\
    if(ctx) context_delete(ctx);					\
    return _ret;							\
  }while(0);


/*
 * MAIN PROCEDURE
 */
int main(int argc, char *argv[])
{
  char *fileIn = NULL;
  char *fileOut = NULL;
  char *filebg = NULL;
  char *filebg_m = NULL;
  char *filebg_s = NULL;
  mesh_t *msh;
  mesh_t *msh_bg;
  mesh_t *msh_output = NULL;
  meshgems_status_t ret;
  sizemap_t *size;

  context_t *ctx;
  meshgems_adapt_session_t *prs;

  ctx = 0;
  msh = 0;
  msh_bg = 0;
  prs = 0;
  msh_output = 0;
  size = 0;


  /* Create the Meshgems working context */
  ctx = meshgems_context_new();
  if (!ctx) {
    RETURN_WITH_MESSAGE(STATUS_NOMEM, "unable to create a new context");
  }

  /* Set the message callback for our context */
  ret = context_set_message_callback(ctx, my_message_cb, stdout);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /* Check input and output files */
  if (argc > 1 && argv[1][0] != '-') {
    FREE_AND_STRDUP(fileIn, argv[1]);
    if (argc > 2) {
      FREE_AND_STRDUP(filebg, argv[2]);
      if (argc > 3) {
	FREE_AND_STRDUP(fileOut, argv[3]);
      }
    }
  }

  if (!fileIn) {
    fprintf(stdout, "ERROR: Missing input file.\n");
    return -1;
  }
  if (!fileOut) {
    int fileInLen = strlen(fileIn);
    char *pchar;
    fileOut = (char *) calloc(fileInLen + 20, sizeof(char));
    if (fileOut) {
      strncpy(fileOut, fileIn, fileInLen + 20);
      pchar = strstr(fileOut + fileInLen - 7, ".mesh");
      if (pchar)
        pchar[0] = 0;

      if (fileIn[fileInLen - 1] == 'b') {
        strncat(fileOut, "_adapt.meshb", fileInLen + 20);
      } else {
        strncat(fileOut, "_adapt.mesh", fileInLen + 20);
      }
    } else {
      fprintf(stdout, "ERROR: Unable to create output file name.\n");
      return -1;
    }
  }

  if (!filebg) {
    fprintf(stdout, "ERROR: Missing input sizemap.\n");
    return -1;
  }


  /* Read the input file fileIn */
  {
    /* Create the Meshgems mesh and read it */
    if (fileIn) {
      msh = meshgems_mesh_new_read_mesh(ctx, fileIn);
    } else {
      fprintf(stdout, "ERROR: No input file...\n");
      return -1;
    }
    if (!msh) {
      printf("Mesh creation or reading failed \n");
      meshgems_adapt_session_delete(prs);
      meshgems_context_delete(ctx);
      return -1;
    }
  }

  /* Read the input sizemap */
  {
    /* Create the Meshgems mesh and read it */
    if (filebg) {
      int filebglen = strlen(filebg);
      
      filebg_m = (char *) calloc(filebglen + 21, sizeof(char));
      if (!filebg_m){
	RETURN_WITH_MESSAGE(STATUS_NOMEM, "Unable to alloc  filebg_m buffer");
      }
      strcpy(filebg_m, filebg);
      strcat(filebg_m, ".mesh");

      filebg_s = (char *) calloc(filebglen + 21, sizeof(char));
      if (!filebg_s){
	RETURN_WITH_MESSAGE(STATUS_NOMEM, "Unable to alloc  filebg_s buffer");
      }
      strcpy(filebg_s, filebg);
      strcat(filebg_s, ".sol");

      msh_bg = meshgems_mesh_new_read_mesh(ctx, filebg_m);

      size = meshgems_sizemap_new_read_sol(msh_bg, filebg_s);

    } else {
      fprintf(stdout, "ERROR: No input sizemap...\n");
      return -1;
    }

    if (!size) {
      printf("Sizemap creation or reading failed \n");
      meshgems_adapt_session_delete(prs);
      meshgems_context_delete(ctx);
      return -1;
    }
  }

  /* Create the Meshgems Adapt session */
  prs = meshgems_adapt_session_new(ctx);
  if (!prs) {
    RETURN_WITH_MESSAGE(ret,
                        "unable to create a new MeshGems-Adapt session \n");
  }


  /* Set the parameters to run MeshGems-Adapt */

  /* 
   * Set the highest verbose level : 10 
   */
  ret = meshgems_adapt_set_param(prs, "verbose", "10");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /* 
   * Ask for volume adaptation 
   */
  ret = meshgems_adapt_set_param(prs, "adaptation", "volume");
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error");

  /*
   * To perform a surface adaptation you can set this previous parameter to "surface"
   * To perform both surface and volume adaptation you can set this previous parameter to "both"
   * this would require that your background mesh and your input mesh are the same
   */

  ret = STATUS_ERROR;
  ret = meshgems_adapt_set_surface_mesh(prs, msh);
  if (ret != STATUS_OK) {
    RETURN_WITH_MESSAGE(ret,
                        "internal error : unable to set surface mesh.");
    goto endsession;
  }

  ret = meshgems_adapt_set_sizemap(prs, size);
  if (ret != STATUS_OK) {
    RETURN_WITH_MESSAGE(ret,
                        "internal error : unable to set sizemap.");
    goto endsession;
  }

  /* 
   * The mesh generation process. 
   * See the meshgems/adapt.h file for more details
   */
  ret = meshgems_adapt_compute(prs);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret, "internal error : mesh processing failed");

  /*
   * Mesh generation is completed.
   * Get the generated mesh. This output mesh belongs to the
   * adapt_session. Thus the user does not have to destroy it
   * afterwards.
   */
  ret = meshgems_adapt_get_mesh(prs, &msh_output);
  if (ret != STATUS_OK)
    RETURN_WITH_MESSAGE(ret,
                        "internal error : unable to set surface mesh.");

  /* We directly write a .mesh formatted file :*/

  if (fileOut) {
    ret = meshgems_mesh_write_mesh(msh_output, fileOut);
    if (ret != STATUS_OK)
      RETURN_WITH_MESSAGE(ret, "unable to write a .mesh file");
  }


endsession:
  /*
   * We are done, give the volume mesh and sizemap back to the session and clean up everything.
   */
  meshgems_adapt_regain_mesh(prs, msh_output);
  meshgems_adapt_session_delete(prs);

  if (msh) {
    meshgems_mesh_delete(msh);
  }

  meshgems_context_delete(ctx);

  if (fileIn)
    free(fileIn);
  if (fileOut)
    free(fileOut);
  if (filebg)
    free(filebg);
  if ( filebg_m)
    free(filebg_m);
  if ( filebg_s)
    free(filebg_s);

  return 0;
  }
