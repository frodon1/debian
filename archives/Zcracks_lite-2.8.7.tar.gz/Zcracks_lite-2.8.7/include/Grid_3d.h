#ifndef __GRID_3D__
#define __GRID_3D__

#include <Finite_set.h>
#include <File.h>
#include <string.h>
#include <Buffered_list.h>
#include <Aaa_zmat_globals.h>
#include <Zminmax.h>

Z_START_NAMESPACE;

  template <class T>
  class GRID_3D 
  {


    //TODO
    //This forbid unintentional copy of these potentiallly big objects.
    //use deliberately copy_self instead;
  public :
    GRID_3D& operator=(const GRID_3D<T> &g) { 
      xmin=g.xmin; ymin=g.ymin; zmin=g.zmin;
      xmax=g.xmax; ymax=g.ymax; zmax=g.zmax;
      if ( (nx!=g.nx) || (ny!=g.ny) || (nz!=g.nz)) {
        nx=g.nx; ny=g.ny; old_nz=nz; nz=g.nz; nxyz=nx*ny*nz; allocate();
      }
      delta_x=(xmax-xmin)/nx; delta_y=(ymax-ymin)/ny; delta_z=(zmax-zmin)/nz;
      max_delta=Zmax(delta_x,Zmax(delta_y,delta_z));
      min_delta=Zmin(delta_x,Zmin(delta_y,delta_z));
      for (unsigned int i=0;i<nxyz;i++) contents[i]=g.contents[i]; 
      return(*this); 
    }
    GRID_3D(const GRID_3D<T> &g) {
      line_ptr=NULL; contents=NULL; z_ptr=NULL; init(g.xmin,g.ymin,g.zmin,g.xmax,g.ymax,g.zmax,g.nx,g.ny,g.nz);
      for (unsigned int i=0;i<nxyz;i++) contents[i]=g.contents[i];
    }

  public :
    void copy_self(const GRID_3D<T> &g) { 
      *this=g;      
    }    


  protected :
    T *contents;
    T **z_ptr;
    T ***line_ptr;

    void allocate()
    {
      if (contents) 
        delete[](contents);
      contents=new T[nxyz]; 

      if(z_ptr)
        delete[](z_ptr);
      z_ptr=new T* [nz]; int nxy=nx*ny;
      for (unsigned int i=0;i<nz;i++) z_ptr[i]=&contents[i*nxy];
      
      if (line_ptr) 
        {
          for (unsigned int i=0;i<old_nz;i++) 
            delete[](line_ptr[i]); 
          delete[](line_ptr);
        }

      line_ptr=new T** [nz];
      for (unsigned int i=0;i<nz;i++) {
        line_ptr[i]=new T* [ny];
        for (unsigned int j=0;j<ny;j++) line_ptr[i][j]=&contents[i*nxy+j*nx];
      }
    }




  public :
    double xmin,xmax,ymin,ymax,zmin,zmax;
    double delta_x,delta_y,delta_z,max_delta,min_delta;
    unsigned int nx,ny,nz,nxyz;
    unsigned int old_nz;
    GRID_3D(double x1=0., double y1=0., double z1=0., double x2=1., double y2=1., double z2=1., 
            unsigned int _nx=20, unsigned int _ny=20, unsigned int _nz=20) { 
      line_ptr=NULL; contents=NULL;   z_ptr=NULL; init(x1,y1,z1,x2,y2,z2,_nx,_ny,_nz);
    }
    ~GRID_3D() { 
      if (contents) delete[](contents); 
      if (line_ptr) 
        {
          for (unsigned int i=0;i<nz;i++) 
            delete[](line_ptr[i]); 
          delete[](line_ptr); 
        }           
      if (z_ptr) delete[](z_ptr);
      
    }

    void init(double x1, double y1, double z1, double x2, double y2, double z2, 
              unsigned int _nx, unsigned int _ny, unsigned int _nz) { 
      xmin=x1; ymin=y1; zmin=z1;
      xmax=x2; ymax=y2; zmax=z2;
      nx=_nx; ny=_ny; old_nz=nz; nz=_nz; nxyz=nx*ny*nz; allocate();
      delta_x=(xmax-xmin)/nx; delta_y=(ymax-ymin)/ny; delta_z=(zmax-zmin)/nz;
      max_delta=Zmax(delta_x,Zmax(delta_y,delta_z));
      min_delta=Zmin(delta_x,Zmin(delta_y,delta_z));
    }

    T& operator[](unsigned int i) { return(contents[i]); }
    const T& operator[](unsigned int i) const { return(contents[i]); }

    T& operator()(const unsigned int i, const unsigned int j, const unsigned int k) { 
#ifdef ZCHECK
//       //    if((i<0) || (i>=nx) || (j<0) || (j>=ny) || (k<0) || (k>=nz))  since this is unsigned ints, i<0 is always false and i>nx is enough
//       if((i>=nx)|| (j>=ny) || (k>=nz))
//         {
//           printf("Out of grid. Position is (%d,%d,%d) and size of grid is : (%d,%d,%d)\n",i,j,k,nx,ny,nz);
//           Assert(0);
//         }
#endif
      return(line_ptr[k][j][i]); 
    }
    const T& operator()(const unsigned int i, const unsigned int j, const unsigned int k) const { 
#ifdef ZCHECK
//       //    if((i<0) || (i>=nx) || (j<0) || (j>=ny) || (k<0) || (k>=nz))  since this is unsigned ints, i<0 is always false and i>nx is enough
//       if((i>=nx)|| (j>=ny) || (k>=nz))
//         {
//           printf("Out of grid. Position is (%d,%d,%d) and size of grid is : (%d,%d,%d)\n",i,j,k,nx,ny,nz);
//           Assert(0);
//         }
#endif
      return(line_ptr[k][j][i]); 
    }

    T& operator()(const FINITE_SET<3,unsigned int> &c) { return(line_ptr[c(2)][c(1)][c(0)]); }
    const T& operator()(const FINITE_SET<3,unsigned int> &c) const { return(line_ptr[c(2)][c(1)][c(0)]); }
  
    double coordinate_x(unsigned i) const { return(xmin+i*delta_x); }
    double coordinate_y(unsigned i) const { return(ymin+i*delta_y); }
    double coordinate_z(unsigned i) const { return(zmin+i*delta_z); }

    bool find_ix(const double x, unsigned int &ix) const { 
      if (x<xmin) return(FALSE); if (x>xmax) return(FALSE);
      ix=(unsigned int)((x-xmin)/delta_x); return(TRUE);
    }

    bool find_iy(const double y, unsigned int &iy) const { 
      if (y<ymin) return(FALSE); if (y>ymax) return(FALSE);
      iy=(unsigned int)((y-ymin)/delta_y); return(TRUE);
    }

    bool find_iz(const double z, unsigned int &iz) const { 
      if (z<zmin) return(FALSE); if (z>zmax) return(FALSE);
      iz=(unsigned int)((z-zmin)/delta_z); return(TRUE);
    }
  
  
    bool interpolate( const VECTOR &pos, T& t);
  



    GRID_3D& operator=(const T t) { for (unsigned int i=0;i<nxyz;i++) contents[i]=t; return(*this); }
    bool equal_grid_size(const GRID_3D < double > &t) { 
      if(t.xmin!=xmin || t.ymin!=ymin || t.zmin!=zmin  ||
         t.xmax!=xmax || t.ymax!=ymax || t.zmax!=zmax  ||
         t.nx!=nx     || t.ny!=ny     || t.nz!=nz     )
        return false;
      else
        return true;
    }

    void set(const T t) { for (unsigned int i=0;i<nxyz;i++) contents[i]=t; }

    void load(STRING f) {

      bool is_double=false;
      bool is_int=false;
      
      ASCII_FILE file(f());
      if(!file.ok) ERROR("Cannot open file: "+f);
      
      old_nz=nz; 
      nx=file.getint(); if (!file.ok) INPUT_ERROR("Read failed");
      ny=file.getint(); if (!file.ok) INPUT_ERROR("Read failed");
      nz=file.getint(); if (!file.ok) INPUT_ERROR("Read failed");
      nxyz=nx*ny*nz;
  
      xmin=file.getdouble(); if (!file.ok) INPUT_ERROR("Read failed");
      ymin=file.getdouble(); if (!file.ok) INPUT_ERROR("Read failed");
      zmin=file.getdouble(); if (!file.ok) INPUT_ERROR("Read failed");
  
      xmax=file.getdouble(); if (!file.ok) INPUT_ERROR("Read failed");
      ymax=file.getdouble(); if (!file.ok) INPUT_ERROR("Read failed");
      zmax=file.getdouble(); if (!file.ok) INPUT_ERROR("Read failed");

      allocate();
      delta_x=(xmax-xmin)/nx; delta_y=(ymax-ymin)/ny; delta_z=(zmax-zmin)/nz;
      max_delta=Zmax(delta_x,Zmax(delta_y,delta_z));
      min_delta=Zmin(delta_x,Zmin(delta_y,delta_z));

      STRING tmp=file.getSTRING();
      if(tmp.if_int())
        is_int=true;
      else if(tmp.if_double())
        is_double=true;
      file.back();

      if(is_double)
        {
          for (unsigned int i=0;i<nz;i++)
            for (unsigned int j=0;j<ny;j++) 
              for (unsigned int k=0;k<nx;k++) { line_ptr[i][j][k]=file.getdouble(); if (!file.ok) INPUT_ERROR("Read failed"); }
        }
      else if(is_int)
        {
          for (unsigned int i=0;i<nz;i++)
            for (unsigned int j=0;j<ny;j++) 
              for (unsigned int k=0;k<nx;k++) { line_ptr[i][j][k]=file.getint(); if (!file.ok) INPUT_ERROR("Read failed"); }
        }
      else
        INTERNAL_ERROR;


      file.close();
    }

    void save(const STRING &f) {
      Zofstream file(f(),ios::out|ios::trunc);
  
      file.setf(ios::scientific,ios::floatfield);
      file<<nx<<" "<<ny<<" "<<nz<<"\n";
      file<<xmin<<" "<<ymin<<" "<<zmin<<"\n";
      file<<xmax<<" "<<ymax<<" "<<zmax<<"\n";

      for (unsigned int i=0;i<nz;i++)
        for (unsigned int j=0;j<ny;j++)
          for (unsigned int k=0;k<nx;k++) file<< line_ptr[i][j][k]<<"\n";
      //          for (unsigned int k=0;k<nx;k++) file<< line_ptr[i][j][k]*1.<<"\n";

      file.close();
    }


    void assign_value_if_in_grid(T val, unsigned int i, unsigned int j, unsigned int k) {
      if(!((i>=nx)|| (j>=ny) || (k>=nz) || (i<0) || (j<0) || (k<0)))
        line_ptr[k][j][i]=val;
    }


    void copy_to_fortran(double* &ptr) const { memcpy(ptr,contents,nxyz); }

    void copy_from_fortran(double* &ptr) { memcpy(contents,ptr,nxyz); }
  };








  template <class T>
  bool GRID_3D<T>::interpolate( const VECTOR &pos, T& t)
  {

    double x,y,z;
    double x_orig,y_orig,z_orig;
    VECTOR N; N.resize(8);
    double Nmx,Npx,Nmy,Npy,Nmz,Npz;
    BUFF_LIST< T >   val;  val.resize(8);
    BUFF_LIST< VECTOR > real_pos; real_pos.resize(8);
    for(int ii=0;ii<8;ii++) real_pos[ii].resize(3);

    x=pos[0];
    y=pos[1];
    z=pos[2];

    if(x<xmin || x>xmax || y<ymin || y>ymax || z<zmin || z>zmax)
      return false;

    //     printf("position demandee : %e %e %e\n", pos[0],pos[1],pos[2]);

    unsigned int i,j,k;  
    i=0;j=0;k=0;

    //find i,j,k, left,bottom,back  coordinate of element that contains the point
    //direct interpolation in a brick, no need to invoke a jacobian.


    find_ix(pos[0],i);
    find_iy(pos[1],j);
    find_iz(pos[2],k);


    //If we exactly are on a sup border, take element -1 in the considered direction 
    //Otherwise, the constructed element would be outside the mesh  -> seg fault
    if(i==nx-1)
      i--;
    if(j==ny-1)
      j--;
    if(k==nz-1)
      k--;

    x_orig=coordinate_x(i);
    y_orig=coordinate_y(j);
    z_orig=coordinate_z(k);



/*
       6 .--------. 7
         |\       |\                                
         | \      | \          
         |4 .--------. 5      
         |  |     |  |        
       2 .--|-----. 3|        
          \ |      \ |        
           \|       \|        
          0 .--------. 1
                                 
            z                       
         y  |                       
          \ |                      
           \|                      
            O---->  x                                               
*/
                                                             


    //     real_pos[0][0]=x_orig;
    //     real_pos[1][0]=x_orig+delta_x;
    //     real_pos[2][0]=x_orig;
    //     real_pos[3][0]=x_orig+delta_x;
    //     real_pos[4][0]=x_orig;
    //     real_pos[5][0]=x_orig+delta_x;
    //     real_pos[6][0]=x_orig;
    //     real_pos[7][0]=x_orig+delta_x;

    //     real_pos[0][1]=y_orig;
    //     real_pos[1][1]=y_orig;
    //     real_pos[2][1]=y_orig+delta_y;
    //     real_pos[3][1]=y_orig+delta_y;
    //     real_pos[4][1]=y_orig;
    //     real_pos[5][1]=y_orig;
    //     real_pos[6][1]=y_orig+delta_y;
    //     real_pos[7][1]=y_orig+delta_y;

    //     real_pos[0][2]=z_orig;
    //     real_pos[1][2]=z_orig;
    //     real_pos[2][2]=z_orig;
    //     real_pos[3][2]=z_orig;
    //     real_pos[4][2]=z_orig+delta_z;
    //     real_pos[5][2]=z_orig+delta_z;
    //     real_pos[6][2]=z_orig+delta_z;
    //     real_pos[7][2]=z_orig+delta_z;

  
    //     for(int kk=0;kk<2;kk++)
    //       for(int jj=0;jj<2;jj++)
    //  for(int ii=0;ii<2;ii++)
    //    {
    //      real_pos[ii+2*jj+4*kk][0]=x_orig+ii*delta_x;
    //      real_pos[ii+2*jj+4*kk][1]=y_orig+jj*delta_y;
    //      real_pos[ii+2*jj+4*kk][2]=z_orig+kk*delta_z;
    //    }



    //     for(int kk=0;kk<2;kk++)
    //       for(int jj=0;jj<2;jj++)
    //  {
    //    Out<<"toto "<<jj<<endl;
    //    for(int ii=0;ii<2;ii++)
    //      {
    //        Out<<"tutu "<<ii<<endl;
    //        //       printf("valeurs  %d %d %d -> %e %e %e  (%e)\n",ii,jj,kk,real_pos[ii+2*jj+4*kk][0],real_pos[ii+2*jj+4*kk][1],real_pos[ii+2*jj+4*kk][2],line_ptr[k+kk][j+jj][i+ii]);
    //    Out<<"TTT "<<line_ptr[k+kk][j+jj][i+ii]<<endl;
    //      }
    //  }


  
    for(int kk=0;kk<2;kk++)
      for(int jj=0;jj<2;jj++)
        for(int ii=0;ii<2;ii++)
          val[ii+2*jj+4*kk]=line_ptr[k+kk][j+jj][i+ii];
  
  
    Nmx=1-(x-x_orig)/delta_x;
    Npx=(x-x_orig)/delta_x;
  
    Nmy=1-(y-y_orig)/delta_y;
    Npy=(y-y_orig)/delta_y;
  
    Nmz=1-(z-z_orig)/delta_z;
    Npz=(z-z_orig)/delta_z;
  
    N[0]=Nmx*Nmy*Nmz;
    N[1]=Npx*Nmy*Nmz;
    N[2]=Nmx*Npy*Nmz;
    N[3]=Npx*Npy*Nmz;
    N[4]=Nmx*Nmy*Npz;
    N[5]=Npx*Nmy*Npz;
    N[6]=Nmx*Npy*Npz;
    N[7]=Npx*Npy*Npz;

    t=0.;
 


    //     printf("Nmx = %e %e %e %e %e %e\n",Nmx,Nmy,Nmz,Npx,Npy,Npz);
    
    //     printf("N = %e %e %e %e %e %e %e %e\n",N[0],N[1],N[2],N[3],N[4],N[5],N[6],N[7]);

    //     for(int ii=0;ii<8;ii++)
    //       Out<<"toto "<<ii<<" = "<<val[ii]<<endl;
    

    for(int ii=0;ii<8;ii++)
      {
        //  Out<<"t="<<t<<" N["<<ii<<"]="<<N[ii]<<"  val["<<ii<<"]="<<val[ii]<<endl;
        t=t+N[ii]*val[ii];
        //  Out<<"t="<<t<<endl<<endl;
      }

    //    printf("valeur trouvee : %e \n",  t);
    //     Out<<"valeur trouvee : "<<  t<<endl;
    
    
    return(true);
  }
  


Z_END_NAMESPACE;




#endif
  
