#ifndef __ISOS__
#define __ISOS__

#include <Base_problem.h>
#include <Bool.h>
#include <Darray.h>
#include <Post_mesh.h>
#include <Zstream.h>
#include <Ut_info.h>

Z_START_NAMESPACE;

ZCLASS2 ISOS : public BASE_PROBLEM
{
  protected :
    int if_ctnod,if_ctele,if_ctmat;
    Zifstream integ;
    Zofstream ctnod,ctele,ctmat;
    UT_INFO *ut;
    POST_MESH *mesh;
    long int nb_gauss_point;
    STRING mesh_type;

    ARRAY<float> integ_values,ctnod_values,ctele_values,ctmat_values;
    LIST<STRING> null_value_elset;
    LIST<STRING> null_value_compo;

    void open_files();
    void close_files();
    void open_ut();
    void size_vector();
    void read_card(int);
    void fill_ctnod();
    void fill_ctele();
    void fill_ctmat();
    void write_ctnod();
    void write_ctele();
    void write_ctmat();

  public :
    ISOS();
    virtual ~ISOS();

    virtual bool Execute(void);
    virtual void load(const STRING&,const STRING&);
};
Z_END_NAMESPACE;

#endif
