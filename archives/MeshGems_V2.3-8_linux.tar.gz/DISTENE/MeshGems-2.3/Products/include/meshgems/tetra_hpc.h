#ifndef __TETRA_HPC_H__
#define __TETRA_HPC_H__

#include <meshgems/mdecl.h>
#include <meshgems/basic_types.h>
#include <meshgems/status.h>
#include <meshgems/context.h>
#include <meshgems/interrupt.h>
#include <meshgems/message.h>
#include <meshgems/mesh.h>
#include <meshgems/sizemap.h>

#include <meshgems/tetra_hpc_short_names.h>

struct meshgems_tetra_hpc_session_t_;

/**
 * Opaque type to store session data.
 */
typedef struct meshgems_tetra_hpc_session_t_ meshgems_tetra_hpc_session_t;

/**
 * Simple constructor.
 *
 * @param[in] ctx : the context this session is attached to.
 *
 * @retval a new tetra_hpc_session_t on success, NULL on failure.
 */
MESHGEMS_METHOD meshgems_tetra_hpc_session_t *meshgems_tetra_hpc_session_new(
    meshgems_context_t *ctx);

/**
 * Destructor.
 *
 * @param[in] tms : the tetra_hpc session (is freed and \b unusable afterwards).
 */
MESHGEMS_METHOD void meshgems_tetra_hpc_session_delete(
    meshgems_tetra_hpc_session_t *ts);

/**
 * Sets the message callback function.
 *
 * This is where the user should detect and print phase changes,
 * timings, intersections, ... \n May be followed by a call to the
 * interrupt callback in particular in case of warning or error.
 *
 * @param[in] tms : the tetra_hpc session.
 * @param[in] cb  : the message callback (or NULL to remove any previous callback and use the callback from the context)
 * @param[in] user_data : the user pointer which will be given to cb as a parameter
 *
 * @retval STATUS_OK in case of success
 */
MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_set_message_callback(
    meshgems_tetra_hpc_session_t *ts, meshgems_message_callback_t cb,
    void *user_data);

/**
 * Sets the interrupt callback function.
 *
 * This is where the user indicates if he wants the process to cleanly
 * end the ongoing session call.  This is where the user may detect
 * and print timings, ...  \n May follow a call to the message
 * callback in particular in case of warning or error.
 *
 * @param[in] tms : the tetra_hpc session.
 * @param[in] cb  : the interrupt callback (or NULL to remove any previous callback and use the callback from the context)
 * @param[in] user_data : the user pointer which will be given to cb as a parameter
 *
 * @retval STATUS_OK in case of success
 */
MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_set_interrupt_callback(
    meshgems_tetra_hpc_session_t *ts, meshgems_interrupt_callback_t cb,
    void *user_data);

/**
 * Sets the sizemap function.
 *
 * @param[in] tms : the tetra_hpc session.
 * @param[in] s  : the sizemap. Accepted types are meshgems_sizemap_type_iso_3d
 * and meshgems_sizemap_type_aniso_3d. The sizemap function must be thread safe.
 *
 * @retval STATUS_OK in case of success
 */
MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_set_sizemap(
    meshgems_tetra_hpc_session_t *ts, meshgems_sizemap_t *s);

/**
 * Sets the input mesh.
 *
 * @param[in] ts : the tetra_hpc session.
 * @param[in] msh  : the input mesh structure.
 *
 * @retval STATUS_OK in case of success
 */
MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_set_input_mesh(
    meshgems_tetra_hpc_session_t *ts, meshgems_mesh_t *msh);

/**
 * Sets the input mesh.
 *
 * @param[in] ts : the tetra_hpc session.
 * @param[in] msh  : the input mesh structure.
 *
 * @retval STATUS_OK in case of success
 */
MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_set_param(
    meshgems_tetra_hpc_session_t *ts, const char *param_name,
    const char *param_value);

/**
 *  Generates a volume mesh from the surface input mesh.
 *
 * @param[in] ts : the tetra_hpc session.
 *
 * @retval STATUS_OK in case of success
 */
MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_mesh(
    meshgems_tetra_hpc_session_t *ts);

/**
 *  Gets the resulting volume.
 *
 * @param[in] ts : the tetra_hpc session.
 * @param[out] msh  : the output mesh structure.
 *
 * @retval STATUS_OK in case of success
 */
MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_mesh(
    meshgems_tetra_hpc_session_t *ts, meshgems_mesh_t **msh);

/**
 *  Gives back the resulting volume mesh to the tetra_hpc session structure.
 *
 * @param[in] ts : the tetra_hpc session.
 * @param[in] msh : the output mesh structure.
 *
 * @retval STATUS_OK in case of success
 */
MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_regain_mesh(
    meshgems_tetra_hpc_session_t *ts, meshgems_mesh_t *msh);

/* Private part of the API. Undocumented. */

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_subdomain_count(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer *n);

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_subdomain_index(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer i, meshgems_integer *k);

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_subdomain_mesh(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer i, meshgems_mesh_t **msh);

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_regain_subdomain_mesh(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer i, meshgems_mesh_t *msh);

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_subdomain_vertices_global_index_count(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer i, meshgems_integer *n);

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_subdomain_vertices_global_index(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer i, meshgems_integer j,
    meshgems_integer *r);

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_subdomain_edges_global_index_count(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer i, meshgems_integer *n);

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_subdomain_edges_global_index(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer i, meshgems_integer j,
    meshgems_integer *r);

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_subdomain_triangles_global_index_count(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer i, meshgems_integer *n);

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_subdomain_triangles_global_index(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer i, meshgems_integer j,
    meshgems_integer *r);

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_subdomain_tetrahedra_global_index_count(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer i, meshgems_integer *n);

MESHGEMS_METHOD meshgems_status_t meshgems_tetra_hpc_get_subdomain_tetrahedra_global_index(
    meshgems_tetra_hpc_session_t *ts, meshgems_integer i, meshgems_integer j,
    meshgems_integer *r);

MESHGEMS_METHOD meshgems_integer meshgems_tetra_hpc_get_version_major(void);
MESHGEMS_METHOD meshgems_integer meshgems_tetra_hpc_get_version_minor(void);
MESHGEMS_METHOD meshgems_integer meshgems_tetra_hpc_get_version_patch(void);
MESHGEMS_METHOD const char *meshgems_tetra_hpc_get_version_string(void);
MESHGEMS_METHOD const char *meshgems_tetra_hpc_get_version_ident_string(void);

#endif
