#ifndef __ZP_ARRAY_P_UTILITY_NODE__
#define __ZP_ARRAY_P_UTILITY_NODE__

#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>
#include <Utility_set.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_ARRAY_P_UTILITY_NODE : public ZP_BASIC_TYPE< ARRAY<UTILITY_NODE*> >
{
  protected :
    virtual ZP_FATAL_ERROR* print(ZP_STACK&,int);
    ZP_FATAL_ERROR* size(ZP_STACK&,int);
    ZP_FATAL_ERROR* bracket(ZP_STACK&,int);
    virtual void type_init(char*) { type="ARRAY_P_UTILITY_NODE"; }

  public :
    BASIC_CONSTRUCTORS(ZP_ARRAY_P_UTILITY_NODE,ARRAY<UTILITY_NODE*>);

    METHOD_DECLARATION_START
      METHOD("!",size,0) METHOD("size",size,0)
      METHOD("[]",bracket,1)
    METHOD_DECLARATION_ANCESTOR(ZP_BASIC_TYPE<ARRAY<UTILITY_NODE*> >)
    ZPO_RTTI_INFO(ARRAY<UTILITY_NODE*>)
};
Z_END_NAMESPACE;

#endif
