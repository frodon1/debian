//-------------------------------------------------------------------------
//
// Commands to show nodes, ips and elements.
// 2002 dec 07 A_R, suffering from PMS
//
//-------------------------------------------------------------------------

#ifndef __Dao_highlight_mesh_objects__
#define __Dao_highlight_mesh_objects__

#include <Graphics_object.h>
#include <Graphics_command.h>
#include <Graphics_area.h>
#include <Graphics_data_dialog.h>

#include <Utility_mesh.h>
#include <Utility_elements.h>
#include <Utility_node.h>
#include <Ref_Gauss_point.h>
#include <Utility_results_database.h>

#include <Dao_geom.h>

Z_START_NAMESPACE;

ZCLASS2 HIGHLIGHT_MESH_OBJECTS_COMMAND :
  public GRAPHICS_COMMAND,
  public GRAPHICS_OBJECT
{
  private:
     GRAPHICS_DATA_DIALOG* its_dialog;

     STRING select_ip,previous_select_ip;
     STRING nodes_to_show,previous_nodes_to_show;
     STRING elements_to_show,previous_elements_to_show;
     LIST<int> options,extra_options;
     int       deformed_flag,first_time;
     int       max_highlight_errors;
     
     
     ARRAY<STRING> meshes_names;
     
     
  public:
     HIGHLIGHT_MESH_OBJECTS_COMMAND();
     virtual ~HIGHLIGHT_MESH_OBJECTS_COMMAND();

     virtual void setup_dialog();

             bool do_command(STRING cmd);
     virtual void local_draw(GRAPHICS_AREA* ga);

     virtual void show_elements(               int show_info=0);
     virtual void show_nodes(GRAPHICS_AREA* ga,int show_info=0);
     virtual void show_ips(  GRAPHICS_AREA* ga,int show_info=0);
     virtual void show_element_numbers(GRAPHICS_AREA* ga);
     virtual void show_node_numbers(   GRAPHICS_AREA* ga);
     virtual void show_ip_numbers(     GRAPHICS_AREA* ga);

};
Z_END_NAMESPACE;

#endif   
