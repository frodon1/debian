#ifndef __Graphics_page__
#define __Graphics_page__

#include <P_container.h>
#include <Global_parameter.h>
#include <Object_factory.h>

Z_START_NAMESPACE;

//==============================================
// 2005/02 A_R
// A container class for paper sizes, used by
// Postscript_drawing_area.
// For now contains only A4 and LETTER
//==============================================
ZCLASS GRAPHICS_PAGE {
  protected :
    int          _type;
    STRING       _orientation;
    double       _width,    _height;   // in pica
    double       _margin_x, _margin_y; // in pica

    LIST<STRING> _page_types;
    LIST<double> _page_widths, _page_heights; // in mm or inch
    LIST<double> _page_units;                 // this one decides the unit

  public :

    GRAPHICS_PAGE();
    GRAPHICS_PAGE(STRING page_type, STRING orientation, double margx, double margy);
    virtual ~GRAPHICS_PAGE() {};

    void   setup_page_types();
    
    void   set_type(STRING type, STRING orientation);
    STRING get_type()        { return( _page_types[_type] ); }
    void   set_orientation(STRING orientation);
    STRING get_orientation() { return( _orientation ); }
    
    
    void   set_margin(  double margin);
    void   set_margin_x(double margin);
    void   set_margin_y(double margin);
    double get_margin_x();
    double get_margin_y();
    double get_margin_x_mm();
    double get_margin_y_mm();
    double get_width();
    double get_height();
    double get_width_mm();
    double get_height_mm();
};
Z_END_NAMESPACE;

#endif
