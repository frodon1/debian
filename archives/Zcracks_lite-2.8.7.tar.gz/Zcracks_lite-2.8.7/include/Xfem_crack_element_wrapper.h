#ifndef __Xfem_crack_element_wrapper__
#define __Xfem_crack_element_wrapper__

// ============================================================================ 
//  ENHANCED_ELEMENT_WRAPPER                                 RF 11/14/2003 
//
//  AKA X_ELEMENT 
// ============================================================================ 

#include <Xfem_enhanced_element_wrapper.h> 

Z_START_NAMESPACE;

class XFEM_CRACK_MODE; 

ZCLASS2 XFEM_CRACK_ELEMENT_WRAPPER : public XFEM_ENHANCED_ELEMENT_WRAPPER { 
    private:
      int num_tip_dim;
    protected : 
      int has_dof; 
      int number_of_standard_dof; 
//      int active_discontinuity;

      GEOMETRY *surfacic_geometry;
      BEHAVIOR *surfacic_behavior;
      ARRAY<MAT_DATA*> surfacic_mat_data;

      virtual void compute_crack_tip_terms(VECTOR& av, MATRIX& dav, const VECTOR& coord, double h_val); 
      virtual void compute_crack_tip_terms_fd(VECTOR& av, MATRIX& dav, const VECTOR& coord, double h_val); 

      virtual void sniff_x_section();

    public :
      enum CRACK_DOF_TYPE { 
           NONE            = 0,
           JUST_ENHANCED   = 1,
           CUT_DOF         = 2,
           TIP_DOF         = 4
      }; 

      int  step_fn_active; 
      int  crack_singularity_active; 

      XFEM_CRACK_ELEMENT_WRAPPER();
      XFEM_CRACK_ELEMENT_WRAPPER(XFEM_CRACK_MODE* boss);
      virtual ~XFEM_CRACK_ELEMENT_WRAPPER();

      virtual void wrap_p_element(P_ELEMENT* elem); 
      virtual void setup_dofs(const char* key);

      virtual void set_enhanced(UTILITY_MESH& sub_util_mesh,
                             int wrap_elem_to_util_elem_left, 
                             int wrap_elem_to_util_elem_right); 

      virtual void check_for_partial_enhancement(ARRAY<int>& xfem_node_flags);
      virtual bool transform_dirichlet();

      virtual void compute_nodal_field(ARRAY<VECTOR>& vals, int all_split_points=FALSE);
      virtual int  nb_nodal_field(int all_split_points=FALSE);

      virtual void enhanced_sym_grad_op(MATRIX& b, const MATRIX& base_b);
      virtual void enhanced_grad_op(MATRIX& b, const MATRIX& base_b);

      virtual INTEGRATION_RESULT* internal_reaction(
                       bool      if_compute_stiffness,
                       VECTOR&   resi,
                       SMATRIX&  stiff,
                       bool      only_get_tg_matrix);

      void create_surfacic_geometry(BEHAVIOR *b);

      virtual void shape_operator(MATRIX& op, const VECTOR &sh) const;
      virtual void compute_crack_tip_terms(VECTOR& av, const VECTOR& coord, double h_val); 


  RTTI_INFO;
}; 
Z_END_NAMESPACE;

#endif 
