#ifndef __Message__
#define __Message__

#include <Stringpp.h>
#include <Z_object.h>

Z_START_NAMESPACE;

ZCLASS APPLICATION_MESSAGE : public Z_OBJECT {
  public :
    STRING message;
  
    APPLICATION_MESSAGE() : Z_OBJECT() { }
    APPLICATION_MESSAGE(const char* c) : Z_OBJECT(),message(c) {}
    virtual ~APPLICATION_MESSAGE() {} 

    RTTI_INFO;
};

template <class T> ZCLASSt TYPED_MESSAGE : public APPLICATION_MESSAGE {
   public :
     T data;

     TYPED_MESSAGE() : APPLICATION_MESSAGE() { }
     TYPED_MESSAGE(const char* c) : APPLICATION_MESSAGE(c) { }
     virtual ~TYPED_MESSAGE() {}

     IMPL_RTTI_INFO_H(Z_OBJECT,TYPED_MESSAGE)
};

template <class T> ZCLASSt TYPED_PTR_MESSAGE : public APPLICATION_MESSAGE {
   public :
     T* pdata;

     TYPED_PTR_MESSAGE() : APPLICATION_MESSAGE() { }
     TYPED_PTR_MESSAGE(const char* c) : APPLICATION_MESSAGE(c) { }
     virtual ~TYPED_PTR_MESSAGE() {}

     IMPL_RTTI_INFO_H(Z_OBJECT,TYPED_PTR_MESSAGE)
};


Z_END_NAMESPACE;

#endif
