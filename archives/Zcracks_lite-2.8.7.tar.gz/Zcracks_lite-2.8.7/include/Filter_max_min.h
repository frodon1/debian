/*--------------------------------------------------------------------------------------------------------------
//
find_min_max_curve() with the following options:
//
// tresh : space between two extremum, used to filter very close ones
// 
// shift_up : all positive values kept will be more than this value
// 
// shift_down : all negative values kept will be less than this value
//
// enrichment_tresh : add sampled points if the difference between two  points is more than this value
//
--------------------------------------------------------------------------------------------------------------*/

#ifndef __Filter_max_min__
#define __Filter_max_min__



Z_START_NAMESPACE;

class FILTER_MAX_MIN
{
  public :
    int choice_max_min;
    double tresh,shift_up,shift_down,enrichment;

    FILTER_MAX_MIN();
    FILTER_MAX_MIN(const FILTER_MAX_MIN&);
   ~FILTER_MAX_MIN();

    bool filter(const VECTOR& x, const VECTOR& y, VECTOR& xf, VECTOR& yf);

};
Z_END_NAMESPACE;

#endif
