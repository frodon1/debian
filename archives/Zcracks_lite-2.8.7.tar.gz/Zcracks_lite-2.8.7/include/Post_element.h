#ifndef __Post_element__
#define __Post_element__

#include <Std_cc_stream.h>

#include <Element.h>
#include <Integ_data.h>
#include <Post_data_type.h>
#include <Post_node.h>

Z_START_NAMESPACE;

class GNODE; class GMESH; class POST_NODE;
class UT_INFO; class INTEG_DATA;

//
// --- load is a key function agruments are:
//        # of card among the selected cards
//        # of the card (global)
//        ranks of loaded variables
//        types of loaded variables
//        file group
// --- write is pretty much the same, note that there is only one
//       type of loaded variables
//

ZCLASS2 POST_ELEMENT : public ELEMENT {
 protected :
   friend class POST_MESH; friend class LOCAL_POST_PROCESSING;
   friend class POST_INTEG; friend class GLOBAL_POST_PROCESSING;
   ZSTREAMPOS off_ct, off_integ, off_ele,off_ctp, off_integp, off_elep;

 public :
   // 
   // For global posts 
   // 1st array is size of locations in ele (#gp or nds for ndata)
   // 2nd array is always zero?? 
   // each integ data has "data" and "out" sized to sz of input i need/output i give 
   // 
   ARRAY< ARRAY<INTEG_DATA> > idata; // can be integ
   ARRAY< ARRAY<INTEG_DATA> > ndata; // can be ctmat or ctele

   POST_ELEMENT() { }

   virtual void initialize_element(const ARRAY<GNODE*>& element_nodes,
                              GMESH* the_mesh_it_belongs_to,
                              GEOMETRY* element_geometry,
                              char *the_im,
                              int element_id /* tag */,
                              const char* ele_type);

   virtual ~POST_ELEMENT();

   POST_NODE* get_node(int inode)            { return (POST_NODE*)ELEMENT::get_node(inode); }
   const POST_NODE* get_node(int inode)const { return (POST_NODE*)ELEMENT::get_node(inode); }

   virtual void size(int,int,int,bool,PDT_GROUP);
   virtual void erase();
   virtual void load(int,int,const ARRAY<int>&,const ARRAY<POST_DATA_TYPE>&,
    PDT_GROUP, const ARRAY<int>& rk_utp_card);
   virtual void write(int,int,const ARRAY<int>&,POST_DATA_TYPE);
   virtual void write(int,int,const ARRAY<int>&,POST_DATA_TYPE,int ip);
};

ZCLASS2 POST_ELEMENT_2D : public POST_ELEMENT {
   public :
     virtual ~POST_ELEMENT_2D() {}
};                       

ZCLASS2 POST_ELEMENT_AXI : public POST_ELEMENT {
   public :
     virtual ~POST_ELEMENT_AXI() {}
};

ZCLASS2 POST_ELEMENT_3D : public POST_ELEMENT {
   public :
     virtual ~POST_ELEMENT_3D() {}
};         

ZCLASS2 POST_ELEMENT_SPH : public POST_ELEMENT {
   public :
     virtual ~POST_ELEMENT_SPH() {}
};

ZCLASS2 POST_ELEMENT_CYL : public POST_ELEMENT {
   public :
     virtual ~POST_ELEMENT_CYL() {}
};         
Z_END_NAMESPACE;

#endif
