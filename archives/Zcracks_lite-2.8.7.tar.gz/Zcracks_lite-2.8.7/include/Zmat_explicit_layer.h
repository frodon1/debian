#ifndef __Zmat_explicit_layer__
#define __Zmat_explicit_layer__ 

// ============================================================================ 
//  This is used as a "behavior modifier" to let the behaviors be used when
//  the VUMAT doesn't send in the total strain tensor.. 
// ============================================================================ 

#include <Integration_method.h>
#include <Mat_data_init.h>
#include <Mechanical_behavior.h>
#include <Behavior_wrapper.h>

Z_START_NAMESPACE;

ZCLASS ZMAT_EXPLICIT_LAYER : public BEHAVIOR_WRAPPER {
   protected :
      int     lagrange_flags; 
      int     usz;      

      SCALAR_VAUX    offset_a; 
      TENSOR2_VAUX   eto_stor; 

      TENSOR2_FLUX*  mb_flux; 
      TENSOR2_GRAD*  mb_grad; 

      MATRIX      m_tgmat;
      void        attach_all(MAT_DATA& mdat ); 
      virtual void   set_null_stress_component(int index);

   public :
 
      ZMAT_EXPLICIT_LAYER(); 
      virtual void initialize(ASCII_FILE& file, int dim, LOCAL_INTEGRATION*); 
      virtual void modifier_set_behavior(BEHAVIOR* b); 
      virtual void  init();

      INTEGRATION_RESULT*  integrate( MAT_DATA&        mdat,
                                      const  VECTOR&   delta_grad,
                                      MATRIX*&         tg_matrix,
                                      int              flags_in       );

      DERIVED;
};
Z_END_NAMESPACE;

#endif
