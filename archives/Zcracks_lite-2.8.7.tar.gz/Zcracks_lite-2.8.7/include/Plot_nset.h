#ifndef __PLOT_NSET__
#define __PLOT_NSET__

#include <Error_messager.h>

#include <Graphics_application.h>

#include <Utility_mesh.h>
#include <Utility_results_database.h>

#include <Post_computation.h>
#include <Local_post_computation.h>

#include <Dao_geom.h>
#include <Plot_set.h>

Z_START_NAMESPACE;

class UTILITY_NODE;

ZCLASS2 PLOT_NSET  : public PLOT_SET {
   protected :
     STRING liset_name;
     LIST<double>  use_maps;
     ARRAY<MATRIX> liset_data;
     LIST<UTILITY_NODE*> use_nodes;
     void get_results();
     VECTOR chord;

     LIST<STRING> local_fields;
     LIST<STRING> integ;
     LIST<STRING> nodal;
     int  u1_index, u2_index, u3_index;

     bool do_a_post(UTILITY_NODE* node, int type, STRING& comp);

   public :
     PLOT_NSET();
     virtual ~PLOT_NSET();

     virtual void initialize(ASCII_FILE& file);
     virtual void write(Zofstream& out);
     virtual bool verification(bool issue_warning=TRUE);
     virtual MODIFY_INFO_RECORD* get_modify_info_record();
     virtual void reset();

     virtual bool do_command(STRING str);
     virtual void get_values(ARRAY<MATRIX>& data, ARRAY<int>& index);
     virtual void add_curve_names(LIST<STRING>& names_for_legend);

     virtual void refresh();
};
Z_END_NAMESPACE;

#endif
