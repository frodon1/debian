#ifndef __MESH_ACTOR__
#define __MESH_ACTOR__

#include <Stringpp.h>
#include <ZP_stack.h>
#include <Graphics_area.h>

Z_START_NAMESPACE;

class ZP_MESH_ACTOR;
class MESH_ACTOR;

ZCLASS2 MESH_ACTOR_2ND_DRAW : public GRAPHICS_OBJECT
{
  public :
   MESH_ACTOR* its_boss;
   MESH_ACTOR_2ND_DRAW(MESH_ACTOR* boss) { its_boss = boss; }

   virtual void local_draw(GRAPHICS_AREA* ga);
};

ZCLASS2 MESH_ACTOR : public GRAPHICS_OBJECT
{
  friend class ZP_MESH_ACTOR;
  friend class MESH_ACTOR_2ND_DRAW;
  protected :
    MESH_ACTOR_2ND_DRAW its_2nd_draw;
    LIST<STRING> view_bset,view_nset,view_eset;
    int highlight_node,highlight_elem;
    int mesh_for_highlight_node;
    int mesh_for_highlight_elem;

    virtual void local_draw(GRAPHICS_AREA* ga);
    virtual void local_draw_second(GRAPHICS_AREA* ga);

    ZP_FATAL_ERROR* apply_options(ZP_STACK&);

    void show_ip_numbers(GRAPHICS_AREA* ga);
    void show_nset_names(GRAPHICS_AREA* ga);
    void show_faset_names(GRAPHICS_AREA* ga);
    void show_elset_names(GRAPHICS_AREA* ga);
    void show_element_axis(GRAPHICS_AREA* ga);

  public :
    enum VIEW_MODE { HIDDEN_FACES=0 , RENDERED=1 , SURFACE_EDGES=2 , ALL_EDGES=3 };
    enum OPTION_MODE { FACE_EDGES=1 , DEFORMED=2 };
    enum NSET_MODE { NSET_NUMBER=1 , NSET_ARROW=2 , NSET_NAME=4 };
    enum BSET_MODE { BSET_NUMBER=1 , BSET_ARROW=2 , BSET_NAME=4 , BSET_NORMAL=8 };
    enum ESET_MODE { ESET_ORDER=1 , ESET_NAME=2 , ESET_AXIS=4 };
    
    VIEW_MODE view_mode;
    OPTION_MODE option;
    NSET_MODE nset_option;
    BSET_MODE bset_option;
    ESET_MODE eset_option;

    MESH_ACTOR();
    virtual ~MESH_ACTOR();

    virtual ZP_FATAL_ERROR* enable(ZP_STACK&);
    virtual ZP_FATAL_ERROR* disable(ZP_STACK&);

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
    ZP_FATAL_ERROR* _highlight_elem(ZP_STACK&,int*);
};
Z_END_NAMESPACE;

#endif
