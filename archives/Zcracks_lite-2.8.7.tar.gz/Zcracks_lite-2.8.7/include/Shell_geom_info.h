#ifndef __SHELL_GEOM_INFO__
#define __SHELL_GEOM_INFO__

#include <File.h>
#include <Geometry_info.h>
#include <Defines.h>
#include <Utility_mesh.h>
#include <Utility_elements.h>
#include <Zstream.h>

#include <Graphics_command.h>
#include <Graphics_data_dialog.h>

Z_START_NAMESPACE;

class REF_GAUSS_POINT;
class MESH_INFO_READER;
class UTILITY_ELSET;
class UTILITY_MESH;

class SHELL_GEOM_INFO : public GEOMETRY_INFO,
                        public GRAPHICS_COMMAND {
  protected :
    GRAPHICS_DATA_DIALOG *its_dialog;
    STRING current_elset_name;
    MESH_INFO_READER *current_mr;
    UTILITY_ELSET *current_elset;

  public :
    int nb_layer;
    int nb_layer_gauss;
    ARRAY<double> thickness;
    UTILITY_MESH* its_mesh;

    SHELL_GEOM_INFO() : GEOMETRY_INFO() { 
      nb_layer=1; 
      thickness.resize(1); 
      thickness[0]=1.; 
      thickness.resize(1); thickness[0]=1.; 
      nb_layer_gauss=-1; 
      its_mesh=NULL;
      its_dialog=NULL;
    }

    virtual ~SHELL_GEOM_INFO() { }

    virtual void initialize(ASCII_FILE&);
    virtual void mesh_loaded(UTILITY_MESH*);

    virtual void write(Zofstream&);
    virtual void read(Zifstream&);
 
    virtual void click(MESH_INFO_READER&,STRING&,UTILITY_ELSET*);

    virtual bool do_command(STRING);

    virtual void build_ipset();


    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
