#ifndef __Ext_simulation_item__
#define __Ext_simulation_item__

#include <Stringpp.h>
#include <Buffered_list.h>
#include <Vector.h>
#include <Simulation_item.h>
#include <Plot_item.h>

Z_START_NAMESPACE;

class EXT_SIMULATION_ITEM : public SIMULATION_ITEM {
  public :
    STRING commands;
    STRING finput,foutput;

    EXT_SIMULATION_ITEM();
    EXT_SIMULATION_ITEM(const EXT_SIMULATION_ITEM&);
   ~EXT_SIMULATION_ITEM();
   
    virtual SIMULATION_ITEM* copy_self_with_prefix(const STRING& prefix);
    virtual bool write(Zofstream& out);
    virtual void read(ASCII_FILE&);
    virtual void run_simulation();
    virtual void write_shell_commands(Zofstream& inp);
    virtual STRING get_output_fname(const STRING& prefix);
    virtual bool fill_plot_item(const STRING& prefix,PLOT_ITEM*);
    virtual void write_inp();
    virtual void write_inp(SIMULATION_ITEM*);

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
