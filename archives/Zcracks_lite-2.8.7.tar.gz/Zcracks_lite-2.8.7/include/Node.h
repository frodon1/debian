#ifndef __Node__
#define __Node__

#include <List.h>
#include <Vector.h>

#include <Dof.h>
#include <GNode.h>
#include <When.h>
#include <External_parameter.h>
#include <Special_vector.h>

Z_START_NAMESPACE;

class GMESH; class MESH; class ELEMENT; class LOCAL_FRAME; 

ZCLASS2 NODE : public GNODE {
  protected :
        const MESH* mesh;      // pointer of the mesh which did create the node 
        ARRAY<DOF_NODE*> dof;  // list of dof's attached to the node;
        
  public :
        AUTO_PTR<EXTERNAL_PARAMETER_VECTOR> external_param_set;      // at time ti
        AUTO_PTR<EXTERNAL_PARAMETER_VECTOR> external_param_set_ini;  // the external param values at nodes at time t
        AUTO_PTR<EXTERNAL_PARAMETER_VECTOR> external_param_set0;     // the external param values at nodes at time t=0 

        NODE() { mesh=NULL; }
        NODE(int,const VECTOR&);
        virtual ~NODE(); // node destructor 

        void init_dof_array(const ARRAY<DOF_NODE*>&);
        void init_dof_array(const LIST<DOF_NODE*>&);

        int nb_dof() const { return !dof; }
        DOF_NODE* get_dof(int i) { return dof[i]; }
        const DOF_NODE* get_dof(int i)const { return dof[i]; }
        DOF_NODE* get_dof(DOF_TYPE *type);            // return the dof pointer, selected by its type
        const DOF_NODE* get_dof(DOF_TYPE *type)const; // return the dof pointer, selected by its type
        ARRAY<DOF_TYPE*> get_dof_type()const;    //
        double d_dof_iter(DOF_TYPE *type)const;  // value of the increment of the dof in the iteration
        double d_dof_incr(DOF_TYPE *type)const;  // value of the increment of the dof 
						     // from the beginning of the load increment
        double d_dof_tot(DOF_TYPE *type)const;   // total dof variation from the beginning of the calculation
        double dof_value(DOF_TYPE *type)const;   // dof value = total dof variation from 
                                                     // the beginning of the calculation
                                                     // + initial value of the dof
        
        double dof_initial_value(DOF_TYPE *type)const; // initial value of the dof
        int    if_fixed(DOF_TYPE *type)const;    // a non zero value for if_fixed corresponds
						     // to a dof with pressurecribed value
        double fixed(DOF_TYPE *type)const;       // value of this prescribed quantity
        void add_fixed_dof(DOF_TYPE *type,double val);   // increment the prescribed value for a dof; 
					                     // the value and the type are provided
        void set_fixed_dof(DOF_TYPE *type,double val);   // fix the prescribed value for a dof; 
						             // the value and the type are provided
        void add_reac_to_dof(DOF_TYPE *type,double val); // increment the force associated to the dof, 
							     // indexed by its name
	void incr_internal_reac(const DOF_TYPE* type,double val);
        VECTOR get_coordw(WHEN) const;                       // w is necessary otherwise
        double get_coordw(WHEN,int,bool issue_error=true) const;                   // conflict with GNODE::get_coord
        void   set_position(WHEN);

        friend void make_VECTOR(const NODE&,const NODE&,VECTOR&,WHEN);

        RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
