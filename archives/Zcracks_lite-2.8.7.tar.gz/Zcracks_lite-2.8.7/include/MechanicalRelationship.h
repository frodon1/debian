#ifndef __MechanicalRelationship__
#define __MechanicalRelationship__

#include <string.h>

#include <Array.h>
#include <Error_messager.h>
#include <Defines.h>
#include <File.h>
#include <ZMath.h>
#include <Stringpp.h>

#include <Dof.h>
#include <Mesh.h>
#include <NNset.h>
#include <Node.h>
#include <Relationship.h>
#include <Set.h>

Z_START_NAMESPACE;


class MPC3 : public RELATIONSHIP {
    double angle;   // angle
    STRING name;    // nset name
    NNSET* nset;
    virtual void _set_relationship(MESH&);

  public :
    MPC3();
    virtual void load(ASCII_FILE&);
};


class MPC3B : public RELATIONSHIP {
 protected :
    STRING          name1, name2; 
    NNSET           *nset1, *nset2;
    ARRAY<DOF_TYPE*> udof;
    double          phi;
    bool            inversion;
    virtual void _set_relationship(MESH&);

  public :
    MPC3B();
    void load(ASCII_FILE&);
};


class MPC4 : public RELATIONSHIP {
  protected :
    double if_in_toler; 
    int   allow_null_set; 
    bool  updated; 
    NNSET* nset;    
    BOUNDARYSET* boundaryset;
    VECTOR Delta;

    STRING nset_name; 
    STRING bset_name; 

    bool find_node_location(NODE* node, 
                            ARRAY<double>& shape_coef, 
                            ARRAY<NODE*>& master_node, 
                            VECTOR *delta=NULL);
 
    void _set_relationship(MESH&);

  public :
    MPC4();
    virtual void load(ASCII_FILE&);
};


class MPC5 : public RELATIONSHIP {
  protected:
    NNSET* nset;
    ARRAY<double> eta;
    ARRAY<NODE*> nodes; 
    NODE *n1, *n2;
    STRING nset_name;
    virtual void _set_relationship(MESH&);

  public :
    MPC5();
    virtual void load(ASCII_FILE&);
};

Z_END_NAMESPACE;

#endif

