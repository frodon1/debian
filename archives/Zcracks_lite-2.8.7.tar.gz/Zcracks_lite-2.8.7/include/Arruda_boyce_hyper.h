#ifndef __Arruda_boyce_hyper__
#define __Arruda_boyce_hyper__

#include <Behavior.h>
#include <Integration_result.h>
#include <Mechanical_behavior.h>
#include <Hyperelastic_behavior.h>
#include <Swap.h>

Z_START_NAMESPACE;

ZCLASS ARRUDA_BOYCE_HYPER_LAW : public HYPERELASTIC_LAW {
  protected :
      double        Jel;
      int           full_output; 
      TENSOR2_VAUX  E, V, X;
      TENSOR2_VAUX  sig_keep;
      SCALAR_VAUX   U; 

      TENSOR2      pk2_0;

      bool save_princ_strain;
      COEFF mu, lambda_m, D; 

      virtual void verif_read();
      VECTOR   C; 
      TENSOR2  tau,s; 
      double   p; 
      SMATRIX  M,H; 
      TENSOR4  C_star;
      SMATRIX  C11, C22; 
      TENSOR2  one; 
      SMATRIX  ONE; 
      SMATRIX  UNIT; 
      SMATRIX  UNITx; 
      double   dU_dI1,d2U_dI12; 
      int      pull_back; 
      bool     modify_for_jaumann;

      TENSOR2  Fb, Fbt;
      TENSOR2  B, dI1_dD;
      double   I1, J, J1_3;

      double   term1, term2;

      double   d2U_dJ2;

      int exit_early_flag; 
      TENSOR4  T, T_1; 
      TENSOR4  dFb_dF; 
      MATRIX   dB_dFb; 
      MATRIX   dB_dF; 
      TENSOR2  dI1_dF; 

  public :
      ARRUDA_BOYCE_HYPER_LAW();
      virtual ~ARRUDA_BOYCE_HYPER_LAW();

      virtual void initialize(ASCII_FILE&,MATERIAL_PIECE*);
      virtual int base_read(const STRING&,ASCII_FILE&);
      virtual void setup(int& flux_pos, int& grad_pos, int& vi_pos, int& va_pos); 
      virtual bool calc_coef();
      virtual INTEGRATION_RESULT* integrate(const  VECTOR& delta_grad, int flags);
      virtual INTEGRATION_RESULT* integrate_using_be(TENSOR2& B, int flags); 

      TENSOR2& give_pk2_0() { return pk2_0; }

      virtual BEHAVIOR::STRESS_MEASURE get_stress_measure() const;

      virtual TENSOR2    calc_sig_only(TENSOR2& Be); 
      virtual TENSOR2    guess_be(TENSOR2& Be, TENSOR2& sigx, bool j_part_only); 
 
      virtual double     strain_energy();

      virtual INTEGRATION_RESULT* integrate_tg_dsig_dF(const VECTOR& delta_grad, int flags);
};
Z_END_NAMESPACE;

#endif
