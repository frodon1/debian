#ifndef __Plot_item__
#define __Plot_item__

#include <Stringpp.h>
#include <Vector.h>
#include <Matrix.h>
#include <Array.h>
#include <File.h>
#include <Circular_list.h>

Z_START_NAMESPACE;

class EXP_ITEM;

class PLOT_INFO {
  public :
    bool x_log_scale, y_log_scale, no_zero, no_line, option, active;
    int x_ticks, y_ticks;
    double x_min, x_max, y_min, y_max;

    PLOT_INFO();
    PLOT_INFO(const PLOT_INFO&);
    ~PLOT_INFO();
};

class PLOT_ITEM {
  public :
    bool no_zero,no_line,x_log_scale,y_log_scale;
    int sz_history,last_run;
    STRING name;
    STRING xname;
    STRING y_label;
    LIST<STRING> yname;
    LIST<STRING> reference;
    CIRCULAR_LIST<MATRIX> values;
    CIRCULAR_LIST<bool>   draw_line;
    PLOT_INFO* plot_info;

    PLOT_ITEM();
    PLOT_ITEM(const PLOT_ITEM&);
   ~PLOT_ITEM();

    void write(Zofstream& out);
    bool read(ASCII_FILE& file);
    bool get_values_from_test(const STRING& name);
    bool get_values_from_exp(EXP_ITEM*);
    bool get_values_from_file(const STRING& fname,int xcol,int ycol);
   
};
Z_END_NAMESPACE;

#endif
