#ifndef __ZP_SMATRIX__
#define __ZP_SMATRIX__

#include <ZP_stack.h>
#include <Matrix.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>

Z_START_NAMESPACE;

ZCLASS ZP_SMATRIX : public ZP_BASIC_TYPE< SMATRIX >
{
  protected :
    ZP_FATAL_ERROR* plus(ZP_STACK&,int);
    ZP_FATAL_ERROR* par(ZP_STACK&,int);
    ZP_FATAL_ERROR* minus(ZP_STACK&,int);
    ZP_FATAL_ERROR* times(ZP_STACK&,int);
    ZP_FATAL_ERROR* assign(ZP_STACK&,int);
    ZP_FATAL_ERROR* transpose(ZP_STACK&,int);
    ZP_FATAL_ERROR* inverse(ZP_STACK&,int);
    ZP_FATAL_ERROR* resize(ZP_STACK&,int);
    virtual ZP_FATAL_ERROR* print(ZP_STACK&,int);

    virtual void type_init(char*) { type="SMATRIX"; }

  public :
    BASIC_CONSTRUCTORS(ZP_SMATRIX,SMATRIX)

    METHOD_DECLARATION_START
      METHOD("=",assign,1)
      METHOD("()",par,2)
      METHOD("+",plus,1)
      METHOD("-",minus,1)
      METHOD("*",times,1)
      METHOD("transpose",transpose,0)
      METHOD("inverse",inverse,0)
      METHOD("resize",resize,1)
    METHOD_DECLARATION_ANCESTOR(ZP_BASIC_TYPE< SMATRIX >)

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);

    ZPO_RTTI_INFO(SMATRIX)
};
Z_END_NAMESPACE;

#endif
