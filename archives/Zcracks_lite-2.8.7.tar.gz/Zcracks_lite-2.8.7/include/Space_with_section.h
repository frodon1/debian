#ifndef __Space_with_section__
#define __Space_with_section__

#include <ZMath.h>
#include <List.h>
#include <Defines.h>
#include <ZMath.h>

#include <Geometry.h>
#include <GeomSpace.h>

#include <Hyper_plane_space.h>
#include <Integration.h>
#include <Interpolation.h>
#include <Ref_Gauss_point.h>
#include <GMesh.h>

Z_START_NAMESPACE;

class VECTOR; class BEHAVIOR; class STRING; class BOUNDARY; class GNODE; class GMESH;
class INTERPOLATION_FUNCTION;

ZCLASS2 SPACE_WITH_SECTION : public GEOMETRY {
  protected :
     SMATRIX           jacobian_matrix; 
     SMATRIX           Fmatrix;

     int       section_element; 
     int       section_gp; 
     int       gp_id;

     MATRIX    coord_elem_section;

  public :
     GEOMETRICAL_MESH* section;
     HPSPACE*     ref_line;    // stored/deleted in this class 
     int       ref_current_ip;

     SPACE_WITH_SECTION(); 
     virtual ~SPACE_WITH_SECTION();

     void set_section(GEOMETRICAL_MESH* s) { section=s; }
     void symmetric_gradient_operator(MATRIX& b)const;
     void get_position_of_integration_point_in_section(VECTOR&)const;
     virtual double jacob(const MATRIX& elem_coord);
     virtual double jacob2(SMATRIX&,const MATRIX&);

     virtual void symmetric_gradient_operator(const MATRIX& dshape_dx, MATRIX& b)const;
     virtual void computeQ(TENSOR2&)=0;
   
     virtual void make_integration(const char* integ_type);

     virtual void start(const MATRIX& elem_coord);
     virtual void start() const;
     virtual void next(const MATRIX& elem_coord);
     virtual void next()const;
     virtual int  ok() const;

     virtual void start_in_ref();
     virtual int  ok_in_ref()const;
     virtual void next_in_ref();
     virtual int nb_gp_tot() const;
     int nb_gp_in_section() const { return section->nb_gp(); }
     int nb_elset_in_section()const { return section->nb_elset(); }

     virtual const VECTOR& shape() const; 
     virtual const MATRIX& deriv() const;
     virtual const double& volum() const;

     virtual void integrate(const double& x, double& tot)const;
     virtual void integrate(const VECTOR& v, VECTOR& tot)const;
     virtual void integrate(const MATRIX& m, MATRIX& tot)const;

     RTTI_INFO;
};


ZCLASS2 SPACEWSECTAXI : public SPACE_WITH_SECTION {
 public :
    SPACEWSECTAXI(); 
    virtual ~SPACEWSECTAXI();

    virtual void initialize_geometry(int num_nodes,int num_gauss_pts,
           GEOM_TYPE, SPACE_TYPE,
           const INTERPOLATION_FUNCTION* const,
           const ARRAY<double>& real_constants);  

    BOUNDARY* create_associated_boundary(const ARRAY<GNODE*>&,GMESH*,ELEMENT*)const;
    double radius()const; 
    virtual void compute_dshape_dx(const MATRIX& em, MATRIX& dshape_dx);
    virtual double jacob2(SMATRIX& jm, const MATRIX& elem_coord);
    virtual void computeQ(TENSOR2&);
    RTTI_INFO;
};
 
ZCLASS2 SPACEWSECT3D : public SPACE_WITH_SECTION {
 public :
    VECTOR t1,t2,n;

    SPACEWSECT3D(); 
    virtual ~SPACEWSECT3D();

    virtual void initialize_geometry(int num_nodes,int num_gauss_pts,
           GEOM_TYPE, SPACE_TYPE,
           const INTERPOLATION_FUNCTION* const,
           const ARRAY<double>& real_constants);  

    BOUNDARY* create_associated_boundary(const ARRAY<GNODE*>&,GMESH*,ELEMENT*)const;
    virtual void compute_dshape_dx(const MATRIX& em, MATRIX& dshape_dx);
    virtual double jacob2(SMATRIX& jm, const MATRIX& elem_coord);
    virtual void computeQ(TENSOR2&);
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
