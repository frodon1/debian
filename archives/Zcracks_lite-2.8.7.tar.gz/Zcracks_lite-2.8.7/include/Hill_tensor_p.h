#ifndef __HillTensorP__
#define __HillTensorP__

#include <ZMath.h>
#include <Matrix.h>
#include <Tensor4.h>

Z_START_NAMESPACE;

ZCLASS HILLTENSORP : public TENSOR4 {
  public :
    HILLTENSORP();
    virtual ~HILLTENSORP();

    virtual void evaluate(const TENSOR4& L,
                          const int npoints, const int sz);

    virtual void add_ijkl_to_ij(const double value,
  		          const int i, const int j,
			  const int k, const int l);

    HILLTENSORP& operator=(const HILLTENSORP& hill) { return (HILLTENSORP&)SMATRIX::operator=((SMATRIX&)hill); }
    HILLTENSORP& operator=(const TENSOR4& hill) { return (HILLTENSORP&)TENSOR4::operator=(hill); }
    HILLTENSORP& operator=(const SMATRIX& hill) { return (HILLTENSORP&)SMATRIX::operator=(hill); }
    HILLTENSORP& operator=(const double& val) { return (HILLTENSORP&)TENSOR4::operator=(val); }

};
Z_END_NAMESPACE;

#endif
