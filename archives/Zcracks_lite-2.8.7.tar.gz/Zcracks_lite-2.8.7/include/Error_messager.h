#ifndef __Error_messager__
#define __Error_messager__

#ifdef _WIN32
  #include <Windows.h>
#endif

#include <Defines.h>
#include <Stringpp.h>

#ifdef ERROR 
  #undef ERROR
#endif 

// 
// These are the exceptions which can be thrown from the 
// basic parts of the program.  All Zebulon exceptions should
// derive from Z7_MAIN_ERROR. 
// 

#ifdef ZEXCEPTIONS
  #include <exception>
#endif

Z_START_NAMESPACE;

class ASCII_FILE; 

#ifdef ZEXCEPTIONS

  class Z7_MAIN_ERROR : public std::exception { 
    public :
      int line;
      STRING file,error;
 
      Z7_MAIN_ERROR() throw() : std::exception() { line=-1; }
      Z7_MAIN_ERROR(int li, const char *fi, const char *err) throw() : std::exception() { line=li; file=fi; error=err; }
      Z7_MAIN_ERROR(const char *err) throw() : std::exception() { line=-1; error=err; }
      virtual ~Z7_MAIN_ERROR() throw() { }
  }; 

  class Z7_CRITICAL_ERROR : public Z7_MAIN_ERROR { 
    public :
      Z7_CRITICAL_ERROR(int li, const char *fi, const char *err) throw() : Z7_MAIN_ERROR(li,fi,err) { }
  };

  class Z7_MATH_ERROR   : public Z7_MAIN_ERROR { 
    public :
      Z7_MATH_ERROR(int li, const char *fi, const char *err) throw() : Z7_MAIN_ERROR(li,fi,err) { }
  };

  class Z7_IO_ERROR     : public Z7_MAIN_ERROR { 
    public :
      Z7_IO_ERROR(int li, const char *fi, const char *err) throw() : Z7_MAIN_ERROR(li,fi,err) { }
  };

  class Z7_READ_ITEM_ERROR : public Z7_MAIN_ERROR { 
    public :
      Z7_READ_ITEM_ERROR(int li, const char *fi, const char *err) throw() : Z7_MAIN_ERROR(li,fi,err) { }
  };

  class Z7_CLASS_ERROR : public Z7_MAIN_ERROR { 
    public :
      STRING class_name;
      Z7_CLASS_ERROR(const char *cn, int li, const char *fi, const char *err) throw() : Z7_MAIN_ERROR(li,fi,err) { class_name=cn; }
      virtual ~Z7_CLASS_ERROR() throw() { }
  };

#endif

template<class T> class  BUFF_LIST;

ZCLASS ERROR_MESSAGER { 
  public :
    static BUFF_LIST<STRING> only_once;

    static void EXIT(); 
#ifdef ZEXCEPTIONS
    virtual void  do_EXIT() throw();
#else
    virtual void  do_EXIT(); 
#endif

    virtual void  err_message(STRING cname, STRING err, const char* fle, int ln);
    virtual void  err_message(STRING err, const char* fle, int ln);
    virtual void  err_message(STRING err);
    virtual void  input_error(STRING str);
    virtual void  not_implemented_error(STRING err, const char* fle, int ln);
    virtual void  critical(STRING err);
    virtual void  message(STRING msg);
    virtual void  alert(STRING msg);
    virtual void  alert_once(STRING msg);
    virtual void  alert_once(STRING base, STRING rem);
    virtual void  help_message(STRING msg);

    typedef ERROR_MESSAGER* (*f_ERROR_MESSAGER)();
    static f_ERROR_MESSAGER active_error_messager;

    ERROR_MESSAGER(); 
    virtual ~ERROR_MESSAGER(); 

    static void  reassign_error_messager(ERROR_MESSAGER* mess); 
    static void  static_err_message(STRING cname, STRING err, const char* fle, int ln);
    static void  static_err_message(STRING err, const char* fle, int ln);
    static void  static_err_message(STRING err);

    static void  STATIC_INPUT_ERROR(STRING str,const char*,int);
    static void  STATIC_NOT_IMPLEMENTED_ERROR(STRING err, const char* fle, int ln);
    static void  STATIC_CRITICAL(STRING,const char*,int);
    static void  STATIC_INTERNAL(STRING,const char*,int);
    static void  STATIC_MESSAGE(STRING msg);
    static void  STATIC_ALERT(STRING msg);
    static void  STATIC_ALERT_ONCE(STRING msg);
    static void  STATIC_ALERT_ONCE(STRING base, STRING rem);
    static void  STATIC_HELP_MESSAGE(STRING msg);

   static void  STATIC_UNKNOWN_ERROR(STRING cl_name,
                                     STRING cmd, 
                                     STRING type, 
                                     const char* fle, int ln);
}; 

// 
// Some conflicts with this... 
// 
#include <Zerror.h>


#ifndef DONT_ALLOW_ERROR 
#define MESSAGE(a)               ERROR_MESSAGER::STATIC_MESSAGE(STRING::EMPTY+a)
// #define ERROR(a)                 ERROR_MESSAGER::static_err_message(STRING::EMPTY+a,__FILE__, __LINE__) 
#endif

#define ERROR2(a,b)              ERROR_MESSAGER::static_err_message(a, STRING::EMPTY+\
                                      b,__FILE__, __LINE__) 

#define INPUT_ERROR(a)           ERROR_MESSAGER::STATIC_INPUT_ERROR(STRING::EMPTY+\
                                      a,__FILE__, __LINE__)

#define NOT_IMPLEMENTED_ERROR(a) ERROR_MESSAGER::STATIC_NOT_IMPLEMENTED_ERROR(STRING::EMPTY+\
                                      a,__FILE__, __LINE__)

#define ZO_NOT_IMPLEMENTED_ERROR(a) { STRING _msg,_ff; _ff=h_file(); hierarchy(_msg); _msg="\n    (Object type is: "+_msg+" from file: "+_ff+")"; ERROR_MESSAGER::STATIC_NOT_IMPLEMENTED_ERROR(STRING::EMPTY+a+" "+_msg,__FILE__, __LINE__); }

#define CRITICAL(a)              ERROR_MESSAGER::STATIC_CRITICAL(STRING::EMPTY+\
                                      a,__FILE__, __LINE__)

#define INTERNAL_ERROR           ERROR_MESSAGER::static_err_message(STRING::EMPTY+\
                                      "Internal error, please contact a ZSet developer",__FILE__, __LINE__)

#define INTERNAL(a)              ERROR_MESSAGER::STATIC_INTERNAL(STRING::EMPTY+\
                                      a,__FILE__, __LINE__)

#define ZMESSAGE(a)              ERROR_MESSAGER::STATIC_MESSAGE(STRING::EMPTY+a)

#define NUMBERED_MESSAGE(a)      ERROR_MESSAGER::STATIC_MESSAGE(STRING::EMPTY+\
                                      a+" at "+__FILE__+":"+itoa(__LINE__)+".")

#define ALERT_USER(a)            ERROR_MESSAGER::STATIC_ALERT(STRING::EMPTY+\
                                      a)

#define ALERT_USER_ONCE(a)       ERROR_MESSAGER::STATIC_ALERT_ONCE(STRING::EMPTY+\
                                      a)

#define ALERT_USER_ONCE2(a,b)    ERROR_MESSAGER::STATIC_ALERT_ONCE(a,b)

#define NUMBERED_ALERT_USER(a)   ERROR_MESSAGER::STATIC_ALERT(STRING::EMPTY+\
                                      a+" at "+__FILE__+":"+itoa(__LINE__)+".")

#define HELP_MESSAGE(a)          ERROR_MESSAGER::STATIC_HELP_MESSAGE(STRING::EMPTY+\
                                      a)

#define ZBAD(a)                  ERROR_MESSAGER::STATIC_INPUT_ERROR(STRING::EMPTY+\
                                      "Trouble reading: "+a,__FILE__, __LINE__); 

// 
// if (kine==NULL) UNKNOWN_OBJECT("DIRECT_KINEMATIC", "*kinematic", type)
// 
#define UNKNOWN_OBJECT(a, b, c)  ERROR_MESSAGER::STATIC_UNKNOWN_ERROR(STRING::EMPTY+a,\
                                      STRING::EMPTY+b, STRING::EMPTY+c, __FILE__, __LINE__); 

#define UNKNOWN_COMMAND(a)       ERROR_MESSAGER::STATIC_INPUT_ERROR(STRING::EMPTY+\
                                      "Unknown command: "+a,__FILE__, __LINE__); 

#define UNKNOWN_COEF(a)          ERROR_MESSAGER::STATIC_INPUT_ERROR(STRING::EMPTY+\
                                      "Unknown coefficient: "+a,__FILE__, __LINE__); 

#define STR_REQ(a,f)             ERROR_MESSAGER::STATIC_INPUT_ERROR(STRING::EMPTY+\
                                      "string data expected: "+a+", string read: "+GLSTR(f),\
                                      __FILE__, __LINE__); 

#define KEY_REQ(a,f)             ERROR_MESSAGER::STATIC_INPUT_ERROR(STRING::EMPTY+\
                                      "keyword expected: "+a+", string read: "+GLSTR(f),\
                                      __FILE__, __LINE__); 

#define DBL_REQ(a,f)             ERROR_MESSAGER::STATIC_INPUT_ERROR(STRING::EMPTY+\
                                      "double required for "+a+", string read: "+GLSTR(f),\
                                      __FILE__, __LINE__); 

#define INT_REQ(a,f)             ERROR_MESSAGER::STATIC_INPUT_ERROR(STRING::EMPTY+\
                                      "int required for "+a+", string read: "+GLSTR(f),\
                                      __FILE__, __LINE__); 

#define VEC_REQ(a,f)             ERROR_MESSAGER::STATIC_INPUT_ERROR(STRING::EMPTY+\
                                      "vector required for "+a+", string read: "+GLSTR(f),\
                                      __FILE__, __LINE__); 

WIN_THINGIE STRING GLSTR(ASCII_FILE&);

#define NEW_LINE STRING("\n")
Z_END_NAMESPACE;

#endif
