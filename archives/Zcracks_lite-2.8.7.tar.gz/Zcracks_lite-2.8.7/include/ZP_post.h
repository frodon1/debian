#ifndef __ZP_POST__
#define __ZP_POST__

#include <Post_processing.h>

Z_START_NAMESPACE;

extern POST_COMPUTATION *The_active_post_processing;
Z_END_NAMESPACE;

#endif
