#ifndef __END_OF_ZSET__
#define __END_OF_ZSET__

Z_START_NAMESPACE;

//
// FF, dec 8th, 2008 : a small helper class to be called at the end of Zset, to do
// anything usefull at this stage.
// One could also use a static object for this purpose, but it's not clear when the
// static destructor will be called.
//

class END_OF_ZSET
{
  public :
    END_OF_ZSET() { }
    virtual ~END_OF_ZSET() { }

    virtual void end() { }
};
Z_END_NAMESPACE;

#endif
