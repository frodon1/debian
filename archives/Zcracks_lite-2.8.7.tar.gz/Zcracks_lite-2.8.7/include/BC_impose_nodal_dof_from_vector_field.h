#ifndef __BC_IMPOSE_NODAL_DOF_FROM_VECTOR_FIELD__
#define __BC_IMPOSE_NODAL_DOF_FROM_VECTOR_FIELD__

#include <Boundary_condition.h>
#include <Set.h>
#include <Clock.h>
#include <Node.h>
#include <Mesh.h>
#include <Print.h>
#include <Vector_field.h>

Z_START_NAMESPACE;


// A base class (abstract) for BCs that depend on external data (stored in a VECTOR_FIELD object)
// 
//       In a ****weak_coupling, it derives to BC_IMPOSE_NODAL_DOF_FROM_TRANSFER & BC_IMPOSE_NODAL_DOF_REACTION_FROM_TRANSFER
//       In an MpCCI weak coupling, it derives to BC_IMPOSE_NODAL_DOF_FROM_EXTERNAL_FIELD
//       There's also BC_IMPOSE_NODAL_DOF_FROM_FUNCTION and BC_IMPOSE_NODAL_DOF_FROM_FILE
// This base class provides a general _update() method, and relies on its daughters to read the data (e.g. from a file in the 1st case, a CCI_Recv in the second, a function in the 3rd)
// 
// JDG, sep 2005, modif jul 2006



class BC_IMPOSE_NODAL_DOF_FROM_VECTOR_FIELD : public BC
{
protected:
  STRING nset_name; 
  bool reaction;
  LIST<STRING> dof_names;
  LIST<DOF_TYPE*> dof_types;

  double initial_extime, final_extime;           // initial and final external times ...
  VECTOR_FIELD initial_field , final_field ;     // ... and fields
  
  virtual bool GetResponse(STRING&, ASCII_FILE&);
  virtual bool get_values(MESH&) =0;    // has to set initial_extime, final_extime and initial_field , final_field ; returns FALSE if no values available
  virtual bool verification();
  virtual void _update(MESH&);   // you shouldn't need to redefine this one in daughter classes
                                 // in fact, you need to if you have some specific initializations which depends on the mesh

public:
  BC_IMPOSE_NODAL_DOF_FROM_VECTOR_FIELD();
  virtual ~BC_IMPOSE_NODAL_DOF_FROM_VECTOR_FIELD() { } 

  virtual void load(ASCII_FILE&,PROBLEM&,int ipc=0);

  RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
