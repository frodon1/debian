#ifndef __Matrix__
#define __Matrix__

#include <Defines.h>
#include <Assert.h>
#include <Array.h>
#include <Bool.h>
#include <Math_obj.h>
#include <Math_defines.h>
#include <Std_cc_stream.h>

/*
#ifndef __Tensor4__
    #include <Tensor4.h> 
#endif
*/

Z_START_NAMESPACE;

class DMATRIX;
class SMATRIX;
class MATRIX;
class TENSOR1;
class TENSOR2;
class TENSOR3;
class TENSOR4;

// #define MATRIX_ALIGN_AS_FORTRAN

//
// General matrix object.
// Matrices are  n x m in size.. that is n is row and m is col.
//

ZCLASS MATRIX : public MATH_OBJECT {
       friend class VECTOR;
       friend class TENSOR2;
       friend class DMATRIX;
       friend class SMATRIX;

       void swap_ptr(double**&)const;
        
  public :
       static double** nexthdl;
       static double*  nextptr;

  protected :

       int      _n;        
       int      _m;       

       double   *mat_zero;
       double   **mat;

       void init_ptr();
       void remove_ptr();

   public:

      enum    LC       { _LINE_, _COLUMN_, _DIAGONAL_ };

      const   int&     n;  // number of rows
      const   int&     m;  // number of columns

      double** dangerous_give_mat()const  { return mat; } 

      MATRIX();

      MATRIX(int nn, int mm);
      MATRIX(int nn ,int mm, const double* d);
      MATRIX(const MATRIX&);
      MATRIX(const DMATRIX& dm);
      MATRIX(int n,int m, const MATRIX& father,int start_n,int start_m); // sub

      ~MATRIX();

      void resize(const MATRIX &m) { resize(m.n,m.m); }
      void resize(int nn, int mm);
      void resize(int nn) { resize(nn,nn); }
      void reassign(int n, int m,const MATRIX& father, int start_n, int start_m);
      void set(const MATRIX&);

      double* operator()(int line) const { return mat[line]; }
              double&  operator()(int i, int j);
      const   double&  operator()(int i, int j) const;

      int      operator!() const { return m*n; }
      int      size()const       { return m*n; }

      int      operator==(const MATRIX& m);

      MATRIX&  assign(const MATRIX&);
      MATRIX&  assign(const DMATRIX&);

      MATRIX&  operator=(const MATRIX&);
      MATRIX&  operator=(double c);
      MATRIX&  operator=(const DMATRIX&);
      MATRIX& operator=(const TENSOR2&);
      MATRIX& operator=(const VECTOR&);

      MATRIX&  operator += (const MATRIX&);
      MATRIX&  operator -= (const MATRIX&); 
 
      MATRIX&  operator *= (double d);
      MATRIX&  operator /= (double d);

      MATRIX& operator+=(const TENSOR2&);
      MATRIX& operator+=(const VECTOR&);
      MATRIX& operator-=(const TENSOR2&);
      MATRIX& operator-=(const VECTOR&);
      
      MATRIX& add_all_element(double d); 
      MATRIX& add_to_diagonal(double d);


      friend  WIN_THINGIE ZOSTREAM& operator<<(ZOSTREAM&,const MATRIX&);  ///< human readable (matlab/scilab format) output
      //       friend  WIN_THINGIE ZISTREAM& operator>>(ZISTREAM&,MATRIX&);  not implemented for the moment
      void print();

      friend  WIN_THINGIE void  op_times_t(MATRIX&,const MATRIX&,const MATRIX&);

      friend  WIN_THINGIE double  operator|(const MATRIX& A, const MATRIX& B);

      friend  WIN_THINGIE void  op_times(MATRIX&,const MATRIX&,const MATRIX&);
      inline friend WIN_THINGIE MATRIX operator*(const MATRIX& a,const MATRIX& b) { MATRIX r; op_times(r,a,b); r.set_temporary(); return(r); }

      friend  WIN_THINGIE MATRIX  operator*(const MATRIX& a, double d);

      friend  WIN_THINGIE MATRIX  operator*(double d, const MATRIX& a);

      friend  WIN_THINGIE MATRIX  operator/(const MATRIX& A, double d);

      friend  WIN_THINGIE MATRIX  operator+(const MATRIX& A, const MATRIX& B);
      friend  WIN_THINGIE MATRIX  operator-(const MATRIX& A, const MATRIX& B);

      friend  WIN_THINGIE MATRIX  transpose(const MATRIX& mat);
      friend  WIN_THINGIE SMATRIX  expand_out(const SMATRIX& in);
      friend  WIN_THINGIE SMATRIX  expand_in (const SMATRIX& in);

      friend WIN_THINGIE void _read_(MATRIX&,Zfstream&);          ///< binary input
      friend WIN_THINGIE void _write_(const MATRIX&,Zfstream&);   ///< binary output
      friend WIN_THINGIE void _write_(const MATRIX&,Zofstream&);   ///< binary output


      // 
      // If you want to use blas routines, call this to get a ptr  RF 10/20/2000
      // storage of the matrix. for non-subs, if 
      // fortran_align==MATRIX::mat_align_default it just returns mat[0]. 
      // otherwise there is some copying. please don't make your matrix a 
      // sub before returning the pointer.  This routine may allocate the 
      // double* storage. please return it always with dispose_blas_vector
      // 
      static const int mat_align_default; 
      double* vectorize_for_blas(bool fortran_align);  
      void set_from_blas_vector(double* vec, bool fortran_align); 
      void dispose_blas_vector(double* vec); 
      friend WIN_THINGIE double norm(const MATRIX& m);


// SVD stuff (P.G. sept 28 2005) 
// includes hability to invert singular matrices, (should be MoorePenrose pseduo inverse)
// 
      void svd(MATRIX&, DMATRIX&,SMATRIX&)const;
      void biDiag(DMATRIX&,VECTOR&,double&);
      void initialWV(DMATRIX&,SMATRIX&,VECTOR&);
      void svdBackSub( const MATRIX&, const DMATRIX&, const SMATRIX&, const VECTOR&, VECTOR& , double eps=0. , int dimnull=0 )const;
      void svdBackSub( const MATRIX&, const DMATRIX&, const SMATRIX&, const MATRIX&, MATRIX& ,double eps=0. , int dimnull=0 )const;
};

// -----------------------------------
//          SMATRIX : user guide
//
//   tXAX  : computes B = tX * A * X
//   tXAXs : same as tXAX but computes only the upper triangle
//   symmetrize : assumes that the upper triangle is OK
//                and copy it into the lower triangle
//

/// a square matrix
ZCLASS SMATRIX : public MATRIX {
      friend class TENSOR2;
   public :
      SMATRIX();
      SMATRIX(int ni);
      SMATRIX(int ni,const double* x);
      SMATRIX(const SMATRIX& mi);
      SMATRIX(const MATRIX&  mi);
      SMATRIX(int nn, const MATRIX& father, int start_n, int start_m);
 
      void reassign(int nn, MATRIX& father, int start_n, int start_m);

      int      operator==(const SMATRIX& m);
      int      operator==(const MATRIX& m);

      SMATRIX& operator=(const MATRIX& mi);
      SMATRIX& operator=(const SMATRIX& mi);
      SMATRIX& operator=(const TENSOR4& mi);

      SMATRIX& operator=(double c);

      SMATRIX& transpose();
      SMATRIX& add_diagonal(double d) { for(int i=0;i<n;i++) mat[i][i]+=d; return *this; }
      double determin() const;

      SMATRIX& spin(const VECTOR &v); // initialize the SMATRIX so that S*u = v^u

      //  Gauss solvers
      //  These return 1 for ok and 0 for null pivot. if you pass in 
      //  TRUE for error it means *you* will handle the error... the default 
      //  calls ERROR which will stop the program in gauss_solver with an 
      //  unhelpful message... 
      // 
      int gauss_solver(const VECTOR&, VECTOR&,bool error=FALSE)const;
      int back_solve(const VECTOR&,VECTOR& x,bool throw_error)const;
      int gauss_solverX(ARRAY<VECTOR>& b,ARRAY<VECTOR>& x,bool throw_error)const; 
      int cofactor_solve(const VECTOR&,VECTOR& x,bool throw_error)const;

      SMATRIX& inverse();
      SMATRIX& inverse(bool &io);
      SMATRIX& inverse(double &det);

      // 
      // replace current matrix by its inverse, if possible and store determinant in det. 
      // If io is true, launch an error if the matrix is not invertible
      // 
      SMATRIX& inverse(double &det, bool& io);

      SMATRIX&  operator += (const SMATRIX& mi) { return (SMATRIX&)MATRIX::operator+=(mi); }
      SMATRIX&  operator -= (const SMATRIX& mi) { return (SMATRIX&)MATRIX::operator-=(mi); }
      SMATRIX&  operator *= (double d)          { return (SMATRIX&)MATRIX::operator*=(d); }
      SMATRIX&  operator /= (double d)          { return (SMATRIX&)MATRIX::operator/=(d); }

      static const SMATRIX& unity(int n);

      friend WIN_THINGIE SMATRIX& tXAX( const MATRIX& X, const SMATRIX& A, SMATRIX& B);  
      friend WIN_THINGIE SMATRIX& tXAXs(const MATRIX& X, const SMATRIX& A, SMATRIX& B);  

      friend WIN_THINGIE void     symmetrize(SMATRIX& mat);
      static bool      eigen(const SMATRIX& in, VECTOR& vals, SMATRIX& vecs);

      void null_result(SMATRIX &A,int k, int &l, VECTOR &v);
};

inline void eigen(const SMATRIX& in, VECTOR& vals, SMATRIX& vecs)       { SMATRIX::eigen(in,vals,vecs); } 

WIN_THINGIE SMATRIX  inverse(const SMATRIX&, double&);
WIN_THINGIE SMATRIX  inverse(const SMATRIX&);
WIN_THINGIE SMATRIX  inverse(const SMATRIX&, double&,bool&);
WIN_THINGIE SMATRIX  inverse(const SMATRIX&,bool&);

/// A diagonal matrix
ZCLASS DMATRIX : public SMATRIX {
      void set_zeros();
   public :
      DMATRIX();
      DMATRIX(int);
      DMATRIX(const DMATRIX&);
      DMATRIX(const TENSOR2&);
      DMATRIX(int n,const MATRIX& father, int start_n, int start_m);

      void resize(int);

      DMATRIX& inverse();
      DMATRIX& inverse(bool &io);
      DMATRIX& inverse(double &det);
      DMATRIX& inverse(double& det, bool &io);

      double& operator[](int i) { assert(i>=0 && i<n); return mat[i][i]; }
      const double& operator[](int i)const  { assert(i>=0 && i<n); return mat[i][i]; }

      DMATRIX& operator=(const TENSOR2&);
      DMATRIX& operator=(double);
      DMATRIX& operator=(const DMATRIX&);

      friend WIN_THINGIE MATRIX  operator*(const MATRIX& m1,const DMATRIX& m2);
      friend WIN_THINGIE MATRIX  operator*(const DMATRIX& m1,const MATRIX& m2);
      friend WIN_THINGIE DMATRIX operator*(const DMATRIX& m1,const DMATRIX& m2);
      friend WIN_THINGIE DMATRIX operator*(const DMATRIX& m, double d);
      friend WIN_THINGIE DMATRIX operator*(double d, const DMATRIX& m);         // d*m
      friend WIN_THINGIE VECTOR  operator*(const DMATRIX& m, const VECTOR& v); // multiplying
      friend WIN_THINGIE VECTOR  operator*(const VECTOR& v, const DMATRIX& m); // multiplying
      friend WIN_THINGIE SMATRIX operator*(const DMATRIX& m1, const SMATRIX& m2);
      friend WIN_THINGIE SMATRIX operator*(const SMATRIX& m1, const DMATRIX& m2);

      friend WIN_THINGIE DMATRIX inverse(const DMATRIX& m);
      friend WIN_THINGIE DMATRIX inverse(const DMATRIX& m, bool& io);
      friend WIN_THINGIE DMATRIX inverse(const DMATRIX& m, double& d);
      friend WIN_THINGIE DMATRIX inverse(const DMATRIX& m, double& d, bool& io);
};

extern WIN_THINGIE void classic_put_hdl_mat(double** v);
extern WIN_THINGIE void classic_put_ptr_mat(double* v);
extern WIN_THINGIE double** classic_get_hdl_mat();
extern WIN_THINGIE double* classic_get_ptr_mat();


WIN_THINGIE double trace(const SMATRIX&);
WIN_THINGIE SMATRIX  operator*(const SMATRIX&,double);
WIN_THINGIE SMATRIX  operator*(double,const SMATRIX&); 

// The * operator must always return a MATRIX, and not a SMATRIX
// WIN_THINGIE SMATRIX  operator*(const SMATRIX& m1,const MATRIX& m2);
// WIN_THINGIE SMATRIX  operator*(const MATRIX& m1,const SMATRIX& m2);
WIN_THINGIE MATRIX  operator*(const SMATRIX& m1,const MATRIX& m2);
WIN_THINGIE MATRIX  operator*(const MATRIX& m1,const SMATRIX& m2);
WIN_THINGIE SMATRIX  operator*(const SMATRIX& m1,const SMATRIX& m2);
WIN_THINGIE SMATRIX  operator*(const SMATRIX& m,double d);
WIN_THINGIE SMATRIX  operator*(double d,const SMATRIX& m);
WIN_THINGIE SMATRIX  operator/(const SMATRIX& m,double d);
WIN_THINGIE SMATRIX  operator+(const SMATRIX& m1,const SMATRIX& m2);
WIN_THINGIE SMATRIX  operator+(const MATRIX& m1,const SMATRIX& m2);
WIN_THINGIE SMATRIX  operator+(const SMATRIX& m1,const MATRIX& m2);
WIN_THINGIE SMATRIX  operator-(const SMATRIX& m1,const SMATRIX& m2);
WIN_THINGIE SMATRIX  operator-(const SMATRIX& m1,const MATRIX& m2);
WIN_THINGIE SMATRIX  operator-(const MATRIX&  m1,const SMATRIX& m2);

// 
// These were taken out of Tensor.h because they made
// a dependance on Matrix.h 
#if ( (( defined __GNUC__ ) && ( __GNUC__ > 3 )) || ( defined AIX ) || ( defined HPUX ) || ( defined SunOS) )
WIN_THINGIE SMATRIX   operator^(const TENSOR2&,const  TENSOR2&);
#endif
WIN_THINGIE MATRIX    operator^(const VECTOR& v1, const VECTOR& v2);
WIN_THINGIE MATRIX    operator^(const TENSOR2&,const  VECTOR&);
WIN_THINGIE MATRIX    operator^(const VECTOR&,const  TENSOR2&);

// WIN_THINGIE SMATRIX   ikjl(const TENSOR2& t1,const  TENSOR2& t2);
// WIN_THINGIE SMATRIX   iljk(const TENSOR2& t1,const  TENSOR2& t2);

WIN_THINGIE SMATRIX   rotate_matrix(const SMATRIX&, const TENSOR2&);
WIN_THINGIE SMATRIX   rotation_matrix(const TENSOR2& t1, const TENSOR2& t2);
WIN_THINGIE MATRIX    ikmn_times_kj(const MATRIX& min, const TENSOR2& tin);


//============================================================================  
// INLINES 
//============================================================================  

inline MATRIX::MATRIX() : MATH_OBJECT(0), _n(0), _m(0), mat(NULL), n(_n), m(_m) { }

inline MATRIX::MATRIX(int nn, int mm) : MATH_OBJECT(0), _n(nn), _m(mm), n(_n), m(_m) { 
         init_ptr();
         #ifdef ZCHECK
            *this = DBL_MAX;
         #endif
}


inline MATRIX& MATRIX::operator *= (double d) { 
         if (if_is_sub()==0) {
             double *r=mat[0];
             for(int i=m*n;i;i--) *r++ *=d;
         }
         else for(int i=0;i<n;i++) for(int j=0;j<m;j++) mat[i][j]*=d; // SUB
         return *this;
}

inline MATRIX& MATRIX::operator /= (double d) { 
         if (if_is_sub()==FALSE) {
             double *r=mat[0];
             for (int i=m*n;i;i--) *r++ /=d;
         }
         else for(int i=0;i<n;i++) for(int j=0;j<m;j++) mat[i][j]/=d; // SUB
         return *this;
} 

inline WIN_THINGIE MATRIX  operator*(const MATRIX& a, double d) { 
          MATRIX b(a);
          if(b.mat) {
              double *r=b.mat[0];
              for(int i=!b-1;i>=0;i--) r[i] *=d;
          }
          b.set_temporary();
          return b;
} 

inline WIN_THINGIE MATRIX  operator*(double d, const MATRIX& a) { 
          MATRIX b(a);
          if(b.mat) {
               double *r=b.mat[0];
               for(int i=!b;i;i--) *r++ *=d;
          }
          b.set_temporary();
          return b ;
} 

#ifdef MATRIX_ALIGN_AS_FORTRAN
   #define MAT_CHECK j 
#else 
   #define MAT_CHECK i 
#endif

inline double& MATRIX::operator()(int i, int j)
{ 
     #ifdef ZCHECK
     assert(i>=0 && i<n && j>=0 && j<m);
     assert(mat && mat[MAT_CHECK]);
     #endif

     #ifdef MATRIX_ALIGN_AS_FORTRAN
          return mat[j][i];
     #else
          return mat[i][j]; 
     #endif
}
   
inline const double& MATRIX::operator()(int i, int j)const
{ 
     #ifdef ZCHECK
          assert(i>=0 && i<n && j>=0 && j<m);
          assert(mat && mat[MAT_CHECK]);
     #endif
     #ifdef MATRIX_ALIGN_AS_FORTRAN
          return mat[j][i]; 
     #else
          return mat[i][j]; 
     #endif
}

#undef MAT_CHECK


inline SMATRIX::SMATRIX() : MATRIX() { }
inline SMATRIX::SMATRIX(int ni) : MATRIX(ni,ni) { }
inline SMATRIX::SMATRIX(int ni,const double* x) : MATRIX(ni,ni,x) { }
inline SMATRIX::SMATRIX(const SMATRIX& mi) : MATRIX(mi) { }
inline SMATRIX::SMATRIX(const MATRIX&  mi) : MATRIX(mi) { assert(mi.n==mi.m); }
inline SMATRIX::SMATRIX(int nn, const MATRIX& father, int start_n, int start_m) :
   MATRIX(nn,nn,father,start_n,start_m) {
}

inline void SMATRIX::reassign(int nn, MATRIX& father, int start_n, int start_m) { 
   MATRIX::reassign(nn,nn,father,start_n,start_m);
}

inline SMATRIX& SMATRIX::operator=(const MATRIX& mi) { 
          return (SMATRIX&)MATRIX::operator=((MATRIX&)mi);
} 

inline SMATRIX& SMATRIX::operator=(const SMATRIX& mi) { 
          return (SMATRIX&)MATRIX::operator=((MATRIX&)mi);
} 

inline SMATRIX& SMATRIX::operator=(const TENSOR4& mi) { 
          return (SMATRIX&)MATRIX::operator=((MATRIX&)mi);
} 

inline SMATRIX& SMATRIX::operator=(double c) { MATRIX::operator=(c); return *this; }

Z_END_NAMESPACE;
#endif

