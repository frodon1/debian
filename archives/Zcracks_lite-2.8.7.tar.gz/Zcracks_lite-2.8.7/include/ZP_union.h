#ifndef __ZP_MESHER_UNION__
#define __ZP_MESHER_UNION__

#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>
#include <Mesher_union.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_MESHER_UNION : public ZP_BASIC_TYPE<MESHER_UNION>
{
  protected :
    ZP_FATAL_ERROR* union_(ZP_STACK&,int);
    ZP_FATAL_ERROR* add(ZP_STACK&,int);
    ZP_FATAL_ERROR* reset(ZP_STACK&,int);
    virtual void type_init(char*) { type="MESHER_UNION"; }

  public :
    BASIC_CONSTRUCTORS(ZP_MESHER_UNION,MESHER_UNION);

    METHOD_DECLARATION_START
      METHOD("union",union_,1)
      METHOD("add",add,0)
      METHOD("reset",reset,0)
    METHOD_DECLARATION_ANCESTOR(ZP_BASIC_TYPE<MESHER_UNION>)

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
};
Z_END_NAMESPACE;

#endif
