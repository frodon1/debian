#ifndef __GMRES__
#define __GMRES__

#include <Array.h>
#include <Vector.h>
#include <Iterative_solver_parameter.h>
#include <Iterative_solver.h>

Z_START_NAMESPACE;

ZCLASS GMRES_PARAMETER : public ITERATIVE_SOLVER_PARAMETER {
  public :
    int krylov_space;

    GMRES_PARAMETER() { krylov_space=10; }
    virtual ~GMRES_PARAMETER() { }
    virtual bool GetResponse(STRING&,ASCII_FILE&);
    RTTI_INFO;
}; 

ZCLASS GMRES : public ITERATIVE_SOLVER {
  protected :
    int krylov_dim;
    VECTOR ve,vchb,qrsin,qrcos,vhb;
    VECTOR temporary;
    ARRAY<VECTOR> vkv;

  public :
    GMRES();
    virtual ~GMRES();

    void set_dimension(int);

    void loop();

    virtual void set_parameter(SOLVER_PARAMETER *ip);
};
Z_END_NAMESPACE;

#endif
