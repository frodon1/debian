#ifndef __ZP_OFILE__
#define __ZP_OFILE__

#include <Defines.h>
#include <ZP_stack.h>
#include <ZP_double.h>
#include <ZP_int.h>
#include <ZP_string.h>
#include <ZP_array.h>
#include <Zstream.h>
#include <ZP_env.h>

  Z_USE_NAMESPACE;

Z_START_NAMESPACE;

class ZP_OFSTREAM : public ZP_OBJECT
{
  protected :
    ZP_FATAL_ERROR* write(ZP_STACK&,int);
    ZP_FATAL_ERROR* m_ll(ZP_STACK&,int);
    ZP_FATAL_ERROR* open(ZP_STACK&,int);
    ZP_FATAL_ERROR* close(ZP_STACK&,int);
    ZP_FATAL_ERROR* flush(ZP_STACK&,int);
    ZP_FATAL_ERROR* good(ZP_STACK&,int);
    ZP_FATAL_ERROR* fail(ZP_STACK&,int);
    ZP_FATAL_ERROR* bad(ZP_STACK&,int);

    virtual void type_init(char*) { type="Zofstream"; }

  public :
    ZP_OFSTREAM() : ZP_OBJECT() { contens=new Zofstream; dont_delete=0; type_init(NULL); }
    ZP_OFSTREAM(Zofstream *i) : ZP_OBJECT() { contens=i; dont_delete=1; type_init(NULL); }
    virtual ~ZP_OFSTREAM() { if(!dont_delete) delete((Zofstream*)contens); }

    Zofstream& get() { return(*((Zofstream*)contens)); }

    METHOD_DECLARATION_START
      METHOD("write",write,2)
      METHOD("<<",m_ll,1)
      METHOD("open",open,2)
      METHOD("close",close,0)
      METHOD("flush",flush,0)
      METHOD("good",good,0)
      METHOD("fail",fail,0)
      METHOD("bad",bad,0)
    METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)

    ZPO_RTTI_INFO(Zofstream)
};

Z_END_NAMESPACE;

#endif
