gcc -I. -L. mg-adapt_example.c -lmg-adapt -lmg-surfopt -lmg-tetra -lmeshgems -lmeshgems_stubs -lm -lc  -o mg-adapt_example.exe
