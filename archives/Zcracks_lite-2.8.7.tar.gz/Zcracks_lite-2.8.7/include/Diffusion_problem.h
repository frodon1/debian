#ifndef __Diffusion_problem__
#define __Diffusion_problem__

#include <Hierarchy.h> 
#include <Vector.h> 
#include <Zunistd.h>

#include <Problem.h> 
#include <Global_matrix.h> 

Z_START_NAMESPACE;

class INTEGRATION_RESULT;

ZCLASS2 PROBLEM_DIFFUSION : public PROBLEM { 
   protected :
      double theta;
      double dCmax;
      int iter_max;
      AUTO_PTR<GLOBAL_MATRIX> K; 
      VECTOR dC, C_dot, Re;
      _ZSYSCLOCK mesh_creation_date;

      void create_mesh();
      virtual void compute_C_dot(VECTOR& C_dot); 
 
  public :  

      // 
      // BUG.. used temporarily to quickly 
      // make modifications in the algo for moving boundary. 
      // 
      static int flags; 

      PROBLEM_DIFFUSION();
      virtual ~PROBLEM_DIFFUSION();

      virtual bool Initialize();
      virtual bool Execute();

      virtual bool make_increment(double);

      virtual void mesh_changed();
      virtual void reset_global_matrix();
      virtual int parallelized(void) { return(1); }

      RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
