#ifndef __INTERFACE_VECTOR__
#define __INTERFACE_VECTOR__

#include <Vector.h>

Z_START_NAMESPACE;

ZCLASS2 INTERFACE_VECTOR : public VECTOR {
  private :
    F_SUB_DOMAIN *fs;
    ARRAY< TENSOR2* > restriction;

  public :

    TENSOR2& operator()(int i) { return(*(restriction[i])); }
    void gap(INTERFACE_VECTOR&);
};
Z_END_NAMESPACE;

#endif
