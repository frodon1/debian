#ifndef __Level_set_problem__
#define __Level_set_problem__

#include <Hierarchy.h> 
#include <Marray.h> 
#include <Vector.h> 

#include <Problem.h> 
#include <Global_matrix.h> 
#include <Mesh.h> 

Z_START_NAMESPACE;

ZCLASS2 LEVEL_SET_MESH : public MESH {
 public :
  LEVEL_SET_MESH() {;} 
  RTTI_INFO;
};

class INTEGRATION_RESULT;

ZCLASS2 PROBLEM_LEVEL_SET : public PROBLEM { 
 protected :
  int iter_max;
      
  SEQUENCE *previous_seq;
  AUTO_PTR<GLOBAL_MATRIX> K; 
      
  void create_mesh();
  virtual INTEGRATION_RESULT* make_iterations(); 


 public :  
  bool   Newton;
  int    max_nb_disp; 
  int    nb_veloc_dof; 
  LIST<DOF_TYPE*> phi_type;
  NSET* nset;

  PROBLEM_LEVEL_SET();
  virtual ~PROBLEM_LEVEL_SET();

  virtual bool Initialize();
  virtual bool Execute();

  void make_dof(VECTOR & dof);
  virtual bool make_increment(double);
  void make_reinitialisation();
  void make_volume();
  void compute_norm_of_grad_phi(double & norme);
  //void compute_norm_of_grad_phi();
  RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
