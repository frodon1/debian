#ifndef __Utility_boundary__
#define __Utility_boundary__

#include <Buffered_list.h>
#include <Defines.h>
#include <Stringpp.h>
#include <Allocator_template.h>

#include <Graphics_face.h>
#include <Graphics_edge.h>

Z_START_NAMESPACE;

class UTILITY_BOUNDARY; 
class UTILITY_MESH;

// ** The ids are *NOT* used in the == operators. 

// See my note about BLOCK_ALLOCATOR in Utility_node.h

class UTILITY_NODE; 

ZCLASS UTILITY_BOUNDARY {
  protected:
    bool do_tet_cmp(const UTILITY_BOUNDARY& b1, const UTILITY_BOUNDARY& b2)const;

  public : 
    enum BTYPES { BTYPE_NONE=0, 
                  BTYPE_LINE=1, 
                  BTYPE_QUAD=2, 
                  BTYPE_T3=4, 
                  BTYPE_T6=8, 
                  BTYPE_Q4=16, 
                  BTYPE_Q6=32, 
                  BTYPE_Q8=64, 
                  BTYPE_TET=128, 
                  BTYPE_PRISM=256, 
                  BTYPE_HEXA=512, 
                  BTYPE_HEXAR=1024, 
                  BTYPE_CUBIC=2048, 
                  BTYPE_T10=4096, 
                  BTYPE_LAST=8192 } type; 
    // VC: is there any reason to keep 2^ values?
    // a BTYPE can't be T2&T3, isn't it?
       
    static const char* translate(BTYPES type); 
    static UTILITY_BOUNDARY* make(STRING type_name);
    bool   setup(STRING type_name); 

    ARRAY<UTILITY_NODE*> nodes;

    // graphics related.. will only be sized for graphics 
    // applications.. therefore they don't add a lot.. 
    // is_shared may be set sometimes... sometimes not
    // 
    void run_face_setup(int force_setup,int element_rank=-1);
    ARRAY<GRAPHICS_POINT>* points; 
    GRAPHICS_FACE*    graphics_face; 
    GRAPHICS_EDGE*    graphics_edge; 
    short             is_shared;
    short             sharable;

    UTILITY_BOUNDARY(); 
    UTILITY_BOUNDARY(const UTILITY_BOUNDARY& in); 
    virtual ~UTILITY_BOUNDARY(); 

    UTILITY_BOUNDARY& operator=(const UTILITY_BOUNDARY&); 
    bool operator==(const UTILITY_BOUNDARY&)const; 
    bool operator!=(const UTILITY_BOUNDARY& in)const { return (*this==in) ? FALSE : TRUE; } 
 
    // 
    // For faces, these are the edges, for lines, nothing is returned 
    // the interface is different than elements because this is not 
    // used often 
    // 
    void get_edges(ARRAY<UTILITY_BOUNDARY>& edges); 

    // 
    // given a point base_point and a projection direction, find the real coord 
    // intersection_point and local coord intersection_xi of the interseciton with 
    // the boundary. If this is within the boundary defined by the nodes return TRUE 
    // 
    bool projection_point( VECTOR& intersection_point,
                       VECTOR& intersection_xi, 
                       const VECTOR& base_point,
                       const VECTOR& direction,
                       double tol=1.e-3, 
                       int limit=50
                       ); 

    VECTOR  compute_normal(VECTOR& at_xi);  ///< Note that at_xi are the coordinates in the reference element.

    bool if_in(VECTOR& xi,
               const VECTOR xp,
               double tol,
               double tolDist,
               int max_iter,double *det=NULL);

    double quality();

    VECTOR  compute_center();  ///< Computes the element's center (average node position)
}; 
Z_END_NAMESPACE;

#endif
