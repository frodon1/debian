#ifndef __Backtrace__
#define __Backtrace__

#include <Defines.h>

Z_START_NAMESPACE;

extern WIN_THINGIE void activate_debug_tools();
extern WIN_THINGIE void print_backtrace(); 
extern WIN_THINGIE void attach_gdb(); 
extern WIN_THINGIE void attach_gdb_return(int tsleep=5,const char *f=0x0, int l=0); 
extern WIN_THINGIE void check_attach_gdb_return(int tsleep=5); 
extern WIN_THINGIE void attach_gdb_return_break_file(char const*,int); 

Z_END_NAMESPACE;

#endif
