#ifndef __Thermal_mesh__
#define __Thermal_mesh__

#include <Mesh.h>
#include <Problem_info.h>

Z_START_NAMESPACE;

ZCLASS2 THERMAL_MESH : public MESH {
      double theta;
      PB_TIME_TYPE type;
  public :
      void set(double,PB_TIME_TYPE);
      void compute_H_dot(VECTOR&);
 
      RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
