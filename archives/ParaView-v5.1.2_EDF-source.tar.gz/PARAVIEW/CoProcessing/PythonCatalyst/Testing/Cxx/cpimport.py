# Script to make sure we can import other scripts from
# a Catalyst script

import cpprogrammablefilter

def RequestDataDescription(datadescription):
    "Callback to populate the request for current timestep -- NULL for this test"
    pass

def DoCoProcessing(datadescription):
    "Callback to do co-processing for current timestep -- NULL for this test"
    pass
