#ifndef __OLD_LIN_TO_QUAD_TRANSFORM__
#define __OLD_LIN_TO_QUAD_TRANSFORM__

#include <Defines.h>
#include <Calcul_timer.h>
#include <Error_messager.h>
#include <File.h>
#include <Function.h>
#include <Out_message.h>
#include <Modify_record.h>
#include <P_container.h>
#include <Global_parameter.h>

#include <Transform_geometry.h>
#include <Utility_mesh.h>
#include <Utility_relations.h>

Z_START_NAMESPACE;

class OLD_LIN_TO_QUAD_TRANSFORM : public TRANSFORMERS 
{
  protected :
    UTILITY_REL_MESH *rel_mesh;
    
  public :
     OLD_LIN_TO_QUAD_TRANSFORM();
     virtual ~OLD_LIN_TO_QUAD_TRANSFORM() { } 

     MODIFY_INFO_RECORD* get_modify_info_record(); 
     virtual void apply(UTILITY_MESH& mesh);
     void lin_to_quad(UTILITY_MESH &mesh, UTILITY_REL_MESH *rel_mesh, BUFF_LIST<UTILITY_NODE*> &added_nodes , BUFF_LIST<UTILITY_REL_NODE*> &added_rel_nodes);
};
Z_END_NAMESPACE;

#endif
