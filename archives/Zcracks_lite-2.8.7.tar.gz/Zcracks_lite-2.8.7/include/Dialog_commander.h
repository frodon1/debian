#ifndef __DIALOG_COMMANDER__
#define __DIALOG_COMMANDER__

#include <Commander.h>
#include <Graphics_data_dialog.h>

Z_START_NAMESPACE;

class DIALOG_COMMANDER : public SUB_DIALOG , public COMMANDER
{
   protected :
     bool scrolled;
     STRING boss,its_name;
     GRAPHICS_DATA_DIALOG* boss_dialog;

   public :
     DIALOG_COMMANDER() {}
     virtual ~DIALOG_COMMANDER() {}

     void set_boss_dialog(GRAPHICS_DATA_DIALOG *dd, STRING &s) 
       { boss_dialog=dd; boss=s; }
     void set_name(STRING &s) { its_name=s; }
     void set_scrolled() { scrolled=TRUE; }
};
Z_END_NAMESPACE;

#endif
