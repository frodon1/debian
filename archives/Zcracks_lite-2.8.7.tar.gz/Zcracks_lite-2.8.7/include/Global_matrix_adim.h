#ifndef _GLOBAL_ADIM_MATRIX_
#define _GLOBAL_ADIM_MATRIX_

#include <DD_sub_domain.h>
#include <Boundary_condition.h>
#include <Global_matrix.h>
#include <Solver_parameter.h>
#include <Matrix.h>

Z_START_NAMESPACE;

//
// 2005-06-10 FF: A diagonal preconditioner which multiplies the operator K by 1./sqrt(fabs(Kii));
//

class GLOBAL_ADIM_MATRIX;

class GLOBAL_ADIM_MATRIX_PARAMETER : public SOLVER_PARAMETER
{
  public :
    STRING local_type;
    SOLVER_PARAMETER *local_parameters;
                                                                                
    GLOBAL_ADIM_MATRIX_PARAMETER();
    virtual ~GLOBAL_ADIM_MATRIX_PARAMETER();
                                                                                
    virtual bool GetResponse(STRING&,ASCII_FILE&);
    RTTI_INFO;
};

class GLOBAL_ADIM_MATRIX : public GLOBAL_MATRIX {

  protected :
    GLOBAL_MATRIX*        local;
    GLOBAL_ADIM_MATRIX_PARAMETER *param;

  public :
    GLOBAL_ADIM_MATRIX();
    virtual ~GLOBAL_ADIM_MATRIX();

    virtual bool solve(VECTOR& displ,VECTOR& force,int if_compute_inverse,int if_compute_kernel=0);
    virtual void set_parameter(SOLVER_PARAMETER *sp);

    virtual bool is_symmetric()const;

    MESH* get_associated_mesh() { return(local->get_associated_mesh()); }
    void  set_associated_mesh(MESH* m) {associated_mesh = m; local->set_associated_mesh(m);}

    virtual void create(MESH& mesh,char* name=NULL);
    virtual int set_flag(STRING what);
    virtual SMATRIX& operator[](int i);
    virtual const SMATRIX& operator[](int i) const;
    virtual double& operator()(int i, int j);
    virtual void global_matrix_structure_change(UPDATE_FLAGS ident_flags);
    virtual bool link_to(GLOBAL_MATRIX *K);

    virtual GLOBAL_MATRIX* copy_type(MESH& mesh);
    virtual void copy_to_matrix(GLOBAL_MATRIX& mat_in);

    
    virtual void store(const D_ELEMENT &e, const SMATRIX &s) { local->store(e,s); }
    virtual bool solve(ARRAY<VECTOR> &, ARRAY<VECTOR> &, int) { NOT_IMPLEMENTED_ERROR("sole([])"); return(FALSE); }
    virtual VECTOR operator *(const VECTOR &v) const { return( (*local)*v ); }
    virtual void arvp(const ARRAY<VECTOR> &, ARRAY<VECTOR> &) const { NOT_IMPLEMENTED_ERROR("arvp"); }
    virtual void normalize_vectors(ARRAY<VECTOR> &av, int i=0) const { local->normalize_vectors(av,i);  }
    virtual void normalize_vector(VECTOR &v) const { local->normalize_vector(v); }
    virtual void compute_schur_complement(ARRAY<DOF *> &ad, MATRIX &m) { local->compute_schur_complement(ad,m); }
    virtual void compute_flexibility_matrix(ARRAY<DOF *> &ad, MATRIX &m, bool verbose_contact=FALSE) { local->compute_flexibility_matrix(ad,m,verbose_contact); }
    virtual void add_stable_force_to_external_reaction() { local->add_stable_force_to_external_reaction(); }
    virtual bool is_determinant_negative() const { return(local->is_determinant_negative()); }
    virtual GLOBAL_MATRIX_KERNEL* initialize_kernel(const DD_SUB_DOMAIN&);
    virtual KERNEL_MATRIX* get_schur();
    virtual void enable_keep_rigid() { NOT_IMPLEMENTED_ERROR("enable_keep_rigid"); }
    virtual void addmult(const GLOBAL_MATRIX& mat1,double d){local->addmult(mat1,d);};
    virtual void assign(const GLOBAL_MATRIX& mat1){local->assign(mat1);}
    virtual void adddiag(double f){local->adddiag(f);}
    virtual void mult(double f){local->mult(f);}
    virtual void zero_matrix() { local->zero_matrix(); };
    virtual void initialize_structure();
    virtual void partial_times(ARRAY<int>& index,const VECTOR& q, VECTOR& v)
      { local->partial_times(index,q,v); }
    virtual void partial_times_hyper_rom(int Nb_testing_dof, ARRAY<int>& index, ARRAY<int>& inv_selec, const MATRIX& v, ARRAY<bool>& if_bc, MATRIX& res)
    {local -> partial_times_hyper_rom(Nb_testing_dof, index, inv_selec, v, if_bc, res);}

};
Z_END_NAMESPACE;

#endif
