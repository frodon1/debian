#ifndef __Utility_dir_file_driver__ 
#define __Utility_dir_file_driver__ 

#include <Utility_file_driver.h> 

Z_START_NAMESPACE;

// ============================================================================  
// 
// ============================================================================  

class MESH;

//
// This object is a concrete implementation of the abstract UTILITY_FILE_DRIVER class
// it represents a .zres directory which contains results
// this .zres may also contains other .zres sub-directories in which case these sub-directories
// are created and instantiated as sub_drivers[] within the current object
//

ZCLASS2 DIR_UTILITY_FILE_DRIVER : public UTILITY_FILE_DRIVER { 
  protected :
     STRING  sep; 
     STRING  path; 
     int     dir_mode; 
     int     file_mode; 
     bool    ut_out_open;
     //
     // Not used ?
     // bool    ut_in_open;
     // ASCII_FILE  ut_in;       // note sep file for maps 

     virtual int   make_node(STRING path, int mode);
     virtual bool  check_file(STRING path, STRING fname); 
     bool rm_rf_x(STRING path, int l=0); 
     bool rm_rf(STRING path, int l=0); 

     bool  pass_on_read(STRING what, double when, UTILITY_DATA& data_rec);
     void add_maps(BUFF_LIST<MAP_INFO>& my_maps, BUFF_LIST<MAP_INFO>& map_in); 

     void other_store_pinfo();
     void master_store_pinfo();
     void save_cut();

     STRING precision_global_parameter;
     int precision;
     

  public : 
     Zofstream   ut_out;      // contents.txt file 

     IOS_OPENMODE bin_file_mode; 
     DIR_UTILITY_FILE_DRIVER* map_driver; 
     int         map_number; 
     STRING      mapdir; 
     STRING      maproot; 

     DIR_UTILITY_FILE_DRIVER(); 
     DIR_UTILITY_FILE_DRIVER(const DIR_UTILITY_FILE_DRIVER& in);
     virtual UTILITY_FILE_DRIVER* copy_self();

     virtual ~DIR_UTILITY_FILE_DRIVER(); 

     virtual bool establish(bool read_only_in=TRUE, UT_MODE mode=OPEN_OUT); 
     virtual bool establish(STRING root_in, bool read_only_in=TRUE, UT_MODE mode=OPEN_OUT);                 // sets root
     virtual bool establish(STRING root_in, STRING item_in, bool read_only_in=TRUE, UT_MODE mode=OPEN_OUT); // sets item

     virtual UTILITY_FILE_DRIVER* add_sub_database(GMESH*,STRING nm, UT_MODE m=OPEN_OUT); 
     virtual LIST<UTILITY_FILE_DRIVER*> create_sub_drivers(); 

     virtual bool wipe_clean(STRING db_name); 
     virtual STRING generate_path(STRING file_name); 

     virtual void set_record_sizes(STRING item, int number);
     virtual void open_files(UT_MODE m); 
     virtual void close_files(); 

     // ---------------------------------------- 
     // Output Items 
     // ---------------------------------------- 
     virtual UTILITY_FILE_DRIVER* add_step(MAP_INFO& map);       // ret val needs to be deleted by you
     virtual void  write(STRING what, UTILITY_DATA& data_rec); 
     virtual void  write(STRING what, UTILITY_DATA& data_rec, int st, int sz);
     virtual void  write_contents(STRING);
     virtual void  open_ascii_out(Zofstream& f, STRING nm, IOS_OPENMODE _m=0);
     virtual void open_binary_out(Zofstream& f, STRING nm, IOS_OPENMODE _m=0);

     // ---------------------------------------- 
     // Input Items 
     // ---------------------------------------- 
     virtual bool  read(STRING what, double when, UTILITY_DATA& data_rec);
     virtual void  add_components(LIST<OUTPUT_COMPONENT*>& comps); 
     virtual void  open_ascii_in(ASCII_FILE& f, double when, STRING nm);
     virtual void  open_binary_in(Zfstream& f, double when, STRING nm);

     virtual void print();
     virtual STRING get_current_mesh();

     RTTI_INFO;
}; 


//   virtual void   set_parameter(STRING param, STRING value); 
//   virtual void   set_parameters(STRING param, LIST<STRING> value); 
//   virtual LIST<STRING> get_parameters(STRING param); 
//   virtual STRING get_parameter(STRING param); 

Z_END_NAMESPACE;

#endif 
