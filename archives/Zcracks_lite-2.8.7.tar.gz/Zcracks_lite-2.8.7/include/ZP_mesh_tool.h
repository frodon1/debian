#ifndef __ZP_MESH_TOOL__
#define __ZP_MESH_TOOL__

#include <Std_cc_stream.h>

#include <Bool.h>
#include <ZP_test_tool.h>
#include <ZP_ext_params.h>

Z_START_NAMESPACE;

class P_LEXER; 
class ZP_ENV;

ZCLASS2 ZP_MESH_TOOL : public ZP_TEST_TOOL {
  protected :
    virtual P_LEXER* build_lexer();
    void set_geometry(DAO_GEOMETRY*);

  public :
    ZP_EXT_PARAMS parameters;

    ZP_MESH_TOOL(void);
    virtual  ~ZP_MESH_TOOL(void);

    void run(DAO_GEOMETRY*,STRING&,ZP_ENV *env=NULL);
    
    bool load_and_check(STRING&);
    bool run_with_args(DAO_GEOMETRY*,ZP_ENV *env=NULL);
};
Z_END_NAMESPACE;

#endif
