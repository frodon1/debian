#ifndef __F_df_d2f__
#define __F_df_d2f__

// This class is an array that simplify storage of the value of a function and its
// first and second derivatives. nvar is the number of variables.
// 
// If f is a function of x=(x1,x2), the storage rule is the following:
// f[0] = f(x)
// f[1] = df/dx1(x)
// f[2] = df/dx2(x)
// f[3] = d^2f/d(x1)^2(x)
// f[4] = d^2f/dx1dx2(x)
// f[5] = d^2f/d(x2)^2(x)
// 
// To make the access to the different values simpler, use () to get the
// function value, (int) to get the first derivatives and (int,int) to get the
// second derivatives:
// f()    gives f(x)           = f[0]
// f(i)   gives df/dxi(x)      = f[1+i]
// f(i,j) gives d^2f/dxidxj(x) = f[1+nvar+(2nvar-1-i)*i/2+j]

#include <Array.h>
#include <Stringpp.h>
#include <Defines.h>

Z_START_NAMESPACE;

ZCLASS F_DF_D2F : public ARRAY<double> {
	protected :
		int nvar, nvarp1 ;
		int twonm1 ;
	public :
		F_DF_D2F() : ARRAY<double>(3), nvar(0), nvarp1(1), twonm1(-1) { } ;
		F_DF_D2F(int nvar_) : ARRAY<double>(1 + nvar_ + (nvar_*(nvar_+1))/2), nvar(nvar_), nvarp1(nvar_+1), twonm1(2*nvar_-1) { } ;
		F_DF_D2F &set_var(int nvar_) { nvar = nvar_ ; nvarp1 = nvar_+1 ; twonm1 = 2*nvar_-1 ; resize(1 + nvar_ + (nvar_*(nvar_+1))/2) ; return *this ; } ;
		inline int get_var() const { return nvar ; } ;
		F_DF_D2F &operator=(double m) { ARRAY<double>::operator=(m) ; return *this ; }
		inline double &operator()() { return x[0] ; } ;
		inline const double &operator()() const { return x[0] ; } ;
		inline double &operator()(int i) { return x[1+i] ; } ;
		inline const double &operator()(int i) const { return x[1+i] ; } ;
		inline double &operator()(int i, int j) { if (j<i) return operator()(j,i) ; else return x[nvarp1+((twonm1-i)*i)/2+j] ; } ;
		inline const double &operator()(int i, int j) const { if (j<i) return operator()(j,i) ; else return x[nvarp1+((twonm1-i)*i)/2+j] ; } ;
} ;

void __prn(STRING, const F_DF_D2F&) ;
WIN_THINGIE void _PrN(STRING, const F_DF_D2F&) ;

Z_END_NAMESPACE;

#endif
