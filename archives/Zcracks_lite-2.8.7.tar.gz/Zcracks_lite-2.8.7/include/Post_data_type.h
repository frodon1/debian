#ifndef __Post_data_type__
#define __Post_data_type__

#include <Stringpp.h> 

Z_START_NAMESPACE;

enum POST_DATA_TYPE { PDT_INTEG, 
                      PDT_NODE, 
                      PDT_CTNOD, 
                      PDT_CTELE, 
                      PDT_CTMAT, 
                      PDT_ELE, 

                      PDT_INTEGP,
                      // 
                      // RF added nodep 06/2002.. use the **output_to_node option to get it
                      // in place of ctnodp for a processing block.. 
                      // 
                      PDT_NODEP, 
                      PDT_CTNODP,
                      PDT_CTELEP,
                      PDT_CTMATP,
                      PDT_ELEP,

                      PDT_UNKNOWN
                    };

// speficies files working together
// G_INTEG = {INTEG,INTEGP}
// G_NODE  = {NODE,CTNOD,CTNODP}
// G_CTELE = {CTELE,CTELEP}
// G_CTMAT = {CTMAT,CTMATP}
// G_ELE   = {ELE,ELEP}

enum PDT_GROUP { G_CTNOD, G_INTEG, G_NODE, G_CTELE, G_CTMAT, G_ELE,PDTG_UNKNOWN };

// speficies to which type of set PDT_GROUP is attached
enum SET_TYPE { T_NSET, T_ELSET, T_IPSET };

// this global array associate a POST_DATA_TYPE to a set type

extern SET_TYPE Pdt_assoc_set[];
extern PDT_GROUP Pdt_group[];

extern WIN_THINGIE2 STRING translate_pdt(POST_DATA_TYPE type); 
extern WIN_THINGIE2 POST_DATA_TYPE translate_pdt(STRING name); 
Z_END_NAMESPACE;

#endif
