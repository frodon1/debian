#ifndef __NT_tool_panel__
#define __NT_tool_panel__ 

#include <Stdafx.h> 
#include <BtnST.h>

#include <Darray.h> 
#include <NT_command.h> 

Z_START_NAMESPACE;

class NT_TRACK_CONTROL; 

class NT_TOOL_PANEL : public CDialogBar { 
  protected : 
  public : 
    int                x_offset, y_offset; 
    int                ran_create;
    LIST<NT_COMMAND*>  cmd_stack;

    DARRAY< CButtonST* > buttons; 
    DARRAY< NT_COMMAND* > commands; 

    NT_TRACK_CONTROL*  its_track_control; 

    NT_TOOL_PANEL(); 
    virtual ~NT_TOOL_PANEL(); 

    BOOL Create( CWnd* pParentWnd, UINT nIDTemplate, UINT nStyle, UINT nID );

    virtual void OnUpdateCmdUI( CFrameWnd* pTarget, BOOL bDisableIfNoHndler ); 
    void enable_all(); 

    void cbtn(int i, int j);
    afx_msg void cbtn11() { cbtn(0,0); }
    afx_msg void cbtn21() { cbtn(1,0); }
    afx_msg void cbtn31() { cbtn(2,0); }
    afx_msg void cbtn41() { cbtn(3,0); }
    afx_msg void cbtn51() { cbtn(4,0); }
    afx_msg void cbtn61() { cbtn(5,0); }
    afx_msg void cbtn71() { cbtn(6,0); }
    afx_msg void cbtn81() { cbtn(7,0); }
    afx_msg void cbtn91() { cbtn(8,0); }

    afx_msg void cbtn12() { cbtn(0,1); }
    afx_msg void cbtn22() { cbtn(1,1); }
    afx_msg void cbtn32() { cbtn(2,1); }
    afx_msg void cbtn42() { cbtn(3,1); }
    afx_msg void cbtn52() { cbtn(4,1); }
    afx_msg void cbtn62() { cbtn(5,1); }
    afx_msg void cbtn72() { cbtn(6,1); }
    afx_msg void cbtn82() { cbtn(7,1); }
    afx_msg void cbtn92() { cbtn(8,1); }

    afx_msg void cbtn13() { cbtn(0,2); }
    afx_msg void cbtn23() { cbtn(1,2); }
    afx_msg void cbtn33() { cbtn(2,2); }
    afx_msg void cbtn43() { cbtn(3,2); }
    afx_msg void cbtn53() { cbtn(4,2); }
    afx_msg void cbtn63() { cbtn(5,2); }
    afx_msg void cbtn73() { cbtn(6,2); }
    afx_msg void cbtn83() { cbtn(7,2); }
    afx_msg void cbtn93() { cbtn(8,2); }
    afx_msg void OnSize(UINT nType, int cx, int cy); 

    afx_msg void OnPaint();
    afx_msg void OnNcPaint();
    afx_msg void OnDrawItem(int,LPDRAWITEMSTRUCT lpDrawItemStruct);

    void add_my_command(NT_COMMAND& cmd); 
    void remove_my_command(NT_COMMAND& cmd); 
    
    DECLARE_MESSAGE_MAP()
}; 

Z_END_NAMESPACE;

#endif
