#ifndef __Batch_graphics_command__
#define __Batch_graphics_command__

#include <Stringpp.h> 
#include <List.h> 

#include <Graphics_command.h> 

Z_START_NAMESPACE;

class GRAPHICS_APPLICATION; 

ZCLASS2 BATCH_COMMAND : public GRAPHICS_COMMANDOR { 
  protected : 
     int active_flag; 
  public : 
     BATCH_COMMAND(int x, int y,
                    STRING name, GRAPHICS_COMMAND* boss, 
                    GRAPHICS_APPLICATION* its_app); 
     virtual ~BATCH_COMMAND(); 
     virtual bool do_command(STRING cmd); 
}; 
Z_END_NAMESPACE;

#endif
