/*=========================================================================
 Developed for EDF by Kitware SAS.
 Copyright (c) Kitware SAS 2015
 All rights reserved.
 More information http://www.kitware.fr
=========================================================================*/
#ifndef __pqPorthosStarter_h
#define __pqPorthosStarter_h

#include <QObject>

/// This is a stater class for plugin which rewire connect
/// button signal to Launcher related slots
class pqPorthosStarter : public QObject
{
  Q_OBJECT
  typedef QObject Superclass;
public:
  pqPorthosStarter(QObject* p = 0);
  ~pqPorthosStarter();

  // Callback for shutdown.
  void onShutdown();

  // Callback for startup.
  void onStartup();

private:
  pqPorthosStarter(const pqPorthosStarter&); // Not implemented.
  void operator=(const pqPorthosStarter&); // Not implemented.
};

#endif


