#ifndef __ZP_SLICE_ACTOR__
#define __ZP_SLICE_ACTOR__

#include <Results_slice_actor.h>
#include <ZP_contour_actor.h>
#include <ZP_stack.h>
#include <ZP_object.h>

Z_START_NAMESPACE;

class ZP_SLICE_ACTOR : public ZP_CONTOUR_ACTOR
{
  protected :
    virtual void type_init(char*) { type="RESULTS_SLICE_ACTOR"; }

  public :
    ZP_SLICE_ACTOR() : ZP_CONTOUR_ACTOR(NULL) { type_init(NULL); contens=new RESULTS_SLICE_ACTOR; }
    ZP_SLICE_ACTOR(RESULTS_SLICE_ACTOR *d) : ZP_CONTOUR_ACTOR(d) { type_init(NULL); }

    RESULTS_SLICE_ACTOR& get() { return(*(RESULTS_SLICE_ACTOR*)contens); }
    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
    ZPO_RTTI_INFO(RESULTS_SLICE_ACTOR)
};
Z_END_NAMESPACE;

#endif
