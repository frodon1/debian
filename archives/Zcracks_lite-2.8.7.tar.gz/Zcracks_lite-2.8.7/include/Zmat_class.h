#ifndef __Zmat_class__ 
#define __Zmat_class__ 

typedef double real_abq; 
typedef float  real1_abq; 

#ifdef WIN32
#undef Time; // this macro is also defined in windows, Clock.h will put it back to Zset definition
#include<Windows.h>
#include <Zerror.h>
#define Time           (Clock->get_time())
#endif

#include <Defines.h> 
#include <Pointer.h> 
#include <Elasticity.h> 
#include <External_parameter.h>
#include <Calcul_timer.h>
#include <Clock.h>

#include <Stringpp.h> 
#include <Behavior.h> 
#include <Mat_data.h> 
#include <Zmat_skip.h> 
#include <Zmat_storage.h> 
#include <Thread_specific_data.h>

Z_START_NAMESPACE;
extern WIN_THINGIE void load_zebaba(ZEBABA_HANDLER& zbbh,int ntens,int ndi,int nsh); 
extern WIN_THINGIE void dig_for_shear_variables(ZEBABA_HANDLER& zbbh);
extern WIN_THINGIE void do_limit_vars(ZEBABA_HANDLER& zbbh, double& newdt);
extern WIN_THINGIE void zmat_list_cwd();

enum ZMAT_SOLVER_TYPE {
   ZMAT_INVALID,
   ZMAT_ABAQUS,
   ZMAT_ABAQUS_EXPLICIT,
   ZMAT_COSMOS,
   ZMAT_MARC,
   ZMAT_ANSYS,
   ZMAT_MAX_SOLVERS
};

class ZELE_HANDLER;

ZCLASS ZMAT_GLOBAL_STORAGE {
   private:
     int      static_lanneal;

	 #ifndef _WIN32
       static pthread_once_t once_control;
     #endif


   public:
     ZMAT_GLOBAL_STORAGE();

     STRING   zmat_keep_odir;

	 static void  thread_init();
     PLIST<ZEBABA_HANDLER> zebaba_handler;
     LIST<long>            zebaba_pids;

     VECTOR*  global_deto_hack;
     int      global_need_deto_hack_in_zmat;
     int*     global_lanneal_hack;

     PLIST<FUNCTION>  f_defs;
     LIST<EXTERNAL_PARAM*> ZeBaBa_EP_list;
     CLOCK                 ZeBaBa_clock;

     LIST<MATERIAL_PIECE_VARIABLE_KEY*> tmp_keys;

     int     global_rerun_dump; // imported from Zmat_explicit_benchmark.c
     int     global_vumatwithin; // a hack for the Zvumat_test_expl.c hack

     int     preload_flag;
     int     suppress_temperature;
     int     timer_outputs;

     int     zebaba_ielem;  // These are for running the vumat interface
     int     zebaba_iip;    // within zebulon or another implicit code

     int zebaba_explicit_format;  // it's the sizeof(real) which somehow didn't work on it's own

     int zebaba_force_plane_stress;
     int zmat_preserve_case;

     int global_skip_gpco;
     int first_time_through;

     CALC_TIMER_COUNTER zmat_calcul_timer;
     CALC_TIMER_COUNTER* zmat_f_calcul_timer() { return(&zmat_calcul_timer); }

     static const int ZEBABA_KEY;

     static void zmat_once();

     //
     //
     //
     STRING zele_keep_odir;
     STRING zele_keep_job;

     int entered_zmat;
     int statusx;
     ZELE_HANDLER* zele_handler;

     //
     // debugging
     //
     int track_iter;
     int max_ele_id;
     int min_ele_id;
     int count_ip;

};

extern WIN_THINGIE CALC_TIMER_COUNTER* zmat_f_calcul_timer();

//
// Clean up globally
//
extern char* ZebulonVersion;
extern char* ZebulonDate;
extern char* ZebulonAuthor;
extern WIN_THINGIE Zofstream* zebaba_name_map_file;  // zTools/Utility.c

extern WIN_THINGIE int     ascii_file_fix_path_hack;
extern WIN_THINGIE STRING  ascii_file_fix_path_path;

#ifndef _WIN32
  extern char* CompilerOptions;
#endif

#ifdef _WIN32
  extern WIN_THINGIE LIST<STRING> loaded_nt_dlls;
  extern WIN_THINGIE LIST<HMODULE> loaded_handles;
#endif


extern WIN_THINGIE THREAD_SPECIFIC_DATA<ZMAT_GLOBAL_STORAGE>* stored_thread_zmat_globals;
#define thread_zmat_globals (*stored_thread_zmat_globals)
/*
#ifdef __POSIX_THREADS__
   #ifndef _WIN64
     extern THREAD_SPECIFIC_DATA<ZMAT_GLOBAL_STORAGE> thread_zmat_globals;
   #else
     extern WIN_THINGIE THREAD_SPECIFIC_DATA<ZMAT_GLOBAL_STORAGE>* stored_thread_zmat_globals;
     #define thread_zmat_globals (*stored_thread_zmat_globals)
   #endif
#else
   extern WIN_THINGIE ZMAT_GLOBAL_STORAGE* thread_zmat_globals;
#endif
   */

class ZMAT_RESULTS_DATABASE;

ZCLASS ZEBABA_HANDLER {
  public :
    STRING exedir;

    double ztime;
    double ztime_ini;
    double zdtime;

    double First_Time;
    double time_1, time_2; 
    char   cmname[256];

    int is_abq_standard;
    int abq_version;

    int issued_size_message;
    int finite_strain;
    int save_energies;

    enum TANGENT_TYPE {
        UNASSIGNED,
        JAUMANN,   
        JAUMANN_K, 
        TRUESDALE, 
        LET_PASS 
    };
    TANGENT_TYPE  tangent_form;
     
    int ps_flag; 
    int dimen; 

    AUTO_PTR<BEHAVIOR> behavior;
    ZMAT_SKIP*   skiph;
    LOCAL_FRAME* rotation;
    LOCAL_FRAME  static_rot;

    MAT_DATA mdat;
    
    // 
    // Storage related 
    // 
    int          using_storage; 
    PTR<ZMAT_STORAGE> storage; 
    LIST<STRING> real_statev;

    LIST<STRING> real_statev_vint;
    LIST<STRING> real_statev_vaux;
    LIST<int>    real_statev_vint_index;
    LIST<int>    real_statev_vaux_index;
//  int          buffer_size; 

    VECTOR   vint_ini;
    VECTOR   vaux_ini;
    VECTOR   vint;
    VECTOR   vaux; 


    //
    // Initial values
    //
    LIST<STRING> initial_vars;
    LIST<double> initial_vals;

    // 
    // Parameter related stuffs
    // 
    int          needed_param_vars; 
    LIST<STRING> extra_variables; 
    int          needs_temperature;
    int          temperature_mode; 
    double       temp_ini; 
    LIST<STRING> param_names; 
    LIST<int>    param_locations; 
    LIST<double> param_ini; 
    LIST<int>    param_mode; 
    
    // 
    // state_var_shear_alter is the transform for shear components in vint, vaux. 
    // if it is M_SQRT2 the output uses engineering shear.. (i.e. ein12*2)
    // if it is 1.0/M_SQRT2 you get what zebulon gives - the real component
    // The default is engineering shear to be consistant with sig and eto 
    // which cannot be adjusted. 
    // 
    double       state_var_shear_alter; 
    LIST<int>    vint_sqrt2_pos; 
    LIST<int>    vaux_sqrt2_pos; 

    //
    //  Stuff for auto time stepping
    //
    LIST<STRING> limit_vars;
    LIST<double> limit_vals;
    double       security;
    double       divergence;
    int          divergence_details;

    // 
    // 
    // 
    int keep_debug_flag; 
    int use_local_debug; 
    LIST<int> debug_ele; 
    LIST<int> debug_gp; 
    double start_debug_time; 
    double end_debug_time; 

    // 
    // If your material file needs parameters but you're too lazy to 
    // make field variables in the input deck
    // 
    LIST<STRING>  fixed_param_names;
    LIST<double>  fixed_param_values;

    // 
    // 
    // 
    int     legacy_small_strain;   // requires the ***behavior <type> explicit  wrapper
    int     skip_thickness_change;   // for abq explicit
    int     suppress_doing_first; 
    int     doing_first; 
    int     first_ele,last_ele; 
    int     first_pt,last_pt; 
    int     is_explicit;
    int     explicit_timer_outputs;
    int     explicit_dump_history;
    int     break_on_mat_failure;
    double  zmat_time_ini;
    Zofstream explicit_dump; 
    
    // 
    // Stuff for energy output/monitoring in the various codes. 
    // 
    STRING  plastic_work_name; 
    STORED_VARIABLE_SPEC* plastic_work;

    // 
    // Stuff for stiffness damping (beta damping like in abaqus). Unfortunatly 
    // we can't get rid of the damping stress in the output by doing this
    // 
    PTR<ELASTICITY> elasticity;
    double beta; 

    int modify_density; 
    int update_modulus; 
    int vaux_modulus; 
    int vint_modulus; 

    int kiter;
    int kstep;
    int kincr;

    // 
    // Options 
    // 
    int symmetrize_tgmat, store_F;

    int flux_position, flux_size; 
    int grad_position, grad_size; 

    VECTOR keep_flux; 
    VECTOR grad0; 
    VECTOR dgrad; 

    MATRIX tg_tmp; 

    int is_shell; 
    bool dont_use_drot;

    TENSOR2  kronecker;

    // added to initialize SDVs with a results database
    int preload_step;
    ZMAT_RESULTS_DATABASE* initial_state;

    static bool cmp_name(const char* handler_name, const char* input_name); 
           void set_name(const char* input_name); 

    ZEBABA_HANDLER();
    virtual ~ZEBABA_HANDLER();

    virtual bool read_option(STRING& keyword, ASCII_FILE& zmat_file); 
    virtual void end_of_load_setup(); 

    void set_DeBuG_for_local(int iele, int igp); 

};

Z_END_NAMESPACE;

#endif
