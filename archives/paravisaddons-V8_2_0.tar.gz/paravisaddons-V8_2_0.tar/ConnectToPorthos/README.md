#Introduction
  pqPorthosServerLauncher est un plugin paraview de lancement et de connexion à un serveur porthos de rendering.
  Un petit programme associé permet de saisir le mot de passe ssh

#Dépendances
  cmake >= 3.2
  paraview git master ( git pull après 1er Juin )

#Compilation
  mkdir build
  cd build
  ParaView_DIR=path/to/paraview_build CMAKE_INSTALL_PREFIX=/path/to/install cmake ../src
  make
  sudo make install

#Utilisation
  modifier fichier .pvsc pour répondre à votre besoin
  ouvrir paraview 
  charger le plugin (libpqPorthosServerLauncher.so ) , le mettre en autoload

  clicker sur connect
  load servers
  selectionner fichier .pvsc fourni et modifié
  clicker sur connect
  
  changer le nom d'utilisateur
  changer les options a votre convenance
  clicker sur le bouton de refresh, update available nodes
  si des noeuds sont atteignables et disponibles, clicker sur Launch and connect.
  Le server sera lancé via slurm et paraview se connectera directement dessus en quelque secondes.

#Problématique SSH
  Il est recommandé de mettre en place un configuration ssh par clé publique/privé entre l'utilisateur et porthos
  Si ce n'est pas le cas, il est possible de rentrer le mot de passe, ce a chaque fois qu'une connexion ssh est mise en place,
  a condition que le programme PorthosAskPass ait été installé.
