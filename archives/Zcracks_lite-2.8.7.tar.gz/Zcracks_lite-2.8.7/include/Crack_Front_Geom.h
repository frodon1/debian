#ifndef __CRACK_FRONT_GEOM__
#define __CRACK_FRONT_GEOM__

#include <Vector.h>
#include <Matrix.h>
#include <Stringpp.h>
#include <Geometry.h>
#include<B3Spline.h>

Z_START_NAMESPACE;


class CRACK_FRONT_GEOM_3D : public GEOMETRY
{
  public:
    CRACK_FRONT_GEOM_3D(INTERPOLATION_FUNCTION*);
    virtual ~CRACK_FRONT_GEOM_3D();

    virtual const VECTOR& shape() const;
    virtual const MATRIX& deriv() const;
    double jacob(const MATRIX& elem_coord);
    double jacob2(SMATRIX& jm, const MATRIX& elem_coord);
};
Z_END_NAMESPACE;

#endif
