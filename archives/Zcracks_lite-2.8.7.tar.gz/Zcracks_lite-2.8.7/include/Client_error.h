#ifndef __Client_error__
#define __Client_error__

#include <Error_messager.h>

Z_START_NAMESPACE;

#define CL_ERROR(a) ERROR_MESSAGER::static_err_message(STRING::EMPTY+ a,__FILE__, __LINE__)
#define CL_INTERNAL ERROR_MESSAGER::static_err_message("Internal Error: ",__FILE__, __LINE__)
Z_END_NAMESPACE;

#endif
