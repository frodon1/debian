#ifndef __P_BUF__ 
#define __P_BUF__

#include <Stringpp.h>
#include <Std_cc_stream.h>
#include <Zbuffer_client.h>
#include <Openmode.h>

Z_START_NAMESPACE;

ZCLASS PBUF : public ZFILEBUFFER_CLIENT {
  private :
    int          fbs;
    int          file_id;
    STRING       name;
    IOS_OPENMODE o_mode;
    int          alloc;
    int          state;
    long         f_size;

    PBUF*        open_file();
    PBUF*        close_file();
    ZSTREAMPOS    seekoff_file(ZSTREAMOFF,_SEEK_DIR,int);
    void         flush_file();
    size_t       send_put_buffer();
    size_t       receive_get_buffer();

    void         set_flags(IOS_OPENMODE);
    void         get_file_size();
    void         kill_buffers();

  protected :
    ZSTREAMPOS    file_length;
    ZSTREAMPOS    gstart,gend;
    ZSTREAMPOS    pstart,pend;

    void         init();
    void         reset_get_buffer();

  public :
    static const int openprot;

    PBUF();
    PBUF(int);
    PBUF(int, char*,int);
    virtual ~PBUF();

    PBUF* attach(int);
    virtual ZFILEBUFFER* open(const char *filename, const char *mode);
#ifdef  __GNUC__ 
    virtual ZFILEBUFFER* open(const char *filename, IOS_OPENMODE mode, int prot = 0664);
#else
    virtual ZFILEBUFFER* open(const char *filename, IOS_OPENMODE mode, int prot = 0664);
#endif

    virtual int underflow();
    virtual int overflow(int c = EOF);

    virtual int is_open() const { return file_id >= 0; }
    int fd() const { return is_open() ? file_id : EOF; }

    virtual ZFILEBUFFER* close();

    virtual int doallocate();
    virtual ZSTREAMPOS seekoff(ZSTREAMOFF, _SEEK_DIR, int mode=ZIOS::in|ZIOS::out);
    virtual ZSTREAMPOS seekpos(ZSTREAMPOS pos, int mode);

//
// Following functions are optimisations used only in istream::read()
//  and ostream::write(). If they are not inherited, then libio use default in-out buffered methods.
//
// I'll perhaps (I don't know when) override those for efficiency...
//  The probleme is complex because some // machines impose message lenght limit.
//
//    ZSTREAMSIZE xsputn(const char* s, ZSTREAMSIZE n);
//    ZSTREAMSIZE xsgetn(char* s, ZSTREAMSIZE n);

    virtual int sync();

  protected :

    int is_reading() { return eback() != egptr(); }
    char* cur_ptr() { return is_reading() ?  gptr() : pptr(); }
    // char* file_ptr() { return eGptr(); }
    char* file_ptr() { return pptr(); }

    virtual ZSTREAMSIZE sys_read(char* buf, ZSTREAMSIZE size);
    virtual ZSTREAMPOS sys_seek(ZSTREAMOFF, _SEEK_DIR);
    virtual ZSTREAMSIZE sys_write(const char*, ZSTREAMSIZE);
    virtual int sys_stat(void*);
    virtual int sys_close();
};

Z_END_NAMESPACE;

#endif
