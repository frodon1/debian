#ifndef __PARALLEL_FOR__
#define __PARALLEL_FOR__

#include <Defines.h>

/*

FF, july 09, 2013

PARALLEL_FOR is a block which is able to run loops in parallel by breaking the iterations between threads

*/

Z_START_NAMESPACE;

ZCLASS PARALLEL_FOR
{
  public :
     struct WORKER {
      virtual bool apply(int s, int e, int d)=0;
      WORKER& operator()() { return(*this); }
    };

    PARALLEL_FOR();
    virtual ~PARALLEL_FOR();

    static bool apply(WORKER &w, int start , int end , int delta=1);
};


ZCLASS SEQUENTIAL_FOR
{
  public :
    SEQUENTIAL_FOR();
    virtual ~SEQUENTIAL_FOR();

    static bool apply(PARALLEL_FOR::WORKER &w, int start , int end , int delta=1);
};


Z_END_NAMESPACE;

#endif
