#ifndef __Unique_Array__
#define __Unique_Array__

#include <Buffered_list.h>
#include <Sort_array.h>

Z_START_NAMESPACE;

// Quickly remove duplicates in the list ; 
// this requires to quicksort the list first.
// It should go in Buffered_list.h, once it's settled

template <class T> void unique_array(BUFF_LIST <T>& array)
{ 
  if (array.size() == 0) return;

  ARRAY<int> pos_tmp,apos;
  sort_array(array, pos_tmp);   // FIXME: i should probably use stdlib's qsort, rather than SQ's _recursive_ sort_array 
  apos.resize(pos_tmp.size());
  int nb_unique=pos_tmp.size();
  for(int i=0;i<pos_tmp.size();i++) {
    if(i>0) {
      if(array[i]==array[i-1]) { 
      apos[pos_tmp[i]]=-1;
      nb_unique--;
      } else apos[pos_tmp[i]]=i;
    } else apos[pos_tmp[i]]=i;
  }
  BUFF_LIST<T> uniqued;
  uniqued.resize(nb_unique);
  int idx=0;
  for(int i=0;i<apos.size();i++) 
    if(apos[i]!=-1) uniqued[idx++]=array[apos[i]];

  array.resize(0); 
  array.add_to(uniqued); 
}

Z_END_NAMESPACE;

#endif
