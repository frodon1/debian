#ifndef __Post_multirange__
#define __Post_multirange__

#include <Post_simple.h>
#include <Post_range.h>

Z_START_NAMESPACE;

ZCLASS2 POST_MULTIRANGE : public POST_SIMPLE {
 protected :

  int first_card, ncard, current_cycle, icmax;
  ARRAY<bool>   cards_tagged;
  ARRAY<double> cards_time;

  bool  issue_warning;
  bool  center;
  int   tsz;
  int   reverse;

  AUTO_PTR<POST_RANGE> lp_range;
  ARRAY<VECTOR> out_range;

 public :

  BUFF_LIST<double>  Rstore;  // Really the diameter ...
  BUFF_LIST<VECTOR> Xstore;
  BUFF_LIST<int> begin,end;
  BUFF_LIST<bool> closed;
  ARRAY<int> ranks, order;

  POST_MULTIRANGE();
  virtual ~POST_MULTIRANGE();

  virtual MODIFY_INFO_RECORD* get_modify_info_record();
  virtual bool verify_info();

  virtual void input_i_need(int,ARRAY<STRING>&);
  virtual void output_i_give(bool&,ARRAY<STRING>&);
  void compute(const ARRAY<VECTOR>&,ARRAY<VECTOR>&);
  int real_compute(const ARRAY<VECTOR>& in);

  void set_reverse(int rev) { reverse=rev; }

//  Position of calculated quantities in output VECTOR
//  for a given cycle
//  int pos_card_beg(int icyc);
//  int pos_card_end(int icyc);
  int pos_diameter(int icyc);
  int pos_center(int icyc);

// to loop on cycles in natural order
  void init_loop_on_cycles(int first=0);
  int get_next_cycle_cards(ARRAY<int>& cards);
  int get_next_cycle_def(ARRAY<int>& cards, ARRAY<double>& times);

};
Z_END_NAMESPACE;

#endif
