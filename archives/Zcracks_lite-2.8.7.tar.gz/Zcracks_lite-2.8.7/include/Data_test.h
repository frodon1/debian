#ifndef __Data_test__
#define __Data_test__

// ============================================================================ 
//  class DATA_TEST  is a handler for test outputs.. he keeps a list
//                   of any number of specific tests to go out
//                   to a file.. i am NOT checking to see if the same
//                   filename is used more than once..
//
//  class DATA_TEST_AT is a base class for any data tests.. we are
//                   starting off with node variables.. nset variables
//                   (surface load) and gauss_point vars.
// ============================================================================ 

#include <Zstream.h>

#include <Array.h>
#include <Bool.h>
#include <Hierarchy.h>
#include <List.h>
#include <Stringpp.h>
#include <Z_object.h>

Z_START_NAMESPACE;

class ASCII_FILE;
class MESH;
class NODE;
class NSET;
class P_ELEMENT;
class ELSET; class DOF_ELSET;

class DATA_TEST;
class DATA_TEST_AT;

// ------------------------------------------------------------ 
ZCLASS2 DATA_TEST_AT : public Z_OBJECT { 
  friend class DATA_TEST;
  protected :
     STRING       sep; 
     LIST<STRING> variables;
     LIST<STRING> plot_names;
     DATA_TEST    *its_boss;
     void          read_vars(ASCII_FILE& file);
     bool raw_file;
     VECTOR        small_for_test;
     Zofstream*    test;
  public :
     DATA_TEST_AT();
     virtual ~DATA_TEST_AT() { } 
     virtual void initialize(DATA_TEST*,ASCII_FILE&);
     virtual void  write_test(MESH&)=0;
     virtual void  write_test_plot(MESH&)=0;
     virtual void mesh_changed() {}
     void set_no_default_time(); 
     RTTI_INFO;
};

// ------------------------------------------------------------ 
ZCLASS2 DATA_TEST : public Z_OBJECT { 
  friend class DATA_TEST_AT;
  protected : 
     bool          no_default_time_output; 
     bool          first_line;
     bool          first_time_flag;
     bool          plot_test;
     bool          insert_blank_line;
     int           precision_of_test;
     bool raw_file;
     LIST<double>   small_for_test;
     Zofstream      test;
     PLIST<DATA_TEST_AT> tests;
     bool           _Is_parallel_computation;

 public :
     bool          blank_line_at_mesh_change;
     int           use_int_reac; 
     int           rename_for_rve;  // hack for zebu within z-sim
     STRING        fle_name;
     STRING        sep;

     DATA_TEST();
     ~DATA_TEST();
     static DATA_TEST* read(ASCII_FILE& file, const STRING& pb_name);
     virtual void enable_parallel_computation() { _Is_parallel_computation=TRUE; }
     virtual bool is_parallel_computation() { return _Is_parallel_computation; }

     void              write_test(MESH& mesh);
     void              open_file(IOS_OPENMODE mode); 
     void              close_file(); 
     void              set_plot() { plot_test=TRUE; }
     const STRING&     fname() { return fle_name; }
     void set_no_default_time() { no_default_time_output=TRUE; } 
     void set_no_first_line()   { first_line=FALSE; }

     void mesh_changed();

     int  get_precision_of_test() { return precision_of_test; }

     RTTI_INFO;
}; 
 
// ------------------------------------------------------------ 
Z_END_NAMESPACE;

#endif
