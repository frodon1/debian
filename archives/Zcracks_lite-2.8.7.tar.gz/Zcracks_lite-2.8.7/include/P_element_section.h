
#ifndef __P_element_section__
#define __P_element_section__

#include <P_element.h>
#include <Space_with_section.h> 

Z_START_NAMESPACE;

ZCLASS2 P_ELEMENT_SECTION : public P_ELEMENT {
    public : 
      P_ELEMENT_SECTION( ); 

      SPACE_WITH_SECTION*   geo() { return ((SPACE_WITH_SECTION*)geometry); }
      const SPACE_WITH_SECTION* geo()const { return ((SPACE_WITH_SECTION*)geometry); }

      // 
      // Sizes the mat data to ((SPACE_WITH_SECTION*)geo)->nb_gp_tot())
      // 
      virtual void initialize_element(const ARRAY<GNODE*>& element_nodes,
                              GMESH*                     the_mesh_it_belongs_to,
                              GEOMETRY*                  element_geometry,
                              char*                      the_im,
                              int                        element_id /*tag*/,
                              const char*                ele_type);

      virtual ~P_ELEMENT_SECTION();
      virtual void compute_param_value();

      virtual void get_position_of_integration_point(ARRAY<VECTOR>&,
                                        bool use_coord=FALSE)const;

      virtual void get_position_of_integration_point(VECTOR& pos,
                                        bool use_coord=FALSE)const;

      virtual void get_position_of_integration_point_in_section(VECTOR& pos)const;
      
      // 
      // Basic geometry attributes 
      // 
      const VECTOR&         normal()const;
      const VECTOR&         unitary_normal() const;
      double                radius()const;
      void                  computeQ(TENSOR2& Q) { (geo())->computeQ(Q); }

      const HPSPACE*        ref_line()const { return geo()->ref_line; } 
      HPSPACE*              ref_line()      { return geo()->ref_line; } 

      // 
      // Careful.. these return the geo w/section integration, where 
      // the base ELEMENT::get_integration returns the un-cast integration.. 
      // same thing? 
      // 
      INTEGRATION*           integration()      { return (geo())->integration; }
      const INTEGRATION*     integration()const { return (geo())->integration; }

      double jacob2(SMATRIX& j, const MATRIX& ec) { return (geo())->jacob2(j,ec); }

      void compute_dshape_dx(const MATRIX& ec, MATRIX& dN_dx) { 
             (geo())->compute_dshape_dx(ec,dN_dx); 
      }


      // 
      // Modified output routines for getting the mat vars through thickness.  
      // ** still under development RF 01/2001 ** 
      // 
      virtual int   nb_contour_nodal_outputs() { return 2*nb_node(); }
      virtual void  cal_contour_outputs(const STRING& var_name,VECTOR& val_node);
      virtual void  cal_contour_outputs(int var_key,VECTOR& val_node);
      virtual void  calc_gpval(int gp_pos,
                               P_ELEMENT& ele,
                               BEHAVIOR* b,
                               int     key_index,
                               VECTOR& val_node);
};
Z_END_NAMESPACE;

#endif
