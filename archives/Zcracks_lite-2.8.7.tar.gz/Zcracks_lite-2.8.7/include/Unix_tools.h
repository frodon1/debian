#ifndef __Unix_tools__ 
#define __Unix_tools__ 

#include <Defines.h>
#include <List.h>
#include <Stringpp.h>
#include <NT_tools.h>

Z_START_NAMESPACE;

WIN_THINGIE extern char __program_name[1024];
WIN_THINGIE extern int* zebu_main_argc;
WIN_THINGIE extern char*** zebu_main_argv;

// WIN_THINGIE extern LIST<STRING> loaded_so_libs;
// WIN_THINGIE extern LIST<void*>  loaded_so_handles;


#ifndef _WIN32 

extern bool load_library(STRING lib,
                         bool version_check=FALSE, 
                         LIST<STRING> *files=NULL,
                         LIST<STRING> *md5=NULL,
                         STRING *lw=NULL,
                         bool *ldbg=NULL); 

extern void load_shared_libs(STRING stub="ANY"); 
extern void free_shared_libs(); 
#endif 

WIN_THINGIE LIST<STRING> find_files(STRING search, STRING stub);

//
// e.g. find_files_w_search(Z7PATH+"/lib/Zmaster/*.z7p"))
//
WIN_THINGIE LIST<STRING> find_files_w_search(STRING search);
Z_END_NAMESPACE;

#endif
