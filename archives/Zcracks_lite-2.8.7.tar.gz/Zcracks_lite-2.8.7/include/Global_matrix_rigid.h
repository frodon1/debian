#ifndef _GLOBAL_RIGID_MATRIX_
#define _GLOBAL_RIGID_MATRIX_

/*
 *
 * FF, nov. 12 2002 : this is a new global matrix which internally uses
 * a "real" instance of global matrix.
 *
 * before any resolution, it checks against rigid body motions
 *
 */

#include <Boundary_condition.h>
#include <Global_matrix.h>
#include <Solver_parameter.h>
#include <Matrix.h>

Z_START_NAMESPACE;

class GLOBAL_RIGID_MATRIX;
class RIGID_KERNEL;

ZCLASS2 GRM_BC : public BC {
  protected :
    GLOBAL_RIGID_MATRIX *boss;

  public :
    GRM_BC(GLOBAL_RIGID_MATRIX &m) : BC() { boss=&m; }
    virtual ~GRM_BC() { }

    virtual void load(class ASCII_FILE &, class PROBLEM&, int) { }
    virtual void _update(MESH&);
};

class GLOBAL_RIGID_MATRIX_PARAMETER : public SOLVER_PARAMETER
{
  public :
    STRING local_type,save_rigid_body_motions;
    SOLVER_PARAMETER *local_parameters;
    bool create_bc;
    bool verbose;
    bool global_strong_detection;
    double threshold;
    int n_last;

    GLOBAL_RIGID_MATRIX_PARAMETER();
    virtual ~GLOBAL_RIGID_MATRIX_PARAMETER();

    virtual bool GetResponse(STRING&,ASCII_FILE&);
    RTTI_INFO;
};

ZCLASS2 GLOBAL_RIGID_MATRIX : public GLOBAL_MATRIX {
  friend class GRM_BC;
  friend class RIGID_KERNEL;

  protected :
    SMATRIX K22,schur,schur_plus,inv_schur_plus;
    GLOBAL_MATRIX*        local;
    GRM_BC*               the_bc;
    GLOBAL_RIGID_MATRIX_PARAMETER *param;
    BUFF_LIST<DOF*> bak_fixed;
    BUFF_LIST<double> bak_fixed_value;
    BUFF_LIST<DOF*> dof_to_fix,rigid_fixed;
    int n_last;
    double threshold;
    bool global_strong_detection;
    ARRAY<VECTOR> kernel;
    ARRAY<int> dof_to_fix_in_schur;

  public :
    GLOBAL_RIGID_MATRIX();
    GLOBAL_RIGID_MATRIX(MESH&,char *name=NULL);
    virtual ~GLOBAL_RIGID_MATRIX();

    virtual bool solve(VECTOR& displ,VECTOR& force,int if_compute_inverse,int if_compute_kernel=0);

    virtual void set_parameter(SOLVER_PARAMETER *sp);
    virtual void create(MESH& mesh,char* name=NULL);
    virtual int set_flag(STRING what);
    virtual SMATRIX& operator[](int i);
    virtual const SMATRIX& operator[](int i) const;
    virtual void global_matrix_structure_change(UPDATE_FLAGS ident_flags);
    virtual bool link_to(GLOBAL_MATRIX *K);

    virtual GLOBAL_MATRIX* copy_type(MESH& mesh);
    virtual void copy_to_matrix(GLOBAL_MATRIX& mat_in);
    virtual GLOBAL_MATRIX& duplicate(GLOBAL_MATRIX&);
    
    virtual void store(const D_ELEMENT &e, const SMATRIX &s) { local->store(e,s); }
    virtual bool solve(ARRAY<VECTOR> &, ARRAY<VECTOR> &, int) { NOT_IMPLEMENTED_ERROR("sole([])"); return(FALSE); }
    virtual VECTOR operator *(const VECTOR &v) const { return( (*local)*v ); }
    virtual void arvp(const ARRAY<VECTOR> &, ARRAY<VECTOR> &) const { NOT_IMPLEMENTED_ERROR("arvp"); }
    virtual void normalize_vectors(ARRAY<VECTOR> &av, int i=0) const { local->normalize_vectors(av,i);  }
    virtual void normalize_vector(VECTOR &v) const { local->normalize_vector(v); }
    virtual void compute_schur_complement(ARRAY<DOF *> &ad, MATRIX &m) { local->compute_schur_complement(ad,m); }
    virtual void compute_flexibility_matrix(ARRAY<DOF *> &ad, MATRIX &m, bool verbose_contact) { local->compute_flexibility_matrix(ad,m,verbose_contact); }
    virtual void add_stable_force_to_external_reaction() { local->add_stable_force_to_external_reaction(); }
    virtual bool is_determinant_negative() const { return(local->is_determinant_negative()); }
    virtual GLOBAL_MATRIX_KERNEL* initialize_kernel(const DD_SUB_DOMAIN&);
    virtual KERNEL_MATRIX* get_schur();
    virtual void enable_keep_rigid() { NOT_IMPLEMENTED_ERROR("enable_keep_rigid"); }
    virtual void addmult(const GLOBAL_MATRIX& mat1,double d){local->addmult(mat1,d);};
    virtual void assign(const GLOBAL_MATRIX& mat1){local->assign(mat1);}
    virtual void adddiag(double f){local->adddiag(f);}
    virtual void mult(double f){local->mult(f);}
    virtual void zero_matrix() { local->zero_matrix(); };
    virtual void initialize_structure();
    virtual void partial_times(ARRAY<int>& index,const VECTOR& q, VECTOR& v) { local->partial_times(index,q,v); }
    virtual void partial_times_hyper_rom(int Nb_testing_dof, ARRAY<int>& index, ARRAY<int>& inv_selec, const MATRIX& v, ARRAY<bool>& if_bc, MATRIX& res)
    {local -> partial_times_hyper_rom(Nb_testing_dof, index, inv_selec, v, if_bc, res);}

    virtual double& operator()(int i, int j) { return((*local)(i,j)); }

    RTTI_INFO;

};
Z_END_NAMESPACE;

#endif
