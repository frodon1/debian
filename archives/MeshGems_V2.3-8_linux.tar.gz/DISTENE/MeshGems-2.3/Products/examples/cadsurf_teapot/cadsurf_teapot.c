/* --------------- */
/* BEZIER (teapot) */
/* --------------- */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <meshgems/meshgems.h>
#include <meshgems/cadsurf.h>

typedef struct {
  integer refs;
  integer ic;
  real *express; integer kmax_express;
} teapot_curve_;

typedef struct {
  integer refs;
  integer nc;
  teapot_curve_ *TC;
} teapot_surface_;

typedef struct {
  real eps;
  real *points;
  integer jmax_points;
  integer *faces;
  integer imax_faces;
  integer degenere[32+1];
  integer ns;
  teapot_surface_ *TG2d;
} teapot_glocad_;

teapot_glocad_ glocad;

void read_vrx_pth();
void read_curv();
void decaler(integer iglos, real *u, real *v, real *t);
char *fgetnonblank(FILE *file, char line[], int n, int *inonblank);

void init_teapot()
{
  integer is;

  read_vrx_pth();
  read_curv();

  for (is=1;is<=32;is++) {
    glocad.degenere[is] = 0;
  }
  glocad.degenere[21] = 1;
  glocad.degenere[22] = 1;
  glocad.degenere[23] = 1;
  glocad.degenere[24] = 1;
  glocad.degenere[29] = 1;
  glocad.degenere[30] = 1;
  glocad.degenere[31] = 1;
  glocad.degenere[32] = 1;
}

char *fgetnonblank(FILE *file, char line[], int n, int *inonblank) {
  int j;
  char *ios;

  /*
       007   7     07    BEL '\a'       107   71    47    G
       010   8     08    BS  '\b'       110   72    48    H
       011   9     09    HT  '\t'       111   73    49    I
       012   10    0A    LF  '\n'       112   74    4A    J
       013   11    0B    VT  '\v'       113   75    4B    K
       014   12    0C    FF  '\f'       114   76    4C    L
       015   13    0D    CR  '\r'       115   77    4D    M
  */

  for(;;) {
    ios = fgets(line, n, file);
    if (ios == NULL) return(ios);
    /* nettoyer la ligne */
    /* fgets => the result stored in string is appended with a null character */
    /* => la boucle ci-dessous ne peut pas etre infinie */
    j = -1;
    for(;;) {
      if (line[++j] ==  '\0') break;
      if (line[j] ==  '#' || line[j] == '!' || line[j] == '/'  || line[j] == ';' || line[j] == '\r' || line[j] == '\n') {
        line[j] = '\0'; break; 
      }
      if (line[j] == '\t' || line[j] == '=') {
        line[j] = ' ';
      }
    }
    /* chercher le premier caractere non blanc */
    j = -1;
    for(;;) {
      if (line[++j] ==  '\0') break;
      if (line[j] != ' ') {
        *inonblank = j;
        return(ios);
      }
    }
  }
}

#define FACES(i,j,k) glocad.faces[(i)+(glocad.imax_faces)*((j)+4*(k))-1]   /* FACES(1:imax, 0:3, 0:3) */

void read_vrx_pth()
{
  integer i, j, n;
  char line[256];
  FILE *file;

  file = fopen("teapot.vrx", "r");
  if(!file){
    printf("unable to open teapot.vrx file.\n");
    exit(-1);
  }

  fgetnonblank(file, line, 256, &j);
  sscanf(line, "%d", &n);
  glocad.points = (real*) calloc(3*n, sizeof(real));
  if(!glocad.points){
    printf("unable to allocate %i bytes of memory\n", 3*n*sizeof(real));
    exit(-1);
  }

  glocad.jmax_points = n;
  for(i=1;i<=n;i++){
    fgetnonblank(file, line, 256, &j);
    sscanf(line, "%lf %lf %lf",
	   glocad.points+3*i-3, glocad.points+3*i-2, glocad.points+3*i-1);
  }
  fclose(file);

  file = fopen("teapot.pth", "r");
  if(!file){
    printf("unable to open teapot.pth file.\n");
    exit(-1);
  }

  fgetnonblank(file, line, 256, &j);
  sscanf(line, "%d", &n);
  glocad.faces = calloc(n*4*4, sizeof(integer));
  if(!glocad.faces){
    printf("unable to allocate %i bytes of memory\n", n*4*4*sizeof(integer));
    exit(-1);
  }

  glocad.imax_faces = n;
  for(i=1;i<=n;i++) {
    fgetnonblank(file, line, 256, &j);
    sscanf(line, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",
	   &(FACES(i,0,0)), &(FACES(i,0,1)), &(FACES(i,0,2)), &(FACES(i,0,3)),
	   &(FACES(i,1,0)), &(FACES(i,1,1)), &(FACES(i,1,2)), &(FACES(i,1,3)),
	   &(FACES(i,2,0)), &(FACES(i,2,1)), &(FACES(i,2,2)), &(FACES(i,2,3)),
	   &(FACES(i,3,0)), &(FACES(i,3,1)), &(FACES(i,3,2)), &(FACES(i,3,3)));
  }
  fclose(file);

  glocad.eps = 5.e-8;
}


void extraire(integer iglos, real centre[3], real P1[2], real P2[2], real P3[2])
{
  integer iglosref, k0, k1, k2, k3;
 
  if (iglos <= 24) {
    iglosref = 21;
  } else {
    iglosref = 29;
  }
       
  k0 = FACES(iglosref,0,0);
  k1 = FACES(iglosref,1,0);
  k2 = FACES(iglosref,2,0);
  k3 = FACES(iglosref,3,0);
  
  centre[0] = glocad.points[3*k0-3];
  centre[1] = glocad.points[3*k0-2];
  centre[2] = glocad.points[3*k0-1];
 
  P1[0] = glocad.points[3*k1-3]-centre[0]; P1[1] = glocad.points[3*k1-1]-centre[2];
  P2[0] = glocad.points[3*k2-3]-centre[0]; P2[1] = glocad.points[3*k2-1]-centre[2];
  P3[0] = glocad.points[3*k3-3]-centre[0]; P3[1] = glocad.points[3*k3-1]-centre[2];
}

void set_F(real P1[2], real P2[2], real P3[2], real t, real F[2])
{
  /* axisymetrique case */
  double t2, t3;
 
  t2 = t*t;
  t3 = t2*t;
  F[0] = P1[0]*(3-6*t+3*t2) + P2[0]*(3*t-3*t2) + P3[0]*(t2);
  F[1] = P1[1]*(3*t-6*t2+3*t3) + P2[1]*(3*t2-3*t3) + P3[1]*(t3);
}

void set_Ft(real P1[2], real P2[2], real P3[2], real t, real Ft[2])
{
  /* axisymetrique case */
  double t2;
 
  t2 = t*t;
  Ft[0] = P1[0]*(-6+6*t) + P2[0]*(3-6*t) + P3[0]*(2*t);
  Ft[1] = P1[1]*(3-12*t+9*t2) + P2[1]*(6*t-9*t2) + P3[1]*(3*t2);
}

void set_Ftt(real P1[2], real P2[2], real P3[2], real t, real Ftt[2])
{
  /* axisymetrique case */
  Ftt[0] = P1[0]*(6) + P2[0]*(-6) + P3[0]*(2);
  Ftt[1] = P1[1]*(-12+18*t) + P2[1]*(6-18*t) + P3[1]*(6*t);
}

void surf0(integer iglos, real uv[2], real S[3])
{
  integer i, j, k;
  real u, v;
  real centre[3], P1[2], P2[2], P3[2], t, F_[2];
  real Bu[4], u2, u3, Bv[4], v2, v3, tmp;

  u = uv[0]; v = uv[1];

  if (glocad.degenere[iglos] == 0) {   /* normal patch */
    u2 = u*u;
    u3 = u2*u;
    Bu[0] = 1-3*u+3*u2-u3;
    Bu[1] = 3*u-6*u2+3*u3;
    Bu[2] = 3*u2-3*u3;
    Bu[3] = u3;

    v2 = v*v;
    v3 = v2*v;
    Bv[0] = 1-3*v+3*v2-v3;
    Bv[1] = 3*v-6*v2+3*v3;
    Bv[2] = 3*v2-3*v3;
    Bv[3] = v3;

    S[0] = 0.;
    S[1] = 0.;
    S[2] = 0.;
    for(i=0;i<=3;i++) {
      for (j=0;j<=3;j++) {
	k = FACES(iglos,i,j);
	tmp = Bu[i] * Bv[j];
	S[0] = S[0] + glocad.points[3*k-3] * tmp;
	S[1] = S[1] + glocad.points[3*k-2] * tmp;
	S[2] = S[2] + glocad.points[3*k-1] * tmp;
      }
    }
  } else {   /* degenerated patch */
    t = sqrt(u*u+v*v);
    extraire(iglos, centre, P1, P2, P3);
    set_F(P1, P2, P3, t, F_);
    S[0] = centre[0] + F_[0]*u;
    S[1] = centre[1] + F_[0]*v;
    S[2] = centre[2] + F_[1];
  }
}

void surf1(integer iglos, real uv[2], real Su[3], real Sv[3])
{
  integer i, j, k;
  real u, v, centre[3], P1[2], P2[2], P3[2], t, tu, tv, F_[2], Ft_[2];
  real Bu[4], u2, u3, Bv[4], v2, v3, tmp, Btu[4], Btv[4];
 
  u = uv[0]; v = uv[1];
 
  if (glocad.degenere[iglos] == 0) {   /* normal patch */
    u2 = u*u;
    u3 = u2*u;
    Bu[0] = 1-3*u+3*u2-u3;
    Bu[1] = 3*u-6*u2+3*u3;
    Bu[2] = 3*u2-3*u3;
    Bu[3] = u3;

    Btu[0] = -3+6*u-3*u2;
    Btu[1] = 3-12*u+9*u2;
    Btu[2] = 6*u-9*u2;
    Btu[3] = 3*u2;

    v2 = v*v;
    v3 = v2*v;
    Bv[0] = 1-3*v+3*v2-v3;
    Bv[1] = 3*v-6*v2+3*v3;
    Bv[2] = 3*v2-3*v3;
    Bv[3] = v3;

    Btv[0] = -3+6*v-3*v2;
    Btv[1] = 3-12*v+9*v2;
    Btv[2] = 6*v-9*v2;
    Btv[3] = 3*v2;

    Su[0] = 0.;
    Su[1] = 0.;
    Su[2] = 0.;

    Sv[0] = 0.;
    Sv[1] = 0.;
    Sv[2] = 0.;

    for (i=0;i<=3;i++) {
      for (j=0;j<=3;j++) {
	k = FACES(iglos,i,j);
	tmp = Btu[i] * Bv[j];
	Su[0] = Su[0] + glocad.points[3*k-3] * tmp;
	Su[1] = Su[1] + glocad.points[3*k-2] * tmp;
	Su[2] = Su[2] + glocad.points[3*k-1] * tmp;
	tmp = Bu[i] * Btv[j];
	Sv[0] = Sv[0] + glocad.points[3*k-3] * tmp;
	Sv[1] = Sv[1] + glocad.points[3*k-2] * tmp;
	Sv[2] = Sv[2] + glocad.points[3*k-1] * tmp;
      }
    }
  } else {   /* degenerated patch */
    t = sqrt(u*u+v*v);
    if (t < glocad.eps) {
      /* code = 0   ! derivee non definie, mais on va donner une derivee voisine */
      decaler(iglos, &u, &v, &t);
    }
    extraire(iglos, centre, P1, P2, P3);
    set_F  (P1, P2, P3, t, F_);
    set_Ft (P1, P2, P3, t, Ft_);
    tu = u/t;
    tv = v/t;
 
    Su[0] = Ft_[0]*tu*u + F_[0];
    Su[1] = Ft_[0]*tu*v;
    Su[2] = Ft_[1]*tu;
 
    Sv[0] = Ft_[0]*tv*u;
    Sv[1] = Ft_[0]*tv*v + F_[0];
    Sv[2] = Ft_[1]*tv;
  }
}

void surf2(integer iglos, real uv[2], real Suu[3], real Suv[3], real Svv[3])
{
  integer i, j, k;
  real u, v, centre[3], P1[2], P2[2], P3[2], t, tu, tv, tuu, tuv, tvv;
  real Ft_[2], Ftt_[2];
  real tmp, u2, u3, Bu[4], Btu[4], Bttu[4], v2, v3, Bv[4], Btv[4], Bttv[4], t3, tu2, tv2;
 
  u = uv[0]; v = uv[1];

  if (glocad.degenere[iglos] == 0) {   /* normal patch */
    u2 = u*u;
    u3 = u2*u;
    Bu[0] = 1-3*u+3*u2-u3;
    Bu[1] = 3*u-6*u2+3*u3;
    Bu[2] = 3*u2-3*u3;
    Bu[3] = u3;

    Btu[0] = -3+6*u-3*u2;
    Btu[1] = 3-12*u+9*u2;
    Btu[2] = 6*u-9*u2;
    Btu[3] = 3*u2;

    Bttu[0] = 6-6*u;
    Bttu[1] = -12+18*u;
    Bttu[2] = 6-18*u;
    Bttu[3] = 6*u;

    v2 = v*v;
    v3 = v2*v;
    Bv[0] = 1-3*v+3*v2-v3;
    Bv[1] = 3*v-6*v2+3*v3;
    Bv[2] = 3*v2-3*v3;
    Bv[3] = v3;

    Btv[0] = -3+6*v-3*v2;
    Btv[1] = 3-12*v+9*v2;
    Btv[2] = 6*v-9*v2;
    Btv[3] = 3*v2;

    Bttv[0] = 6-6*v;
    Bttv[1] = -12+18*v;
    Bttv[2] = 6-18*v;
    Bttv[3] = 6*v;

    Suu[0] = 0.;
    Suu[1] = 0.;
    Suu[2] = 0.;

    Suv[0] = 0.;
    Suv[1] = 0.;
    Suv[2] = 0.;

    Svv[0] = 0.;
    Svv[1] = 0.;
    Svv[2] = 0.;

    for (i=0;i<=3;i++) {
      for (j=0;j<=3;j++) {
	k = FACES(iglos,i,j);
	tmp = Bttu[i] * Bv[j];
	Suu[0] = Suu[0] + glocad.points[3*k-3] * tmp;
	Suu[1] = Suu[1] + glocad.points[3*k-2] * tmp;
	Suu[2] = Suu[2] + glocad.points[3*k-1] * tmp;
	tmp = Btu[i] * Btv[j];
	Suv[0] = Suv[0] + glocad.points[3*k-3] * tmp;
	Suv[1] = Suv[1] + glocad.points[3*k-2] * tmp;
	Suv[2] = Suv[2] + glocad.points[3*k-1] * tmp;
	tmp = Bu[i] * Bttv[j];
	Svv[0] = Svv[0] + glocad.points[3*k-3] * tmp;
	Svv[1] = Svv[1] + glocad.points[3*k-2] * tmp;
	Svv[2] = Svv[2] + glocad.points[3*k-1] * tmp;
      }
    }
  } else {   /* degenerated patch */
    t = sqrt(u*u+v*v);
    if (t < glocad.eps) decaler(iglos, &u, &v, &t);
    extraire(iglos, centre, P1, P2, P3);
    set_Ft (P1, P2, P3, t, Ft_);
    set_Ftt(P1, P2, P3, t, Ftt_);
    tu = u/t;
    tv = v/t;
    t3 = t*t*t;
    tuu = v*v/t3;
    tuv = -u*v/t3;
    tvv = u*u/t3;
    tu2 = tu*tu;
    tv2 = tv*tv;
 
    Suu[0] = Ftt_[0]*tu2*u + Ft_[0]*(tuu*u+2*tu);
    Suu[1] = Ftt_[0]*tu2*v + Ft_[0]*tuu*v;
    Suu[2] = Ftt_[1]*tu2 + Ft_[1]*tuu;

    Suv[0] = Ftt_[0]*tv*tu*u + Ft_[0]*(tuv*u+tv);
    Suv[1] = Ftt_[0]*tv*tu*v + Ft_[0]*(tuv*v+tu);
    Suv[2] = Ftt_[1]*tv*tu + Ft_[1]*tuv;
 
    Svv[0] = Ftt_[0]*tv2*u + Ft_[0]*tvv*u;
    Svv[1] = Ftt_[0]*tv2*v + Ft_[0]*(tvv*v+2*tv);
    Svv[2] = Ftt_[1]*tv2 + Ft_[1]*tvv;
  }
}

void decaler(integer iglos, real *u, real *v, real *t) {
  integer k1, k2;
  real mil[2];
  real sqrt2 = 1.4142135623730950488;
 
  k1 = FACES(iglos,3,0);   /* extremite 1 de l'arc exterieur */
  k2 = FACES(iglos,3,3);   /* extremite 2 de l'arc exterieur */
  mil[0] = glocad.points[3*k1-3] + glocad.points[3*k2-3];
  mil[1] = glocad.points[3*k1-2] + glocad.points[3*k2-2];
 
  if (mil[0] < 0.) {
    *u = -glocad.eps;
  } else {
    *u =  glocad.eps;
  }
 
  if (mil[1] < 0.) {
    *v = -glocad.eps;
  } else {
    *v =  glocad.eps;
  }
 
  *t = glocad.eps * sqrt2;
}

void read_curv()
{
  integer is, ns, ic, nc, ip, np, j;
  char line[256];
  FILE *file;
  
  file = fopen("teapot.curv", "r");
  if(!file){
    printf("unable to open teapot.curv file.\n");
    return;
  }
  fgetnonblank(file, line, 256, &j);
  sscanf(line, "%d", &ns);

  glocad.TG2d = calloc(ns+1, sizeof(teapot_surface_));
  if(!glocad.TG2d){
    printf("unable to allocate %i bytes of memory.\n", (ns+1)*sizeof(teapot_surface_));
    exit(-1);
  }

  glocad.ns = ns;

  for(is=1;is<=ns;is++) {   /* surfaces */
    glocad.TG2d[is].refs = is;
    fgetnonblank(file, line, 256, &j);
    sscanf(line, "%d", &nc);
    glocad.TG2d[is].TC = calloc(nc+1, sizeof(teapot_curve_));
    if(!glocad.TG2d[is].TC){
      printf("unable to allocate %i bytes of memory.\n", (nc+1)*sizeof(teapot_curve_));
      exit(-1);
    }

    glocad.TG2d[is].nc = nc;
    
    for(ic=1;ic<=nc;ic++) {   /* curves */
      glocad.TG2d[is].TC[ic].refs = is;
      glocad.TG2d[is].TC[ic].ic = ic;
      fgetnonblank(file, line, 256, &j);
      sscanf(line, "%d", &np);
      
      glocad.TG2d[is].TC[ic].express = calloc(2*4*np,sizeof(real));
      if(!glocad.TG2d[is].TC[ic].express){
	printf("unable to allocate %i bytes of memory.\n", (2*4*np)*sizeof(real));
	exit(-1);
      }
      glocad.TG2d[is].TC[ic].kmax_express = np;
      for(ip=1;ip<=np;ip++) {   /* pieces */
	fgetnonblank(file, line, 256, &j);
	sscanf(line, "%lf %lf %lf %lf",
	       glocad.TG2d[is].TC[ic].express+8*ip-8,
	       glocad.TG2d[is].TC[ic].express+8*ip-7,
	       glocad.TG2d[is].TC[ic].express+8*ip-6,
	       glocad.TG2d[is].TC[ic].express+8*ip-5);
	fgetnonblank(file, line, 256, &j);
	sscanf(line, "%lf %lf %lf %lf",
	       glocad.TG2d[is].TC[ic].express+8*ip-4,
	       glocad.TG2d[is].TC[ic].express+8*ip-3,
	       glocad.TG2d[is].TC[ic].express+8*ip-2,
	       glocad.TG2d[is].TC[ic].express+8*ip-1);
      }
    }
  }
  fclose(file);
}

void decomposer_t(integer refs, integer ic, real t, integer *ip, real *r)
{
  integer np, it;
 
  /* connaissant t, trouver *ip (numero du morceau) et *r (reste) */
  np = glocad.TG2d[refs].TC[ic].kmax_express;   /* number of pieces */
  it = (integer)(t);
  *ip = it + 1;
  if (*ip < 1) {
    *ip = 1;
    *r = 0.;
  } else if (*ip > np) {
    *ip = np;
    *r = 1.;
  } else {
    *r = t - it;
  }
}

void curv0(integer refs, integer ic, real t, real uv[2])
{
  /* f(r) = e0 + e1*r + e2*r^2 + e3*r^3 */
  integer ip;
  real r, *e; /* (1:2, 0:3) */
 
  decomposer_t(refs, ic, t, &ip, &r);
  e = &(glocad.TG2d[refs].TC[ic].express[8*ip-8]);
  uv[0] = e[0]+r*(e[1]+r*(e[2]+r*e[3]));
  uv[1] = e[4]+r*(e[5]+r*(e[6]+r*e[7]));
}

void curv1(integer refs, integer ic, real t, real uv[2])
{
  /* f'(r) = e1 + 2*e2*r + 3*e3*r^2 */
  integer ip;
  real r, *e; /* (1:2, 0:3) */
 
  decomposer_t(refs, ic, t, &ip, &r);
  e = &(glocad.TG2d[refs].TC[ic].express[8*ip-8]);
  uv[0] = e[1]+r*(2*e[2]+r*3*e[3]);
  uv[1] = e[5]+r*(2*e[6]+r*3*e[7]);
}

void curv2(integer refs, integer ic, real t, real uv[2])
{
  /* f''(r) = 2*e2 + 6*e3*r */
  integer ip;
  real r, *e; /* (1:2, 0:3) */
 
  decomposer_t(refs, ic, t, &ip, &r);
  e = &(glocad.TG2d[refs].TC[ic].express[8*ip-8]);
  uv[0] = 2*e[2]+r*6*e[3];
  uv[1] = 2*e[6]+r*6*e[7];
}


void free_teapot() {
  free(glocad.points);
  free(glocad.faces);
  /* glocad.TG2d a faire (cf. read_curv) */
}


status_t surf(real *uv, real *xyz,
	      real*du, real *dv,
	      real *duu, real *duv, real *dvv,
	      void *user_data )
{
  teapot_surface_ *s = (teapot_surface_ *)user_data;
 
  if(xyz)
    surf0(s->refs, uv, xyz);

  if(du && dv)
    surf1(s->refs, uv, du, dv);

  if(duu && duv && dvv)
    surf2(s->refs, uv, duu, duv, dvv);

  return STATUS_OK;
}

status_t curv(real t, real *uv,
	    real*dt, real *dtt,
	    void *user_data )
{
  teapot_curve_ *c = (teapot_curve_ *)user_data;

  if(uv)
    curv0(c->refs, c->ic, t, uv);

  if(dt)
    curv1(c->refs, c->ic, t, dt);

  if(dtt)
    curv2(c->refs, c->ic, t, dtt);

  return STATUS_OK;
}



int main(int argc, char **argv)
{
  context_t *ctx = NULL;
  cadsurf_session_t *css = NULL;
  cad_t *c = NULL;
  mesh_t *msh = NULL;
  integer i,j,eid;
  cad_face_t *f;
  status_t ret;

  init_teapot();
  ret = STATUS_OK;

  ctx = context_new();
  c = cad_new(ctx);

  /* Create CAD */
  eid = 0;
  for(i=1;i<=glocad.ns;i++){
    f = cad_face_new(c, i, surf, glocad.TG2d+i);
    for(j=1;j<=glocad.TG2d[i].nc;j++){
      cad_edge_t *e;
      real np = glocad.TG2d[i].TC[j].kmax_express;   /* number of pieces */
      e = cad_edge_new(f, ++eid , 0, np, curv, glocad.TG2d[i].TC+j);
      if((i<=4 || i==19 || i==20) && (j==glocad.TG2d[i].nc)){
	cad_edge_set_property(e, EDGE_PROPERTY_INTERNAL);
	cad_edge_set_property(e, EDGE_PROPERTY_REQUIRED);
      }
    }
  }

  /* give everything to the cadsurf session */
  css = cadsurf_session_new(ctx);
  if(!css)
    return -1;

  ret = cadsurf_set_cad(css, c);
  if(ret != STATUS_OK)
    return -1;

  cadsurf_set_param(css, "verbose", "3");
  cadsurf_set_param(css, "geometric_size_mode", "global");
  cadsurf_set_param(css, "physical_size_mode", "global");
  cadsurf_set_param(css, "global_physical_size", "0.3");
  cadsurf_set_param(css, "gradation", "1.35");
  cadsurf_set_param(css, "min_size", "0.01");
  cadsurf_set_param(css, "geometric_approximation_angle", "3");
  cadsurf_set_param(css, "discard_input_topology", "1");
  cadsurf_set_param(css, "process_3d_topology", "1");


  /* mesh */
  ret = cadsurf_compute_mesh(css);
  if(ret != STATUS_OK)
    return -1;

  /* get the resulting mesh */
  cadsurf_get_mesh(css, &msh);
  if(msh){
    mesh_write_mesh(msh, "aa.mesh");
  }	

  /*release it */
  cadsurf_regain_mesh(css, msh);

  /* clean up everything */
  cadsurf_session_delete(css);

  cad_delete(c);

  context_delete(ctx);

  return 0;
}
