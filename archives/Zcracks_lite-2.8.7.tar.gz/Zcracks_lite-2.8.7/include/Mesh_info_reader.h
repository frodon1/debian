#ifndef __MESH_INFO_READER__
#define __MESH_INFO_READER__

#include <Zstream.h>
#include <Utility_mesh.h>
#include <Stringpp.h>

Z_START_NAMESPACE;

class GEOMETRY_INFO;
class UTILITY_ELSET;

ZCLASS MESH_INFO_READER {
  protected :
    bool _read(ASCII_FILE&);

  public :
    STRING geof_name,type;
    UTILITY_MESH *its_mesh;
    LIST<STRING> elset_name;
    LIST<STRING> elset_type;
    LIST<GEOMETRY_INFO*> geometry_info;

    MESH_INFO_READER() { }
    virtual ~MESH_INFO_READER() { }

    static MESH_INFO_READER* initialize(const STRING&,UTILITY_MESH&,int ipc=0);
    virtual void click(STRING&,UTILITY_MESH*,UTILITY_ELSET*);
    virtual bool handle(STRING&);
};
Z_END_NAMESPACE;

#endif
