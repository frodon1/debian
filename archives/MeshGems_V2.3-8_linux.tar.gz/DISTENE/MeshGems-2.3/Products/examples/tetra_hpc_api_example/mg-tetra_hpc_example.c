
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <meshgems/meshgems.h>
#include <meshgems/tetra_hpc.h>

#define FREE_AND_STRDUP(_p_,_s_) do{if(_p_) free(_p_); _p_=NULL; _p_ = strdup(_s_);}while(0)

/*
 * message callback function
 */
meshgems_status_t my_message_cb(message_t * msg, void *user_data)
{
  char *desc;
  integer e;
  status_t ret;

  ret = message_get_description(msg, &desc);
  if (ret != STATUS_OK) {
    printf("internal error");
    return ret;
  }
  ret = message_get_number(msg, &e);
  if (ret != STATUS_OK) {
    printf("internal error");
    return ret;
  }
  if (e == 0) { /* this is a simple text information */
    printf("%s", desc);
  } else if (e > 0){   /* this is a formatted information */
    printf("INFORMATION %i : %s", e, desc);
  }else if (e < 0) {           /* this is an error */
    printf("ERROR %i: %s", e, desc);
  }

  return STATUS_OK;
}

/* 
 * A macro we will call to cleanly return from the function in case of failure 
 */
#define RETURN_WITH_MESSAGE(_ret, _msg) do{				\
    fprintf(stderr,"%s\n",_msg);					\
    if(ts) tetra_hpc_session_delete(ts);				\
    if(msh) mesh_delete(msh);						\
    if(ctx) context_delete(ctx);					\
    return _ret;							\
  }while(0);


#ifndef MAX
#define MAX(a,b)  ((a)>(b)?(a):(b))
#endif /* !MAX */

/*
 * MAIN PROCEDURE
 */
int main(int argc, char *argv[])
{
  char *fileIn = NULL;
  char *fileOut = NULL;
  mesh_t *msh;
  mesh_t *omsh = NULL;
  status_t ret;

  context_t *ctx;
  tetra_hpc_session_t *ts;

  ctx = 0;
  msh = 0;
  ts = 0;
  omsh = 0;

  /* Create the Meshgems working context */
  ctx = context_new();
  if (!ctx)
    return -1;

  /* Set the message callback for our context */
  ret = context_set_message_callback(ctx, my_message_cb, 0);
  if (ret != STATUS_OK)
    return -1;

  ts = tetra_hpc_session_new(ctx);
  if(!ts)
    return -1;

  /* Check input and output files */
  if (argc > 1 && argv[1][0] != '-') {
    FREE_AND_STRDUP(fileIn, argv[1]);
    if (argc > 2) {
      FREE_AND_STRDUP(fileOut, argv[2]);
    }
  }

  if (!fileIn) {
    fprintf(stdout, "ERROR: Missing input file.\n");
    return -1;
  }


  if (!fileOut) {
    int fileInLen = strlen(fileIn);
    char *pchar;
    fileOut = (char *) calloc(fileInLen + 20, sizeof(char));
    if (fileOut) {
      strncpy(fileOut, fileIn, fileInLen + 20);
      pchar = strstr(fileOut + MAX(0,fileInLen-7), ".mesh");
      if (pchar)
        pchar[0] = 0;

      if (fileIn[fileInLen - 1] == 'b') {
        strncat(fileOut, "_tetra_hpc.meshb", fileInLen + 20);
      } else {
        strncat(fileOut, "_tetra_hpc.mesh", fileInLen + 20);
      }
    } else {
      fprintf(stdout, "ERROR: Unable to create output file name.\n");
      return -1;
    }
  }

  /* Read the input file fileIn */
  {
    /* Create the Meshgems mesh and read it */
    if (fileIn) {
      msh = meshgems_mesh_new_read_mesh(ctx, fileIn);
    } else {
      fprintf(stdout, "ERROR: No input file...\n");
      return -1;
    }
    if (!msh) {
      printf("Mesh creation or reading failed \n");
      tetra_hpc_session_delete(ts);
      context_delete(ctx);
      return -1;
    }
  }

  ret = tetra_hpc_set_input_mesh(ts, msh);
  if (ret != STATUS_OK)
    return -1;

  tetra_hpc_set_param(ts, "verbose", "3");
  tetra_hpc_set_param(ts, "max_number_of_threads", "6");
  tetra_hpc_set_param(ts, "gradation", "1.1");


  /* Build the volume mesh */
  ret = tetra_hpc_mesh(ts);
  if (ret != STATUS_OK)
    return -1;

  /* get the resulting mesh */
  ret = tetra_hpc_get_mesh(ts, &omsh);
  if(omsh){
    mesh_write_mesh(omsh, fileOut);
  }	

  /*release it */
  tetra_hpc_regain_mesh(ts, omsh);

  /* clean up everything */
  tetra_hpc_session_delete(ts);
  mesh_delete(msh);
  context_delete(ctx);

  return 0;
}
