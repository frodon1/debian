#ifndef __THERMO_LINEAR_ELASTIC_SD__
#define __THERMO_LINEAR_ELASTIC_SD__

#ifdef ZCHECK
  #include <Z_Random.h>
#endif

#include <File.h>
#include <ZMath.h>
#include <Error_messager.h>
#include <Print.h>

#include <Clock.h>
#include <Mechanical_behavior.h>
#include <Integration_method.h>
#include <Integration_result.h>

Z_START_NAMESPACE;

class THERMO_LINEAR_ELASTIC_SD : public M_TLE_B_SD {
  protected :
     TENSOR2_VINT  eel;
     TENSOR2       ths, previous_ths; 
     TENSOR2       grate; 
     bool          first_time, needs_eel;
     int           plane_stress_idx;
     SMATRIX EE;
     VECTOR v;

     virtual void set_null_stress_component(int);
     virtual void null_result(SMATRIX &A,int k, int &l, VECTOR &v);

  public :
     THERMO_LINEAR_ELASTIC_SD();
     virtual ~THERMO_LINEAR_ELASTIC_SD() { } 

     virtual void initialize(int dim, LOCAL_INTEGRATION*);
     virtual void initialize(ASCII_FILE& file,int dim, LOCAL_INTEGRATION*);
     virtual bool declare_data(AUTO_PTR<AID_PART>&);

     INTEGRATION_RESULT* integrate(MAT_DATA& mdat,const VECTOR& delta_grad, 
                                   MATRIX*& tg_matrix, int flags);

     virtual void impose_grad_rate(const VECTOR&); 
     virtual void material_derivative(double tau, const VECTOR& var_int, VECTOR& dvar); 

     virtual void update_var_aux();

     RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
