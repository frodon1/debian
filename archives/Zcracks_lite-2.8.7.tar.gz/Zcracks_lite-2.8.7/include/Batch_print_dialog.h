#ifndef __Batch_print_dialog__
#define __Batch_print_dialog__
// ------------------------------------------------------------
// ------------------------------------------------------------

#include <Graphics_command.h>
#include <Stringpp.h>
#include <Defines.h>

#include <Print_dialog.h>
#include <Graphics_page.h>

Z_START_NAMESPACE;

class GRAPHICS_DATA_DIALOG;

ZCLASS2 BATCH_PRINT_DIALOG : public PRINT_DIALOG {
  public :
    BATCH_PRINT_DIALOG();
    virtual ~BATCH_PRINT_DIALOG();
};
Z_END_NAMESPACE;

#endif
