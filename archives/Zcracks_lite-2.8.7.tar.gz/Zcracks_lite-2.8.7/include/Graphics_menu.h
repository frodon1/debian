#ifndef __GRAPHICS_MENU__
#define __GRAPHICS_MENU__

#include <Defines.h>
#include <List.h>
#include <Commander.h>

Z_START_NAMESPACE;

//
// FF, January 9 2004
//   a simple container to store menus in an abstract way
//

ZCLASS GRAPHICS_MENU_ITEM
{
};

ZCLASS GRAPHICS_MENU
{
  public :
    LIST<COMMANDER*> cmds;
    LIST<STRING> commands;
    LIST<STRING> accels;
    LIST<STRING> items;
    LIST<STRING> infos;
    LIST<GRAPHICS_MENU*> sub;
    LIST<void*>  internals;

    GRAPHICS_MENU();
    ~GRAPHICS_MENU();

    void add(STRING it, STRING accel, COMMANDER *cmd , STRING c , STRING inf=STRING::EMPTY);
    void add(STRING it, GRAPHICS_MENU *m, COMMANDER *cmd , STRING c , STRING inf=STRING::EMPTY);
    void add_at(int i, STRING it, STRING accel, COMMANDER *cmd , STRING c , STRING inf=STRING::EMPTY);
    void add_after(STRING it, const STRING& after, STRING accel, COMMANDER *cmd , STRING c , STRING inf=STRING::EMPTY);
    void set_internal(STRING it, void *intern);
    void reset();
};

ZCLASS GRAPHICS_MENU_BAR
{
  public :
    LIST<STRING> names;
    LIST<char> short_cuts;
    LIST<GRAPHICS_MENU*> popups;
 
    GRAPHICS_MENU_BAR();
    ~GRAPHICS_MENU_BAR();

    void add(STRING,char,GRAPHICS_MENU*);
    void add_to_menu(STRING menu, STRING it, STRING accel, COMMANDER *cmd , STRING c , STRING inf=STRING::EMPTY);
    void add_to_menu(STRING menu, int pos, STRING it, STRING accel, COMMANDER *cmd , STRING c , STRING inf=STRING::EMPTY);
    void add_to_menu_after(STRING menu, const STRING& after, STRING it, STRING accel, COMMANDER *cmd , STRING c , STRING inf=STRING::EMPTY);
};
Z_END_NAMESPACE;

#endif
