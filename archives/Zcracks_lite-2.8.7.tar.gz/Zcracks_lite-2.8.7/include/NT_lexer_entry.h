#ifndef __NT_LEXER_ENTRY__
#define __NT_LEXER_ENTRY__

#include <Master_interactive_lexer_control.h>

Z_START_NAMESPACE;

class NT_LEXER_ENTRY : public MASTER_INTERACTIVE_LEXER_CONTROL
{
  public :
    NT_LEXER_ENTRY();
    virtual ~NT_LEXER_ENTRY();

    void setup();
    void clicked();
    void enter();
};
Z_END_NAMESPACE;

#endif
