//
// Gosselet 2004, Generic iterative solvers (mostly used with generic_dd)
// see P. Gosselet thesis (2003), nice paper soon
//
// Base class for generic iterative solvers
//
#ifndef __N_ITERATIVE_SOLVER__
#define __N_ITERATIVE_SOLVER__

#include <Zstream.h>
#include <File.h>
#include <Solver_parameter.h>
#include <Iterative_solver_operator.h>
#include <Error_messager.h>
#include <Z_object.h>
#include <Verbose.h>
#include <Out_message.h>
#include <Calcul_timer.h>
#include <Message_passing_client.h>

#include <Algebra_like.h>
#include <Projector_like.h>

Z_START_NAMESPACE;

//
//  designed to solve M A P x = M R
//  where A is an operator 
//  P a specific projector (provided by the formulation)
//  M is a preconditioner
//  additional constraint C^T Resid = 0 can also be imposed
//  (C being constructed from information arising 
//            from the formulation and the solver)
//

class N_ITERATIVE_SOLVER_PARAMETER : public SOLVER_PARAMETER {
  protected:
    void set_convergence_norm(STRING);
    void set_convergence_factor(STRING);
  public :
    int       max_iteration,min_iteration,standing_iteration;
    int       output_every_iter,load_augm_number;
    double    precision,epsmp;
    bool      output_to_file,load_augm,save_augm,selec,firstmp;
    STRING    output_file_name,cv_type,cv_factor_type;
    enum CONVERGENCE_NORM_TYPE  { NORMAL, PRECOND, EXTERNAL};
    CONVERGENCE_NORM_TYPE convergence_norm_type,convergence_factor_type; 

    N_ITERATIVE_SOLVER_PARAMETER() : SOLVER_PARAMETER() {
      output_every_iter=10; max_iteration=1000;min_iteration=0;
      standing_iteration=30;precision=1.e-8; output_to_file=FALSE;selec=false;
      cv_type="normal";cv_factor_type="normal";set_convergence_norm(cv_type);set_convergence_factor(cv_factor_type);
      load_augm=save_augm=FALSE;load_augm_number=1;firstmp=false;epsmp=1.;;
    }
    virtual ~N_ITERATIVE_SOLVER_PARAMETER() { }

    virtual bool GetResponse(STRING&,ASCII_FILE&);
    RTTI_INFO;
};


class N_ITERATIVE_SOLVER : public Z_OBJECT {
  protected:
//    N_ITERATIVE_SOLVER_PARAMETER *parameters;
    ITERATIVE_SOLVER_OPERATOR *provider;
    AUTO_PTR<PROJECTOR_LIKE> augmentation_projector;
//    AUTO_PTR<OPERATOR_LIKE> augmentation_projector;
    AUTO_PTR<MATRIX_LIKE> augmentation_matrix,storage_matrix;
  public :
    N_ITERATIVE_SOLVER_PARAMETER *parameters;
    AUTO_PTR<VECTOR_LIKE> X,Xs,R,Rs,X00;
    AUTO_PTR<OPERATOR_LIKE> opera,preco,given_projector;
    N_ITERATIVE_SOLVER();
    virtual void set_parameter(SOLVER_PARAMETER*); 
    enum CSTATUS {unknown,converged,max_iter_exc,standing};
    CSTATUS status;
    virtual void check_status();
    Zofstream ofile;
    //
    double ratio;
    int niter;
    bool provide_initialization;
    //
    virtual void convergence_info();
    virtual void set_operator(ITERATIVE_SOLVER_OPERATOR*);
    virtual void update_operator(ITERATIVE_SOLVER_OPERATOR*);
    virtual void loop()=0;
    virtual void reset() { }
    virtual ~N_ITERATIVE_SOLVER(){if(parameters->output_to_file) ofile.close();}
    void set_augmentation(AUTO_PTR<MATRIX_LIKE> mm) {*storage_matrix = *mm;}
    void give_me_augmentation(AUTO_PTR<MATRIX_LIKE> mm) {*mm=*augmentation_matrix;}
    virtual void handle_augmentation();

    //GLOBAL_MATRIX* get_mixed(){return(NULL);}
    
    
    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
