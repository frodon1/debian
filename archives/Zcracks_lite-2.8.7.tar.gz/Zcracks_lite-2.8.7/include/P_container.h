#ifndef __P_container__
#define __P_container__

#include <Stringpp.h>
#include <List.h>
#include <Verbose.h>
#include <Std_cc_stream.h>
#include <Auto_readable.h>
#include <Auto_input_data_part.h>
#include <File.h>

Z_START_NAMESPACE;

class GLOBAL_PARAMETER;

ZCLASS P_CONTAINER {
   public :
      P_CONTAINER();

      void write_out()const;
      void update(const char* p, const char* s);
      void add(GLOBAL_PARAMETER *gp, const char* n, const char *help);
     
      void get_cmd_line(LIST<STRING>&);

      GLOBAL_PARAMETER* get(const char* n,bool verify=TRUE);

      void scan_init_files(bool issue_error=TRUE);
      void init_from_file(ASCII_FILE&, bool issue_error=TRUE);

      int size();
      STRING name(int);
      STRING help(int);
      GLOBAL_PARAMETER* get(int);
};

struct P_CONTAINER_DESCRIPTION : public AUTO_READABLE
{
  STRING name,value;

  virtual bool declare_data(AUTO_PTR<AID_PART> &_data) {
    AID_LIST *data=new AID_LIST("global_parameter");
    data->add(new AID_STRING("name","Name of the parameter",name));
    data->add(new AID_STRING("value","Value of the parameter",value));
    _data=data;
    return(true);
  }
};

extern WIN_THINGIE P_CONTAINER gpco;

#define GPINT(a)    ( *( (int*)   ( gpco.get((a),TRUE)->value() ) ) )
#define GPSTR(a)    ( *( (STRING*)( gpco.get((a),TRUE)->value() ) ) )
#define GPDOUBLE(a) ( *( (double*)( gpco.get((a),TRUE)->value() ) ) )
Z_END_NAMESPACE;

#include <Global_parameter.h>

#endif
