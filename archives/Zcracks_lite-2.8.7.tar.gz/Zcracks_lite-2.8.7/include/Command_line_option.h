#ifndef __CMD_LINE_OPTION__
#define __CMD_LINE_OPTION__

#include <Defines.h>

Z_START_NAMESPACE;

typedef int (*CMD_ANALYZER)(int&,char**&);

ZCLASS STA_CMD_ANALYZER {
  public :
    STA_CMD_ANALYZER(const char*,int,CMD_ANALYZER);

    static int parse_cmd_line(int&,char**&);
};

#define DECLARE_CMD_LINE_OPTION(kk,k,p,f) static STA_CMD_ANALYZER STACMDANALYZER##kk( k , p,f)
Z_END_NAMESPACE;

#endif
