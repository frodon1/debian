#ifndef __FRONT_KERNEL__
#define __FRONT_KERNEL__

#include <Global_matrix_kernel.h>

Z_START_NAMESPACE;

ZCLASS2 FRONT_KERNEL : public GLOBAL_MATRIX_KERNEL {

  public :
    FRONT_KERNEL(GLOBAL_MATRIX&);
    FRONT_KERNEL(const DD_SUB_DOMAIN&,GLOBAL_MATRIX&);

    virtual ~FRONT_KERNEL();

    virtual bool build_kernel(int,bool);
    virtual void fix_dof();
};
Z_END_NAMESPACE;

#endif
