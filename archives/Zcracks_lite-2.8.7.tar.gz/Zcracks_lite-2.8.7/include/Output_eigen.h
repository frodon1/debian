#ifndef __Output_eigen__
#define __Output_eigen__

#include <Output.h>
#include <Output_z7.h>

Z_START_NAMESPACE;

ZCLASS2 EIGEN_OUTPUT : public OUTPUT_Z7 {
  protected :
     int first_output; 

  public :
     Zfstream eigen_info_file;
     Zfstream eigen_file;

     STRING   eigen_restart_name; 
     Zfstream eigen_restart;
      
     EIGEN_OUTPUT(); 
     virtual ~EIGEN_OUTPUT();
     virtual void open_files(MODE m=OPEN);
     virtual void write_ut_header(MESH& mesh); 
     virtual void write_ut(MESH&);
     virtual void output_eigen(int,double,double,VECTOR&,MESH&);

     RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
