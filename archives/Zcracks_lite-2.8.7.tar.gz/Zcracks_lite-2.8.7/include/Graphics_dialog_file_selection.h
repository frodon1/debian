#ifndef __GRAPHICS_DIALOG_FILE_SELECTION__
#define __GRAPHICS_DIALOG_FILE_SELECTION__

#include <Graphics_dialog_piece.h>

Z_START_NAMESPACE;

// ---------------------------------------- 
//  Text fields 
// ---------------------------------------- 

ZCLASS FILE_SELECTION_APPLICATION_MESSAGE : public APPLICATION_MESSAGE {
  public :
    STRING contens;

    FILE_SELECTION_APPLICATION_MESSAGE();
    virtual ~FILE_SELECTION_APPLICATION_MESSAGE() { }

    RTTI_INFO;
};

ZCLASS GRAPHICS_DIALOG_FILE_SELECTION : public GRAPHICS_DIALOG_PIECE {
  public :
    STRING val;
    enum FLAG { DEFAULT=0, LARGE_DATA=2 };
    FLAG flag;

    GRAPHICS_DIALOG_FILE_SELECTION();
    virtual ~GRAPHICS_DIALOG_FILE_SELECTION() { }

    virtual STRING get_value();

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
