#ifndef __Ziostream__
#define __Ziostream__

//============================================================================ 
// Ziostream.h     attempt at re-defining the use of c++ iostreams for 
//                 use in Z-set to avoid portability issues, and especially 
//                 compiler/compiler conflicts when linking with other solvers
//                 using some C++ (e.g. abaqus and eventually ansys). 
//
//                 RF 12/26/2002 
//============================================================================ 

#define ZIOSTATE int

#include <Zios.h>
#include <Zstreambuf.h>
#include <Defines.h> 

Z_START_NAMESPACE;

extern WIN_THINGIE ZIOS& dec(ZIOS&);
extern WIN_THINGIE ZIOS& hex(ZIOS&);
extern WIN_THINGIE ZIOS& oct(ZIOS&);

ZCLASS ZISTREAM : virtual public ZIOS {
  private:
    ZISTREAM(ZIOS&);
    int getint(char *);
    int getdouble(char *, int);
    int _fGline;
    int x_gcount;

  protected:
    ZISTREAM();
    ZISTREAM(const ZISTREAM&);    // treat as private
    ZISTREAM& operator=(ZSTREAMBUF* _isb); // treat as private
    ZISTREAM& operator=(const ZISTREAM& _is) { return operator=(_is.rdbuf()); }
    ZISTREAM& get(char *, int, int);
    int do_ipfx(int);

  public:
    ZISTREAM(ZSTREAMBUF*);
    virtual ~ZISTREAM();

    int  ipfx(int =0);
    void isfx() { unlockbuf(); unlock(); }

    inline ZISTREAM& operator>>(ZISTREAM& (* _f)(ZISTREAM&));
    inline ZISTREAM& operator>>(ZIOS& (* _f)(ZIOS&));
    ZISTREAM& operator>>(char *);
    inline ZISTREAM& operator>>(unsigned char *);
    inline ZISTREAM& operator>>(signed char *);
    ZISTREAM& operator>>(char &);
    inline ZISTREAM& operator>>(unsigned char &);
    inline ZISTREAM& operator>>(signed char &);
    ZISTREAM& operator>>(short &);
    ZISTREAM& operator>>(unsigned short &);
    ZISTREAM& operator>>(int &);
    ZISTREAM& operator>>(unsigned int &);
    ZISTREAM& operator>>(long &);
    ZISTREAM& operator>>(unsigned long &);
    ZISTREAM& operator>>(float &);
    ZISTREAM& operator>>(double &);
    ZISTREAM& operator>>(long double &);
    ZISTREAM& operator>>(ZSTREAMBUF*);
#ifdef AIX5
    ZISTREAM& operator>>(long long &);
#endif 

    int get();

    inline ZISTREAM& get(         char *,int,char ='\n');
    inline ZISTREAM& get(unsigned char *,int,char ='\n');
    inline ZISTREAM& get(  signed char *,int,char ='\n');

    ZISTREAM& get(char &);
    inline ZISTREAM& get(unsigned char &);
    inline ZISTREAM& get(  signed char &);

    ZISTREAM& get(ZSTREAMBUF&,char ='\n');
    inline ZISTREAM& getline(         char *,int,char ='\n');
    inline ZISTREAM& getline(unsigned char *,int,char ='\n');
    inline ZISTREAM& getline(  signed char *,int,char ='\n');

    inline ZISTREAM& ignore(int =1,int =EOF);
    ZISTREAM& read(char *,int);
    inline ZISTREAM& read(unsigned char *,int);
    inline ZISTREAM& read(signed char *,int);

    int gcount() const { return x_gcount; }
    int peek();
    ZISTREAM& putback(char);
    int sync();

    ZISTREAM& seekg(ZSTREAMPOS);
    ZISTREAM& seekg(ZSTREAMOFF,ZIOS::SEEK_DIR);
    ZSTREAMPOS tellg();

    void eatwhite();
};

inline ZISTREAM& ZISTREAM::operator>>(ZISTREAM& (* _f)(ZISTREAM&)) { (*_f)(*this); return *this; }
inline ZISTREAM& ZISTREAM::operator>>(ZIOS& (* _f)(ZIOS&)) { (*_f)(*this); return *this; }

inline ZISTREAM& ZISTREAM::operator>>(unsigned char * _s) { return operator>>((char *)_s); }
inline ZISTREAM& ZISTREAM::operator>>(  signed char * _s) { return operator>>((char *)_s); }

inline ZISTREAM& ZISTREAM::operator>>(unsigned char & _c) { return operator>>((char &) _c); }
inline ZISTREAM& ZISTREAM::operator>>(  signed char & _c) { return operator>>((char &) _c); }

inline ZISTREAM& ZISTREAM::get(         char * _b, int _lim, char _delim) { return get(        _b, _lim, (int)(unsigned char)_delim); }
inline ZISTREAM& ZISTREAM::get(unsigned char * _b, int _lim, char _delim) { return get((char *)_b, _lim, (int)(unsigned char)_delim); }
inline ZISTREAM& ZISTREAM::get(signed   char * _b, int _lim, char _delim) { return get((char *)_b, _lim, (int)(unsigned char)_delim); }

inline ZISTREAM& ZISTREAM::get(unsigned char & _c) { return get((char &)_c); }
inline ZISTREAM& ZISTREAM::get(  signed char & _c) { return get((char &)_c); }

inline ZISTREAM& ZISTREAM::getline(         char * _b,int _lim,char _delim) { lock(); _fGline++; get(        _b, _lim, (int)(unsigned char)_delim); unlock(); return *this; }
inline ZISTREAM& ZISTREAM::getline(unsigned char * _b,int _lim,char _delim) { lock(); _fGline++; get((char *)_b, _lim, (int)(unsigned char)_delim); unlock(); return *this; }
inline ZISTREAM& ZISTREAM::getline(  signed char * _b,int _lim,char _delim) { lock(); _fGline++; get((char *)_b, _lim, (int)(unsigned char)_delim); unlock(); return *this; }

inline ZISTREAM& ZISTREAM::ignore(int _n,int _delim) { lock(); _fGline++; get((char *)0, _n+1, _delim); unlock(); return *this; }

inline ZISTREAM& ZISTREAM::read(unsigned char * _ptr, int _n) { return read((char *) _ptr, _n); }
inline ZISTREAM& ZISTREAM::read(  signed char * _ptr, int _n) { return read((char *) _ptr, _n); }

ZCLASS ZISTREAM_WITHASSIGN : public ZISTREAM {
         public:
             ZISTREAM_WITHASSIGN();
             ZISTREAM_WITHASSIGN(ZSTREAMBUF*);
             ~ZISTREAM_WITHASSIGN();
     ZISTREAM& operator=(const ZISTREAM& _is) { return ZISTREAM::operator=(_is); }
     ZISTREAM& operator=(ZSTREAMBUF* _isb) { return ZISTREAM::operator=(_isb); }
};


// extern istream_withassign cin;

//---------------------------------------------------------------------------- 
// 
//---------------------------------------------------------------------------- 
ZCLASS ZOSTREAM : virtual public ZIOS {
  private:
        ZOSTREAM(ZIOS&);
        ZOSTREAM& writepad(const char *, const char *);
        int x_floatused;

  protected:
        ZOSTREAM();
        ZOSTREAM(const ZOSTREAM&);        // treat as private
        ZOSTREAM& operator=(ZSTREAMBUF*); // treat as private
        ZOSTREAM& operator=(const ZOSTREAM& _os) {return operator=(_os.rdbuf()); }
        int do_opfx(int);               // not used
        void do_osfx();                 // not used

  public:
        ZOSTREAM(ZSTREAMBUF*);
        virtual ~ZOSTREAM();

        ZOSTREAM& flush();
        int  opfx();
        void osfx();

inline  ZOSTREAM& operator<<(ZOSTREAM& (* _f)(ZOSTREAM&));
inline  ZOSTREAM& operator<<(ZIOS& (* _f)(ZIOS&));
        ZOSTREAM& operator<<(const char *);
inline  ZOSTREAM& operator<<(const unsigned char *);
inline  ZOSTREAM& operator<<(const signed char *);
inline  ZOSTREAM& operator<<(char);
        ZOSTREAM& operator<<(unsigned char);
inline  ZOSTREAM& operator<<(signed char);
        ZOSTREAM& operator<<(short);
        ZOSTREAM& operator<<(unsigned short);
        ZOSTREAM& operator<<(int);
        ZOSTREAM& operator<<(unsigned int);
        ZOSTREAM& operator<<(long);
        ZOSTREAM& operator<<(unsigned long);
inline  ZOSTREAM& operator<<(float);
        ZOSTREAM& operator<<(double);
        ZOSTREAM& operator<<(long double);
        ZOSTREAM& operator<<(const void *);
        ZOSTREAM& operator<<(ZSTREAMBUF*);
#ifdef AIX5
        ZOSTREAM& operator<<(long long &);
#endif 

inline  ZOSTREAM& put(char);
        ZOSTREAM& put(unsigned char);
inline  ZOSTREAM& put(signed char);
        ZOSTREAM& write(const char *,int);
inline  ZOSTREAM& write(const unsigned char *,int);
inline  ZOSTREAM& write(const signed char *,int);
        ZOSTREAM& seekp(ZSTREAMPOS);
        ZOSTREAM& seekp(ZSTREAMOFF,ZIOS::SEEK_DIR);
        ZSTREAMPOS tellp();


};

inline ZOSTREAM& ZOSTREAM::operator<<(ZOSTREAM& (* _f)(ZOSTREAM&)) { (*_f)(*this); return *this; }
inline ZOSTREAM& ZOSTREAM::operator<<(ZIOS& (* _f)(ZIOS& )) { (*_f)(*this); return *this; }

inline  ZOSTREAM& ZOSTREAM::operator<<(char _c) { return operator<<((unsigned char) _c); }
inline  ZOSTREAM& ZOSTREAM::operator<<(signed char _c) { return operator<<((unsigned char) _c); }

inline  ZOSTREAM& ZOSTREAM::operator<<(const unsigned char * _s) { return operator<<((const char *) _s); }
inline  ZOSTREAM& ZOSTREAM::operator<<(const signed char * _s) { return operator<<((const char *) _s); }

inline  ZOSTREAM& ZOSTREAM::operator<<(float _f) { x_floatused = 1; return operator<<((double) _f); }

inline  ZOSTREAM& ZOSTREAM::put(char _c) { return put((unsigned char) _c); }
inline  ZOSTREAM& ZOSTREAM::put(signed char _c) { return put((unsigned char) _c); }

inline  ZOSTREAM& ZOSTREAM::write(const unsigned char * _s, int _n) { return write((char *) _s, _n); }
inline  ZOSTREAM& ZOSTREAM::write(const signed char * _s, int _n) { return write((char *) _s, _n); }


ZCLASS ZOSTREAM_WITHASSIGN : public ZOSTREAM {
         public:
                 ZOSTREAM_WITHASSIGN();
                 ZOSTREAM_WITHASSIGN(ZSTREAMBUF* _is);
                 ~ZOSTREAM_WITHASSIGN();
     ZOSTREAM& operator=(const ZOSTREAM& _os) { return ZOSTREAM::operator=(_os.rdbuf()); }
     ZOSTREAM& operator=(ZSTREAMBUF* _sb) { return ZOSTREAM::operator=(_sb); }
};

// extern ostream_withassign cout;
// extern ostream_withassign cerr;
// extern ostream_withassign clog;

inline ZOSTREAM& flush(ZOSTREAM& _outs) { return _outs.flush(); }
inline ZOSTREAM& endl(ZOSTREAM& _outs) { return _outs << '\n' << flush; }
inline ZOSTREAM& ends(ZOSTREAM& _outs) { return _outs << char('\0'); }

//---------------------------------------------------------------------------- 
// 
//---------------------------------------------------------------------------- 
ZCLASS ZIOSTREAM : public ZISTREAM, public ZOSTREAM {
  private:
    ZIOSTREAM(ZIOS&);
    ZIOSTREAM(ZISTREAM&);
    ZIOSTREAM(ZOSTREAM&);

  protected:
    ZIOSTREAM();
    ZIOSTREAM(const ZIOSTREAM&);
    ZIOSTREAM& operator=(ZSTREAMBUF* _sb) {
           ZISTREAM::operator=(_sb);
           ZOSTREAM::operator=(_sb);
           return *this;
    }

    ZIOSTREAM& operator=(ZIOSTREAM& _strm) {
           return operator=(_strm.rdbuf());
    }

  public:
    ZIOSTREAM(ZSTREAMBUF*);
    virtual ~ZIOSTREAM();
};

extern WIN_THINGIE ZISTREAM& In; 

// class Iostream_init {
// public:
//         Iostream_init();
//         Iostream_init(ZIOS &, int =0);   // treat as private
//         ~Iostream_init();
// };
Z_END_NAMESPACE;

#endif  
