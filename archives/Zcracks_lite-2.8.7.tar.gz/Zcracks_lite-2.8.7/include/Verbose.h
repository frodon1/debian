#ifndef __Verbose__
#define __Verbose__

#include <stdio.h>
#include <stdlib.h>
#include <Defines.h>
#include <Std_cc_stream.h>

Z_START_NAMESPACE;

//
// Verbose must be an int, in order to store the verbosity level (in the future)
//

extern WIN_THINGIE int Verbose;

#ifdef ZCHECK
  #define verbose(ex) if(Verbose>0) Out << (ex)
  #define ExeVerbose(ex) if(Verbose>0) { ex }
#else
  #define verbose(ex)
  #define ExeVerbose(ex)
#endif

Z_END_NAMESPACE;

#endif
