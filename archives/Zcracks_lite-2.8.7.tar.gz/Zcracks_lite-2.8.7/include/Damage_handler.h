#ifndef __Damage_handler__
#define __Damage_handler__
// ---------------------------------------------------------------------------- 
//  DAMAGE_HANDLER   Generalized damage handler.. damage vars are 
//                   in the int_var vector.. stored as params.. 
//                   
//                   * elastic damage model is hard-coded in
//                     move it out quick!
//                   * actually this only does scalar damage..
//                     anisotropic will be in a derived class??
//                   * this is kindof hacked together with respect
//                     to the number of damages
// ---------------------------------------------------------------------------- 

#include <Std_elastic.h>

Z_START_NAMESPACE;

class NL_M_TLE_B_SD; 
class GLOBAL_POT_INTERACTION; 
class DAMAGE_MODEL; 

ZCLASS DAMAGE_HANDLER : public STD_ELASTIC {
  protected : 
    enum FLAG_TYPES { 
        DH_NONE = 0, 
        DH_UNCOUPLED = 4 
    }; 
    
    GLOBAL_POT_INTERACTION* its_inter;
    int                  dsize; 
    double               D;
    int                  dh_flags;  
    int                  calcd;  
    SMATRIX              elas_copy, m_dsig_deel;
    TENSOR2              m_real_stress;	
    TENSOR2              dse_dsig;

    ARRAY<double>        scalar_damages;

    LIST<DAMAGE_MODEL*>  dams;
    double               dmax; 

    double               y_bar;
    VECTOR               d_rate; 

    VECTOR               m_f_vec_damage; 

    MATRIX               m_dsig_ddamage;   
    MATRIX               m_dfeel_ddamage;   
    MATRIX               m_ddamage_deel;   
    MATRIX               m_ddamage_ddamage;   

    ARRAY<MATRIX>        m_dfflow_ddamage;  
    ARRAY<MATRIX>        m_dfhard_ddamage;  
    ARRAY<MATRIX>        m_dfdamage_dflow;
    ARRAY<MATRIX>        m_dfdamage_dhard;

  public : 
                 DAMAGE_HANDLER(); 
    virtual     ~DAMAGE_HANDLER(); 
    virtual void initialize( ASCII_FILE& file, NL_M_TLE_B_SD* boss ); 

    virtual void    handler_setup( const TENSOR2& detot, VECTOR& dvar );
    virtual void    setup(int& flux_pos, int& grad_pos, int& vi_pos, int& va_pos); 

    virtual void    set_matricies( VECTOR&    f_vec,
                                   SMATRIX&   f_grad
                                 );

    virtual const TENSOR2& calc_stress(int num=-1);
//  virtual TENSOR2     real_stress(const VECTOR& var_int, int num=-1);
    virtual TENSOR2     dsig(int num=0);
    virtual double      strain_energy(const VECTOR& var_int);
    virtual MATRIX 	mul_in(MATRIX& mat); 
    virtual TENSOR2 	mul_in(TENSOR2& tens); 
    virtual const SMATRIX& elas_matrix();
    virtual const SMATRIX& dsig_deel();
    virtual const TENSOR2& give_eel()    { return eel; }

    virtual void  g_hat(const VECTOR& dvar, POTENTIAL& pot, int pc);

    virtual const SMATRIX& multi_matrix(); 
    virtual TENSOR2 g_hat_simul(TENSOR2& detot,
                                 const TENSOR2& ctl,
                                 const TENSOR2& de_extra ); 
  
    //  --- special functions
    virtual double give_damage(int pot_num); 
    virtual const TENSOR2&  dsigeff_dsig();
    DERIVED;
};

// ============================================================================ 
//  A special interaction which couples a potential and the 
//  damage handler... kinda spooky. 
//
//  needs to fudge the vdot to vdot/(1-D)
//
//  this must be done in the potential and in the f_vec_flow
//  The evolution terms will then be adjusted.  Note that 
//  the kinematic coefs must be done with the coefficient
//  mechanism... 
// ============================================================================ 

ZCLASS DAMAGE_INTERACTION : public GLOBAL_POT_INTERACTION {
  protected : 
    DAMAGE_HANDLER* its_dh; 
    LIST<POTENTIAL*>* pots; 
  public : 
    DAMAGE_INTERACTION();

    virtual void  initialize(GEN_NL_M_B_SD *b) { INTERACTION::initialize(b); }
    virtual void  initialize(ASCII_FILE& file, GEN_NL_M_B_SD *b) { 
                         INTERACTION::initialize(file,b); }

    virtual void initialize(GEN_NL_M_B_SD *b, GLOBAL_HANDLER *hand); 
    virtual ~DAMAGE_INTERACTION(); 
    
    virtual void  setup(int&, int&, int&, int&); 

    virtual void  do_interaction();

    virtual void  do_interaction( ARRAY<VECTOR>& m_big_h,
                                  const ARRAY<VECTOR>& m_little_h );

    virtual double multi_term(    int pc, const VECTOR& dequ_dhard, 
                                  const ARRAY<VECTOR>& f_vec_hard );

    virtual void  alter_flow(int pc, VECTOR& f_vec_flow);
    virtual void  alter_flow(int pc, const VECTOR&, VECTOR& f_vec_flow);

    virtual void  add_interaction_jacob();
}; 

Z_END_NAMESPACE;

#endif
