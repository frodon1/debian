#ifndef __ZP_INTEG_DATA__
#define __ZP_INTEG_DATA__

#include <ZP_stack.h>
#include <Integ_data.h>
#include <ZP_object.h>
#include <ZP_basic_type.h>

Z_START_NAMESPACE;

ZCLASS2 ZP_INTEG_DATA : public ZP_BASIC_TYPE< INTEG_DATA >
{
  protected :

    virtual void type_init(char*) { type="INTEG_DATA"; }

  public :
    BASIC_CONSTRUCTORS(ZP_INTEG_DATA,INTEG_DATA)

    virtual ZP_FATAL_ERROR* acess(STRING&,ZP_STACK&,bool resolv=FALSE);
    ZPO_RTTI_INFO(INTEG_DATA)
};
Z_END_NAMESPACE;

#endif
