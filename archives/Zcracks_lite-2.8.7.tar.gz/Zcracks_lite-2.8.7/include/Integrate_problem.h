#ifndef __INTEGRATE_PROBLEM__
#define __INTEGRATE_PROBLEM__

#include <Problem.h>
#include <Algorithm.h>

Z_START_NAMESPACE;

/*

FF, 02/02/02

This is a special FE problem which does only the local stage : material integration.
No global problem is solved, and there is no DOF at all...

What is it useful for ? Is it useful to re-use integration algorithms which depends on
external parameters.

GC uses it to model microsctructural evolution of a gear during heat treatment. In this
case external parameter is the temperature history, and the local behavior consists in the
integration of microstructure evolution (differential system on volumic fraction of all phases).

A test is in the database.

*/

ZCLASS2 INTEGRATE_PROBLEM : public PROBLEM {
    public :
       INTEGRATE_PROBLEM();
       virtual ~INTEGRATE_PROBLEM();

       virtual int parallelized() { return(1); }
       virtual void read_restart(RST_FSTREAM&);
       virtual void write_restart(RST_FSTREAM&);
       virtual void init_mesh();

       virtual void create_mesh();

      virtual bool Execute();
      virtual bool Initialize();

      virtual bool make_increment(double);
      virtual void reinit();

      RTTI_INFO;
};

class INTEGRATE_ALGORITHM : public ALGORITHM {
    public :
        INTEGRATE_ALGORITHM();
        virtual ~INTEGRATE_ALGORITHM();

        virtual INTEGRATION_RESULT* convergence_loop(MESH&);
        virtual int can_parallel_computations() { return(1); }
};
Z_END_NAMESPACE;

#endif
