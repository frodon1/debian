#ifndef __HANDLER_MP__
#define __HANDLER_MP__

#include <Bool.h>
#include <Error_messager.h>
#include <Message_passing_exchange.h>
#include <Server.h>
#include <Z_object.h>

Z_START_NAMESPACE;

class STRING;

ZCLASS HANDLER_MP : public MP_EXCHANGE , public Z_OBJECT
{
  protected :
    HANDLER_MP *next;
    ZSERVER *the_server;

    virtual bool can_handle_message(int /* m */) { return(FALSE); }
    virtual int action(int msg_tag);

  public :
    int num_node,who;
    enum MPH_TAGS { Z_ZSIM=1023, ZM_TAG=99999 }; 

    HANDLER_MP() { the_server=NULL; next=NULL; }
    HANDLER_MP(ZSERVER *zs) { the_server=zs; next=NULL; }
    virtual ~HANDLER_MP(void) { }

    void set_server(ZSERVER *s) { the_server=s; }
    void set_who(int w) { who=w; }
    void set_mpi(MP_INTERFACE *m) { mpi=m; }

    int handle_message(int m);
    virtual LIST<int> get_msg_tags() { LIST<int> ret; ret.resize(0); ERROR("Internal error"); return(ret); }

    RTTI_INFO;
};

#define DECLARE_HANDLER protected : virtual bool can_handle_message(int); \
    virtual int action(int); \
    virtual LIST<int> get_msg_tags()

#define IMPLEMENT_HANDLER1(the_class,msg1) \
    bool the_class::can_handle_message(int msg) { return (msg==msg1); } \
    LIST<int> the_class::get_msg_tags() { LIST<int> ret; ret.add(msg1); return(ret); }

#define IMPLEMENT_HANDLER2(the_class,msg1,msg2) \
    bool the_class::can_handle_message(int msg) { return ((msg==msg1)||(msg==msg2)); } \
    LIST<int> the_class::get_msg_tags() { LIST<int> ret; ret.add(msg1); ret.add(msg2); return(ret); }

Z_END_NAMESPACE;
 
#endif
