#ifndef __Output_component_contour__ 
#define __Output_component_contour__ 

//============================================================================ 
// Implementation of CTNOD data... classic **contour option 
//============================================================================ 

#include <Utility_file_driver.h> 
#include <Utility_z8_results.h> 
#include <Output_component.h> 
#include <Behavior.h> 
#include <P_element.h> 
#include <Print.h> 

Z_START_NAMESPACE;

ZCLASS2 OUTPUT_COMPONENT_CTNOD : public OUTPUT_COMPONENT {
   protected :
     STRING       class_key; 
     MESH* its_mesh;
     LIST<STRING> nsets; 
     int          mode_ascii; 
     STRING       nset_name;  

     STRING          last_var; 
     int             last_idx; 

     int        npos;
     ARRAY<int> node_positions;
     ARRAY<int> num_val_at_node; 

   public :
     OUTPUT_COMPONENT_CTNOD();
     virtual ~OUTPUT_COMPONENT_CTNOD();
     virtual void initialize(ASCII_FILE& file);

     virtual void look_at_params(UTILITY_FILE_DRIVER* drv,
                                 MESH& mesh, 
                                 ARRAY<BEHAVIOR*>& behavior);

     virtual void write_output(UTILITY_FILE_DRIVER* drv);
     virtual void get_results(double time, STRING comp); 
};
Z_END_NAMESPACE;

#endif 
