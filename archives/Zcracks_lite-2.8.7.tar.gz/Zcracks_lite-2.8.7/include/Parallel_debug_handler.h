#ifndef _WIN32

#ifndef __PARALLEL_DEBUG_HANDLER__
#define __PARALLEL_DEBUG_HANDLER__

#include <Bool.h>
#include <Handler_mp.h>
#include <Server.h>

Z_START_NAMESPACE;

#define Z_PARALLEL_DEBUG 12376

ZCLASS PARALLEL_DEBUG_HANDLER : public HANDLER_MP
{
  public :
    struct PDB_INFO {
      LIST<int> nodes,other_tids;
      LIST<int> pids;
      LIST<STRING> host_names;
    };
  protected :
    PDB_INFO infos;

    void launch_debugger();

  public :
    int n_node;

    PARALLEL_DEBUG_HANDLER();
    virtual ~PARALLEL_DEBUG_HANDLER(void);

    DECLARE_HANDLER;
    RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
#endif
