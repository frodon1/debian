#ifndef __J_mail__ 
#define __J_mail__ 

#include <Array.h> 
#include <Marray.h> 
#include <ZMath.h> 

Z_START_NAMESPACE;

struct J_MAIL {
   double ener;
   ARRAY< double >*   W;      // energy density at GP
   MARRAY< TENSOR2 >* sigini; // sig at GP
   VECTOR*            dX;     // nodal perturbation
   bool Cstar;
};  
Z_END_NAMESPACE;

#endif 
