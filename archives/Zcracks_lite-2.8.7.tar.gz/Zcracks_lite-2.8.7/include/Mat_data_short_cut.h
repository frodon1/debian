#ifndef ___Mat_data_short_cut__
#define ___Mat_data_short_cut__

Z_START_NAMESPACE;

// conventionnal #define to used with a MAT_DATA instance called mdat
// must be included after all other headers !!!

#define grad            mdat.grad(grad_index)
#define flux            mdat.flux(flux_index)
#define param_set       mdat.param_set()
#define param_set_ini   mdat.param_set_ini()
#define param_set0      mdat.param_set0()
#define var_int         mdat.var_int(vint_index)
#define var_int_ini     mdat.var_int_ini(vint_index)
#define var_aux         mdat.var_aux(vaux_index)
#define var_aux_ini     mdat.var_aux_ini(vaux_index)
Z_END_NAMESPACE;

#endif
