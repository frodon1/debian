#ifndef __Hyper_line_space__
#define __Hyper_line_space__

#include <ZMath.h>
#include <List.h>
#include <Defines.h>
#include <ZMath.h>

#include <GeomSpace.h>
#include <Geometry.h>

Z_START_NAMESPACE;

class VECTOR; class BEHAVIOR; class STRING;

//
// HyperLine Space Element 
//

ZCLASS2 HLSPACE : public GEOMETRY {
    double jacob2(SMATRIX&, const MATRIX&);
  public :
    HLSPACE() { } 
    virtual ~HLSPACE() {}
};


ZCLASS2 HLSPACE2D : public HLSPACE {
  public :
    HLSPACE2D();
    virtual ~HLSPACE2D();
    double jacob(const MATRIX& elem_coord);
};

ZCLASS2 HLSPACE3D : public HLSPACE {
  public :
   HLSPACE3D() { } 
   virtual ~HLSPACE3D() {}
   double jacob(const MATRIX& elem_coord); 
};
Z_END_NAMESPACE;

#endif
