#ifndef __Cosserat_elastic__
#define __Cosserat_elastic__

#include <Elasticity.h>
#include <Mechanical_behavior.h>

Z_START_NAMESPACE;

ZCLASS COSSERAT_BEHAVIOR : public BEHAVIOR {
   protected :
     AUTO_PTR<COSSERAT_ELASTICITY> Ee, Ek;
     SMATRIX m_tg_matrix;
     TENSOR2_GRAD eto, kappa;
//     VECTOR_GRAD phi;
     TENSOR2_FLUX sig, mu;
     TENSOR2_VINT Eel, Kel;
     bool read_mp(const STRING&,ASCII_FILE&);
     void make_mp();
     int  ktsz; 
   public :
     COSSERAT_BEHAVIOR();
     virtual ~COSSERAT_BEHAVIOR();
     virtual void initialize(ASCII_FILE&,int,LOCAL_INTEGRATION*);
     virtual INTEGRATION_RESULT* integrate(MATERIAL_INTEGRATION_INFO&);
};
Z_END_NAMESPACE;

#endif
