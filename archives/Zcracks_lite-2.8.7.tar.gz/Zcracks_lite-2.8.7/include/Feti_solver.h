#ifndef __FETI_SOLVER__
#define __FETI_SOLVER__

#include <Sorted_list.h>
#include <File.h>
#include <CG_solver.h>
#include <P_projector.h>
#include <Global_matrix.h>
#include <Global_matrix_kernel.h>
#include <DD_sub_domain.h>
#include <Parallel_solver.h>
#include <Zstream.h>

Z_START_NAMESPACE;

class V_BOUNDARY;
class OUTPUT;

ZCLASS2 FETI_SOLVER : public PARALLEL_SOLVER , public CG_SOLVER {
  protected :
    enum PRECOND { NONE , LUMPED , DIRICHLET };

    int timer_feti_solver;
    int timer_feti_projector;
    int timer_feti_full;

    int    return_minimum;
    double min_ratio;
    VECTOR keep_disp,previous_lp;

    int use_max,use_absolu;
    double absolu_norm;

    bool displacements_during_convergence;
    bool init_from_previous;
    Zofstream output;
    
    GLOBAL_CLIENT glc;
    MESH *mesh;
    CG_PARAMETER cgp;
    DD_SUB_DOMAIN *domain;
    P_PROJECTOR *projector;
    GLOBAL_MATRIX *K,*Kp;
    GLOBAL_MATRIX_KERNEL *global_kernel;
//
    ARRAY<int> g_fixed_dof_index; // 0 : not fixed, 1 : fixed , 2 : mpc
    ARRAY<double> g_fixed_dof_value; // fixed value or MPC second member

    SORTED_LIST<int> interface_dof_index;
//
    VECTOR q,F,Fp,qp,Fmpc;
    VECTOR alpha2,alpha, displacement;
    VECTOR *dofg,*residualg;
    V_BOUNDARY *vb1,*vb2;
    double eps_projector;
    int  kd_projector;
    int ifci;
    PRECOND preco;
    bool if_keep_rigid, strong_rigid_body_detection;
    int inp_read;

    void internal_initialize();
    void save_fixed_dofs();
    void backup_fixed_dofs();
    void fix_dofs();
    virtual void check_status();

  protected :
    virtual bool initialize(VECTOR&,int);
    virtual void prodD(VECTOR&,VECTOR&);
    virtual void project(VECTOR&,VECTOR&);
    virtual void update_rho_coefficients(double&,double&);
    virtual void update_dgamma_coefficients(ARRAY<double>&);
    virtual double compute_norme(const VECTOR&) const;
    virtual void update_norme(double&);
    virtual void update_primal_vector(double);
    virtual void update_primal_vector_during_initial_projection();
    virtual void convergence_info(double,int,int);
    virtual void precond(VECTOR&,VECTOR&);
    virtual void update_before_precond();

    virtual void check_one(VECTOR&);
    virtual void check_two(VECTOR&);

    void update_domain_boundaries();

    virtual bool GetResponse(STRING&,ASCII_FILE&);

  public :
    FETI_SOLVER();
    virtual ~FETI_SOLVER();

    virtual void initialize(MESH&,DD_SUB_DOMAIN &dom); 
    virtual void read(ASCII_FILE&);

    void set_associated_matrix(GLOBAL_MATRIX *fm) { K=fm; }
    bool solve(GLOBAL_MATRIX*,VECTOR&,VECTOR&,int,int);

    virtual void reset();
};
Z_END_NAMESPACE;

#endif
