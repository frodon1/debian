#ifndef __Results_slice__
#define __Results_slice__

// ============================================================================ 
//  Zmaster results view with a plane (or multiple parallel slices) of the 
//  mesh. we could eventually have cyl slices or surface slices. No plans for 
//  flattening a curved surface however. 
// ============================================================================ 

#include <Marray.h> 
#include <Vector.h> 
#include <Simple_delaunay.h> 

#include <Graphics_command.h> 
#include <Graphics_object.h> 
#include <Results_base.h> 
#include <Results_contour.h> 

Z_START_NAMESPACE;

ZCLASS2 RESULTS_SLICE : public RESULTS_CONTOUR 
{ 
  protected :
    virtual void build_wrapper();
    virtual void setup_dialog();

  public :
    RESULTS_SLICE(); 

    virtual ~RESULTS_SLICE(); 

    virtual bool do_command(STRING cmd);
    virtual bool do_click( int, GRAPHICS_POINT& clk, GRAPHICS_OBJECT* target);
};
Z_END_NAMESPACE;

#endif
