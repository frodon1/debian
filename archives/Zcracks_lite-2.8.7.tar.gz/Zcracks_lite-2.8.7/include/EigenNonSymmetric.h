#ifndef __EigenNonSymmetric__
#define __EigenNonSymmetric__

#include <math.h>
#include <Array.h>
#include <Bool.h>
#include <Matrix.h>
#include <Vector.h>
#include <Zminmax.h>

Z_START_NAMESPACE;

ZCLASS EIGEN_NON_SYMMETRIC {
  private :
       static  double pythag_(double *a, double *b);
       static  int csroot_(double *xr, double *xi, double *yr, double *yi);
       static  int cdiv_(double *ar, double *ai, double *br, double *bi, double *cr, double *ci);
       static  int corth_(int *nm, int *n, int *low, int * igh, double *ar, double *ai, double *ortr, double * orti);
       static  int cbal_(int *nm, int *n, double *ar, double *ai, int *low, int *igh, double *scale);
       static  int cbabk2_(int *nm, int *n, int *low, int * igh, double *scale, int *m, double *zr, double *zi);
       static  int comqr_(int *nm, int *n, int *low, int * igh, double *hr, double *hi, double *wr, double *wi, int *ierr);
       static  int comqr2_(int *nm, int *n, int *low, int * igh, double *ortr, double *orti, double *hr, double * hi,
                    double *wr, double *wi, double *zr, double *zi, int *ierr);
       static int cg_(int *nm, int *n, double *ar, double * ai, double *wr, double *wi, int *matz, double *zr,
                          double *zi, double *fv1, double *fv2, double *fv3, int *ierr);
  public :
       static int solve(const SMATRIX&, ARRAY<double>&, ARRAY<VECTOR>&,
                        const SMATRIX&, ARRAY<double>&, ARRAY<VECTOR>&);
       static int solve(const SMATRIX&, ARRAY<double>&, ARRAY<VECTOR>&,
                                        ARRAY<double>&, ARRAY<VECTOR>&);
};
Z_END_NAMESPACE;

#endif
