#ifndef __ZP_STACK_OBJECT__
#define __ZP_STACK_OBJECT__

#include <ZP_stack.h>
#include <ZP_object.h>
#include <ZP_type.h>

Z_START_NAMESPACE;

ZCLASS ZP_STACK_OBJECT : public ZP_OBJECT 
{
  protected :
    virtual ZP_FATAL_ERROR* print(ZP_STACK&,int);
    ZP_FATAL_ERROR* size(ZP_STACK&,int);

    virtual void type_init(char*) { }

  public :
    ZP_STACK_OBJECT() : ZP_OBJECT() { type="stack"; }

    METHOD_DECLARATION_START
      METHOD("size",size,0)
    METHOD_DECLARATION_ANCESTOR(ZP_OBJECT)
};
Z_END_NAMESPACE;

#endif
