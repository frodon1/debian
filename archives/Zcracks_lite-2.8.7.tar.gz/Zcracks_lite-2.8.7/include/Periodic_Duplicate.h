#include <Utility_mesh.h>
#include <Transform_geometry.h>

// A mesher that creates a periodic mesh from a surfacic one with s3d3
// Created by A. Jean (CdM) and modified by G. Grail (Onera)


Z_START_NAMESPACE;

class PERIODIC_DUPLICATE : public TRANSFORMERS {
  public :
  STRING elset1_name, elset2_name;
  VECTOR vect_period;
  bool adapt_only_boundary;  // skips the adaptation of the inside-faces... you only want it TRUE in very specific situations (see G.Grail for examples)

  PERIODIC_DUPLICATE() : TRANSFORMERS(), adapt_only_boundary(FALSE) { }
  virtual MODIFY_INFO_RECORD* get_modify_info_record();
  virtual void apply(UTILITY_MESH& mesh);
};
Z_END_NAMESPACE;

