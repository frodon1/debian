#include <QApplication>
#include <QInputDialog>

#include <iostream>

int main(int argc, char **argv)
{
  QApplication app(argc, argv);
  bool ok;
  QString text(QInputDialog::getText(NULL,"You don't have done operation to avoid to type your password !","Password to connect to porthos :",QLineEdit::Password,"",&ok));
  if (ok && !text.isEmpty())
    {
      std::cout << text.toLatin1().data() << std::endl;
    }
  return 0;
}
