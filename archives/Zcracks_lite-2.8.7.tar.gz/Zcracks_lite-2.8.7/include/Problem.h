#ifndef __Problem__
#define __Problem__

#include <File.h>
#include <Memory_buffer.h>
#include <Hierarchy.h>
#include <List.h>
#include <Auto_ptr.h>
#include <Stringpp.h>

#include <Dof_type.h>
#include <Discrete_timer.h>

#include <Base_problem.h>
#include <Mesh.h>
#include <Pre_problem.h>
#include <Problem_info.h>
#include <Restarter.h>
#include <Problem_includes.h>
#include <Problem_component.h>

Z_START_NAMESPACE;

class MESH; 
class BC; 
class RELATIONSHIP; 
class TABLE; 
class GLOBAL_MATRIX; 
class SOLVER_PARAMETER;
class RANDOM_DISTRIBUTION;

class MESH; class BC; 
class BEHAVIOR;
class ALGORITHM; 
class OUTPUT;
class COEFFICIENT; 
class EXTRA_RESTART; 
class DOF_SETTER; 
class IPSET;
class PROBLEM_COMPONENT;
class INTEGRATION_RESULT;

// 
class COEFFICIENT; class ELSET;  class MATERIAL_DATA_INIT;
class GEOMETRY_INFO; class PREDEFINED_SECTION;

extern WIN_THINGIE2 bool Fem_Problem_finished;

// 
// Sets of data from the different read blocks.. see header Problem_read_data.h 
// 
class MATERIAL_READ_DATA; 


ZCLASS2 PROBLEM : public BASE_PROBLEM { // base class for physical problems

  // 
  // these items are generally protected.. so don't use unless you must... to 
  // do so risks having the code broken in the future. 
  // 
  protected :
            bool mandatory_restart;
            STRING inp_name;

            void read_restart_preamble(RST_FSTREAM&);
            void write_restart_preamble(RST_FSTREAM&);
            void write_restart_section(RST_FSTREAM& rep, MEMORY_BUFFER *mem_buff, STRING subject);
            void read_restart_section(RST_FSTREAM& rep, MEMORY_BUFFER *mem_buff, STRING subject);

  public : 
            LIST<GLOBAL_MATRIX*> global_matrices;
            LIST<VECTOR*>        additional_fields;

            LIST<STRING>     keywords_to_skip;

            LIST<STRING>     elset_name;  // used to specify mesh type
            LIST<STRING>     elset_type;

            LIST<STRING>     nset_name;  // used to create dofs on given nset (when this nset contains nodes not linked to an element)
            LIST< LIST<STRING> >    nset_dof_name;  

            LIST<GEOMETRY_INFO*> geom_info;
            LIST<PREDEFINED_SECTION*> predef_sections;

            PLIST<MATERIAL_READ_DATA> matl_reads; 

            STRING           mesh_global_type;
            STRING           global_matrix_type;

            STRING             geof;

            // For such a big and important object, the use of PTR is not obvious
            // do not use PTR it is straightforward to know where/when to delete the pointer (FF)
            MESH *mesh;

            RESTARTER          restarter;
            bool               no_restart_management;
            bool               do_initial_output;
            bool               coupled;
            PLIST<DOF_SETTER>  initial_dof_value;
            PLIST<OUTPUT>      output;
            bool               output_invalid,dont_assign_behavior;
            bool               needs_initial_reac_loop;

            PLIST<RANDOM_DISTRIBUTION>      random_distribution;

            PLIST<EXTRA_RESTART> extra_restart;
            DISCRETE_TIMER       discrete_timer; 
            DISCRETE_TIMER*      previous_discrete_timer;
    
            virtual void write_restart_magic_number(RST_FSTREAM&);
            virtual void check_restart_magic_number(RST_FSTREAM&);
            virtual void write_predefined_mesh(ASCII_FILE&);
            virtual void read_material_rotations(LIST<LOCAL_FRAME*>&,ELSET&,STRING r_file_name);
            virtual void read_material_rotations(LIST<LOCAL_FRAME*>&,IPSET&,STRING r_file_name);
                    void init_material(int reread_behaviors=1);
            virtual void assign_behaviors(int re_read_behavior); 

            virtual void read_all(const STRING&, ASCII_FILE&);
            virtual void setup_output();
            virtual void resetup_output();
            virtual bool may_have_output() { return(true); }

            double time_step_i, time_step_f;

            // data structures needed for the ***impose_kinematics option

            enum { IK_TIME, IK_WEAK, IK_CONSTANT}  ik_method;
            LIST<double>     ik_time;
            LIST<STRING>     ik_files;
            LIST<long int>   ik_rec;

            LIST<STRING>     ik_elset; 
            LIST<VECTOR>     ik_value; 
            LIST<FUNCTION*>  ik_func; 

           LIST<PROBLEM_COMPONENT*> plug_in_components;
           LIST<PROBLEM*>           companion_problems; // to be able to ask component in other pbs (auto remesh for coupled pbs)

  public:
           virtual void add_component(PROBLEM_COMPONENT* comp_in); // for wrappers. deleted by this class
           void create_component(STRING);


           LIST<BEHAVIOR*>       behavior;
           LIST<LOCAL_FRAME*>    material_rotation; // used for storage

           LIST<LOCAL_FRAME*>    elem_frame;        // used for storage
           PLIST<BC>             bc;
           PLIST<RELATIONSHIP>   relationship;
           ALGORITHM*            algorithm;   // PTR removed, still local var
           AUTO_PTR<SOLVER_PARAMETER> gmp;
           PLIST<UTILITY_MESH>   transfer_meshes;

           // MESH* get_mesh() { return mesh(); }
           MESH* get_mesh() { return mesh; }
 
           PROBLEM();
           virtual ~PROBLEM();

           // ------------------------------------------------------------ 
           // Functions/data for creating the mesh 
           // 
           // RF broke the configure_new_mesh into 2 parts for remeshing stuff 
           // June 25 2003.. also added data members which were local so 
           // the same MESH structure can be created over again 
           // ------------------------------------------------------------ 
           LIST<STRING>            predef_sec_elset;
           LIST<STRING>            local_frame_nsets;
           LIST<LOCAL_FRAME*>      local_frame_prototypes;
           LIST< LIST<double> >    real_c_values;
           LIST< STRING >          real_c_elsets;

           virtual void configure_new_mesh();
           virtual void mesh_default();
           virtual void mesh_will_change();
           virtual void mesh_changed();
           virtual void mesh_changed_after_transfer();
           virtual void clean_after_remesh();
           virtual OUTPUT_CONTROL* get_remesh_frequency();

           RANDOM_DISTRIBUTION* get_random_distribution(const STRING&);
           virtual GLOBAL_MATRIX* give_matrix();

           virtual void assign_table();
	   virtual void create_param_at_nodes();

           virtual void bc_update();
           virtual void set_relationship();
           virtual bool apply_bc(GLOBAL_MATRIX* K=NULL);
           virtual void add_bc_stiffness_and_residual_contribution(GLOBAL_MATRIX*,VECTOR&);

	   virtual void add_bc_damping_contribution(double coeff, GLOBAL_MATRIX* C);
	   virtual void add_bc_residual_contribution(double coeff, VECTOR &R, VECTOR& veloc);

           virtual void add(BC *o) { bc.add(o); }
           virtual void remove(BC* o);
           virtual void add(RELATIONSHIP *o) { relationship.add(o); }
           virtual void add(RANDOM_DISTRIBUTION *o) { random_distribution.add(o); }

	   virtual void external_param_update();
           virtual bool prepare_restart(ASCII_FILE&);
           virtual bool do_a_restart(ASCII_FILE&);
           virtual void set_dof_initial_value();

           //
           // input member functions
           // they are all virtual
           // the controller function is GetResponse
           // a class deriving from PROBLEM can call PROBLEM::GetResponse
           // in case it cannot interprete some keyword
           //

           virtual bool GetResponse(const char* const,ASCII_FILE&);
           virtual bool skip_storage(ASCII_FILE&);
           virtual bool skip_mesh(ASCII_FILE&);

           virtual void pre_manage_restart();
           virtual void manage_restart();
           virtual void post_manage_restart();
           void restart_sequence();

           virtual void output_data(bool forced=FALSE);
           virtual void init_mesh();
           virtual OUTPUT* default_output();
           virtual STRING impose_output_type() { return(""); }
           virtual void reinit();
           virtual void init_iterations();
           virtual void reset();
           virtual void impose_kinematic();

           //
           // The auto-input reader version of read_all.
           // Up to now it's purely experimental
           //
           virtual bool declare_data(AUTO_PTR<AID_PART>&);

           virtual bool needs_a_mesh() { return(TRUE); } 
           virtual void create_mesh() { NOT_IMPLEMENTED_ERROR("Base create_mesh"); } 
           virtual void load(const STRING&, const STRING&);

           // the following functions have all a default implementation
           // giving an error. They are first introducted for weak coupling
           // but should be used in any case.

           PROBLEM_COMPONENT* CreateComponent(const STRING&);
           virtual bool Initialize();
           virtual bool make_increment(double);
           virtual void start_increment();
           virtual void end_increment(INTEGRATION_RESULT*&);
           virtual void start_iteration();
           virtual void start_fictious_iteration(bool &if_compute_stiffness);
           virtual void if_accuracy(VECTOR&,VECTOR&,MESH&);
           virtual bool ok_for_plugins();
           virtual void end_iteration();
           virtual void end_fictious_iteration(bool &efi);
           virtual bool end_iteration_converge();
           virtual bool end_problem();
           virtual void end_of_zset();

           virtual void write_restart(RST_FSTREAM&);
           virtual void write_restart_phase_1(RST_FSTREAM&);
           virtual void read_restart(RST_FSTREAM&);
           virtual void read_restart_phase_1(RST_FSTREAM&);
           virtual void write_output(Zfstream&);
                   void invalidate_output();
                   void validate_output();
                   void invalidate_restart_management();
                   void validate_restart_management();
                   void set_discrete_timer();
                   void unset_discrete_timer();
                   void no_initial_output() { do_initial_output=FALSE; }

           bool if_read_global_matrix; 
           LIST<STRING> global_matrix_name; 
           LIST<STRING> global_matrix_file_name; 
           virtual void reset_global_matrix();

           virtual bool ask_components(APPLICATION_MESSAGE*);
           virtual bool ask_components(STRING,APPLICATION_MESSAGE*);
           virtual PROBLEM_COMPONENT* look_for_component(const STRING&);
           void check_for_mesh_component();

           void keep_element_internal_reaction() { mesh->keep_element_internal_reaction(); }
           double get_internal_reaction(D_ELEMENT* ele, DOF* dof) { return mesh->get_internal_reaction(ele,dof); }
           UTILITY_MESH* get_transfer_mesh(const STRING& _pb_name, const STRING& format);
           void increment_output();

           RTTI_INFO;
           virtual bool verification();
};

Z_END_NAMESPACE;

#endif   
