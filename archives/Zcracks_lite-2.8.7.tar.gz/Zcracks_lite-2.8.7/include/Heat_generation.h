#ifndef __Heat_generation__ 
#define __Heat_generation__ 

// ============================================================================ 
//  THis material piece is used to store the vaux used for internal 
//  heating.. ie sig|deps terms.. or phase change.. I put this type 
//  of thing in a class mostly so the reading can be seperate, and the 
//  SCALAR_VAUX is a direct member variable.. 
// ============================================================================ 

#include <Material_piece.h>
#include <Coefficient.h>
#include <Int_variable_holder.h>

Z_START_NAMESPACE;

class ASCII_FILE;

ZCLASS MECHANICAL_HEAT_GENERATION : public MATERIAL_PIECE { 
  protected : 
     COEFF   f;
     SCALAR_VAUX q_dot; 
  public : 
     MECHANICAL_HEAT_GENERATION(ASCII_FILE& file, MATERIAL_PIECE* boss);
     MECHANICAL_HEAT_GENERATION(const MECHANICAL_HEAT_GENERATION& iso, MATERIAL_PIECE* boss);
     virtual ~MECHANICAL_HEAT_GENERATION(); 
     virtual MATERIAL_PIECE* copy_self(MATERIAL_PIECE*);
     static  MECHANICAL_HEAT_GENERATION* read(ASCII_FILE& file, MATERIAL_PIECE* b);

     virtual void attach_all(MAT_DATA& mdat) ; 
     virtual void add_heat(double dq); 
     virtual void zero_out(); 
     RTTI_INFO;
}; 

// 
// different types of heat? i donno.. 
// 
// DEFINE_AS_BASE_FOR_AUTO_READ1(MECHANICAL_HEAT_GENERATION,MATERIAL_PIECE*);
Z_END_NAMESPACE;

#endif
