#ifndef __PROBLEM_THERMAL_TRANSIENT__
#define __PROBLEM_THERMAL_TRANSIENT__

#include <Thermal_problem.h>

Z_START_NAMESPACE;

class PROBLEM_THERMAL_TRANSIENT : public PROBLEM_THERMAL {
   protected :
      bool lumped_rhoC;

   public :
      PROBLEM_THERMAL_TRANSIENT();
      virtual ~PROBLEM_THERMAL_TRANSIENT();

      virtual bool read_thermal_controls(ASCII_FILE&);
      virtual bool GetResponse(const char* const keyword, ASCII_FILE& file);
      virtual bool Initialize();

      RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
