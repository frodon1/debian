#ifndef __GRAPHICS_DIALOG_COMBO_GROUP__
#define __GRAPHICS_DIALOG_COMBO_GROUP__

#include <Graphics_dialog_piece.h>

Z_START_NAMESPACE;

// ---------------------------------------- 
//  Combo groups 
// ---------------------------------------- 

class GRAPHICS_DIALOG_COMBO_GROUP;

ZCLASS COMBO_GROUP_APPLICATION_MESSAGE : public APPLICATION_MESSAGE 
{
  public :
    int selection;
    ARRAY<STRING> contens;
    STRING value;
    LIST<GRAPHICS_DIALOG_PIECE*> others;

    COMBO_GROUP_APPLICATION_MESSAGE();
    virtual ~COMBO_GROUP_APPLICATION_MESSAGE() { }

    RTTI_INFO;
};

ZCLASS GRAPHICS_DIALOG_COMBO_GROUP : public GRAPHICS_DIALOG_PIECE 
{
  public :
    int independant,default_index;
    STRING value;
    LIST<STRING> items;
    LIST<int>    vals;

    GRAPHICS_DIALOG_COMBO_GROUP();
    virtual ~GRAPHICS_DIALOG_COMBO_GROUP() { }

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
