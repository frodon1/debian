#ifndef __MG__
#define __MG__

#include <Sorted_list.h>
#include <Utility_mesh.h>
#include <Utility_results_database.h>
#include <Transform_geometry.h>
#include <Distene_tools.h>
#include <Refinement_density.h>
#include <Bit_collection.h>

Z_START_NAMESPACE;

//
// 2004-10-12 FF: an interface with YAMS, a surfacic remesher sold by Distene
//   support also volumic remeshing by calling the Distene volumic mesher GHS3D
//

template <class T>
class MG_EDGE : public SORTED_LIST<T> {
  public :
    bool                  required, ridge;
    ARRAY<UTILITY_NODE*>  nodes;
    LIST<int>             refs;
    int                   extended_ref;

    void reassign(const ARRAY<UTILITY_NODE*>& edge);
    bool operator<(const MG_EDGE<T>& l)const;
    MG_EDGE<T>& operator=(const MG_EDGE<T>&);
};

template <class T>
class MG_FACE : public SORTED_LIST<T> {
  public :
    int rk; // rank in the list of faces used when building the tree

    void reassign(const ARRAY<UTILITY_NODE*> nodes, int _rk=-1);
    bool operator<(const MG_FACE<T>& l)const;
};

class MG : public TRANSFORMERS
{
  protected :
    VECTOR liset_refine;
    STRING liset_front,skin_nset;
    int ipc;
    int    nitter_vol,nitter_surf;
    bool   no_volume,crack_propagation,get_ridges,local_remeshing,mesh_cleaner;
    int ref_ext;
    STRING refine_file,error_based_refine_file,mesh_name;
    double refine_factor,lip_factor,ref_size;
    double power_constant;
    bool   smooth_refinement;
    STRING origin_nset;
    MARRAY<VECTOR> nodes_origin;
    BUFF_LIST<VECTOR> ext_nodes;
    bool if_deform_mesh, use_deform_mesh_quad;
    DISTENE_TOOLS distene;
    STRING mesh_dir,yams,ghs3d,yams_options,ghs3d_options,given_metric_file;
    STRING meshadapt, meshadapt_options;
    LIST<STRING> surfopt_replace_options,surfopt_replace_options_to;
    LIST<STRING> tetra_replace_options,tetra_replace_options_to;
    LIST<STRING> adapt_replace_options,adapt_replace_options_to;
    STRING elset_name,file_surf,external_density;
    int dim;
    double minsize,maxsize,tolerance,gradation;
    STRING optim_style,optim_1st;
    bool absolu,ascii,yams_only,ghs_only,needs_volume_mesh_loop,layer_extension;
    bool nbb_64,use_yams_exe,use_freeyams;
    STRING shell;

    STRING skin_name,mesh_out_name;
    STRING mext ;  // metric file extension

    ARRAY<STRING> new_elset_names;
    bool compute_curvature(UTILITY_SET &origin,UTILITY_MESH &mesh);

    /*
    ARRAY<int> domain_triplet; // for each domain a specific triplet
    ARRAY<int> element_tags; // number of the sub-domain
    BUFF_LIST<int> tags_by_elset;
    */

    FUNCTION *refinement;
    REFINEMENT_DENSITY* refinement_density;

    UTILITY_MESH surface_mesh;
    ARRAY< ARRAY<int> > edges;
    BUFF_LIST<int> node_refs,elem_refs,edge_refs;
    SORTED_LIST<int> nodes_save, required_faces, corners_nodes; // Yams indexes

    BUFF_LIST<STRING> corners,ridges;
    BUFF_LIST<STRING> preserve_nset,preserve_faset,preserve_liset,preserve_elset,
                      preserve_topo,preserve_geom,preserve_nset_if_possible;
    STRING            preserve_fasets_start_with;
    SORTED_LIST<BIT_COLLECTION>  preserve_nset_colors, preserve_face_colors;

    ARRAY< ARRAY<int>* > vertices_tags,edges_tags;

    ARRAY<VECTOR> pos0;
    ARRAY<VECTOR> pos1;
    ARRAY<VECTOR> pt_of_elsets;   

    ARRAY<UTILITY_BOUNDARY*> yams_faces; 
    ARRAY<UTILITY_NODE*>     yams_nodes; 
    ARRAY< MG_EDGE<int> >  yams_edges;
    ARRAY<int>               faces_refs;
    ARRAY<int>               nodes_refs; 
    // correspondance between global node rank and yams vertice rank
    ARRAY<int>               nodes_to_yams;

    // SQ 06/04/12 : factorize handling of the "copy" option !!!
    int run_yams(STRING cmd);

    virtual void clean();
    virtual void store_skin(STRING);
    virtual void extract_skin(UTILITY_MESH&);
    virtual void build_yams_sets(UTILITY_MESH &mesh);
    virtual void deform_mesh(UTILITY_MESH&);
    virtual void deform_mesh_quad(UTILITY_MESH&);
    bool test_output_format(const STRING& base, STRING& suffix, bool& is_64);

    virtual bool provide_surfacic_density();
    virtual bool given_surfacic_density();
    virtual void surfacic_density(ARRAY<UTILITY_NODE*> &nodes, VECTOR &densities,bool if_volume=FALSE);
    void write_metric_file(ARRAY<UTILITY_NODE*> &nodes, VECTOR &densities, STRING base_name);
    void write_yams_metric_file(ARRAY<UTILITY_NODE*> &nodes, VECTOR &densities, STRING base_name);
    void write_freeyams_metric_file(ARRAY<UTILITY_NODE*> &nodes, VECTOR &densities, STRING base_name);
    virtual bool provide_volumic_density();
    virtual void volumic_density(ARRAY<UTILITY_NODE*> &nodes, VECTOR &densities);
    virtual void optimize_volume_mesh(bool,const STRING&);

    void run_yams_ghs3d(UTILITY_MESH&);
    void recreate_elsets(UTILITY_MESH&);
    virtual void rebuild_3d_entites(UTILITY_MESH &mesh);
    bool if_remesh;

    STRING ask_if_remesh;

  public :
    MG();
    virtual ~MG();

    virtual bool GetResponse(STRING,ASCII_FILE&);
    virtual void initialize(ASCII_FILE& file);
    virtual void apply(UTILITY_MESH& mesh);
  
  friend class PARALLEL_YAMS; // Allow PARALLEL_YAMS to init MG objects (APF 02/06/2010)
};

template <class T>
void MG_EDGE<T>::reassign(const ARRAY<UTILITY_NODE*>& edge)
{
  SORTED_LIST<T>::resize(0);
  for(int i=0;i<!edge;i++) SORTED_LIST<T>::add(edge[i]->give_rank());
  nodes.resize(!edge);
  nodes = edge;
  refs.resize(0);
  required = FALSE;
  ridge    = FALSE;
}

template <class T>
inline bool MG_EDGE<T>::operator<(const MG_EDGE<T>& l)const
{
  if(this->sz>l.sz) return FALSE;
  if(this->sz<l.sz) return TRUE;
  for(int i=0;i<l.sz;i++) {
    if(     this->x[i]<l[i]) return TRUE;
    else if(this->x[i]>l[i]) return FALSE;
  }
  return FALSE;
}

template <class T>
MG_EDGE<T>& MG_EDGE<T>::operator=(const MG_EDGE<T>& e)
{ SORTED_LIST<T>::resize(0);
  for(int i=0;i<!e;i++) SORTED_LIST<T>::add(e[i]);
  nodes.resize(!e.nodes);
  nodes = e.nodes;
  refs  = e.refs;
  extended_ref = e.extended_ref;
  required     = e.required;
  ridge        = e.ridge;
  return(*this);
}

template <class T>
void MG_FACE<T>::reassign(const ARRAY<UTILITY_NODE*> nodes, int _rk)
{ SORTED_LIST<T>::resize(0);
  for(int i=0;i<!nodes;i++) SORTED_LIST<T>::add(nodes[i]->give_rank());
  rk    = _rk;
}

template <class T>
inline bool MG_FACE<T>::operator<(const MG_FACE<T>& l)const
{
  if(this->sz>l.sz) return FALSE;
  if(this->sz<l.sz) return TRUE;
  for(int i=0;i<l.sz;i++) {
    if(     this->x[i]<l[i]) return TRUE;
    else if(this->x[i]>l[i]) return FALSE;
  }
  return FALSE;
}
Z_END_NAMESPACE;

#endif
