#ifndef __MECHANICAL_INTERFACE_ELEMENT__
#define __MECHANICAL_INTERFACE_ELEMENT__

#include <Bool.h>
#include <ZMath.h>
#include <Rotation.h>

#include <Coefficient.h>
#include <Dimension.h>
#include <Dof.h>
#include <Global_matrix.h>
#include <GMesh.h>
#include <Integration_result.h>
#include <Mechanical_behavior.h>
#include <Mechanical_mesh.h>
#include <P_ele_interface.h>
#include <Skew_vec_rot.h>
#include <Strain_trans_matrix.h>
#include <Space.h>

Z_START_NAMESPACE;

//
// A very simple class just to be able to use RTTI. Interface elements (eg debonding) should derived from that class
//

ZCLASS2 MECHANICAL_INTERFACE_ELEMENT : public P_ELEMENT_INTERFACE {
  public :
    MECHANICAL_INTERFACE_ELEMENT() { }
    virtual ~MECHANICAL_INTERFACE_ELEMENT() { }

    virtual bool cal_val_at_integration(int ivar , ARRAY<BEHAVIOR*>& behavior_index , ARRAY< BUFF_LIST<int> >& key_indices, VECTOR& val)const;
    virtual bool cal_val_at_integration(const STRING& var_name,VECTOR& val)const;

    RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
