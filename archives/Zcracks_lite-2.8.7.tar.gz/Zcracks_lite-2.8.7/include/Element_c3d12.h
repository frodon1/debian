// ===========================================
// N.G. and N.C. 03 06 06
// Made some modification to permit ti display the results at Gauss Point 
// Semms that these stuffs disapeare form the project ... Very strange ...
// ===========================================


#include <Array.h>
#include <Object_factory.h>
#include <Utility_elements.h>
#include <Utility_boundary.h>
#include <GeomSpace.h>
#include <Out_message.h>
#include <Verbose.h>
#include <Print.h>
#include <Layer_geom_info.h>
#include <Element_c3d16.h>

Z_START_NAMESPACE;

#define __STD_FACES__ { if(!faces) { elem_faces=faces; return; } }

#define pt(rank) (nodes[rank]->position)

class C3D12_L_UTILITY_ELEMENT : public UTILITY_ELEMENT {
  protected :
    int active_layer,nb_layer,nb_gauss_layer;
    bool g_faces_inited;

   int nb_surface_gauss,nb_gp_tot;
   LAYER_GEOM_INFO *its_info;
  public :
  bool set_info();
  virtual void run_face_setup(int force_setup=0);
  virtual void run_face_setup_disp(const ARRAY<VECTOR>& disp,double mag);
  virtual void set_integ(VECTOR& values, int& index);
  virtual void set_integ_skin(VECTOR& values, int& index);


    C3D12_L_UTILITY_ELEMENT() : UTILITY_ELEMENT() { space_dim=3; g_faces_inited=FALSE; its_info=NULL;}
    C3D12_L_UTILITY_ELEMENT(const C3D12_L_UTILITY_ELEMENT& in) : UTILITY_ELEMENT(in) { 
      num_gp=0;
      active_layer=nb_layer=nb_gauss_layer=-1;
      g_faces_inited=FALSE;
    }

    virtual ~C3D12_L_UTILITY_ELEMENT() {
      active_layer=-1;
    }

    virtual void initialize(const STRING& t) {
      UTILITY_ELEMENT::initialize(t);
      nodes.resize(12);
      num_gp=-1;
      active_layer=nb_layer=nb_gauss_layer=-1;
    }

    virtual UTILITY_ELEMENT* element_copy_self();
    virtual UTILITY_ELEMENT* copy_to_linear(ARRAY<UTILITY_NODE*>& rem);

    virtual void get_element_axis(ARRAY<VECTOR>&);
    virtual void invert_element(int axe_number);
    virtual void check_orientation(bool ori=TRUE);
    virtual void add_bsets(B_UTILITY_SET&, BUFF_LIST<UTILITY_NODE*>&);
    virtual ARRAY<UTILITY_BOUNDARY>& get_faces();

    virtual int   num_contour_vals()const;
    virtual void  set_ctnod(ARRAY<int>& markers, VECTOR& values);

    void* operator new(size_t t) { return(::new char[t]); }
    void  operator delete(void* oo) { delete((char*)oo); }            

    virtual bool do_command(STRING);
};
Z_END_NAMESPACE;


