#ifndef __Delete_elset__
#define __Delete_elset__

// ============================================================================ 
//  Delete an elset from the mesh 
// ============================================================================ 

#include <Defines.h>
#include <File.h>
#include <Transform_geometry.h>
#include <Utility_mesh.h>

Z_START_NAMESPACE;

ZCLASS DELETE_ELSET_TRANSFORM : public TRANSFORMERS {
     bool   keep_orphans, clean_all; 
  public :
     LIST<STRING> names; // the elsets to delete 
    
     DELETE_ELSET_TRANSFORM();
     virtual void initialize(ASCII_FILE& file);
     virtual void write(Zofstream& out); 

     virtual ~DELETE_ELSET_TRANSFORM() { } 
     virtual void apply(UTILITY_MESH& mesh);
};
Z_END_NAMESPACE;

#endif
