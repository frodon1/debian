#ifndef __Local_frame__
#define __Local_frame__

#include <ZMath.h>
#include <Defines.h>
#include <Rotation.h>
#include <File.h>

Z_START_NAMESPACE;

class ASCII_FILE;

// for doc, see .zdoc

ZCLASS LOCAL_FRAME {
   protected : 
        ROTATION* rotation; 

   public :
        bool space_dependent;

        LOCAL_FRAME(); 
        LOCAL_FRAME(const LOCAL_FRAME& cpy); 
        virtual ~LOCAL_FRAME(); 

        virtual void initialize(ASCII_FILE& inp_file);

        void set_rotation(ROTATION &r);

        virtual bool constant()const { return TRUE; } 

        virtual void compute_angle(VECTOR& normal);

        virtual void verify_dimension(int dim);

        virtual LOCAL_FRAME* copy_self();         

        LOCAL_FRAME& operator=(const TENSOR2&);

        // 
        // define the rotationtion matrix from the local referential to the 
        // global one... the use of the id's is context dependant. The idea is 
        // this could map directly to file data. 
        // 
        virtual void    compute_rotation(const VECTOR& node_position,  
                                         int major_id,   // eg ele_id | node_id 
                                         int minor_id);  // e.g. gauss pt number

        virtual VECTOR  update_coord(const VECTOR& coord0, const VECTOR& ddof)const; 


        VECTOR  apply(const VECTOR&  v)const { return rotation->apply(v); } 
        TENSOR2 apply(const TENSOR2& t)const { return rotation->apply(t); }
        SMATRIX apply(const SMATRIX& m)const { return rotation->apply(m); }
        VECTOR  apply_like_tensor(const VECTOR& v)const { return rotation->apply_like_tensor(v); }
        SMATRIX apply_like_matrix(const MATRIX& m)const { return rotation->apply_like_matrix(m); }

        VECTOR  remove(const VECTOR&  v)const { return rotation->remove(v); }
        TENSOR2 remove(const TENSOR2& t)const { return rotation->remove(t); }
        SMATRIX remove(const SMATRIX& m)const { return rotation->remove(m); }
        VECTOR  remove_like_tensor(const VECTOR& v)const { return rotation->remove_like_tensor(v); }
        SMATRIX remove_like_matrix(const MATRIX& m)const { return rotation->remove_like_matrix(m); }

        ROTATION* give_rot_object() { return(rotation); }
        TENSOR2 give_rot()        { return rotation->give_rot(); } 
        SMATRIX give_rot_matrix() { return rotation->give_rot_matrix(); }

        // 
        // only calls invert to its rotation... not valid for any 
        // spatial varying local frame or anything. 
        // 
        virtual void    invert()          { rotation->invert(); }

        // 
        // Makes the equivilent of a ROTATION. used for compatibility with
        // the original reading etc in Problem.c
        //
        static LOCAL_FRAME* create_constant_rotation(ASCII_FILE& inp);
};
Z_END_NAMESPACE;

#endif
