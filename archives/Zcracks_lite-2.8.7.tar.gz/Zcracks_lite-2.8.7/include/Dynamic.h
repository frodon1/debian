#ifndef __Dynamic__
#define __Dynamic__

#include <Calcul_timer.h>
#include <Error_messager.h>
#include <File.h>
#include <Stringpp.h>

#include <Clock.h>
#include <Contact.h>
#include <Discrete_timer.h>
#include <Element.h>
#include <Global_matrix.h>
#include <Integration_result.h>
#include <Mechanical_algorithm.h>
#include <Mesh.h>
#include <Object_factory.h>
#include <Output.h>
#include <Problem_mechanical.h>
#include <Sequence.h>

#include <Dof_setter.h>
#include <Output.h>
#include <Random_distribution.h>
#include <Extra_restart.h>
#include <Behavior.h>
#include <Rotation.h>
#include <Boundary_condition.h>
#include <Relationship.h>
#include <Extra_restart.h>

#include <Damping.h>

Z_START_NAMESPACE;

class INTEGRATION_RESULT;

ZCLASS2 PROBLEM_DYNAMIC_MECHANICAL : public PROBLEM_MECHANICAL {
  public :
      virtual void reinit();
   // AUTO_PTR<GLOBAL_MATRIX> K,M,K_M,K_0; 
      AUTO_PTR<GLOBAL_MATRIX> M,K_0; 
      DAMPING *damping;
      int save_veloc_accel;
      int dim,iout;
      Zfstream utp_file,nodep_file;
      _ZSYSCLOCK mesh_creation_date;

      void output_veloc_accel();
      PLIST<DOF_SETTER>  initial_velocity_value;
      void setup_Khat();

  public :
      VECTOR veloc, accel, df;
      PROBLEM_DYNAMIC_MECHANICAL();
      virtual ~PROBLEM_DYNAMIC_MECHANICAL();

      virtual void create_mesh();
      virtual bool read_damping(ASCII_FILE&);
      virtual bool read_dynamic_output(ASCII_FILE&);
      virtual bool read_init_velocity(ASCII_FILE& inp);
      virtual OUTPUT* default_output(); 

      virtual bool GetResponse(const char* const keyword, ASCII_FILE& file);

      virtual bool Initialize();
      virtual bool Execute();

      virtual void write_restart(RST_FSTREAM&);
      virtual void read_restart(RST_FSTREAM&);

      virtual bool make_increment(double);

      virtual void reset_global_matrix();
      virtual void reset();

      virtual void add_bc_damping_contribution(double coeff, GLOBAL_MATRIX* C);
      virtual void add_bc_residual_contribution(double coeff, VECTOR &R, VECTOR& veloc);

      
      VECTOR df0,veloc0,accel0,f_external_last,f_internal_last;

      VECTOR set_initialization_variables(STRING var);
      void init_variables(VECTOR& M,VECTOR& N,VECTOR& O,VECTOR& P);
  
      RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
