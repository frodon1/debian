/*=========================================================================
 Developed for EDF by Kitware SAS.
 Copyright (c) Kitware SAS 2015
 All rights reserved.
 More information http://www.kitware.fr
=========================================================================*/
#include "pqPorthosStarter.h"

// Local Includes.
#include "pqServerLauncher.h"
#include "pqPorthosServerLauncher.h"

//-----------------------------------------------------------------------------
pqPorthosStarter::pqPorthosStarter(QObject* p)
: QObject(p)
{
}

//-----------------------------------------------------------------------------
pqPorthosStarter::~pqPorthosStarter()
{
}

//-----------------------------------------------------------------------------
void pqPorthosStarter::onStartup()
{
  pqServerLauncher::setServerDefaultLauncherType(&pqPorthosServerLauncher::staticMetaObject);
}

//-----------------------------------------------------------------------------
void pqPorthosStarter::onShutdown()
{
  pqServerLauncher::setServerDefaultLauncherType(NULL);
}
