#ifndef __Handler__
#define __Handler__

// ============================================================================ 
//  Notes:      Most data structures are labeled starting with 
//              a m_ for "member" so we avoid confusion with 
//              the many local variables.
//
//  GLOBAL_HANDLER: The class to handle the global treatment..
//                  that's to say the stress calculations.  
//                  Energy equivilant damage models fall into
//                  this class.. also other localisations to
//                  come.  The polycrystal will fall here as well!
//                  (we note that it's all the same in the end!)
//
//                  calc_stress takes a num which could be
//                  potential number etc.  the default is 
//                  zero which is the global stress.. ie
//                  flux
//
//                  These classes are now tied to POTENTIAL...
// ============================================================================ 

#include <Hierarchy.h>
#include <ZMath.h>
#include <Rotation.h>

#include <Material_piece.h>
#include <Gen_visco.h>

Z_START_NAMESPACE;

class MAT_DATA;
class ASCII_FILE;
class POTENTIAL;
class NL_M_TLE_B_SD;

enum GH_FLAGS {  GH_NONE = 0,
                 GH_MODIFIED_AUXSZ=1,
                 GH_DAMAGE_FLAG_ELASTIC=2,
                 GH_DAMAGE_FLAG_PLASTIC=4,
                 GH_PLANE_STRESS=8
};

ZCLASS GLOBAL_HANDLER : public MATERIAL_PIECE { 
  protected :
    int                     handler_flags;
    LIST<POTENTIAL*>*       the_potentials;
    NL_M_TLE_B_SD*          behavior; 

    virtual void    base_initialize(NL_M_TLE_B_SD* boss ); 

  public :
    SMATRIX         ps_modify_matrix; 

                    GLOBAL_HANDLER( ); 
                    GLOBAL_HANDLER( const GLOBAL_HANDLER& gin ); 
    virtual void    initialize(ASCII_FILE&, NL_M_TLE_B_SD* boss ); 

    virtual void    set_null_stress_component(int index); 

    static  GLOBAL_HANDLER* default_model(NL_M_TLE_B_SD*); 
    static  GLOBAL_HANDLER* read(const STRING& str, ASCII_FILE&, NL_M_TLE_B_SD*);
    virtual bool    token_read(const STRING& tok, ASCII_FILE& file); 

    virtual void    look_at_potentials(LIST<POTENTIAL*>& pots); 
    virtual void    handler_setup( const TENSOR2& detot, VECTOR& dvar )=0;
    virtual void    set_control(const ARRAY<STRING>& ctl); // SIM

            void    add_flags(int flg) { handler_flags |= flg; } 

    virtual void    set_matricies( VECTOR&    f_vec,
                                   SMATRIX&   f_grad
                                 );

    virtual const TENSOR2&  calc_stress(int num=-1)=0;
    virtual TENSOR2         real_stress(int num=-1);
    virtual TENSOR2         dsig(int num=0)=0;
    virtual TENSOR2         dsig_dparam(int num=0);
    virtual double          strain_energy(const VECTOR& var_int)=0;
    virtual double          give_damage(int pot_num);

    virtual void    g_hat(const VECTOR& dvar, POTENTIAL& pot, int pc)=0;

    virtual void    update_var_aux(); 

    virtual MATRIX          mul_in(MATRIX& mat)=0;    
    virtual TENSOR2         mul_in(TENSOR2& tens)=0;  
    virtual const SMATRIX&  elas_matrix()=0;
    virtual const SMATRIX&  multi_matrix(); // SIM
    virtual const SMATRIX&  dsig_deel()=0;

    //
    // Special methods for simulation
    //
    ROTATION* simulation_rotation; 
    virtual TENSOR2 g_hat_simul(TENSOR2& detot, const TENSOR2& ctl, 
                                const TENSOR2& de_extra); // SIM 

    virtual TENSOR2 find_rate( const SMATRIX& dsig_deto,
                                const SMATRIX& Del,
                                      TENSOR2& control,
                                const TENSOR2& de_extra, 
                                const TENSOR2* dsig_extra=NULL);

    virtual void set_simulation_rotation(ROTATION* rot) { simulation_rotation=rot; } 

    virtual void   calc_ps_terms() { } 

     RTTI_INFO;
};

Z_END_NAMESPACE;
#endif

