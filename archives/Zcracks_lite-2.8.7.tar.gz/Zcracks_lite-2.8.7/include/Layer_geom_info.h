#ifndef __LAYER_GEOM_INFO__
#define __LAYER_GEOM_INFO__

#include <File.h>
#include <Geometry_info.h>
#include <Defines.h>
#include <Utility_mesh.h>
#include <Utility_elements.h>
#include <Zstream.h>

#include <Graphics_command.h>
#include <Graphics_data_dialog.h>

Z_START_NAMESPACE;

class REF_GAUSS_POINT;
class MESH_INFO_READER;
class UTILITY_ELSET;
class UTILITY_MESH;
class BEHAVIOR;

ZCLASS2 LAYER_GEOM_INFO : public GEOMETRY_INFO,
                        public GRAPHICS_COMMAND {
  protected :
    GRAPHICS_DATA_DIALOG *its_dialog;
    ARRAY<REF_GAUSS_POINT*> surface_gauss_points; 
    bool gauss_inited;
    STRING current_elset_name;
    MESH_INFO_READER *current_mr;
    UTILITY_ELSET *current_elset;

  public :
    int nb_layer;
    int nb_layer_gauss;
    int nb_surface_gauss;
    int need_build_ipset;
//    STRING element_type;
    ARRAY<double> thickness;
    UTILITY_MESH* its_mesh;

    LAYER_GEOM_INFO() : GEOMETRY_INFO() { 
      nb_layer=1; 
      thickness.resize(1); thickness[0]=1.; 
      nb_surface_gauss=nb_layer_gauss=-1; 
      need_build_ipset=1;
      its_mesh=NULL; its_dialog=NULL; need_build_ipset=1;
    }

    virtual ~LAYER_GEOM_INFO() { }

    virtual void initialize(ASCII_FILE&);
    virtual void post_initialize();

    virtual bool GetResponse(ASCII_FILE&,const STRING&);

    virtual void build_ipset();
    virtual void mesh_loaded(UTILITY_MESH*);

    virtual void write(Zofstream&);
    virtual void read(Zifstream&);
 
    virtual void click(MESH_INFO_READER&,STRING&,UTILITY_ELSET*);

    virtual bool do_command(STRING);

    virtual bool handle_element_output();
//    virtual void cal_contour_outputs(ELEMENT*,int,VECTOR&);
    virtual void cal_contour_outputs(ELEMENT*,int,ARRAY<BEHAVIOR*>&,ARRAY< BUFF_LIST<int> >&,VECTOR&);
    virtual int  nb_contour_nodal_outputs(ELEMENT*);


    RTTI_INFO;
};

Z_END_NAMESPACE;

#endif
