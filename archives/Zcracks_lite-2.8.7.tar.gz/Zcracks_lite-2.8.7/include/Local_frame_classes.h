#ifndef __Local_frame_classes__ 
#define __Local_frame_classes__ 

#include <Local_frame.h> 

Z_START_NAMESPACE;

// ============================================================================ 
// 
// ============================================================================ 
ZCLASS CARTESIAN_LOCAL_FRAME : public LOCAL_FRAME {
   public :
     virtual void initialize(ASCII_FILE& inp_file);
     virtual LOCAL_FRAME* copy_self();
};                                                                                                                          
ZCLASS EULER_LOCAL_FRAME : public LOCAL_FRAME {
   public :
     virtual void initialize(ASCII_FILE& inp_file);
     virtual LOCAL_FRAME* copy_self();
     virtual void define_euler(double phi1, double gphi, double phi2);
};

ZCLASS ANGULAR_LOCAL_FRAME : public LOCAL_FRAME {
   public :
     virtual void initialize(ASCII_FILE& inp_file);
     virtual LOCAL_FRAME* copy_self();
};

ZCLASS ABOUT_AXIS_LOCAL_FRAME : public LOCAL_FRAME {
   public :
     virtual void initialize(ASCII_FILE& inp_file);
     virtual LOCAL_FRAME* copy_self();
     virtual void define_about_axis(STRING axis, double angle);
};

ZCLASS LOCAL_CYLINDRICAL_FRAME : public LOCAL_FRAME {
   protected :
   public :
        VECTOR cent;
        VECTOR Z;

        LOCAL_CYLINDRICAL_FRAME();
        LOCAL_CYLINDRICAL_FRAME(const LOCAL_CYLINDRICAL_FRAME&);
        virtual void initialize(ASCII_FILE& inp_file);
        virtual LOCAL_FRAME* copy_self();

        virtual bool constant()const { return FALSE; }

        virtual ~LOCAL_CYLINDRICAL_FRAME();
        virtual void compute_angle(VECTOR& normal);

        virtual void    compute_rotation(const VECTOR& node_position,
                                         int ele_id,
                                         int gp_number); // def error

//      virtual VECTOR update_coord(const VECTOR& coord0, const VECTOR& ddof)const;
        virtual void verify_dimension(int dim);
};

// SQ 06/26/08 : added for compatibility with abaqus
//   (slightly different definition)

ZCLASS LOCAL_CYLINDRICAL_FRAME2 : public LOCAL_FRAME {
   protected :
   public :
        VECTOR P1, P2, Z;

        LOCAL_CYLINDRICAL_FRAME2();
        LOCAL_CYLINDRICAL_FRAME2(const LOCAL_CYLINDRICAL_FRAME&);
        virtual void initialize(ASCII_FILE& inp_file);
        virtual LOCAL_FRAME* copy_self();

        virtual bool constant()const { return FALSE; }

        virtual ~LOCAL_CYLINDRICAL_FRAME2();
        virtual void compute_angle(VECTOR& normal);

        virtual void    compute_rotation(const VECTOR& node_position,
                                         int ele_id,
                                         int gp_number); // def error
        virtual void verify_dimension(int dim);
};

// 
// An easy one to create by itself.. just a 3x3 SMATRIX and 
// translation vector. 2D positions coming in just ignore the 
// 3 terms in the transform. 
// 
ZCLASS DIRECT_LOCAL_FRAME : public LOCAL_FRAME {
   protected :
   public :
        VECTOR  T;
        SMATRIX R;

        DIRECT_LOCAL_FRAME();
        DIRECT_LOCAL_FRAME(const DIRECT_LOCAL_FRAME&);
        virtual void initialize(ASCII_FILE& inp_file);
        virtual LOCAL_FRAME* copy_self();

        virtual bool constant()const { return TRUE; }

        virtual ~DIRECT_LOCAL_FRAME();

        virtual void    compute_rotation(const VECTOR& node_position,
                                         int ele_id,
                                         int gp_number); 
};

Z_END_NAMESPACE;

#endif 
