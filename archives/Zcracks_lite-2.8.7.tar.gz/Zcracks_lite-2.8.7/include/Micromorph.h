#ifndef __MICROMORPH_SD__
#define __MICROMORPH_SD__

#include <Bool.h>
#include <ZMath.h>
#include <Rotation.h>
 
#include <Coefficient.h>
#include <Dimension.h>
#include <Dof.h>
#include <Global_matrix.h>
#include <GMesh.h>
#include <Integration_result.h>
//#include <Isoparametric.h>
#include <Mechanical_behavior.h>
#include <Mechanical_volume_element.h>
#include <Mechanical_mesh.h>
#include <Skew_vec_rot.h>
#include <Strain_trans_matrix.h>
#include <Space.h>

Z_START_NAMESPACE;
 
// ----------------------------------------------------------------------------
//    Continuous Mechanical Element Small Displacement
//    for the micromorphic contiuum
// ---------------------------------------------------------------------------- 
ZCLASS2 MICROMORPH_SD : public MECHANICAL_VOLUME_ELEMENT {
  protected :
   virtual void  compute_B(const MATRIX& dshape_dx, MATRIX& b)=0;
   virtual int gradsz()const;
   virtual int utsz()const;
   int ktsz()const;
 
  public :
   MICROMORPH_SD(); 
   virtual void setup_dofs(const char* ele_type);

   virtual      ~MICROMORPH_SD();
   INTEGRATION_RESULT* internal_reaction(bool,VECTOR&, SMATRIX&,bool=FALSE);
};       
Z_END_NAMESPACE;

#endif
