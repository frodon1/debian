#ifndef __C_BUF__ 
#define __C_BUF__

#include <Stringpp.h>
#include <Std_cc_stream.h>
#include <Zbuffer.h>
#include <Defines.h>

#include <stdio.h>

Z_START_NAMESPACE;

ZCLASS CBUF : public ZFILEBUFFER {
  protected :
    FILE *o_file;
    FILE *i_file;
    int pid;
    int fd1[2],fd2[2];
    int alloc;
    IOS_OPENMODE m;
    STRING n;

    CBUF* open_file();
    CBUF* close_file();
    ZSTREAMPOS seekoff_file(ZSTREAMPOS,_SEEK_DIR,int);
    void flush_file();

    void kill_buffers();
    void init();

  public :
    CBUF();
    ~CBUF();

    virtual ZFILEBUFFER* open(const char *command, IOS_OPENMODE mode, int prot = 0664);
    virtual ZFILEBUFFER* close();

    virtual int doallocate();
    virtual int underflow();
    virtual int overflow(int c = EOF);

    virtual int is_open() const { return i_file!=NULL; }
    virtual int sync();
};
Z_END_NAMESPACE;

#endif
