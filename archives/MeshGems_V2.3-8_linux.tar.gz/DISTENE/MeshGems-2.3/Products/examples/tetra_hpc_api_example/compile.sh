gcc -I. -L. mg-tetra_hpc_example.c -lmg-tetra_hpc -lmeshgems -lmeshgems_stubs -lm -lc  -o mg-tetra_hpc_example.exe

