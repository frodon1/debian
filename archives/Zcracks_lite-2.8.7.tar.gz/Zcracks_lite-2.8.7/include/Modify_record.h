#ifndef __Modify_record__ 
#define __Modify_record__ 

#include <List.h>
#include <Buffered_list.h>
#include <Stringpp.h>

Z_START_NAMESPACE;

class VECTOR; 
#ifndef SKIP_STD_FUNCTION
class FUNCTION; 
#endif
class Zofstream;
class ASCII_FILE;

ZCLASS MODIFY_INFO {
  public :
    enum MOD_FORMAT { MOD_NONE, MOD_STRING, MOD_INT, MOD_BOOL, MOD_DOUBLE, 
                      MOD_KEYWORD_OPTION, 
                      MOD_SPACE_VECTOR, 
                      MOD_LIST_STRING, MOD_LIST_INT, 
                      #ifndef SKIP_STD_FUNCTION
                      MOD_FUNCTION,  MOD_LIST_FUNCTION,
                      #endif
                      MOD_RADIO_SELECT, 
                      // 
                      // the following are not done yet 
                      // 
                      MOD_SVAL_POPUP, 
                      MOD_STRING_WHOLE_LINE, 
                      MOD_LAST_STD_FORMAT 
                      // 
                      // User formats numbers should be well past here.. 
                      // Need a way of documenting them, so they are unique
                      // 
                      }; 

    enum MOD_PROPERTY { PROP_NONE=0 , PROP_ADJ=1 , PROP_INT=2 , PROP_AUTO_UPDATE=4 };

    MOD_FORMAT  format,like; 
    int         property;
    void* p_params[10];
    void*       subject; 

    int    displayed;

    STRING name;

    int    max_num;      // normally 1 but can be more.. -1 means any number

    BUFF_LIST<STRING> s_dat;  // these are the data for the record.. 

    MODIFY_INFO(); 
    MODIFY_INFO(const MODIFY_INFO& mod); 

    virtual ~MODIFY_INFO(); 

    virtual void reset_subject(); 

    virtual bool set(STRING,bool error=true);
    virtual bool set(int,bool error=true);
    virtual bool set(double,bool error=true);
#ifndef BOOL_IS_INT
    virtual bool set(bool,bool error=true);
#endif

    virtual bool get(STRING&,bool error=true);
    virtual bool get(int&,bool error=true);
    virtual bool get(double&,bool error=true);
#ifndef BOOL_IS_INT
    virtual bool get(bool&,bool error=true);
#endif
}; 

ZCLASS STD_MODIFY_INFO : public MODIFY_INFO { 
  public : 
    STD_MODIFY_INFO(); 
    STD_MODIFY_INFO(STRING nm, double&  val); 
    STD_MODIFY_INFO(STRING nm, int&     val, bool val_is_bool=FALSE); 
#ifndef BOOL_IS_INT
    STD_MODIFY_INFO(STRING nm, bool&     val); 
#endif
    STD_MODIFY_INFO(STRING nm, STRING&  val); 

    STD_MODIFY_INFO(STRING nm, BUFF_LIST<STRING>& val);        // strings listed in s_dat[0]
    STD_MODIFY_INFO(STRING nm, LIST<STRING>& val);             // strings listed in s_dat[0]
    STD_MODIFY_INFO(STRING nm, LIST<int>& val);                // ints listed in s_dat[0]

#ifndef SKIP_STD_FUNCTION
    STD_MODIFY_INFO(STRING nm, FUNCTION& val);
    STD_MODIFY_INFO(STRING nm, LIST<FUNCTION*>& val);
#endif
    STD_MODIFY_INFO(STRING nm, VECTOR& val);
    STD_MODIFY_INFO(STRING nm, STRING tok, int& val);
    STD_MODIFY_INFO(STRING nm, ARRAY<STRING>& tok, int& val);

    STD_MODIFY_INFO(const STD_MODIFY_INFO& mod); 
    virtual ~STD_MODIFY_INFO(); 
   
    double get_double(int index=0); 
    int    get_int(int index=0); 

    virtual void reset_subject(); 
};

ZCLASS MODIFY_INFO_RECORD {
   public :
     bool    required;

     bool    was_read;
   
     void *ptr,*ptr2;

     STRING  info;

     BUFF_LIST<MODIFY_INFO*>        data;
     BUFF_LIST<MODIFY_INFO_RECORD*> commands;

     MODIFY_INFO_RECORD(); 
     MODIFY_INFO_RECORD(const MODIFY_INFO_RECORD& mod); 

     MODIFY_INFO* get_info_named(STRING name); 

     virtual ~MODIFY_INFO_RECORD(); 

     virtual void reset_records(); 

     void write(Zofstream&);
     void load(ASCII_FILE&);

     bool read_data_fields(ASCII_FILE& file,MODIFY_INFO_RECORD* modif);
     void write_item(Zofstream& out, MODIFY_INFO_RECORD* cmd,  MODIFY_INFO& info, bool stars=TRUE);
};

#define ADD_SINGLE_CMD_TO_MODIF_REC(keyword, variable) \
  MODIFY_INFO_RECORD* keyword##_cmd = new MODIFY_INFO_RECORD; \
  keyword##_cmd->info = #keyword ;   \
  keyword##_cmd->data.add(new STD_MODIFY_INFO( #keyword , variable)); \
  ret->commands.add( keyword##_cmd );

#define ADD_DOUBLE_CMD_TO_MODIF_REC(keyword, variable1, variable2) \
  MODIFY_INFO_RECORD* keyword##_cmd = new MODIFY_INFO_RECORD; \
  keyword##_cmd->info = #keyword ;   \
  keyword##_cmd->data.add(new STD_MODIFY_INFO( #keyword , variable1)); \
  keyword##_cmd->data.add(new STD_MODIFY_INFO( #keyword , variable2)); \
  ret->commands.add( keyword##_cmd );

#define ADD_BIG_STRING_TO_MODIF_REC(keyword, variable) \
  MODIFY_INFO_RECORD* keyword##_cmd = new MODIFY_INFO_RECORD; \
  keyword##_cmd->info = #keyword ;   \
  keyword##_cmd->data.add(new STD_MODIFY_INFO( #keyword , variable)); \
  keyword##_cmd->data->last()->format = MODIFY_INFO::MOD_SVAL_POPUP ;   \
  ret->commands.add( keyword##_cmd );

#define SET_PROPERTY(prop) ret->commands.last()->data.last()->property=prop;
#define SET_PARAM2(p1,p2) ret->commands.last()->data.last()->p_params[0]=&p1; ret->commands.last()->data.last()->p_params[1]=&p2;
#define SET_PARAM3(p1,p2,p3) ret->commands.last()->data.last()->p_params[0]=&p1; ret->commands.last()->data.last()->p_params[1]=&p2; ret->commands.last()->data.last()->p_params[2]=&p3;
#define SET_PARAM4(p1,p2,p3,p4) ret->commands.last()->data.last()->p_params[0]=&p1; ret->commands.last()->data.last()->p_params[1]=&p2; ret->commands.last()->data.last()->p_params[2]=&p3; ret->commands.last()->data.last()->p_params[3]=&p4;

//
// Val should be TRUE or FALSE .. 
//
// 
// Note the bool(TRUE) indicates that the value is a bool, and not an int 
// 

#ifndef BOOL_IS_INT

#define ADD_SINGLE_BOOL_TO_MODIF_REC(keyword, variable) \
  MODIFY_INFO_RECORD* keyword##_cmd = new MODIFY_INFO_RECORD; \
  keyword##_cmd->info = #keyword ;   \
  keyword##_cmd->data.add(new STD_MODIFY_INFO( STRING( #keyword ), (bool&)(variable) )); \
  keyword##_cmd->data.last()->format = MODIFY_INFO::MOD_BOOL ;   \
  ret->commands.add( keyword##_cmd );

#else

#define ADD_SINGLE_BOOL_TO_MODIF_REC(keyword, variable) \
  MODIFY_INFO_RECORD* keyword##_cmd = new MODIFY_INFO_RECORD; \
  keyword##_cmd->info = #keyword ;   \
  keyword##_cmd->data.add(new STD_MODIFY_INFO( STRING( #keyword ), (int&)(variable), bool(TRUE))); \
  keyword##_cmd->data.last()->format = MODIFY_INFO::MOD_BOOL ;   \
  ret->commands.add( keyword##_cmd );

#endif
Z_END_NAMESPACE;

#endif
