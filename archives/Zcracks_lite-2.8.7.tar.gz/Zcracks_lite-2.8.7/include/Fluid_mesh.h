#ifndef __Fluid_mesh__
#define __Fluid_mesh__

#include <Mesh.h>

Z_START_NAMESPACE;

ZCLASS2 FLUID_MESH : public MESH {
   public :
      virtual ~FLUID_MESH() {}
      RTTI_INFO;
};
Z_END_NAMESPACE;

#endif
